# Hotfix Feed & Video Web — Kocehind 2.18.0 / Feed Fast Resume R1

## Tujuan

Mengurangi jeda saat video pertama dibuka di web dan mempertahankan tampilan For You ketika pengguna berpindah ke Profil, Kotak Masuk, atau halaman SPA lain lalu kembali ke Beranda.

## Perubahan

1. `warmVideo()` tidak lagi menunggu registrasi/aktivasi Service Worker sebelum menyiapkan sumber video di elemen `<video>`. Registrasi Service Worker tetap berjalan di latar belakang.
2. Prefetch video berikutnya dibatasi satu video dan baru dimulai setelah video yang sedang ditonton mencapai `canplaythrough`. Prefetch dilewati pada mode hemat data atau jaringan 2G/slow-2G agar tidak mengalahkan bandwidth video aktif.
3. Tampilan For You dan Mengikuti disimpan sebagai DOM view selama sesi SPA. Saat meninggalkan feed, video aktif dijeda, elemen video aktif dan buffer-nya dipertahankan, posisi scroll dan pagination tetap tersimpan. Saat kembali, DOM yang sama dipasang lagi tanpa meminta feed dari API untuk kedua kalinya.
4. Feed yang sedang menunggu respons API menampilkan skeleton pemuatan sehingga area konten tidak kosong hitam.
5. Cache feed dibersihkan saat logout/pergantian akun, pemblokiran akun, penghapusan video, perubahan privasi video, atau penyegaran feed secara eksplisit.
6. Versi query asset JS/CSS dan URL Service Worker dinaikkan agar browser tidak memakai modul lama dari cache.

## File utama

- `websites/web/app.js`
- `websites/web/media-playback.js`
- `websites/web/session-video.js`
- `websites/web/social-ui.css`
- `websites/web/index.html`
- `websites/web/test-feed-fast-resume-v2181.mjs`
- `websites/web/test-feed-fast-resume-v2181-browser.mjs`

## Validasi pada lingkungan pembuatan paket

- `node --check` untuk `app.js`, `media-playback.js`, `session-video.js`, dan kedua file tes: lulus.
- Tes unit `test-feed-fast-resume-v2181.mjs`: 1/1 lulus. Tes memastikan sumber video foreground tidak tertunda oleh Service Worker dan hanya satu video berikutnya diprefetch setelah video aktif siap.
- Tes browser end-to-end disertakan. Eksekusinya pada lingkungan pembuatan paket terhalang kebijakan Chromium yang memblokir alamat HTTP localhost (`ERR_BLOCKED_BY_ADMINISTRATOR`), sehingga hasil browser end-to-end tidak diklaim lulus di lingkungan ini. Jalankan ulang pada runner CI/VPS yang mengizinkan browser mengakses server fixture lokal.
- Paket UI dan ZIP source diverifikasi kembali melalui manifest/checksum setelah arsip dibangun.

## Penerapan

Hotfix ini hanya mengubah website; tidak mengubah API, skema database, saldo, konfigurasi `.env`, atau aplikasi Flutter. Tidak perlu build APK/AAB maupun restart API.

```bash
sudo python3 UPDATE_UI_WEB.py --check
sudo python3 UPDATE_UI_WEB.py
```

Untuk update terpadu yang juga menjalankan jalur backend dan memverifikasi Hotfix Inbox Web:

```bash
sudo python3 UPDATE_BACKEND_WEB.py --check
sudo python3 UPDATE_BACKEND_WEB.py
```

Jalankan satu jalur update yang sesuai kebutuhan, bukan keduanya secara berurutan tanpa alasan. Installer UI membuat release baru dan rollback record sebelum mengaktifkannya.

## Batasan

Cache DOM feed bertahan selama tab web SPA tetap terbuka. Jika tab dimuat ulang atau browser ditutup, feed diambil kembali dari API. Waktu respons awal API dan waktu unduh media tetap bergantung pada jaringan pengguna, origin media, dan kondisi server produksi.
