# Kocehind v2.18.0 dengan pembaruan UI web sosial

Paket ini memuat source lengkap, aset web siap pasang, dan alat rilis Kocehind v2.18.0. Pembaruan UI mencakup navigasi desktop dan mobile, pencarian, profil, filter visibilitas, dan dompet. Source backend, migrasi, dan aplikasi Android sama dengan rilis dasar.

## Ekstrak dan periksa paket

Dari direktori yang berisi ZIP, jalankan:

```bash
unzip Kocehind_Full_Source_Update_Web_UI_v2.18.0.zip
cd Kocehind_v2.18.0_Sampul_Profil_Email
sha256sum -c SHA256SUMS.txt
unzip SOURCE_LENGKAP_v2.18.0.zip
(cd kocehind_realtime_v2 && sha256sum -c MANIFEST_SHA256.txt)
```

Source yang bisa dikembangkan ada di `kocehind_realtime_v2/`. Folder `websites/` di tingkat paket menyediakan salinan aset web yang sama untuk alat pemasangan.

## Pasang UI pada VPS yang sudah menjalankan v2.18.0

Jalankan dari direktori paket yang sudah diekstrak dan diverifikasi. Gunakan Bash dan akses `sudo`. Pemeriksaan checksum memastikan tiga aset yang akan diganti cocok dengan rilis dasar. Jika pemeriksaan gagal, gabungkan perubahan dengan aset yang aktif sebelum melakukan pemasangan.

```bash
set -euo pipefail
PACKAGE_ROOT="$(pwd -P)"
WEB_ROOT=/var/www/kocehind-sites

test -L "$WEB_ROOT/current"
OLD_RELEASE="$(readlink -f "$WEB_ROOT/current")"
[[ "$OLD_RELEASE" == "$WEB_ROOT/releases/"* ]]
(cd "$OLD_RELEASE" && sha256sum -c "$PACKAGE_ROOT/BASELINE_WEB_UI.sha256")

STAMP="$(date -u +%Y%m%d-%H%M%S)-ui-$$"
NEXT_RELEASE="$WEB_ROOT/releases/$STAMP"
PAYLOAD="$(mktemp -d)"
mkdir "$PAYLOAD/web"
assets=(index.html app.js wallet.js social-ui.css)
relative_paths=("${assets[@]/#/web/}")
for asset in "${assets[@]}"; do
  install -m 0644 "$PACKAGE_ROOT/websites/web/$asset" "$PAYLOAD/web/$asset"
done

sudo python3 "$PACKAGE_ROOT/kocehind_realtime_v2/backend/deploy/stage_web_release.py" \
  "$PAYLOAD" "$NEXT_RELEASE" --previous "$OLD_RELEASE"
(cd "$PAYLOAD" && sha256sum "${relative_paths[@]}") \
  | (cd "$NEXT_RELEASE" && sha256sum -c -)

test "$(readlink -f "$WEB_ROOT/current")" = "$OLD_RELEASE"
sudo ln -s "$NEXT_RELEASE" "$WEB_ROOT/.current-$STAMP"
sudo mv -Tf "$WEB_ROOT/.current-$STAMP" "$WEB_ROOT/current"
printf 'Rilis sebelumnya %s\nRilis baru %s\n' "$OLD_RELEASE" "$NEXT_RELEASE"
```

Periksa beranda, pencarian, profil, dan dompet dengan akun uji di desktop dan ponsel. Pemasangan ini hanya mengganti empat aset UI melalui symlink rilis web. Untuk peningkatan backend dari versi yang lebih lama, gunakan `PANDUAN_UPDATE_v2.18.0.md`.

## Kembali ke rilis sebelumnya

Gunakan nilai `OLD_RELEASE`, `NEXT_RELEASE`, dan `WEB_ROOT` dari sesi pemasangan.

```bash
test -d "$OLD_RELEASE" && \
test "$(readlink -f "$WEB_ROOT/current")" = "$NEXT_RELEASE" && \
sudo ln -s "$OLD_RELEASE" "$WEB_ROOT/.rollback-$$" && \
sudo mv -Tf "$WEB_ROOT/.rollback-$$" "$WEB_ROOT/current"
```
