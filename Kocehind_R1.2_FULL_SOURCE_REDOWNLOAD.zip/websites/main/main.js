import {applyApkAvailability} from './download.js?v=2.18.0';
import {api,esc,safeUrl} from '/shared/api.js?v=2.18.0';
document.querySelector('#year').textContent=new Date().getFullYear();
document.querySelector('.menu-btn').onclick=()=>document.querySelector('.site-header').classList.toggle('open');
document.querySelectorAll('nav a').forEach(a=>a.onclick=()=>document.querySelector('.site-header').classList.remove('open'));
const apk=document.querySelector('#apk-download');let ready=false;
const links=[...document.querySelectorAll('[data-apk-link]')],status=document.querySelector('#download-status');
for(const link of links)link.addEventListener('click',e=>{if(!ready){e.preventDefault();document.querySelector('#unduh').scrollIntoView({behavior:'smooth'});status.textContent='APK belum tersedia. Anda dapat mencoba Kocehind versi web sambil menunggu file aplikasi dipublikasikan.';}});
fetch('/downloads/Kocehind.apk',{method:'HEAD',cache:'no-store'}).then(async r=>{
 ready=applyApkAvailability(links,r);
 if(ready){for(const link of links){link.textContent='↓ Unduh APK Android';link.setAttribute('aria-disabled','false');link.setAttribute('href','/downloads/Kocehind.apk');link.setAttribute('download','Kocehind.apk');}status.textContent='Android · Unduhan langsung dari situs resmi Kocehind.';
 try{const metadata=await fetch('/downloads/app-info.json',{cache:'no-store'}).then(r=>r.ok?r.json():null);if(metadata?.bytes)document.querySelector('#apk-file-info').textContent='Ukuran file '+(metadata.bytes/1024/1024).toFixed(1)+' MB · Diperbarui '+new Date(metadata.published_at).toLocaleDateString('id-ID');}catch{}
 }else{apk.textContent='APK belum tersedia';status.textContent='APK belum dipublikasikan. Gunakan versi web untuk mencoba Kocehind sekarang.';}
}).catch(()=>{status.textContent='Unduhan belum dapat diperiksa. Muat ulang halaman atau buka versi web.';});
api('/feed?limit=4').then(r=>{if(r.items.length)document.querySelector('#community-posts').innerHTML=r.items.map(p=>`<a class="community-card" href="https://vt.kocehind.web.id/${encodeURIComponent(p.id)}"><img src="${esc(safeUrl(p.thumbnail_url))}" alt="${esc(p.caption||'Cerita @'+p.author.username)}" loading="lazy"><strong>@${esc(p.author.username)}</strong><p>${esc(p.caption)}</p></a>`).join('');}).catch(()=>{});
