import {api,openDialog,busy,esc,toast,date,setMe} from './api.js?v=2.18.0';

export function verifyEmailDialog(challenge) {
  return new Promise(resolve=>{
    let token=challenge,completed=false;
    const d=openDialog('Verifikasi email',
      '<p>Masukkan kode enam digit yang dikirim ke email akun. Berlaku 15 menit.</p>'+
      '<form><label>Kode verifikasi<input name="code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code" required></label>'+
      '<p class="form-error" role="alert"></p><button class="btn primary" type="submit">Verifikasi dan masuk</button></form>'+
      '<button class="text-btn" id="resend-code">Kirim ulang kode</button>');
    const f=d.querySelector('form'),resend=d.querySelector('#resend-code');
    f.onsubmit=async event=>{
      event.preventDefault();busy(f,true);resend.disabled=true;
      try {
        const result=await api('/web/auth/verify-email',{method:'POST',refresh:false,
          body:{challenge:token,code:new FormData(f).get('code')}});
        completed=true;resolve(result);d.close();
      } catch(error){f.querySelector('.form-error').textContent=error.message;}
      finally{busy(f,false);resend.disabled=false;}
    };
    resend.onclick=async()=>{
      resend.disabled=true;
      try{const r=await api('/auth/resend-verification',{method:'POST',refresh:false,body:{challenge:token}});
        token=r.challenge;toast(r.message);
      }catch(error){f.querySelector('.form-error').textContent=error.message;}
      finally{resend.disabled=false;}
    };
    d.addEventListener('close',()=>{if(!completed)resolve(null);});
  });
}

export function passwordResetDialog(challenge='') {
  let token=challenge;
  const d=openDialog('Pulihkan password',
    '<p>Kode dikirim ke email pemilik akun. Administrator tidak meminta password atau kode Anda.</p>'+
    '<form id="reset-request"><label>Username atau email<input name="identifier" minlength="3" maxlength="254" required autocomplete="username"></label>'+
    '<button class="btn" type="submit">Kirim kode pemulihan</button><p class="form-error" role="alert"></p></form>'+
    '<form id="reset-confirm"><label>Kode enam digit<input name="code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" required autocomplete="one-time-code"></label>'+
    '<label>Password baru<input name="password" type="password" minlength="10" maxlength="128" required autocomplete="new-password"></label>'+
    '<label>Ulangi password baru<input name="confirmation" type="password" minlength="10" maxlength="128" required autocomplete="new-password"></label>'+
    '<p class="form-error" role="alert"></p><button class="btn primary" type="submit">Simpan password</button></form>');
  const request=d.querySelector('#reset-request'),confirm=d.querySelector('#reset-confirm');
  confirm.hidden=!token;
  request.onsubmit=async event=>{
    event.preventDefault();busy(request,true);
    try{const r=await api('/auth/password-reset/request',{method:'POST',refresh:false,
      body:{identifier:new FormData(request).get('identifier')}});
      token=r.challenge;confirm.hidden=false;toast(r.message);
    }catch(error){request.querySelector('.form-error').textContent=error.message;}
    finally{busy(request,false);}
  };
  confirm.onsubmit=async event=>{
    event.preventDefault();busy(confirm,true);
    try{
      const values=Object.fromEntries(new FormData(confirm));
      if(values.password!==values.confirmation)throw new Error('Konfirmasi password harus sama.');
      await api('/auth/password-reset/confirm',{method:'POST',refresh:false,
        body:{challenge:token,code:values.code,password:values.password}});
      toast('Password diperbarui. Silakan masuk kembali.');d.close();
    }catch(error){confirm.querySelector('.form-error').textContent=error.message;}
    finally{busy(confirm,false);}
  };
  return d;
}

export async function mountAccountDeletion(root) {
  const [{has_password},result]=await Promise.all([
    api('/account/security'),api('/account/deletion/requests')]);
  root.innerHTML='<h2>Penghapusan akun</h2><p>Ajukan permintaan untuk ditinjau tim Kocehind. Kepemilikan dikonfirmasi melalui email.</p>'+
    '<button class="btn danger" id="request-deletion">Ajukan penghapusan akun</button>'+
    '<div id="deletion-history">'+result.items.map(x=>'<article><p><strong>'+esc(x.status)+'</strong> · '+esc(date(x.created_at))+
      '</p><p>'+esc(x.resolution||'')+'</p>'+(x.status==='pending'?'<button class="text-btn" data-cancel="'+esc(x.id)+'">Batalkan permintaan</button>':'')+'</article>').join('')+'</div>';
  root.querySelectorAll('[data-cancel]').forEach(button=>button.onclick=async()=>{
    button.disabled=true;
    try{await api('/account/deletion/requests/'+encodeURIComponent(button.dataset.cancel)+'/cancel',{method:'POST'});
      await mountAccountDeletion(root);
    }catch(error){toast(error.message);button.disabled=false;}
  });
  root.querySelector('#request-deletion').onclick=()=>{
    let token='';
    const d=openDialog('Ajukan penghapusan akun','<form>'+
      (has_password?'<label>Password saat ini<input type="password" name="password" required autocomplete="current-password"></label>':'')+
      '<label>Alasan<textarea name="reason" minlength="3" maxlength="2000" required></textarea></label>'+
      '<label id="deletion-code-label" hidden>Kode dari email<input name="code" inputmode="numeric" maxlength="6"></label>'+
      '<p class="form-error" role="alert"></p><button class="btn danger" type="submit">Kirim kode konfirmasi</button></form>');
    const f=d.querySelector('form');
    f.onsubmit=async event=>{
      event.preventDefault();busy(f,true);
      try{const values=Object.fromEntries(new FormData(f));
        if(!token){
          const r=await api('/account/deletion/code',{method:'POST',body:{password:values.password||''}});
          token=r.challenge;f.querySelector('#deletion-code-label').hidden=false;
          f.querySelector('[name="code"]').required=true;f.querySelector('[name="code"]').pattern='[0-9]{6}';
          f.querySelector('button').textContent='Konfirmasi permintaan penghapusan';
        }else{
          await api('/account/deletion/requests',{method:'POST',body:{challenge:token,code:values.code,reason:values.reason}});
          d.close();toast('Permintaan diterima untuk ditinjau.');await mountAccountDeletion(root);
        }
      }catch(error){f.querySelector('.form-error').textContent=error.message;}
      finally{busy(f,false);}
    };
  };
}

export async function changeEmailDialog(onChanged=()=>{}) {
 const {has_password}=await api('/account/security');
 let challenge='',ownerChallenge='',destination='',resendAt=0,ownerAt=0,closed=false;
 const d=openDialog('Ubah email','<p>Email lama tetap aktif sampai kode dari email baru berhasil diverifikasi. Kode berlaku 15 menit.</p><form>'+
  '<div data-start><label>Email baru<input type="email" name="new_email" maxlength="254" autocomplete="email" required></label>'+
  (has_password?'<label>Password saat ini<input type="password" name="password" maxlength="128" autocomplete="current-password" required></label>':'<p>Konfirmasi kepemilikan melalui email saat ini.</p><button type="button" class="btn" data-owner>Kirim kode ke email saat ini</button><label>Kode dari email saat ini<input name="owner_code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code" required></label>')+
  '</div><div data-confirm hidden><p data-destination></p><label>Kode dari email baru<input name="code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code" disabled></label><button type="button" class="text-btn" data-resend>Kirim ulang kode</button></div><p class="form-error" role="alert"></p><button type="submit" class="btn primary">Kirim kode ke email baru</button></form>');
 const f=d.querySelector('form'),resend=d.querySelector('[data-resend]'),owner=d.querySelector('[data-owner]'),error=f.querySelector('.form-error');
 const remaining=at=>Math.max(0,Math.ceil((at-Date.now())/1000));
 function tick(){if(closed)return;const active=f.dataset.sending==='true';resend.disabled=active||remaining(resendAt)>0;resend.textContent=remaining(resendAt)>0?'Kirim ulang dalam '+remaining(resendAt)+' detik':'Kirim ulang kode';if(owner){owner.disabled=active||remaining(ownerAt)>0;owner.textContent=remaining(ownerAt)>0?'Kirim ulang dalam '+remaining(ownerAt)+' detik':'Kirim kode ke email saat ini';}}
 function working(value){f.dataset.sending=String(value);busy(f,value);if(!value){f.querySelectorAll('[data-start] input').forEach(input=>input.disabled=!!challenge);f.querySelector('[name=code]').disabled=!challenge;}tick();}
 const timer=setInterval(tick,1000);d.addEventListener('close',()=>{closed=true;clearInterval(timer);f.reset();});
 if(owner)owner.onclick=async()=>{working(true);error.textContent='';try{const result=await api('/account/email/owner-code',{method:'POST'});if(closed)return;ownerChallenge=result.challenge;ownerAt=Date.now()+60000;toast('Kode dikirim ke email saat ini.');}catch(e){error.textContent=e.message;}finally{if(!closed)working(false);}};
 resend.onclick=async()=>{working(true);error.textContent='';try{const result=await api('/account/email/resend',{method:'POST',body:{challenge}});if(closed)return;challenge=result.challenge;resendAt=Date.now()+60000;f.querySelector('[name=code]').value='';toast('Kode baru dikirim.');}catch(e){error.textContent=e.message;}finally{if(!closed)working(false);}};
 f.onsubmit=async event=>{event.preventDefault();if(f.dataset.sending==='true')return;const data=Object.fromEntries(new FormData(f));working(true);error.textContent='';try{
  if(!challenge){const result=await api('/account/email/request',{method:'POST',body:{new_email:data.new_email,password:data.password||'',...(!has_password?{owner_challenge:ownerChallenge,owner_code:data.owner_code}:{})}});if(closed)return;challenge=result.challenge;destination=result.new_email;resendAt=Date.now()+60000;f.querySelector('[data-start]').hidden=true;f.querySelector('[data-confirm]').hidden=false;f.querySelector('[data-destination]').textContent='Kode dikirim ke '+destination;f.querySelector('[name=password]')?.value&&(f.querySelector('[name=password]').value='');f.querySelector('[name=code]').required=true;f.querySelector('[type=submit]').textContent='Verifikasi dan ubah email';
  }else{const result=await api('/web/account/email/confirm',{method:'POST',body:{challenge,code:data.code}});setMe(result.user);d.close();toast('Email berhasil diubah dan diverifikasi.');await onChanged();}
 }catch(e){if(!closed)error.textContent=e.message;}finally{if(!closed)working(false);}};
 return d;
}
