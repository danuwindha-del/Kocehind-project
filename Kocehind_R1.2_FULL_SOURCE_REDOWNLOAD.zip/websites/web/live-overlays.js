import {api,esc,safeUrl,openDialog,toast} from '/shared/api.js?v=2.18.0';

export function clampOverlay(item,x,y){return {...item,x:Math.max(0,Math.min(1-item.width,x)),y:Math.max(0,Math.min(1-item.height,y))};}
export function resizeOverlayBox(item,width,height){return clampOverlay({...item,width:Math.max(.08,Math.min(1,width)),height:Math.max(.04,Math.min(1,height)),image_fit:'fill'},item.x,item.y);}
function bindOverlayGesture(node,item,stage,onMove){
 const points=new Map();let draft={...item},base={...item},anchor,axis='move';
 const bounds=()=>stage.getBoundingClientRect();
 const metrics=()=>{const p=[...points.values()],a=p[0],b=p[1]||a;return {x:(a.x+b.x)/2,y:(a.y+b.y)/2,distance:Math.hypot(a.x-b.x,a.y-b.y)};};
 const place=value=>{Object.assign(node.style,{left:`${value.x*100}%`,top:`${value.y*100}%`,width:`${value.width*100}%`,height:`${value.height*100}%`});const image=node.querySelector('img');if(image)image.style.objectFit=value.image_fit==='fill'?'fill':'contain';};
 const rebase=()=>{base={...draft};anchor=metrics();};
 node.onpointerdown=e=>{if(e.button!==0)return;e.preventDefault();e.stopPropagation();points.set(e.pointerId,{x:e.clientX,y:e.clientY});if(!node.dragging){draft={...item};axis=e.target?.closest?.('[data-resize]')?.dataset.resize||'move';}if(points.size>1)axis='scale';node.dragging=true;node.setPointerCapture?.(e.pointerId);rebase();};
 node.onpointermove=e=>{if(!points.has(e.pointerId))return;e.preventDefault();e.stopPropagation();points.set(e.pointerId,{x:e.clientX,y:e.clientY});const b=bounds(),m=metrics();if(!b.width||!b.height)return;const dx=(m.x-anchor.x)/b.width,dy=(m.y-anchor.y)/b.height;
  if(axis==='scale'&&anchor.distance>0){const scale=m.distance/anchor.distance;draft=resizeOverlayBox(base,base.width*scale,base.height*scale);draft=clampOverlay(draft,base.x+dx,base.y+dy);}
  else if(axis==='move')draft=clampOverlay(base,base.x+dx,base.y+dy);
  else draft=resizeOverlayBox(base,base.width+(axis==='height'?0:dx),base.height+(axis==='width'?0:dy));
  place(draft);
 };
 node.onpointerup=e=>{if(!points.has(e.pointerId))return;e.stopPropagation();points.delete(e.pointerId);if(points.size){axis=points.size>1?'scale':'move';rebase();return;}node.dragging=false;if(JSON.stringify(draft)!==JSON.stringify(item))onMove?.(draft);};
 node.onpointercancel=e=>{e.stopPropagation();points.clear();node.dragging=false;place(item);};
}
export function resizeImageOverlay(item,size){
 const longest=Math.max(item.width,item.height),w=item.width/longest,h=item.height/longest;
 const target=Math.min(1,Math.max(size,.08/w,.04/h));
 return clampOverlay({...item,width:w*target,height:h*target},item.x,item.y);
}
export function newOverlay(kind){return {id:crypto.randomUUID(),kind,x:.15,y:.2,width:.7,height:kind==='image'?.4:.2,text:'',color:'#FFFFFF',background:null,font_size:.05};}

export function renderLiveOverlays(stage,state,{editable=false,onMove}={}){
 let layer=stage.querySelector(':scope > .live-canvas');
 if(!layer){layer=document.createElement('div');layer.className='live-canvas';stage.append(layer);}
 layer.classList.toggle('editing',editable);
 const items=state?.items||[],ids=new Set(items.map(i=>i.id));
 for(const node of layer.children)if(!ids.has(node.dataset.overlay))node.remove();
 for(const item of items){
  let node=[...layer.children].find(n=>n.dataset.overlay===item.id);
  if(!node){node=document.createElement('div');node.className='live-canvas-item';node.dataset.overlay=item.id;layer.append(node);}
  if(node.dragging)continue;
  layer.append(node); // Preserve the saved stacking order when bringing an element forward.
  const signature=JSON.stringify([item,editable]);
  if(signature!==node.signature){
   node.signature=signature;node.replaceChildren();node.classList.toggle('is-text',item.kind==='text');
   if(item.kind==='image'){const image=document.createElement('img');image.src=safeUrl(item.image_url);image.alt='Gambar peserta LIVE';image.draggable=false;image.style.objectFit=item.image_fit==='fill'?'fill':'contain';node.append(image);
    if(editable)for(const [axis,label,glyph] of [['width','Lebarkan gambar','↔'],['height','Ubah tinggi gambar','↕'],['both','Perbesar gambar','↗']]){const handle=document.createElement('button');handle.type='button';handle.className='live-resize-handle '+axis;handle.dataset.resize=axis;handle.setAttribute('aria-label',label);handle.title=label;handle.textContent=glyph;node.append(handle);}
   }
   else {const label=document.createElement('span');label.textContent=item.text;label.style.color=item.color;label.style.backgroundColor=item.background||'transparent';label.style.fontSize=`${item.font_size*stage.clientWidth}px`;node.append(label);}
  }else if(item.kind==='text')node.firstElementChild.style.fontSize=`${item.font_size*stage.clientWidth}px`;
  function position(value){Object.assign(node.style,{left:`${value.x*100}%`,top:`${value.y*100}%`,width:`${value.width*100}%`,height:`${value.height*100}%`});}
  position(item);node.setAttribute('aria-label',item.kind==='text'?'Teks LIVE: '+item.text:'Gambar LIVE');
  if(editable)bindOverlayGesture(node,item,stage,onMove);
  else node.onpointerdown=node.onpointermove=node.onpointerup=node.onpointercancel=null;
  node.onclick=editable?e=>{e.stopPropagation();}:null;
 }
}

export function openLiveOverlays({getState,save,startDragging,roomId,guest=false}){
 const dialog=openDialog(guest?'Gambar di kotak Anda':'Gambar & teks LIVE','<p>Tambah gambar dari galeri atau teks. Setelah disimpan, pilih Geser di layar untuk menempatkannya.</p><div class="buttons"><button class="btn" data-add-image>+ Gambar galeri</button><button class="btn" data-add-text>+ Teks</button><button class="btn primary" data-drag>Geser di layar</button></div><input type="file" accept="image/jpeg,image/png,image/webp" data-image hidden><div data-items></div><p class="form-error" role="alert"></p>');
 if(guest){dialog.querySelector('[data-add-text]').remove();dialog.querySelector('.dialog-body p')?.replaceChildren(document.createTextNode('Gambar galeri hanya tampil di dalam kotak tamu Anda. Maksimal 4 gambar.'));}const limit=guest?4:12;const error=dialog.querySelector('.form-error'),list=dialog.querySelector('[data-items]');let busy=false;
 const fail=e=>error.textContent=e.message;
 async function commit(items){if(busy)return false;busy=true;error.textContent='';dialog.querySelectorAll('button').forEach(b=>b.disabled=true);try{await save(items);draw();return true;}catch(e){fail(e);return false;}finally{busy=false;dialog.querySelectorAll('button').forEach(b=>b.disabled=false);}}
 function draw(){list.innerHTML=(getState().items||[]).map(item=>`<div class="live-overlay-row"><strong>${item.kind==='image'?'Gambar galeri':esc(item.text)}</strong><button class="btn small" data-edit="${esc(item.id)}">Edit</button><button class="btn small" data-front="${esc(item.id)}">Ke depan</button><button class="btn small danger" data-delete="${esc(item.id)}">Hapus</button></div>`).join('')||'<p>Belum ada gambar atau teks.</p>';
  list.querySelectorAll('[data-front]').forEach(b=>b.onclick=()=>{const items=getState().items,item=items.find(i=>i.id===b.dataset.front);commit([...items.filter(i=>i.id!==item.id),item]);});
  list.querySelectorAll('[data-delete]').forEach(b=>b.onclick=()=>commit(getState().items.filter(i=>i.id!==b.dataset.delete)));
  list.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>edit(getState().items.find(i=>i.id===b.dataset.edit)));
 }
 function edit(original){
  let item={...original};const text=item.kind==='text';
  const d=openDialog(text?'Teks LIVE':'Ukuran gambar',`<form>${text?`<label>Teks<textarea name="text" required maxlength="200" rows="3">${esc(item.text)}</textarea></label><label>Versi teks<select name="style"><option value="plain" ${item.background?'':'selected'}>Teks biasa</option><option value="background" ${item.background?'selected':''}>Teks berbackground</option></select></label><label>Warna background<input name="background" type="color" value="${esc(item.background||'#000000')}"></label><label>Warna teks<input name="color" type="color" value="${esc(item.color)}"></label><label>Ukuran teks<input name="font_size" type="range" min="0.02" max="0.12" step="0.005" value="${item.font_size}"></label>`:''}${!text?`<label>Ukuran gambar<input name="image_size" type="range" min="0.08" max="1" step="0.01" value="${Math.max(item.width,item.height)}"></label><button type="button" class="btn" data-fill-stage>Penuhi kotak LIVE</button>`:''}<label>Lebar<input name="width" type="range" min="0.08" max="1" step="0.01" value="${item.width}"></label><label>Tinggi<input name="height" type="range" min="0.04" max="1" step="0.01" value="${item.height}"></label><div class="live-overlay-preview" aria-label="Pratinjau elemen"></div><p class="form-error" role="alert"></p><button type="submit" class="btn primary">Simpan ke LIVE</button></form>`),f=d.querySelector('form');
  function value(){const fd=new FormData(f);return clampOverlay({...item,...(text?{text:String(fd.get('text')).trim(),background:fd.get('style')==='background'?fd.get('background'):null,color:fd.get('color'),font_size:Number(fd.get('font_size'))}:{}),width:Number(fd.get('width')),height:Number(fd.get('height')),...(!text?{image_fit:'fill'}:{})},item.x,item.y);}
  function preview(){const v=value(),p=d.querySelector('.live-overlay-preview');
   Object.assign(p.style,{position:'relative',height:'auto',aspectRatio:'9 / 16',width:'min(100%, 210px)',margin:'12px auto'});
   renderLiveOverlays(p,{items:[v]});
   if(text)f.elements.background.disabled=f.elements.style.value==='plain';
   else f.elements.image_size.value=Math.max(v.width,v.height);
  }
  if(!text){
   f.elements.image_size.oninput=event=>{event.stopPropagation();item=resizeImageOverlay(value(),Number(event.target.value));f.elements.width.value=item.width;f.elements.height.value=item.height;preview();};
   f.querySelector('[data-fill-stage]').onclick=()=>{item={...value(),x:0,y:0,width:1,height:1};f.elements.width.value=1;f.elements.height.value=1;preview();};
  }
  f.oninput=preview;preview();f.onsubmit=async event=>{event.preventDefault();const changed=value();if(text&&!changed.text)return;const items=[...(getState().items||[])],index=items.findIndex(i=>i.id===item.id);if(index<0)items.push(changed);else items[index]=changed;const ok=await commit(items);if(ok)d.close();else d.querySelector('.form-error').textContent=error.textContent;};
 }
 const addText=dialog.querySelector('[data-add-text]');if(addText)addText.onclick=()=>{if(getState().items.length>=limit){fail(new Error(guest?'Maksimal 4 gambar di kotak Anda':'Maksimal 12 elemen LIVE'));return;}edit(newOverlay('text'));};
 const input=dialog.querySelector('[data-image]');dialog.querySelector('[data-add-image]').onclick=()=>input.click();
 input.onchange=async()=>{const file=input.files?.[0];input.value='';if(!file||busy)return;if(getState().items.length>=limit){fail(new Error(guest?'Maksimal 4 gambar di kotak Anda':'Maksimal 12 elemen LIVE'));return;}if(file.size>10*1024*1024){fail(new Error('Gambar maksimal 10 MB'));return;}
  try{busy=true;error.textContent='Mengunggah gambar…';const body=new FormData();body.set('file',file);const result=await api('/media/upload',{method:'POST',body});error.textContent='Memeriksa ketelanjangan dan gore/darah pada gambar…';let scan=await api('/live/rooms/'+roomId+'/overlay-assets',{method:'POST',body:{media_url:result.media_url}});const deadline=Date.now()+60000;while(scan.status==='pending'&&Date.now()<deadline&&dialog.open){await new Promise(resolve=>setTimeout(resolve,1000));scan=await api('/live/rooms/'+roomId+'/overlay-assets/'+scan.id);}if(!dialog.open)return;if(scan.status!=='approved')throw new Error(scan.status==='rejected'?scan.message:'Pemeriksaan masih berjalan. Coba lagi sesaat; gambar belum ditayangkan.');busy=false;await commit([...getState().items,{...newOverlay('image'),media_url:result.media_url}]);}catch(e){fail(e);}finally{busy=false;}
 };
 dialog.querySelector('[data-drag]').onclick=()=>{startDragging();dialog.close();toast('Geser gambar atau teks pada layar. Ketuk Selesai geser setelah selesai.');};draw();
 return dialog;
}
