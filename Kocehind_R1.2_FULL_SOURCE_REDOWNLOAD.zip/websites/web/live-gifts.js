export function isExclusiveVideoGift(g){return g.display_mode==='exclusive_video'&&g.exclusive_video===true&&Boolean(g.video_url);}
import {api,esc,openDialog,safeUrl,toast} from '/shared/api.js?v=2.18.0';
import {keyedAction} from './wallet.js?v=2.18.0';
export async function giftPicker(rid){
 const [catalog,balance]=await Promise.all([api('/gifts/catalog'),api('/wallet')]);let coins=balance.coins;
 const d=openDialog('Kirim gift',`<p>Saldo <strong id="gift-coins">${coins}</strong> koin <button class="btn small" id="gift-refresh" type="button">Segarkan saldo</button></p><form><div class="gift-grid">${catalog.items.map((g,i)=>`<label><input type="radio" name="gift" value="${esc(g.id)}" ${i?'':'checked'} required><img src="${esc(safeUrl(g.image_url))}" alt="${esc(g.name)}"><strong>${esc(g.name)}</strong><small>${g.coins} koin${g.video_url?' · Video':''}</small></label>`).join('')}</div><p class="form-error" role="alert"></p><div class="buttons"><button class="btn primary" type="submit">Kirim gift</button><a class="btn" href="/wallet" target="_blank" rel="noopener">Top up koin</a></div></form>`),f=d.querySelector('form'),send=keyedAction(body=>api('/live/rooms/'+encodeURIComponent(rid)+'/gifts',{method:'POST',body}));
 d.querySelector('#gift-refresh').onclick=async e=>{e.target.disabled=true;try{const w=await api('/wallet');coins=w.coins;d.querySelector('#gift-coins').textContent=coins;}catch(error){f.querySelector('.form-error').textContent=error.message;}finally{e.target.disabled=false;}};
 f.onsubmit=async e=>{e.preventDefault();const b=f.querySelector('[type=submit]');b.disabled=true;try{const r=await send({gift_id:new FormData(f).get('gift')});coins=r.coins;d.querySelector('#gift-coins').textContent=coins;f.querySelector('.form-error').textContent='';toast('Gift terkirim');}catch(error){f.querySelector('.form-error').textContent=error.message;}finally{b.disabled=false;}};
}
export function mountGiftOverlay(root,rid){
 let stopped=false,cursor=null,busy=false,current=false,queue=[],timer,end,video;
 const overlay=document.createElement('div');overlay.className='live-gift-overlay';root.append(overlay);
 function next(){if(stopped||current||!queue.length)return;current=true;const g=queue.shift();overlay.innerHTML=`<div class="live-gift-card"><strong>@${esc(g.sender)} mengirim ${esc(g.name)}</strong><img src="${esc(safeUrl(g.image_url))}" alt="${esc(g.name)}">${g.video_url?`<video playsinline preload="auto" src="${esc(safeUrl(g.video_url))}" aria-label="Gift video ${esc(g.name)}"></video>`:''}</div>`;
  video=overlay.querySelector('video');if(video){video.volume=.3;video.addEventListener('playing',()=>{overlay.querySelector('img').hidden=true;});video.addEventListener('error',()=>video.hidden=true);video.play().catch(()=>video.hidden=true);}
  end=setTimeout(()=>{video?.pause();overlay.replaceChildren();current=false;next();},g.duration_seconds*1000);
 }
 async function tick(){if(stopped||busy)return;busy=true;try{const r=await api('/live/rooms/'+encodeURIComponent(rid)+'/gifts?'+(cursor===null?'initialize=true':'after='+cursor));if(stopped)return;cursor=r.cursor;queue.push(...r.items.filter(isExclusiveVideoGift));if(queue.length>100)queue=queue.slice(-100);next();}catch(_){/* Retry the durable cursor. */}finally{busy=false;}}
 tick();timer=setInterval(tick,1000);
 return ()=>{stopped=true;clearInterval(timer);clearTimeout(end);video?.pause();overlay.remove();};
}
