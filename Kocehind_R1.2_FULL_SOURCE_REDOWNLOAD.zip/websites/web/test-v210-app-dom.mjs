import {installV216Deps} from './v216-test-deps.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
import {VideoCollection,MixedCollection} from './collections.js';
import {createPlaybackSignals,richText,visibilityOptions,visibilityNames,mountWatchHistory} from './v27.js';
const {JSDOM}=createRequire(import.meta.url)('jsdom');
const settle=()=>new Promise(r=>setTimeout(r,25));
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const post=id=>({id,kind:'image',caption:'Kopi '+id,media_url:'https://example.com/'+id+'.jpg',thumbnail_url:'https://example.com/'+id+'.jpg',views:125,visibility:'public',author:{id:'owner',username:'kreator',name:'Kreator'},likes:0,comments:0});
async function app(path,api,overrides={}){
 const html=(await readFile(new URL('./index.html',import.meta.url),'utf8')).replace(/<script[^>]*>.*?<\/script>/g,'');
 const dom=new JSDOM(html,{url:'https://web.kocehind.web.id'+path,runScripts:'outside-only'}),w=dom.window;
 w.__livePaths=[];w.__observers=[];w.IntersectionObserver=class{constructor(callback,options){this.callback=callback;this.options=options;this.targets=[];w.__observers.push(this);}observe(node){this.targets.push(node);}disconnect(){}emit(node,visible){this.callback([{target:node,isIntersecting:visible,intersectionRatio:visible?1:0}]);}};Object.defineProperty(w.HTMLElement.prototype,'offsetTop',{get(){return this.classList.contains('collection-entry')?[...this.parentElement.children].indexOf(this)*600:0;}});w.CSS={escape:v=>v};w.setInterval=()=>0;w.clearInterval=()=>{};
 const me={id:'viewer',username:'viewer',name:'Viewer',legal_required:false};
 w.__deps={mountMycha:async()=>{},api,me,restore:async()=>me,setMe:()=>{},logout:async()=>{},authDialog:async()=>true,requireAccount:async()=>true,requireLegalAcceptance:async()=>true,esc,safeUrl:v=>v,count:n=>String(n||0),date:v=>String(v||''),badge:()=>'',avatar:()=>'<span class="avatar">K</span>',icon:()=>'<svg></svg>',toast:()=>{},openDialog:()=>{},busy:()=>{},legalLinks:'',VideoCollection,MixedCollection,createPlaybackSignals,richText,visibilityOptions,visibilityNames,loadCommentTarget:()=>{},mountStudio:()=>{},mountWatchHistory,mountHelp:()=>{},mountCases:()=>{},mountOfficial:()=>{},mountLive:(_root,path)=>{w.__livePaths.push(path);return ()=>{};},previewHTML:l=>`<article class="live-preview-card" data-live="${l.id}"><a href="/live/${l.id}" data-link>LIVE ${l.title}</a></article>`,bindPreviews:()=>()=>{},...overrides};
 const errors=[];w.addEventListener('error',e=>errors.push(e.message));
 const source=(await readFile(new URL('./app.js',import.meta.url),'utf8')).replace(/^import\s+\{([^}]+)\}\s+from\s+[^;]+;/gm,'const {$1}=window.__deps;');
 await installV216Deps(w);w.eval(source);await settle();return {dom,w,errors};
}

test('Search route renders LIVE cards and continues mixed vertical search using its cursor',async()=>{
 const paths=[],live={id:'l1',title:'Kopi langsung',mode:'audio',viewers:2,host:{id:'host',username:'host'}};
 const {dom,w,errors}=await app('/search?q=kopi',async path=>{
  paths.push(path);
  if(path.startsWith('/search')){const more=path.includes('cursor=');return {posts:[post(more?'p2':'p1')],entries:more?[{type:'post',post:post('p2')}]:[{type:'post',post:post('p1')},{type:'live',live}],lives:[live],users:[],sounds:[],hashtags:[],next_cursor:more?null:'scope:2'};}
  if(path==='/users/me/privacy')return {revision:'one'};
  if(path.startsWith('/posts/'))return post(path.split('/').pop());
  if(path.startsWith('/live/rooms/'))return {...live,status:'active'};
  return {items:[],unread:0};
 });
 assert.equal(w.document.querySelectorAll('.live-search-card').length,1);
 assert.match(w.document.querySelector('.grid-card .views').textContent,/125/);
 w.document.querySelector('a[data-collection]').click();await settle();
 assert.equal(w.document.querySelectorAll('#feed .post').length,1);
 assert.equal(w.document.querySelectorAll('#feed .live-preview-card').length,1);
 w.document.querySelector('#feed').dispatchEvent(new w.Event('scroll'));await settle();
 assert(paths.some(p=>p.includes('cursor=scope%3A2')));
 assert.equal(w.document.querySelectorAll('#feed .post').length,2);
 assert.deepEqual(errors,[]);dom.window.close();
});

test('History route opens its clicked position and fetches next history page without For You',async()=>{
 const paths=[];
 const {dom,w,errors}=await app('/history',async path=>{
  paths.push(path);
  if(path.startsWith('/users/me/history')){const more=path.includes('cursor=');return {items:[{post:post(more?'h2':'h1'),watched_at:'2026-10-23'}],total:2,next_offset:more?null:1,next_cursor:more?null:'history:1'};}
  if(path==='/users/me/privacy')return {revision:'one'};
  if(path.startsWith('/posts/'))return post(path.split('/').pop());
  return {items:[],unread:0};
 });
 w.document.querySelector('.history-row a').click();await settle();
 assert.match(w.document.querySelector('.collection-header').textContent,/Riwayat tontonan/);
 w.document.querySelector('#feed').dispatchEvent(new w.Event('scroll'));await settle();
 assert(paths.some(p=>p.includes('cursor=history%3A1')));
 assert(!paths.some(p=>p.startsWith('/feed')));
 assert.equal(w.document.querySelectorAll('#feed .post').length,2);
 assert.deepEqual(errors,[]);dom.window.close();
});

for(const denied of [403,404,410])test('Cached history hides revoked '+denied+' between valid neighbors and keeps cursor',async()=>{
 const paths=[];
 const {dom,w}=await app('/history',async path=>{
  paths.push(path);if(path.startsWith('/users/me/history'))return {items:['before','revoked','after'].map(id=>({post:post(id)})),total:4,next_cursor:'original:3'};
  if(path==='/posts/revoked')throw Object.assign(new Error('Tidak tersedia'),{status:denied});
  if(path.startsWith('/posts/'))return post(path.split('/').pop());
  return {items:[],unread:0,revision:'one'};
 });
 w.document.querySelectorAll('.history-row a')[1].click();await settle();
 assert(paths.includes('/posts/revoked'));assert(!w.document.querySelector('.post[data-id="revoked"]'));assert(!w.document.querySelector('#feed').textContent.includes('Kopi revoked'));
 assert.deepEqual([...w.document.querySelectorAll('#feed .post')].map(n=>n.dataset.id),['before','after']);
 w.document.querySelector('#feed').dispatchEvent(new w.Event('scroll'));await settle();assert(paths.some(p=>p.includes('cursor=original%3A3')));assert(!paths.some(p=>p.startsWith('/feed')));dom.window.close();
});
test('Cached history transport error retries current detail and ignores late route result',async()=>{
 let fail=true,resolve;
 const {dom,w}=await app('/history',async path=>{
  if(path.startsWith('/users/me/history'))return {items:[{post:post('h1')}],next_cursor:null};
  if(path==='/posts/h1'){if(fail)throw Object.assign(new Error('Anda sedang Offline periksa jaringan Anda'),{status:0});return new Promise(r=>resolve=r);}
  return {items:[],unread:0,revision:'one'};
 });
 w.document.querySelector('.history-row a').click();await settle();assert.match(w.document.querySelector('#feed').textContent,/Anda sedang Offline periksa jaringan Anda/);assert(!w.document.querySelector('.post'));
 fail=false;w.document.querySelector('[data-entry-retry]').click();await settle();
 w.history.pushState({},'', '/settings');w.dispatchEvent(new w.PopStateEvent('popstate'));await settle();resolve(post('h1'));await settle();assert(!w.document.querySelector('.post'));dom.window.close();
});
for(const only of [false,true])test('Selecting non-first LIVE uses typed mixed snapshot and continues '+only,async()=>{
 const paths=[],live=id=>({id,title:id,mode:'audio',host:{id:'owner',username:'host'}});
 const {dom,w}=await app('/search?q=kopi'+(only?'&tab=lives':''),async path=>{
  paths.push(path);if(path.startsWith('/search'))return {entries:path.includes('cursor=')?[{type:'live',live:live('last')}]:[...(only?[]:[{type:'post',post:post('same')}]),{type:'live',live:live('same')},{type:'live',live:live('chosen')}],posts:[],lives:[],users:[],sounds:[],hashtags:[],next_cursor:path.includes('cursor=')?null:'live:3'};
  if(path.startsWith('/posts/'))return post(path.split('/').pop());if(path.startsWith('/live/rooms/'))return {...live(path.split('/').pop()),status:'active'};
  return {items:[],unread:0,revision:'one'};
 });
 const links=w.document.querySelectorAll('.live-search-cover');assert(links[1].dataset.collection);assert.equal(links[1].getAttribute('href'),'/live/chosen');links[1].click();await settle();
 assert.equal(w.history.state.entryType,'live');assert.equal(w.document.querySelector('#feed').scrollTop,only?600:1200);assert.equal(w.document.querySelector('[data-entry-id="chosen"]').dataset.entryType,'live');assert(w.document.querySelector('a[href="/live/chosen"]'));
 w.document.querySelector('#feed').dispatchEvent(new w.Event('scroll'));await settle();assert(paths.some(p=>p.includes('cursor=live%3A3')));assert(w.document.querySelector('[data-live="last"]'));assert(!paths.some(p=>p.startsWith('/feed')));w.document.querySelector('a[href="/live/chosen"]').click();await settle();assert.equal(w.history.state.collectionKey,undefined);assert.equal(w.__livePaths.at(-1),'/live/chosen');dom.window.close();
});

test('Cached history retries a 503 with its actual message and restores the current post',async()=>{
 let recovered=false;
 const {dom,w}=await app('/history',async path=>{
  if(path.startsWith('/users/me/history'))return {items:[{post:post('h1')}],next_cursor:null};
  if(path==='/posts/h1'){if(!recovered)throw Object.assign(new Error('Pemeliharaan server'),{status:503});return post('h1');}
  return {items:[],unread:0,revision:'one'};
 });
 w.document.querySelector('.history-row a').click();await settle();assert.match(w.document.querySelector('#feed').textContent,/Pemeliharaan server/);assert(!w.document.querySelector('.post'));recovered=true;w.document.querySelector('[data-entry-retry]').click();await settle();assert.equal(w.document.querySelector('.post').dataset.id,'h1');dom.window.close();
});
test('Cached collection only requests the selected neighborhood and rejects ended LIVE metadata',async()=>{
 const paths=[],live={id:'ended',title:'Revoked title',host:{username:'host'}};
 const {dom,w}=await app('/search?q=kopi',async path=>{
  paths.push(path);if(path.startsWith('/search'))return {entries:[...Array.from({length:20},(_,i)=>({type:'post',post:post('p'+i)})),{type:'live',live}],posts:[],lives:[],users:[],sounds:[],hashtags:[],next_cursor:null};
  if(path.startsWith('/posts/'))return post(path.split('/').pop());if(path.startsWith('/live/rooms/'))return {...live,status:'ended'};
  return {items:[],unread:0,revision:'one'};
 });
 w.document.querySelector('.live-search-cover').click();await settle();assert.deepEqual(paths.filter(p=>p.startsWith('/posts/')),['/posts/p19']);assert(!w.document.querySelector('.live-preview-card'));assert(!w.document.querySelector('#feed').textContent.includes('Revoked title'));assert.match(w.document.querySelector('#feed').textContent,/Halaman\/Page yang Anda Tuju/);dom.window.close();
});
test('Mixed lookup disambiguates a post and LIVE with the same ID',()=>{
 const source=new MixedCollection({path:'/search?q=kopi',entries:[{type:'post',post:post('same')},{type:'live',live:{id:'same'}}],next_cursor:'typed:2'});
 assert.equal(source.indexOf('same','post'),0);assert.equal(source.indexOf('same','live'),1);assert.equal(source.indexOf('same','unknown'),-1);assert.equal(source.nextURL(),'/search?q=kopi&cursor=typed%3A2');
});

test('Activating an unvalidated slot rechecks access and discards a superseded same-slot response',async()=>{
 let resolve,attempt=0;const paths=[];
 const {dom,w}=await app('/history',async path=>{
  paths.push(path);if(path.startsWith('/users/me/history'))return {items:Array.from({length:6},(_,i)=>({post:post('h'+i)})),next_cursor:'unchanged:6'};
  if(path==='/posts/h4'){if(++attempt===1)return new Promise(r=>resolve=r);throw Object.assign(new Error('Ditolak'),{status:403});}
  if(path.startsWith('/posts/'))return post(path.split('/').pop());return {items:[],unread:0,revision:'one'};
 });
 w.document.querySelector('.history-row a').click();await settle();assert(!paths.includes('/posts/h4'));
 const slot=w.document.querySelector('[data-entry-id="h4"]'),observer=w.__observers.find(o=>o.targets.includes(slot));
 observer.emit(slot,true);await settle();observer.emit(slot,false);observer.emit(slot,true);resolve(post('h4'));await settle();assert.equal(attempt,2);assert(!slot.querySelector('.post'));assert.match(slot.textContent,/Video yang Anda tuju tidak di temukan/);dom.window.close();
});
test('Social startup unavailable session offers restoration retry before the login gate',async()=>{
 let restores=0;
 const {dom,w}=await app('/history',async()=>({items:[],unread:0}),{me:null,restoreError:new Error('Anda sedang Offline periksa jaringan Anda'),restore:async()=>{restores++;return null;}});
 assert.match(w.document.querySelector('#content').textContent,/Anda sedang Offline periksa jaringan Anda/);assert(!w.document.querySelector('#gate-login'));w.document.querySelector('#session-retry').click();await settle();assert.equal(restores,2);dom.window.close();
});
