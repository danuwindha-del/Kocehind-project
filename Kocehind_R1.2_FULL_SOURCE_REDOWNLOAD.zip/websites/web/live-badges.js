// Avatar markup accepts the existing escaped avatar renderer; no SDK is loaded.
export function liveAvatarHTML(user, imageHTML, esc){
 const room=user.is_live===true?String(user.live_room_id||''):'';
 return `<span class="profile-live-avatar${room?' is-live':''}" data-live-user="${esc(user.username||'')}" data-live-room="${esc(room)}">${imageHTML}<span class="avatar-live-label" ${room?'':'hidden'}>LIVE</span></span>`;
}

export function applyLiveStatus(root,states){
 for(const node of root.querySelectorAll('[data-live-user]')){
  const state=states[node.dataset.liveUser];if(!state)continue;
  const room=state.is_live===true?String(state.live_room_id||''):'';
  node.dataset.liveRoom=room;node.classList.toggle('is-live',Boolean(room));
  const label=node.querySelector('.avatar-live-label');if(label)label.hidden=!room;
  const button=node.closest('button');if(button)button.setAttribute('aria-label',room?'@'+node.dataset.liveUser+' sedang LIVE. Buka siaran':'Profil @'+node.dataset.liveUser);
 }
}

export function visibleLiveUsers(root){
 return [...new Set([...root.querySelectorAll('[data-live-user]')].filter(n=>{
  const r=n.getBoundingClientRect();return r.width>0&&r.bottom>0&&r.top<innerHeight;
 }).map(n=>n.dataset.liveUser).filter(Boolean))].slice(0,50);
}
