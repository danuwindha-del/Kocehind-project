// A viewer owns the exact ordered collection that opened it, including pagination.
export class VideoCollection {
 constructor({label='Koleksi video',path,items=[],itemsKey='items',next_offset,next_cursor,returnURL,mapItem=item=>item,showUploadTime=false}){
  this.label=label;this.path=path;this.itemsKey=itemsKey;this.returnURL=returnURL;
  this.mapItem=mapItem;
  this.showUploadTime=showUploadTime===true;
  this.items=[];this.append({[itemsKey]:items,next_offset,next_cursor});
 }
 indexOf(id){return this.items.findIndex(item=>String(item.id)===String(id));}
 append(page){const seen=new Set(this.items.map(item=>String(item.id)));for(const raw of page[this.itemsKey]||[]){const item=this.mapItem(raw);if(item&&!seen.has(String(item.id))){this.items.push(item);seen.add(String(item.id));}}
  this.next=page.next_cursor?{key:'cursor',value:page.next_cursor}:page.next_offset!==null&&page.next_offset!==undefined?{key:'offset',value:page.next_offset}:null;
 }
 nextURL(){if(!this.path||!this.next)return null;const [path,query='']=this.path.split('?'),params=new URLSearchParams(query);params.set(this.next.key,String(this.next.value));return path+'?'+params.toString();}
}

export class MixedCollection {
 constructor({label,path,entries=[],next_cursor,returnURL}){
  this.label=label;this.path=path;this.returnURL=returnURL;this.entries=[];
  this.append({entries,next_cursor});
 }
 indexOf(id,type='post'){return this.entries.findIndex(e=>e.type===type&&String((e.type==='live'?e.live:e.post)?.id)===String(id));}
 append(page){const seen=new Set(this.entries.map(e=>e.type+':'+(e.live||e.post).id));for(const e of page.entries||[]){const key=e.type+':'+(e.live||e.post)?.id;if(!seen.has(key)){this.entries.push(e);seen.add(key);}}this.cursor=page.next_cursor??null;}
 nextURL(){return this.cursor?this.path+'&cursor='+encodeURIComponent(this.cursor):null;}
}
