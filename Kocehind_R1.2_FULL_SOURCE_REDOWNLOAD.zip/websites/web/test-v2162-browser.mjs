import {execFileSync} from 'node:child_process';
import {mkdtemp,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile,mkdir} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {createRequire} from 'node:module';
const {chromium}=createRequire(import.meta.url)('playwright');
const root=resolve(new URL('..',import.meta.url).pathname);
const owner={id:'00000000-0000-4000-8000-000000000001',username:'creator',name:'Kreator Kocehind',bio:'Cerita sehari-hari dari komunitas.',is_admin:true,legal_required:false,profile_limits:{},followers:1500,following_count:15,likes_received:4200,links:[{title:'Situs resmi',url:'https://example.com/'},{title:'Portofolio',url:'https://example.org/'}]};
const post={id:'00000000-0000-4000-8000-000000000002',caption:'Video kreator',kind:'video',media_url:'',thumbnail_url:'',author:owner,views:1234,likes:50,following:false,is_mine:true,is_pinned:false,visibility:'public',mentions:[]};
const ai={id:'youtube',title:'YouTube',summary:'YouTube menyediakan ruang untuk berbagi cerita dan membangun komunitas.\n\nProduk YouTube mencakup YouTube Music, YouTube Kids, dan YouTube Studio.',images:[],sources:[{label:'YouTube resmi',url:'https://about.youtube/'}],studied_at:'2026-10-31T00:00:00Z'};
const qa=process.env.KOCEHIND_QA_DIR||'/tmp/kocehind-qa-v216';

async function scenario(site,path,handler,run){
 const calls=[];
 const server=createServer(async(req,res)=>{
  try{
   const url=new URL(req.url,'http://fixture');
   if(url.pathname.startsWith('/api/')){
    const chunks=[];for await(const chunk of req)chunks.push(chunk);const raw=Buffer.concat(chunks);
    const call={path:url.pathname.slice(4),method:req.method,query:url.searchParams,body:req.headers['content-type']?.includes('json')&&raw.length?JSON.parse(raw):null};calls.push(call);
    let data=await handler(call);
    if(data===undefined){if(call.path==='/users/me'||call.path==='/admin/me'||call.path==='/users/creator')data=owner;else if(call.path==='/users/me/privacy')data={revision:'test'};else data={items:[],next_offset:null,unread:0};}
    if(data?.fixtureFile){res.writeHead(200,{'content-type':data.contentType});res.end(await readFile(data.fixtureFile));return;}
    res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(data));return;
   }
   const relative=url.pathname.startsWith('/shared/')?url.pathname.slice(1):/\.(js|css|png)$/.test(url.pathname)?site+url.pathname:site+'/index.html';
   const file=resolve(root,relative);if(!file.startsWith(root+'/'))throw new Error('Invalid path');
   res.writeHead(200,{'content-type':({'.js':'text/javascript','.css':'text/css','.html':'text/html','.png':'image/png'}[extname(file)]||'application/octet-stream')});res.end(await readFile(file));
  }catch{res.writeHead(404);res.end('missing');}
 });
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:390,height:844}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 try{await page.goto(origin+path);await run(page,calls);assert.deepEqual(errors,[]);}finally{await browser.close();await new Promise(r=>server.close(r));}
}

test('Activity like color/count and save color update before delayed server confirmation',async()=>{
 let releaseLike,releaseSave;const likeGate=new Promise(r=>releaseLike=r),saveGate=new Promise(r=>releaseSave=r);
 await scenario('web','/inbox',async c=>{
  if(c.path==='/notifications')return {items:[{id:'n',username:'reader',text:'Aktivitas baru',kind:'like',post_id:post.id,created_at:'2026-11-02T00:00:00Z'}],unread:1};
  if(c.path==='/posts/'+post.id)return {...post,kind:'image',liked:false,saved:false};
  if(c.path.endsWith('/like')){await likeGate;return {liked:c.body.liked,likes:51};}
  if(c.path.endsWith('/save')){await saveGate;return {saved:c.body.saved};}
 },async page=>{
  await page.locator('[data-activity]').click();await page.locator('[data-action=like]').click();
  await page.waitForFunction(()=>document.querySelector('[data-action=like]').classList.contains('active'));
  assert.equal(await page.locator('.like-count').textContent(),'51');
  assert.equal(await page.locator('[data-action=like]').isDisabled(),true);
  releaseLike();await page.waitForFunction(()=>!document.querySelector('[data-action=like]').disabled);
  await page.locator('[data-action=save]').click();
  await page.waitForFunction(()=>document.querySelector('[data-action=save]').classList.contains('active'));
  assert.equal(await page.locator('[data-action=save]').isDisabled(),true);
  releaseSave();await page.waitForFunction(()=>!document.querySelector('[data-action=save]').disabled);
  assert(new URL(page.url()).pathname.startsWith('/video/'));
 });
});

test('Only the local front video is mirrored; the rear camera and viewers stay original',async()=>{
 const source=(await readFile(new URL('live-stage.js',import.meta.url),'utf8')).replace(/^import[^;]+;/gm,'');
 const {liveCameraMirror}=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
 assert.equal(liveCameraMirror(true,'user'),true);assert.equal(liveCameraMirror(true,'environment'),false);assert.equal(liveCameraMirror(false,'user'),false);
});
