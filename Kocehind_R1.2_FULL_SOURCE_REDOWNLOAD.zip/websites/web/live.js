import {liveSummaryHTML} from './live-summary.js?v=2.18.0';
import {liveRoomOptions,updateLiveVideoQuality} from './live-quality.js?v=2.18.0';
import {openLiveOverlays} from './live-overlays.js?v=2.18.0';
import {giftPicker,mountGiftOverlay} from './live-gifts.js?v=2.18.0';
import {renderLiveStage} from './live-stage.js?v=2.18.0';
import {openLiveLayout} from './live-layout.js?v=2.18.0';
import {shareToInbox} from './inbox-share.js?v=2.18.0';
import {liveModeration} from './live-moderation.js?v=2.18.0';
import {previewHTML,bindPreviews} from './live-preview.js?v=2.18.0';
import {LiveLoves} from './live-loves.js?v=2.18.0';
import {api,discovery,me,esc,avatar,toast,openDialog,requireAccount,safeUrl} from '/shared/api.js?v=2.18.0';
const pink='#ff2857';
export async function mountLive(root,path,navigate,register=()=>{}){
 let overlayEditing=false,overlaySaving=false;let giftCleanup=()=>{};let stageResize;let disposed=false,rtc=null,info=null,timer=null,ticking=false,cursor=0,comments=[],mic=false,cam=false,role='viewer',ending=false,audioMuteEpoch=0;
 const isHost=()=>info?.host?.id===me?.id;const canOverlay=()=>isHost()||(role==='speaker'&&info?.mode==='camera');const ownsOverlay=item=>isHost()?!item.participant_id:item.participant_id===me.id;const ownOverlays=()=>({...info.overlays,items:(info.overlays?.items||[]).filter(ownsOverlay)});
 const rid=path.split('/')[2];
 const base='/live/rooms/'+rid;
 let loves=null,loveTimer=null,moderation=null,privacyChanged=()=>{},previewCleanup=()=>{};
 const stop=()=>{stageResize?.disconnect();giftCleanup();clearInterval(timer);clearInterval(loveTimer);loves?.dispose();moderation?.dispose();previewCleanup();rtc?.disconnect();};
 const qualityChanged=()=>{if(!disposed)updateLiveVideoQuality(rtc,info,!document.hidden);};
 document.addEventListener('visibilitychange',qualityChanged);
 const realtime=event=>{if(!disposed&&event.detail?.room_id===rid)tick();};window.addEventListener('liverealtime',realtime);const cleanup=()=>{disposed=true;window.removeEventListener('liverealtime',realtime);document.removeEventListener('visibilitychange',qualityChanged);stageResize?.disconnect();window.removeEventListener('privacychange',privacyChanged);stop();};
 register(cleanup);
 const run=fn=>async()=>{try{await fn();}catch(e){toast(e.message);}};
 if(!rid){
   let next=null,loading=false,ended=false,clean=[];
   previewCleanup=()=>{clean.forEach(fn=>fn());root.querySelector('#live-feed')?.removeEventListener('scroll',onScroll);};
   root.innerHTML='<div class="feed-header live-discovery-header"><h2>LIVE untuk Anda</h2><div class="buttons"><button class="btn" id="live-refresh">Refresh</button><a class="btn primary" href="/live/new" data-link>+ Mulai LIVE</a><button class="btn" id="live-sessions">Siaran / undangan</button></div></div><div class="feed-scroll live-discovery" id="live-feed"></div>';
   const pane=root.querySelector('#live-feed');
   async function load(){if(loading||ended||disposed)return;loading=true;try{const page=await discovery('/live/discover?limit=10'+(next?'&cursor='+encodeURIComponent(next):''));if(disposed)return;next=page.next_cursor;ended=!next;pane.insertAdjacentHTML('beforeend',page.items.map(previewHTML).join(''));clean.push(bindPreviews(pane,page.items));if(!pane.children.length)pane.innerHTML='<div class="empty">Belum ada LIVE aktif. Mulai cerita Anda melalui tombol +.</div>';}catch(e){if(!disposed)toast(e.message);}finally{loading=false;}}
   function onScroll(){if(pane.scrollTop+pane.clientHeight>=pane.scrollHeight-pane.clientHeight*1.5)load();}
   pane.addEventListener('scroll',onScroll);
   root.querySelector('#live-refresh').onclick=()=>navigate('/live');
   root.querySelector('#live-sessions').onclick=run(async()=>{if(!await requireAccount())return;const [mine,invites]=await Promise.all([api('/live/mine'),api('/live/invitations')]);if(disposed)return;openDialog('Siaran dan undangan',([...mine.items,...invites.items].filter((r,i,a)=>a.findIndex(x=>x.id===r.id)===i).map(r=>`<a class="user-row" href="/live/${encodeURIComponent(r.id)}" data-link>${avatar(r.host)}<span>${esc(r.title)}<small>@${esc(r.host.username)}</small></span></a>`).join('')||'<p>Belum ada siaran atau undangan.</p>'));});
   await load();return cleanup;
 }
 if(!await requireAccount()){if(!disposed){root.innerHTML='<div class="empty"><h2>Masuk untuk bergabung ke LIVE</h2><button class="btn primary" id="live-login">Masuk / Daftar</button> <a class="btn" href="/live" data-link>Kembali ke daftar LIVE</a></div>';root.querySelector('#live-login').onclick=()=>navigate(path);}return cleanup;}
 const sdk=await import('/shared/livekit.js?v=2.18.0');if(disposed)return cleanup;
 if(rid==='new'){
   const [config,pref]=await Promise.all([api('/live/config'),api('/live/preferences')]);
   if(disposed)return cleanup;
   root.innerHTML=`<div class="live-setup"><div class="live-setup-visual"><video playsinline muted autoplay id="live-preview"></video><div class="live-setup-mark">LIVE<br><span>Cerita Anda. Sekarang.</span></div></div><form id="live-start"><span class="eyebrow">KOCEHIND LIVE</span><h1>Mari mulai percakapan.</h1><label>Judul siaran<input name="title" required maxlength="120" placeholder="Apa yang ingin Anda ceritakan?"></label><label>Mode<select name="mode"><option value="camera">Kamera perangkat</option><option value="audio">Obrolan suara saja</option></select></label><label data-camera-capacity>Jumlah tamu kamera<select name="camera_guests"><option value="8">Host + 8 tamu</option><option value="1">Host + 1 tamu</option></select></label><label class="switch-row">Siaran bersama tamu<input name="together" type="checkbox"></label><label class="switch-row">Pesan pembuka otomatis<input type="checkbox" name="welcome_enabled" ${pref.welcome_enabled?'checked':''}></label><label>Pesan pembuka<textarea name="welcome_text" maxlength="300" rows="3">${esc(pref.welcome_text||'')}</textarea><small>Gunakan {username} untuk menyapa penonton baru.</small></label><p class="muted">Mode sendiri tetap dapat menerima komentar. Aktifkan mode bersama untuk mengundang teman atau menerima permintaan penonton.</p><button class="btn" type="button" id="preview-camera">Pratinjau kamera</button><p class="form-error" role="alert"></p><button class="btn primary" type="submit" ${!config.enabled?'disabled':''}>Siarkan LIVE</button>${!config.enabled?'<p>Server LIVE belum diaktifkan oleh pengelola.</p>':''}</form></div>`;
   let stream=null;register(()=>{cleanup();stream?.getTracks().forEach(t=>t.stop());});
   root.querySelector('#preview-camera').onclick=run(async()=>{stream?.getTracks().forEach(t=>t.stop());stream=await navigator.mediaDevices.getUserMedia({video:true,audio:false});if(disposed){stream.getTracks().forEach(t=>t.stop());return;}root.querySelector('video').srcObject=stream;});
   const f=root.querySelector('form');const capacity=f.querySelector('[data-camera-capacity]');f.querySelector('[name=mode]').addEventListener('change',()=>{capacity.hidden=f.querySelector('[name=mode]').value!=='camera';});f.onsubmit=async e=>{e.preventDefault();const button=f.querySelector('[type=submit]');button.disabled=true;try{stream?.getTracks().forEach(t=>t.stop());const d=new FormData(f);const r=await api('/live/rooms',{method:'POST',body:{title:d.get('title'),mode:d.get('mode'),together:d.has('together'),camera_guests:Number(d.get('camera_guests')||8),welcome_enabled:d.has('welcome_enabled'),welcome_text:d.get('welcome_text')}});navigate('/live/'+r.id);}catch(err){f.querySelector('.form-error').textContent=err.message;button.disabled=false;}};
   return ()=>{cleanup();stream?.getTracks().forEach(t=>t.stop());};
 }
 root.innerHTML=`<section class="live-room"><header class="live-top"><span class="live-tag">LIVE</span><div><strong id="live-title">Menyiapkan ruang…</strong><small id="live-status">Menyambungkan</small></div><button class="btn danger" id="live-leave">Keluar</button></header><div id="live-notice" role="status"></div><div id="live-invite"></div><div class="live-columns"><div class="live-stage" id="live-stage"></div><aside class="live-conversation"><div id="live-comments" aria-live="polite"></div><form id="live-comment-form"><input name="body" maxlength="500" required placeholder="Sapa dan kirim komentar…" autocomplete="off"><button class="btn primary">Kirim</button></form></aside></div><footer class="live-controls"><button class="btn" id="live-overlays" hidden>Gambar & teks</button><button class="btn" id="live-overlay-done" hidden>Selesai geser</button><button class="btn" id="live-layout" hidden>Atur layar</button><button class="btn" id="live-guests">Tamu / undangan</button><button class="btn" id="live-mic" hidden>Mikrofon</button><button class="btn" id="live-camera" hidden>Kamera</button><button class="btn" id="live-flip" hidden>Balik kamera</button><button class="btn" id="live-audio">Aktifkan suara</button><button class="btn" id="live-like">♥ Suka <span>0</span></button><button class="btn" id="live-gift">🎁 Gift</button><a class="btn" href="/wallet" target="_blank" rel="noopener">Koin dan pendapatan</a><button class="btn" id="live-share">Bagikan</button><button class="btn" id="live-inbox-share">Kirim ke inbox</button><button class="btn" id="live-report">Laporkan LIVE</button></footer><div id="live-audio-tracks"></div></section>`;
 const $=s=>root.querySelector(s);
 $('#live-gift').onclick=run(()=>giftPicker(rid));
 async function saveOverlays(items){
  if(overlaySaving)throw new Error('Tunggu perubahan layar selesai disimpan');
  overlaySaving=true;const previous=info.overlays||{version:0,items:[]};
  info.overlays={...previous,items:[...previous.items.filter(i=>!ownsOverlay(i)),...items.map(i=>({...i,...(!isHost()?{participant_id:me.id}:{})}))]};controls();updateStage();
  try{const result=await api(base+'/overlays',{method:'PUT',body:{version:previous.version,items}});if(!disposed)info.overlays=result;}
  catch(e){if(!disposed){info.overlays=previous;if(e.status===409){const latest=await api(base);info.overlays=latest.overlays;}}throw e;}
  finally{overlaySaving=false;if(!disposed){controls();updateStage();}}
 }
 $('#live-overlays').onclick=()=>openLiveOverlays({roomId:rid,guest:!isHost(),getState:ownOverlays,save:saveOverlays,startDragging:()=>{overlayEditing=true;controls();updateStage();}});
 $('#live-overlay-done').onclick=()=>{overlayEditing=false;controls();updateStage();};

 $('#live-report').onclick=run(async()=>{
  if(!await requireAccount())return;
  const d=openDialog('Laporkan LIVE','<p class="muted">Jelaskan masalah pada siaran ini untuk ditinjau moderator.</p><form><label>Alasan laporan<textarea name="reason" minlength="3" maxlength="1000" required></textarea></label><p class="form-error" role="alert"></p><button class="btn primary" type="submit">Kirim laporan</button></form>'),form=d.querySelector('form');
  form.onsubmit=async event=>{event.preventDefault();const button=form.querySelector('[type=submit]');button.disabled=true;try{await api('/reports',{method:'POST',body:{target_type:'live',target_id:rid,reason:new FormData(form).get('reason')}});d.close();toast('Laporan LIVE masuk ke antrean moderator');}catch(error){form.querySelector('.form-error').textContent=error.message;}finally{button.disabled=false;}};
 });

 const tracks=new Map();
 moderation=liveModeration({root,base,getInfo:()=>info,refresh:tick,guestAction,navigate});
 privacyChanged=()=>{if(disposed||ending)return;comments=[];cursor=0;const pane=$('#live-comments');pane.querySelectorAll('p').forEach(n=>n.livePressCleanup?.());pane.replaceChildren();tick();};window.addEventListener('privacychange',privacyChanged);
 loves=new LiveLoves((count,batch_id)=>api(base+'/like',{method:'POST',body:{count,batch_id}}),n=>{const label=$('#live-like span');if(label)label.textContent=n;});
 loveTimer=setInterval(()=>loves.flush(),500);
 function tapLove(e){if(ending||disposed||e.target.closest('button,a,input'))return;loves.tap();const stage=$('#live-stage');if(!stage)return;const bounds=stage.getBoundingClientRect(),heart=document.createElement('span');heart.className='live-floating-heart';heart.textContent='♥';heart.style.left=(e.clientX-bounds.left-20)+'px';heart.style.top=(e.clientY-bounds.top-25)+'px';if(stage.querySelectorAll('.live-floating-heart').length>=16)stage.querySelector('.live-floating-heart').remove();stage.append(heart);heart.addEventListener('animationend',()=>heart.remove(),{once:true});}
 $('#live-stage').addEventListener('click',tapLove);
 function updateStage(){
  qualityChanged();
   if(disposed||ending||!info||!rtc||!$('#live-stage'))return;
   root.querySelector('.live-room')?.classList.toggle('camera-room',info.mode==='camera');
   renderLiveStage($('#live-stage'),info,rtc,{localId:me.id,bindPerson:(tile,m)=>moderation.bind(tile,m),onEmpty:run(showGuests),overlayOptions:{editable:canOverlay()&&overlayEditing&&!overlaySaving,guestId:isHost()?'':me.id,onMove:item=>saveOverlays(ownOverlays().items.map(i=>i.id===item.id?item:i)).catch(e=>{toast(e.message);updateStage();})}});
 }

 function controls(){$('#live-overlays').hidden=!canOverlay();$('#live-overlay-done').hidden=!canOverlay()||!overlayEditing;$('#live-overlay-done').disabled=overlaySaving;$('#live-gift').hidden=isHost();const publisher=role!=='viewer';$('#live-layout').hidden=!(isHost()||info.can_manage_layout);$('#live-mic').hidden=!publisher;$('#live-camera').hidden=!publisher||info.mode==='audio';$('#live-flip').hidden=!publisher||info.mode==='audio';$('#live-mic').textContent=mic?'Matikan mikrofon':'Aktifkan mikrofon';$('#live-camera').textContent=cam?'Matikan kamera':'Aktifkan kamera';$('#live-leave').textContent=isHost()?'Akhiri LIVE':'Keluar';moderation.controls();const f=$('#live-comment-form');f.querySelector('input').disabled=info.comment_muted===true;f.querySelector('button').disabled=info.comment_muted===true;f.querySelector('input').placeholder=info.comment_muted?'Komentar Anda dibisukan':'Sapa dan kirim komentar…';}
 async function publish(){try{await rtc.localParticipant.setMicrophoneEnabled(true,{echoCancellation:true,noiseSuppression:true,autoGainControl:true});mic=true;if(info.mode==='camera'){await rtc.localParticipant.setCameraEnabled(true,{facingMode:'user'});rtc.localParticipant.kocehindCameraFacing='user';cam=true;}}catch(e){$('#live-notice').textContent='Izinkan mikrofon/kamera untuk menyiarkan. '+e.message;}controls();}
 function summary(r){ending=true;stop();root.innerHTML=liveSummaryHTML(r);}
 async function tick(){
   if(disposed||ending||ticking)return;ticking=true;
   try{if(isHost())await api(base+'/presence',{method:'POST',body:{foreground:document.visibilityState==='visible'}});const latest=await api(base+'/heartbeat',{method:'POST'});if(disposed||ending)return;if(['ending','ended'].includes(latest.status)){summary(latest);return;}if(overlaySaving||(latest.overlays?.version||0)<(info.overlays?.version||0))latest.overlays=info.overlays;if((latest.layout?.version||0)<(info.layout?.version||0)){for(const key of ['layout','seats','camera_guest_limit','together','members'])latest[key]=info[key];}info=latest;
     if(role!==info.role){role=info.role;if(role==='viewer'){await rtc.localParticipant.setCameraEnabled(false);await rtc.localParticipant.setMicrophoneEnabled(false);mic=cam=false;}else await publish();}
     if((info.audio_mute_epoch||0)>audioMuteEpoch){audioMuteEpoch=info.audio_mute_epoch;await rtc.localParticipant.setMicrophoneEnabled(false);mic=false;toast('Mikrofon Anda dimatikan host/moderator. Anda dapat menyalakan kembali melalui tombol mikrofon.');}
     $('#live-title').textContent=info.title;$('#live-status').textContent=`@${info.host.username} · ${info.viewers} menonton · ${rtc.state}`;loves.update(info.likes);controls();updateStage();
     const invite=$('#live-invite');if(info.consent==='invited'&&role==='viewer'){if(!invite.children.length){invite.innerHTML='<p>Host mengundang Anda menjadi tamu. Mikrofon/kamera aktif setelah diterima.</p><button class="btn primary" data-accept>Terima</button><button class="btn" data-decline>Tolak</button>';invite.querySelector('[data-accept]').onclick=run(()=>guestAction('accept'));invite.querySelector('[data-decline]').onclick=run(()=>guestAction('decline'));}}else invite.replaceChildren();
     const page=await api(base+'/comments?after='+cursor);if(disposed||ending)return;const pane=$('#live-comments'),atBottom=pane.scrollHeight-pane.scrollTop-pane.clientHeight<100;
     for(const c of page.items)if(!comments.includes(c.id)){comments.push(c.id);const row=document.createElement('p');row.innerHTML=`<strong>@${esc(c.author.username)}${c.author.is_moderator?' · Moderator':''}</strong> ${c.kind==='welcome'?'<small class=welcome-tag>Pesan pembuka</small> ':''}${c.kind==='gift'&&c.gift?`<img src="${esc(safeUrl(c.gift.image_url))}" alt="${esc(c.gift.name)}">`:''}${esc(c.body)}`;row.classList.toggle('gift-comment',c.kind==='gift');moderation.bind(row,c.author);pane.append(row);}
     cursor=page.cursor;while(pane.childElementCount>200){pane.firstElementChild.livePressCleanup?.();pane.firstElementChild.remove();}if(atBottom)pane.scrollTop=pane.scrollHeight;
   }catch(e){if([401,403,404].includes(e.status)){stop();navigate('/live');return;}try{const r=await api(base);if(!disposed&&['ending','ended'].includes(r.status)){summary(r);return;}}catch{}if(!disposed)$('#live-notice').textContent=(navigator.onLine===false||e.status===0?'Anda sedang Offline periksa jaringan Anda':'Sinkronisasi tertunda: '+e.message);}
   finally{ticking=false;}
 }
 async function guestAction(action,user_id){await api(base+'/guests',{method:'POST',body:{action,user_id}});await tick();}
 async function showGuests(){
   const friends=isHost()?await api(`/users/${encodeURIComponent(me.username)}/connections?kind=friends&limit=50`):{items:[]};
   const d=openDialog('Siaran LIVE dengan tamu',`${isHost()?`<label class="switch-row">Mode bersama<input type="checkbox" id="together-toggle" ${info.together?'checked':''}></label>`:''}<div class="live-guests">${(info.members||[]).map(m=>`<div>${avatar(m)}<span>@${esc(m.username)}<small>${esc(m.role)} · ${esc(m.consent)}</small></span>${moderation.can('approve_guests')&&m.id!==me.id?`<div>${m.consent==='requested'?`<button class="btn primary small" data-guest="approve" data-uid="${esc(m.id)}">Setujui</button>`:''}${m.role==='speaker'?`<button class="btn small" data-guest="remove" data-uid="${esc(m.id)}">Turunkan</button>`:''}${isHost()?`<button class="btn small danger" data-guest="kick" data-uid="${esc(m.id)}">Keluarkan</button>`:''}</div>`:''}</div>`).join('')}</div>${isHost()&&info.together?`<h3>Undang teman</h3><div class="live-guests">${friends.items.map(f=>`<div>${avatar(f)}<span>@${esc(f.username)}</span><button class="btn primary small" data-guest="invite" data-uid="${esc(f.id)}">Undang</button></div>`).join('')||'<p>Belum ada teman yang saling mengikuti.</p>'}</div>`:''}${!isHost()&&info.together?`<button class="btn primary" data-guest="${role==='speaker'?'cancel':'request'}">${role==='speaker'?'Turun dari kursi':'Minta bergabung sebagai tamu'}</button>`:''}`);
   d.addEventListener('close',()=>d.querySelectorAll('.live-guests > div').forEach(node=>node.livePressCleanup?.()));
   d.querySelectorAll('.live-guests > div').forEach((node,i)=>{if(info.members?.[i])moderation.bind(node,info.members[i]);});
   d.querySelectorAll('[data-guest]').forEach(b=>b.onclick=run(async()=>{await guestAction(b.dataset.guest,b.dataset.uid);d.close();}));
   d.querySelector('#together-toggle')?.addEventListener('change',run(async()=>{await api(base+'/settings',{method:'PUT',body:{title:info.title,mode:info.mode,together:d.querySelector('#together-toggle').checked}});d.close();await tick();}));
 }
 try{
   const grant=await api(base+'/join',{method:'POST'});if(disposed)return cleanup;info=grant.room;role=grant.role;giftCleanup=mountGiftOverlay(root.querySelector('.live-room'),rid);
   rtc=new sdk.Room(liveRoomOptions);
   rtc.on(sdk.RoomEvent.TrackSubscribed,(track,pub,p)=>{if(disposed)return;if(track.kind==='audio'){const a=track.attach();a.dataset.sid=pub.trackSid;$('#live-audio-tracks')?.append(a);tracks.set(pub.trackSid,track);}updateStage();});
   rtc.on(sdk.RoomEvent.TrackUnsubscribed,track=>track.detach().forEach(el=>el.remove()));
   rtc.on(sdk.RoomEvent.Disconnected,()=>{if(!disposed&&!ending){$('#live-notice').textContent='Koneksi media terputus. Muat ulang untuk menyambungkan, atau keluar dari sesi.';tick();}});
   rtc.on(sdk.RoomEvent.Reconnecting,()=>{if(!disposed)$('#live-notice').textContent='Koneksi melemah. Menyambungkan ulang…';});
   rtc.on(sdk.RoomEvent.Reconnected,()=>{if(!disposed)$('#live-notice').textContent='Tersambung kembali';});
   await rtc.connect(grant.url,grant.token);if(disposed){stop();return cleanup;}
   if(role!=='viewer')await publish();
   await tick();timer=setInterval(tick,2000);
   $('#live-mic').onclick=run(async()=>{await rtc.localParticipant.setMicrophoneEnabled(!mic);mic=!mic;controls();});
   $('#live-camera').onclick=run(async()=>{await rtc.localParticipant.setCameraEnabled(!cam);cam=!cam;controls();});
   $('#live-flip').onclick=run(async()=>{const track=[...rtc.localParticipant.videoTrackPublications.values()].find(p=>p.track)?.track;if(track){const facing=track.mediaStreamTrack.getSettings().facingMode||rtc.localParticipant.kocehindCameraFacing||'user',next=facing==='environment'?'user':'environment';await track.restartTrack({facingMode:next});rtc.localParticipant.kocehindCameraFacing=next;updateStage();}});
   $('#live-audio').onclick=run(async()=>{await rtc.startAudio();toast('Suara diaktifkan');});
   $('#live-guests').onclick=run(showGuests);
   $('#live-layout').onclick=()=>openLiveLayout(info,base,next=>{info=next;controls();updateStage();});
   stageResize=new ResizeObserver(()=>updateStage());stageResize.observe($('#live-stage'));
   $('#live-like').onclick=()=>loves.tap();
   $('#live-inbox-share').onclick=run(()=>shareToInbox('live',rid,info.title));
   $('#live-share').onclick=run(async()=>{const url=location.href;if(navigator.share)await navigator.share({title:info.title,url});else{await navigator.clipboard.writeText(url);toast('Tautan LIVE disalin');}});
   $('#live-comment-form').onsubmit=async e=>{e.preventDefault();const f=e.target,b=f.querySelector('button');if(f.dataset.posting)return;const body=String(new FormData(f).get('body')).trim();if(!body)return;f.dataset.posting='true';b.disabled=true;f.reset();const pane=$('#live-comments'),row=document.createElement('p');row.innerHTML=`<strong>@${esc(me.username)}</strong> ${esc(body)} <small>Mengirim…</small>`;pane.append(row);pane.scrollTop=pane.scrollHeight;try{const sent=await api(base+'/comments',{method:'POST',body:{body}});if(disposed)return;row.remove();if(!comments.includes(sent.id)){comments.push(sent.id);row.innerHTML=`<strong>@${esc(me.username)}</strong> ${esc(body)}`;pane.append(row);}}catch(err){row.remove();if(!f.elements.body.value)f.elements.body.value=body;toast(err.message);}finally{delete f.dataset.posting;b.disabled=info.comment_muted===true;}};
   $('#live-leave').onclick=run(async()=>{
     if(isHost()){
       const d=openDialog('Akhiri LIVE sekarang?','<p>Sesi seluruh peserta, kamera, dan suara akan ditutup.</p><button class="btn danger" id="confirm-end">Akhiri sekarang</button>');
       d.querySelector('#confirm-end').onclick=run(async()=>{await loves.flush();const result=await api(base+'/end',{method:'POST'});d.close();summary(result);});
     }else{await loves.flush();await rtc.disconnect();await api(base+'/leave',{method:'POST'});navigate('/live');}
   });
 }catch(e){stop();if(!disposed)root.innerHTML=`<div class="empty"><h2>LIVE belum tersambung</h2><p>${esc(navigator.onLine===false||e.status===0?'Anda sedang Offline periksa jaringan Anda':e.message)}</p><a class="btn" href="/live" data-link>Kembali ke LIVE</a></div>`;}
 const unload=e=>{if(isHost()&&!ending){e.preventDefault();e.returnValue='';}};
 window.addEventListener('beforeunload',unload);
 return ()=>{window.removeEventListener('beforeunload',unload);cleanup();};
}
