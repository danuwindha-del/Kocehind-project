import {execFileSync} from 'node:child_process';
import {mkdtemp,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile,mkdir} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {createRequire} from 'node:module';
const {chromium}=createRequire(import.meta.url)('playwright');
const {WebSocketServer}=createRequire(import.meta.url)('ws');
const root=resolve(new URL('..',import.meta.url).pathname);
const owner={id:'00000000-0000-4000-8000-000000000001',username:'creator',name:'Kreator Kocehind',bio:'Cerita sehari-hari dari komunitas.',is_admin:true,legal_required:false,profile_limits:{},followers:1500,following_count:15,likes_received:4200,links:[{title:'Situs resmi',url:'https://example.com/'},{title:'Portofolio',url:'https://example.org/'}]};
const post={id:'00000000-0000-4000-8000-000000000002',caption:'Video kreator',kind:'video',media_url:'',thumbnail_url:'',author:owner,views:1234,likes:50,following:false,is_mine:true,is_pinned:false,visibility:'public',mentions:[]};
const ai={id:'youtube',title:'YouTube',summary:'YouTube menyediakan ruang untuk berbagi cerita dan membangun komunitas.\n\nProduk YouTube mencakup YouTube Music, YouTube Kids, dan YouTube Studio.',images:[],sources:[{label:'YouTube resmi',url:'https://about.youtube/'}],studied_at:'2026-10-31T00:00:00Z'};
const qa=process.env.KOCEHIND_QA_DIR||'/tmp/kocehind-qa-v216';

async function scenario(site,path,handler,run){
 const calls=[];
 const server=createServer(async(req,res)=>{
  try{
   const url=new URL(req.url,'http://fixture');
   if(url.pathname.startsWith('/api/')){
    const chunks=[];for await(const chunk of req)chunks.push(chunk);const raw=Buffer.concat(chunks);
    const call={path:url.pathname.slice(4),method:req.method,query:url.searchParams,body:req.headers['content-type']?.includes('json')&&raw.length?JSON.parse(raw):null};calls.push(call);
    let data=await handler(call);
    if(data===undefined){if(call.path==='/users/me'||call.path==='/admin/me'||call.path==='/users/creator')data=owner;else if(call.path==='/users/me/privacy')data={revision:'test'};else data={items:[],next_offset:null,unread:0};}
    if(data?.fixtureFile){res.writeHead(200,{'content-type':data.contentType});res.end(await readFile(data.fixtureFile));return;}
    res.writeHead(data?.fixtureStatus||200,{'content-type':'application/json'});res.end(JSON.stringify(data?.fixtureStatus?data.body:data));return;
   }
   const relative=url.pathname.startsWith('/shared/')?url.pathname.slice(1):/\.(js|css|png)$/.test(url.pathname)?site+url.pathname:site+'/index.html';
   const file=resolve(root,relative);if(!file.startsWith(root+'/'))throw new Error('Invalid path');
   res.writeHead(200,{'content-type':({'.js':'text/javascript','.css':'text/css','.html':'text/html','.png':'image/png'}[extname(file)]||'application/octet-stream')});res.end(await readFile(file));
  }catch{res.writeHead(404);res.end('missing');}
 });
 const sockets=[],wsServer=new WebSocketServer({server,path:'/api/ws'});wsServer.on('connection',socket=>{sockets.push(socket);socket.on('message',value=>{if(String(value)==='ping')socket.send('{"type":"pong"}');});});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:390,height:844}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 try{await page.goto(origin+path);await run(page,calls,{sockets});assert.deepEqual(errors,[]);}finally{await browser.close();wsServer.close();await new Promise(r=>server.close(r));}
}

test('Upload time changes at minute, hour, day and one-week boundaries',async()=>{
 const {uploadTime}=await import('./upload-time.js');const now=new Date('2026-11-10T12:00:00Z');
 for(const [seconds,text] of [[59,'Baru saja'],[60,'1 menit'],[3599,'59 menit'],[3600,'1 jam'],[86399,'23 jam'],[86400,'1 hari'],[604799,'6 hari'],[604800,'3 November 2026']])assert.equal(uploadTime(new Date(now-seconds*1000).toISOString(),now),text);
 assert.equal(uploadTime('',now),'');assert.equal(uploadTime('invalid',now),'');
});

for(const username of ['creator','other'])test('Time is visible after opening a video from '+username+' profile and stays hidden in For You',async()=>{
 const author={...owner,username,id:username==='creator'?owner.id:'other-id'},item={...post,author,kind:'image',created_at:'2023-11-10T12:00:00Z'};
 await scenario('web','/@'+username,async c=>{
  if(c.path==='/users/'+username)return author;
  if(c.path==='/users/'+username+'/posts')return {items:[item],next_offset:null};
  if(c.path==='/posts/'+post.id)return item;
  if(c.path==='/feed')return {items:[item],next_cursor:null};
 },async page=>{
  await page.locator('#profile-posts .grid-cover').click();
  await page.locator('time.post-upload-time').waitFor();assert.equal(await page.locator('time.post-upload-time').textContent(),'· 10 November 2023');
  await page.reload();await page.locator('time.post-upload-time').waitFor();
  await page.goto(new URL('/',page.url()).href);await page.locator('.post').waitFor();assert.equal(await page.locator('time.post-upload-time').count(),0);
 });
});

test('Guest can widen and enlarge the image with handles while it remains inside its own tile',async()=>{
 await scenario('web','/missing',async()=>undefined,async page=>{
  await page.evaluate(async()=>{
   const {renderLiveStage}=await import('/live-stage.js');
   const stage=document.createElement('div');stage.id='resize-stage';Object.assign(stage.style,{position:'fixed',top:'70px',left:'5px',width:'320px',height:'500px',zIndex:100,display:'grid'});document.body.append(stage);
   const info={together:true,seats:2,mode:'camera',host:{id:'host'},members:[{id:'host',username:'host',role:'host'},{id:'guest',username:'guest',role:'speaker'}],overlays:{version:1,items:[{id:'guest-image',kind:'image',participant_id:'guest',x:.1,y:.1,width:.4,height:.4,image_url:''}]},layout:{}};
   const options={localId:'guest',overlayOptions:{editable:true,guestId:'guest',onMove:item=>{window.__resizeSaved=item;info.overlays.items=[item];renderLiveStage(stage,info,null,options);}}};renderLiveStage(stage,info,null,options);
  });
  const handle=page.locator('#resize-stage [data-resize=width]');await handle.waitFor();let b=await handle.boundingBox();
  await page.mouse.move(b.x+b.width/2,b.y+b.height/2);await page.mouse.down();await page.mouse.move(b.x+800,b.y+b.height/2,{steps:8});await page.mouse.up();
  await page.waitForFunction(()=>window.__resizeSaved?.image_fit==='fill');
  const enlarged=await page.evaluate(()=>{const image=document.querySelector('#resize-stage [data-overlay]'),tile=image.closest('[data-person]'),a=image.getBoundingClientRect(),b=tile.getBoundingClientRect();return {saved:window.__resizeSaved,fit:image.querySelector('img').style.objectFit,inside:a.left>=b.left&&a.right<=b.right+1&&a.top>=b.top&&a.bottom<=b.bottom+1};});
  assert.equal(enlarged.saved.width,1);assert.equal(enlarged.fit,'fill');assert(enlarged.inside);
  const corner=page.locator('#resize-stage [data-resize=both]');b=await corner.boundingBox();await page.mouse.move(b.x+10,b.y+10);await page.mouse.down();await page.mouse.move(b.x+800,b.y+800,{steps:8});await page.mouse.up();
  const saved=await page.evaluate(()=>window.__resizeSaved);assert(saved.width<=1&&saved.height<=1&&saved.x+saved.width<=1&&saved.y+saved.height<=1);
 });
});
