// Frame extraction stays on the device; only the chosen image is uploaded.
export function chooseVideoCover(file,{initial=null,signal}={}){
 return new Promise(resolve=>{
  let selected=0,duration=0,gallery=initial,closed=false,saving=false,serial=Promise.resolve(),ready=false;
  const urls=[],url=blob=>{const value=URL.createObjectURL(blob);urls.push(value);return value;};
  const dialog=document.createElement('dialog');dialog.className='cover-editor';dialog.setAttribute('aria-label','Ubah sampul video');
  dialog.innerHTML='<header><button type="button" data-cancel>Batalkan</button><strong>Sampul</strong><button type="button" data-save>Simpan</button></header><div class="cover-stage"><video playsinline muted preload="auto"></video><img alt="Pratinjau sampul pilihan" hidden></div><button type="button" class="text-btn" data-preview>▷ Pratinjau video</button><div class="cover-selection"><div class="cover-strip" role="slider" tabindex="0" aria-label="Pilih cuplikan sampul" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"></div><label class="btn cover-import">+<span>Impor</span><input hidden type="file" accept="image/jpeg,image/png,image/webp"></label></div><label class="cover-seek-label">Cuplikan <output>00:00</output><input type="range" min="0" max="0" value="0" step="0.001" aria-label="Waktu cuplikan sampul" disabled></label><p class="form-error" role="alert"></p>';
  document.body.append(dialog);dialog.showModal();
  const video=dialog.querySelector('video'),image=dialog.querySelector('img'),strip=dialog.querySelector('.cover-strip'),range=dialog.querySelector('[type=range]'),save=dialog.querySelector('[data-save]'),error=dialog.querySelector('.form-error');
  video.src=url(file);save.disabled=!gallery;
  const waiting=new Set();
  function wait(event,action){return new Promise((ok,fail)=>{
   const finish=reason=>{clearTimeout(timer);video.removeEventListener(event,done);video.removeEventListener('error',bad);waiting.delete(cancel);reason?fail(reason):ok();};
   const done=()=>finish(),bad=()=>finish(new Error('Video tidak dapat dipratinjau. Anda dapat mengimpor sampul dari galeri.')),cancel=()=>finish(new Error('Editor ditutup'));
   const timer=setTimeout(bad,12000);waiting.add(cancel);video.addEventListener(event,done,{once:true});video.addEventListener('error',bad,{once:true});try{action?.();}catch(e){finish(e);}
  });}
  const seek=time=>Math.abs(video.currentTime-time)<0.001&&video.readyState>=2?Promise.resolve():wait('seeked',()=>{video.currentTime=time;});
  function setImage(blob){gallery=blob;image.src=url(blob);image.hidden=false;video.hidden=true;save.disabled=false;}
  if(gallery)setImage(gallery);
  function stamp(time){const s=Math.floor(time);return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0');}
  function select(time){if(!ready||saving||closed)return;gallery=null;image.hidden=true;video.hidden=false;video.pause();selected=Math.max(0,Math.min(duration-0.001,time));range.value=String(selected);dialog.querySelector('output').value=stamp(selected);strip.style.setProperty('--cover-position',(selected/duration*100)+'%');strip.setAttribute('aria-valuenow',String(Math.round(selected/duration*100)));serial=serial.catch(()=>{}).then(()=>closed?undefined:seek(selected)).catch(e=>{if(!closed)error.textContent=e.message;});}
  range.oninput=()=>select(Number(range.value));
  function point(event){const rect=strip.getBoundingClientRect();select((event.clientX-rect.left)/rect.width*duration);}
  strip.onpointerdown=event=>{if(!ready||saving)return;strip.setPointerCapture(event.pointerId);point(event);};
  strip.onpointermove=event=>{if(strip.hasPointerCapture(event.pointerId))point(event);};
  strip.onkeydown=event=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(event.key)){event.preventDefault();select(event.key==='Home'?0:event.key==='End'?duration:selected+(event.key==='ArrowLeft'?-1:1)*Math.max(.1,duration/100));}};
  dialog.querySelector('[data-preview]').onclick=()=>{if(!ready||saving)return;image.hidden=true;video.hidden=false;if(video.paused)video.play().catch(e=>{error.textContent=e.message;});else{video.pause();if(gallery){image.hidden=false;video.hidden=true;}else select(selected);}};
  dialog.querySelector('[type=file]').onchange=event=>{if(saving)return;const value=event.target.files[0];if(!value)return;if(!['image/jpeg','image/png','image/webp'].includes(value.type)||value.size>10*1024*1024){error.textContent='Pilih gambar JPG, PNG, atau WebP maksimal 10 MB.';return;}video.pause();error.textContent='';setImage(value);};
  function finish(value){if(closed)return;closed=true;waiting.forEach(cancel=>cancel());video.pause();video.removeAttribute('src');video.load();urls.forEach(value=>URL.revokeObjectURL(value));signal?.removeEventListener('abort',abort);dialog.close();dialog.remove();resolve(value);}
  const abort=()=>finish(null);signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted){finish(null);return;}
  dialog.querySelector('[data-cancel]').onclick=()=>finish(null);dialog.addEventListener('cancel',event=>{event.preventDefault();finish(null);});dialog.addEventListener('close',()=>finish(null));
  function canvasBlob(width){const canvas=document.createElement('canvas'),ratio=Math.min(1,width/Math.max(video.videoWidth,video.videoHeight));canvas.width=Math.max(1,Math.round(video.videoWidth*ratio));canvas.height=Math.max(1,Math.round(video.videoHeight*ratio));canvas.getContext('2d').drawImage(video,0,0,canvas.width,canvas.height);return new Promise((ok,fail)=>canvas.toBlob(blob=>blob?ok(blob):fail(new Error('Sampul tidak dapat disimpan.')), 'image/jpeg',.92));}
  save.onclick=async()=>{if(saving||(!ready&&!gallery))return;saving=true;save.disabled=true;error.textContent='';try{video.pause();await serial;if(closed)return;let result=gallery;if(!result){await seek(selected);result=new File([await canvasBlob(720)],'sampul.jpg',{type:'image/jpeg'});}finish(result);}catch(e){if(!closed){error.textContent=e.message;saving=false;save.disabled=false;}}};
  (async()=>{try{
   if(video.readyState<1)await wait('loadedmetadata');duration=video.duration;
   if(!Number.isFinite(duration)||duration<.001)throw new Error('Durasi video tidak valid. Impor sampul dari galeri.');
   range.max=String(Math.max(0,duration-.001));
   for(let i=0;i<8;i++){if(closed)return;await seek(Math.max(0,(duration-.001)*i/7));const blob=await canvasBlob(120);if(closed)return;const thumb=document.createElement('img');thumb.src=url(blob);thumb.alt='';strip.append(thumb);}
   if(closed)return;await seek(0);ready=true;range.disabled=false;save.disabled=false;const chosen=gallery;select(0);if(chosen)setImage(chosen);
  }catch(e){if(!closed){error.textContent=e.message;save.disabled=!gallery;}}})();
 });
}
