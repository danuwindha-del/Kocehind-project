import {playbackSource} from './media-playback.js?v=2.18.0';
export function albumHTML(post,{esc,safeUrl}){
 const photos=post.photos?.length?post.photos:[{media_url:post.media_url}];
 return `<div class="photo-album" role="region" aria-label="Album ${photos.length} foto"><div class="photo-slides" tabindex="0" aria-label="Geser ke kiri atau kanan untuk melihat foto">${photos.map((p,i)=>`<div class="photo-slide" role="group" aria-label="Foto ${i+1} dari ${photos.length}"><img class="post-image" src="${esc(playbackSource(p.media_url))}" alt="${esc(post.caption||'Foto')} · ${i+1}/${photos.length}" ${i?'loading="lazy"':''}></div>`).join('')}</div>${photos.length>1?`<span class="photo-counter" aria-live="polite">1/${photos.length}</span><div class="photo-navigation"><button class="photo-prev" aria-label="Foto sebelumnya">‹</button><div class="photo-dots">${photos.map((_,i)=>`<button class="${i?'':'active'}" data-photo="${i}" aria-label="Lihat foto ${i+1}" aria-current="${i===0}"></button>`).join('')}</div><button class="photo-next" aria-label="Foto berikutnya">›</button></div>`:''}${post.sound?'<button class="photo-music" aria-label="Putar atau bisukan musik">♪</button>':''}</div>`;
}
export function bindAlbum(root,post){
 const album=root.querySelector('.photo-album');if(!album)return null;
 const slides=album.querySelector('.photo-slides'),count=slides.children.length;
 let index=0,disposed=false,active=false;
 const audioURL=playbackSource(post.audio_url||post.sound?.media_url);
 const audio=post.sound&&audioURL?new Audio(audioURL):null;
 if(audio){audio.loop=true;audio.preload='none';}
 const move=i=>{index=Math.max(0,Math.min(count-1,i));slides.scrollTo({left:slides.clientWidth*index,behavior:'smooth'});};
 const paint=()=>{
  index=Math.max(0,Math.min(count-1,Math.round(slides.scrollLeft/Math.max(1,slides.clientWidth))));
  const text=album.querySelector('.photo-counter');if(text)text.textContent=`${index+1}/${count}`;
  album.querySelectorAll('[data-photo]').forEach((b,i)=>{b.classList.toggle('active',i===index);b.setAttribute('aria-current',String(i===index));});
  const prev=album.querySelector('.photo-prev'),next=album.querySelector('.photo-next');
  if(prev)prev.disabled=index===0;if(next)next.disabled=index===count-1;
 };
 slides.addEventListener('scroll',paint,{passive:true});
 slides.addEventListener('keydown',e=>{if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();move(index+(e.key==='ArrowRight'?1:-1));}});
 album.querySelector('.photo-prev')?.addEventListener('click',()=>move(index-1));
 album.querySelector('.photo-next')?.addEventListener('click',()=>move(index+1));
 album.querySelectorAll('[data-photo]').forEach(b=>b.onclick=()=>move(Number(b.dataset.photo)));
 const button=album.querySelector('.photo-music');
 const sync=()=>{if(!audio)return;if(active&&!document.hidden&&!disposed&&!audio.muted)audio.play().catch(()=>{if(button)button.textContent='▶ ♪';});else audio.pause();};
 if(button&&!audio){button.disabled=true;button.title='Musik belum tersedia';}
 if(button&&audio)button.onclick=()=>{audio.muted=!audio.paused&&!audio.muted;button.textContent=audio.muted?'♪ ×':'♪';sync();};
 const visibility=()=>sync();document.addEventListener('visibilitychange',visibility);paint();
 return {setActive(value){active=value;sync();},dispose(){disposed=true;audio?.pause();if(audio){audio.removeAttribute('src');audio.load();}document.removeEventListener('visibilitychange',visibility);}};
}
