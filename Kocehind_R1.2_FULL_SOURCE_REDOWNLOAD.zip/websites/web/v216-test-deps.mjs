// The historical jsdom harness replaces browser imports with window.__deps.
// Load the new production helpers into that same realm, preserving real behavior.
import {readFile} from 'node:fs/promises';
export async function installV216Deps(window){
 for(const [file,names] of [
  ['upload-time.js',['uploadTime','uploadTimeHTML']],
  ['live-badges.js',['liveAvatarHTML','applyLiveStatus','visibleLiveUsers']],
  ['media-playback.js',['playbackSource','adaptivePlayback']],
  ['albums.js',['albumHTML','bindAlbum']],
  ['search-tools.js',['recentSearches','mountRecent','mountInboxSearch']],
  ['video-cover.js',['chooseVideoCover']],
  ['album-composer.js',['mountAlbumComposer']],
 ]){
  const source=(await readFile(new URL(file,import.meta.url),'utf8')).replace(/^import[^;]+;/gm,'').replaceAll('export ','');
  Object.assign(window.__deps,window.eval('(()=>{'+(file==='albums.js'?'const {playbackSource}=window.__deps;':file==='album-composer.js'?'const {chooseVideoCover}=window.__deps;':'')+source+';return {'+names.join(',')+'};})()'));
 }
}
