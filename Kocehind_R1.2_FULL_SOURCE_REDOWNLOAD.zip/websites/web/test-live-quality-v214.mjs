import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const source=await readFile(new URL('live-quality.js',import.meta.url),'utf8');
const {liveRoomOptions,liveVideoQuality,updateLiveVideoQuality}=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));

test('Main LIVE requests the clear main layer for solo/duo/focus and reduces the other grid tiles',()=>{
 assert.equal(liveVideoQuality({together:false},'host'),2);
 assert.equal(liveVideoQuality({together:true,seats:2},'guest'),2);
 assert.equal(liveVideoQuality({together:true,seats:9},'guest'),1);
 assert.equal(liveVideoQuality({together:true,seats:9,layout:{focus_id:'host'}},'host'),2);
 assert.equal(liveVideoQuality({together:true,seats:9,layout:{focus_id:'host'}},'guest'),0);
 assert.equal(liveRoomOptions.videoCaptureDefaults.resolution.width,540);
 assert.equal(liveRoomOptions.videoCaptureDefaults.resolution.height,960);
 assert.equal(liveRoomOptions.publishDefaults.simulcast,true);
 assert.equal(liveRoomOptions.publishDefaults.videoEncoding.maxBitrate,1500000);
 assert.equal(liveRoomOptions.publishDefaults.videoEncoding.maxFramerate,24);
 assert.equal(liveRoomOptions.publishDefaults.degradationPreference,'maintain-resolution');
});
test('Subscription quality changes once per state, pauses hidden video and resumes it',()=>{
 const events=[],publication={setEnabled:v=>events.push(['enabled',v]),setVideoQuality:v=>events.push(['quality',v])};
 const room={remoteParticipants:new Map([['host',{identity:'host',videoTrackPublications:new Map([['track',publication]])}]])};
 updateLiveVideoQuality(room,{together:false});updateLiveVideoQuality(room,{together:false});
 assert.deepEqual(events,[['enabled',true],['quality',2]]);
 updateLiveVideoQuality(room,{together:false},false);assert.deepEqual(events.at(-1),['enabled',false]);
 updateLiveVideoQuality(room,{together:false});assert.deepEqual(events.at(-1),['enabled',true]);
});
test('Uniform image enlargement preserves proportions and keeps the image on the stage',async()=>{
 const source=(await readFile(new URL('live-overlays.js',import.meta.url),'utf8')).replace(/^import .*;\n/gm,'');
 const {resizeImageOverlay}=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
 const image={kind:'image',width:.7,height:.4,x:.3,y:.6};
 const large=resizeImageOverlay(image,1);
 assert.equal(large.width,1);assert(Math.abs(large.height-(.4/.7))<1e-9);
 assert.equal(large.x,0);assert(large.y+large.height<=1);
 const small=resizeImageOverlay({...image,width:.08,height:1},.1);
 assert(small.width>=.08&&small.height>=.04);
});
