import {execFileSync} from 'node:child_process';
import {mkdtemp,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile,mkdir} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {createRequire} from 'node:module';
const {chromium}=createRequire(import.meta.url)('playwright');
const {WebSocketServer}=createRequire(import.meta.url)('ws');
const root=resolve(new URL('..',import.meta.url).pathname);
const owner={id:'00000000-0000-4000-8000-000000000001',username:'creator',name:'Kreator Kocehind',bio:'Cerita sehari-hari dari komunitas.',is_admin:true,legal_required:false,profile_limits:{},followers:1500,following_count:15,likes_received:4200,links:[{title:'Situs resmi',url:'https://example.com/'},{title:'Portofolio',url:'https://example.org/'}]};
const post={id:'00000000-0000-4000-8000-000000000002',caption:'Video kreator',kind:'video',media_url:'',thumbnail_url:'',author:owner,views:1234,likes:50,following:false,is_mine:true,is_pinned:false,visibility:'public',mentions:[]};
const ai={id:'youtube',title:'YouTube',summary:'YouTube menyediakan ruang untuk berbagi cerita dan membangun komunitas.\n\nProduk YouTube mencakup YouTube Music, YouTube Kids, dan YouTube Studio.',images:[],sources:[{label:'YouTube resmi',url:'https://about.youtube/'}],studied_at:'2026-10-31T00:00:00Z'};
const qa=process.env.KOCEHIND_QA_DIR||'/tmp/kocehind-qa-v216';

async function scenario(site,path,handler,run){
 const calls=[];
 const server=createServer(async(req,res)=>{
  try{
   const url=new URL(req.url,'http://fixture');
   if(url.pathname.startsWith('/api/')){
    const chunks=[];for await(const chunk of req)chunks.push(chunk);const raw=Buffer.concat(chunks);
    const call={path:url.pathname.slice(4),method:req.method,query:url.searchParams,raw,body:req.headers['content-type']?.includes('json')&&raw.length?JSON.parse(raw):null};calls.push(call);
    let data=await handler(call);
    if(data===undefined){if(call.path==='/users/me'||call.path==='/admin/me'||call.path==='/users/creator')data=owner;else if(call.path==='/users/me/privacy')data={revision:'test'};else data={items:[],next_offset:null,unread:0};}
    if(data?.fixtureFile){res.writeHead(200,{'content-type':data.contentType});res.end(await readFile(data.fixtureFile));return;}
    res.writeHead(data?.fixtureStatus||200,{'content-type':'application/json'});res.end(JSON.stringify(data?.fixtureStatus?data.body:data));return;
   }
   const relative=url.pathname.startsWith('/shared/')?url.pathname.slice(1):/\.(js|css|png)$/.test(url.pathname)?site+url.pathname:site+'/index.html';
   const file=resolve(root,relative);if(!file.startsWith(root+'/'))throw new Error('Invalid path');
   res.writeHead(200,{'content-type':({'.js':'text/javascript','.css':'text/css','.html':'text/html','.png':'image/png'}[extname(file)]||'application/octet-stream')});res.end(await readFile(file));
  }catch{res.writeHead(404);res.end('missing');}
 });
 const sockets=[],wsServer=new WebSocketServer({server,path:'/api/ws'});wsServer.on('connection',socket=>{sockets.push(socket);socket.on('message',value=>{if(String(value)==='ping')socket.send('{"type":"pong"}');});});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:390,height:844}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 try{await page.goto(origin+path);await run(page,calls,{sockets});assert.deepEqual(errors,[]);}finally{await browser.close();wsServer.close();await new Promise(r=>server.close(r));}
}


test('Cover editor selects a real video frame and uploads only that cover image',async()=>{
 const directory=await mkdtemp(resolve(tmpdir(),'kocehind-cover-')),file=resolve(directory,'video.webm');
 execFileSync('ffmpeg',['-nostdin','-v','error','-y','-f','lavfi','-i','testsrc2=size=180x320:rate=12','-t','2','-c:v','libvpx','-b:v','300k',file]);
 let uploads=0,coverBytes;
 try{await scenario('web','/upload',async c=>{
  if(c.path==='/media/upload'){uploads++;if(uploads===2)coverBytes=c.raw;return uploads===1?{kind:'video',media_url:'/video.webm',thumbnail_url:'/automatic.jpg'}:{kind:'image',media_url:'/chosen.jpg',thumbnail_url:'/chosen.jpg'};}
  if(c.path==='/posts')return {...post,id:'chosen-video'};
  if(c.path==='/posts/chosen-video')return {...post,id:'chosen-video'};
 },async(page,calls)=>{
  await page.locator('#upload-file').setInputFiles(file);await page.locator('#choose-cover').click();
  await page.waitForFunction(()=>document.querySelectorAll('.cover-strip img').length===8);
  await page.locator('.cover-editor [type=range]').evaluate(el=>{el.value='1.25';el.dispatchEvent(new Event('input',{bubbles:true}));});
  await mkdir('/tmp/kocehind-qa-v2180',{recursive:true});await page.screenshot({path:'/tmp/kocehind-qa-v2180/cover.png'});
  await page.locator('[data-save]').click();await page.locator('.cover-editor').waitFor({state:'detached'});
  await page.locator('#cover-choice img').waitFor({state:'visible'});await page.locator('#upload-form button[type=submit]').click();
  await page.waitForFunction(()=>location.pathname==='/video/chosen-video');
  const body=calls.find(c=>c.path==='/posts'&&c.method==='POST').body;
  assert.equal(body.cover_url,'/chosen.jpg');assert.equal(body.thumbnail_url,'/automatic.jpg');
  assert.equal(uploads,2);assert.ok(coverBytes.includes(Buffer.from('image/jpeg')));assert.ok(coverBytes.includes(Buffer.from([255,216,255])));
 });}finally{await rm(directory,{recursive:true,force:true});}
});

test('Gallery cover survives editor initialization and can be cancelled without changing the choice',async()=>{
 await scenario('web','/upload',async()=>undefined,async page=>{
  await page.evaluate(async()=>{
   const {chooseVideoCover}=await import('/video-cover.js');
   window.__coverChoice=chooseVideoCover(new File(['unsupported'],'bad.webm',{type:'video/webm'}));
  });
  await page.locator('.cover-editor [type=file]').setInputFiles({name:'gallery.png',mimeType:'image/png',buffer:Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aF9sAAAAASUVORK5CYII=','base64')});
  await page.locator('.cover-stage img').waitFor({state:'visible'});await page.locator('[data-save]').click();
  assert.equal(await page.evaluate(async()=>{const file=await window.__coverChoice;return file.name;}),'gallery.png');
 });
});

test('Profile renders its header immediately and uses a single bundled API request',async()=>{
 await scenario('web','/@other',async c=>{
  if(c.path==='/users/other/profile'){await new Promise(r=>setTimeout(r,350));return {user:{...owner,username:'other',name:'Profil Cepat',id:'other'},posts:{items:[],next_offset:null}};}
 },async(page,calls)=>{
  await page.getByRole('heading',{name:'@other',exact:true}).waitFor();await page.getByRole('heading',{name:'Profil Cepat',exact:true}).waitFor();
  assert.equal(calls.filter(c=>c.path==='/users/other/profile').length,1);assert.equal(calls.find(c=>c.path==='/users/other/profile').query.has('visibility'),false);assert.equal(calls.filter(c=>['/users/other','/users/other/posts'].includes(c.path)).length,0);
 });
});

test('Settings verifies the new mailbox before changing email and keeps an invalid-code error visible',async()=>{
 await scenario('web','/settings',async c=>{
  if(c.path==='/account/security')return {has_password:true};
  if(c.path==='/account/email/request')return {challenge:'challenge',new_email:'new@example.com'};
  if(c.path==='/web/account/email/confirm')return c.body.code==='123456'?{user:{...owner,email:'new@example.com'}}:{fixtureStatus:400,body:{detail:'Kode tidak valid'}};
 },async(page,calls)=>{
  await page.locator('#change-email').click();const dialog=page.locator('dialog');
  await dialog.locator('[name=new_email]').fill('new@example.com');await dialog.locator('[name=password]').fill('password');await dialog.locator('[type=submit]').click();
  await dialog.getByText('Kode dikirim ke new@example.com').waitFor();
  assert.equal(calls.filter(c=>c.path==='/web/account/email/confirm').length,0);
  await dialog.locator('[name=code]').fill('000000');await dialog.locator('[type=submit]').click();await dialog.getByText('Kode tidak valid',{exact:true}).waitFor();
  await dialog.locator('[name=code]').fill('123456');await dialog.locator('[type=submit]').click();await dialog.waitFor({state:'detached'});
  await page.getByText('new@example.com',{exact:false}).waitFor();
 });
});
