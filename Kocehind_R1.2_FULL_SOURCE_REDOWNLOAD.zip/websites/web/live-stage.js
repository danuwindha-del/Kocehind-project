import {renderLiveOverlays} from './live-overlays.js?v=2.18.0';
import {avatar,esc} from '/shared/api.js?v=2.18.0';
import {stageSlots,stageCells} from './live-layout.js?v=2.18.0';

export const liveCameraMirror=(local,facingMode)=>Boolean(local&&facingMode==='user');

// One stage renderer for the actual room and its read-only feed preview.
export function renderLiveStage(stage,info,rtc,{localId='',bindPerson,onEmpty,overlayOptions}={}){
 const state={...info,members:info.members?.length?info.members:[{...info.host,role:'host'}]};
 const slots=stageSlots(state),focus=slots.findIndex(m=>m?.id===info.layout?.focus_id);
 const layout=stageCells(slots.length,focus,stage.clientWidth,stage.clientHeight);
 stage.classList.add('live-stage');stage.classList.toggle('together',Boolean(info.together));
 stage.classList.toggle('voice',info.mode==='audio');stage.classList.toggle('solo',!info.together);
 stage.classList.toggle('duo',Boolean(info.together&&info.seats===2));
 stage.style.gridTemplateColumns=`repeat(${layout.columns},minmax(0,1fr))`;stage.style.gridTemplateRows=layout.rows;
 const ids=new Set(slots.filter(Boolean).map(m=>m.id));
 for(const tile of stage.querySelectorAll('[data-person]'))if(!ids.has(tile.dataset.person)){
  tile.livePressCleanup?.();const video=tile.querySelector('video');if(video)tile.liveTrack?.detach(video);tile.remove();
 }
 stage.querySelectorAll('.empty-seat').forEach(n=>n.remove());
 slots.forEach((member,index)=>{
  const cell=layout.cells[index];
  if(!member){
   const seat=document.createElement(onEmpty?'button':'div');seat.className='empty-seat';
   if(onEmpty){seat.type='button';seat.onclick=onEmpty;}
   seat.setAttribute('aria-label','Kursi tamu '+(index+1));
   seat.style.gridRow=cell.row;seat.style.gridColumn=cell.column;
   seat.innerHTML='<b>+</b><small>Kursi '+(index+1)+'</small>';stage.append(seat);return;
  }
  let tile=[...stage.children].find(n=>n.dataset.person===member.id);
  if(!tile){tile=document.createElement('div');tile.className='live-tile';tile.dataset.person=member.id;
   tile.innerHTML='<div class="live-avatar"></div><span></span>';stage.append(tile);bindPerson?.(tile,member);}
  tile.style.gridRow=cell.row;tile.style.gridColumn=cell.column;
  const signature=JSON.stringify([member.avatar_url,member.name,member.username]);
  if(tile.avatarSignature!==signature){
   tile.avatarSignature=signature;
   const area=tile.querySelector('.live-avatar');area.innerHTML=avatar(member)+`<strong>${esc(member.name||member.username)}</strong>`;
   const image=area.querySelector('img');if(image){image.loading='eager';image.onerror=()=>{
    const fallback=document.createElement('span');fallback.className='avatar letter';fallback.textContent=(member.name||member.username||'K')[0].toUpperCase();image.replaceWith(fallback);};}
  }
  tile.querySelector(':scope > span').textContent=(member.role==='host'?'Host · ':member.is_moderator?'Moderator · ':'')+'@'+member.username;
  const participant=member.id===localId?rtc?.localParticipant:rtc?.remoteParticipants?.get(member.id);
  tile.classList.toggle('speaking',participant?.isSpeaking===true);
  const pub=[...(participant?.videoTrackPublications.values()||[])].find(p=>p.track&&!p.isMuted);
  const video=tile.querySelector('video');
  if(pub?.track&&info.mode==='camera'){
   if(tile.liveTrack!==pub.track){if(video)tile.liveTrack?.detach(video);video?.remove();
    const v=pub.track.attach();v.playsInline=true;v.muted=true;v.autoplay=true;v.dataset.sid=pub.trackSid;v.style.transform='none';v.style.objectFit='cover';
    tile.prepend(v);tile.liveTrack=pub.track;v.play().catch(()=>{});}
   const currentVideo=tile.querySelector('video');
   const facing=pub.track.mediaStreamTrack?.getSettings?.()?.facingMode||rtc?.localParticipant?.kocehindCameraFacing||'user';
   currentVideo?.classList.toggle('local-front-camera',liveCameraMirror(member.id===localId,facing));
   tile.classList.add('has-video');
  }else{if(video)tile.liveTrack?.detach(video);video?.remove();tile.liveTrack=null;tile.classList.remove('has-video');}
 });
 if(info.overlays){
  renderLiveOverlays(stage,{...info.overlays,items:info.overlays.items.filter(i=>!i.participant_id)},{...overlayOptions,editable:overlayOptions?.editable&&!overlayOptions?.guestId});
  for(const tile of stage.querySelectorAll('[data-person]'))renderLiveOverlays(tile,{...info.overlays,items:info.overlays.items.filter(i=>i.participant_id===tile.dataset.person)},{...overlayOptions,editable:overlayOptions?.editable&&overlayOptions?.guestId===tile.dataset.person});
 }
}
