import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {createRequire} from 'node:module';
const {chromium}=createRequire(import.meta.url)('playwright');
const sites=resolve(new URL('..',import.meta.url).pathname);
const viewer={id:'viewer-id',username:'viewer',name:'Viewer Kocehind',email:'viewer@example.test',legal_required:false,followers:10,following_count:3,likes_received:25,links:[],profile_limits:{}};
const creator={id:'creator-id',username:'creator',name:'Creator Kocehind',is_verified:false,is_official:false};
const posts=['a','b','c'].map(id=>({id,kind:'video',caption:'Story '+id,media_url:'/fixture-'+id+'.mp4',hls_url:'',thumbnail_url:'',author:creator,visibility:'public',following:false,is_friend:false,relationship_label:'Ikuti',likes:0,comments:0,views:1}));
async function fixture(handle){
 const server=createServer(async(req,res)=>{
  try{
   const url=new URL(req.url,'http://fixture');
   if(url.pathname.startsWith('/api/')){
    let body='';for await(const part of req)body+=part;
    const result=await handle({path:url.pathname.slice(4),query:url.searchParams,method:req.method,body:body?JSON.parse(body):null});
    res.writeHead(Number.isInteger(result?.status)?result.status:200,{'content-type':'application/json'});res.end(JSON.stringify(result?.data??result??{}));return;
   }
   if(url.pathname.endsWith('.mp4')){res.writeHead(200,{'content-type':'video/mp4','content-length':'1024'});res.end(Buffer.alloc(1024));return;}
   const relative=url.pathname.startsWith('/shared/')?url.pathname.slice(1):/\.(js|css)$/.test(url.pathname)?'web'+url.pathname:'web/index.html';
   const path=resolve(sites,relative);if(!path.startsWith(sites+'/'))throw Error('path');
   const bytes=await readFile(path);res.writeHead(200,{'content-type':({'.js':'text/javascript','.css':'text/css','.html':'text/html'}[extname(path)]||'application/octet-stream')});res.end(bytes);
  }catch(error){res.writeHead(404);res.end('missing: '+error.message);}
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 return {url:'http://127.0.0.1:'+server.address().port,close:()=>new Promise(resolve=>server.close(resolve))};
}
const launch=()=>chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE||'/usr/bin/chromium',args:['--no-sandbox','--no-proxy-server','--proxy-bypass-list=*']});

test('Feed skeleton appears while loading; player starts without waiting for Service Worker registration',async()=>{
 let feedRequests=0;
 const f=await fixture(async request=>{
  if(request.path==='/users/me')return viewer;
  if(request.path==='/feed'){feedRequests++;await new Promise(resolve=>setTimeout(resolve,900));return {items:posts,next_cursor:null};}
  if(request.path==='/notifications'||request.path==='/official/activities/unread')return {items:[],unread:0};
  if(request.path==='/users/viewer/profile')return {user:viewer,posts:{items:[],next_offset:null,total:0}};
  if(request.path.startsWith('/users/me/profile-visits'))return {items:[],total:0,unread:0,next_offset:null};
  if(request.path==='/users/me/privacy')return {revision:'1'};
  return {items:[],next_offset:null,next_cursor:null};
 });
 const browser=await launch(),page=await browser.newPage({viewport:{width:420,height:850}}),errors=[];
 page.on('pageerror',error=>errors.push(error.message));
 await page.addInitScript(()=>{
  if('serviceWorker' in navigator){try{Object.defineProperty(navigator.serviceWorker,'register',{configurable:true,value:()=>new Promise(()=>{})});}catch{}}
  const proto=HTMLMediaElement.prototype;
  Object.defineProperty(proto,'load',{configurable:true,value:function(){this.dataset.testLoad=String((Number(this.dataset.testLoad)||0)+1);}});
  Object.defineProperty(proto,'play',{configurable:true,value:function(){this.dataset.testPlay=String((Number(this.dataset.testPlay)||0)+1);return Promise.resolve();}});
  Object.defineProperty(proto,'pause',{configurable:true,value:function(){this.dataset.testPause=String((Number(this.dataset.testPause)||0)+1);}});
 });
 try{
  await page.goto(f.url);
  await page.locator('.feed-loading-skeleton').waitFor();
  assert.equal(await page.locator('.feed-loading-skeleton').isVisible(),true);
  await page.locator('.post[data-id=a]').waitFor({timeout:5000});
  const first=page.locator('.post[data-id=a] video');
  await page.waitForFunction(()=>Boolean(document.querySelector('.post[data-id=a] video')?.getAttribute('src')));
  const firstSource=await first.getAttribute('src');
  assert.match(firstSource,/fixture-a\.mp4/,'first video source should be assigned even while Service Worker registration is pending');
  await page.evaluate(()=>{const root=document.querySelector('#feed');window.savedFeedRoot=root;window.savedVideo=document.querySelector('.post[data-id=a] video');window.savedScroll=root.scrollTop;});
  await page.locator('[data-nav="inbox"]').click();
  await page.getByRole('heading',{name:'Kotak masuk'}).waitFor();
  await page.locator('[data-nav="profile"]').click();
  await page.getByRole('heading',{name:'Viewer Kocehind'}).waitFor();
  await page.locator('[data-nav="feed"]').click();
  await page.locator('.post[data-id=a]').waitFor();
  await page.waitForFunction(()=>Boolean(document.querySelector('.post[data-id=a] video')?.getAttribute('src')));
  const state=await page.evaluate(()=>({sameRoot:window.savedFeedRoot===document.querySelector('#feed'),sameVideo:window.savedVideo===document.querySelector('.post[data-id=b] video'),scroll:document.querySelector('#feed').scrollTop,source:document.querySelector('.post[data-id=a] video')?.getAttribute('src')}));
  assert.equal(state.sameRoot,true,'feed DOM/root should be reused after visiting Inbox and Profile');
  assert.equal(state.sameVideo,true,'existing video element should be reused, not rebuilt');
  assert.equal(state.scroll,await page.evaluate(()=>window.savedScroll),'feed scroll position should be preserved');
  assert.equal(state.source,firstSource,'already prepared media source should remain attached');
  assert.equal(feedRequests,1,'returning to For You must not request the feed again');
  assert.deepEqual(errors,[]);
 }catch(error){console.log('PAGE ERRORS',errors);console.log('PAGE BODY',await page.locator('#content').innerText());throw error;}
 finally{await browser.close();await f.close();}
});
