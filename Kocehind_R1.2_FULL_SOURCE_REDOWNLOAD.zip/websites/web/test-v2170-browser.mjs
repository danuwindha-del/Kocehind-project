import {execFileSync} from 'node:child_process';
import {mkdtemp,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile,mkdir} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {createRequire} from 'node:module';
const {chromium}=createRequire(import.meta.url)('playwright');
const {WebSocketServer}=createRequire(import.meta.url)('ws');
const root=resolve(new URL('..',import.meta.url).pathname);
const owner={id:'00000000-0000-4000-8000-000000000001',username:'creator',name:'Kreator Kocehind',bio:'Cerita sehari-hari dari komunitas.',is_admin:true,legal_required:false,profile_limits:{},followers:1500,following_count:15,likes_received:4200,links:[{title:'Situs resmi',url:'https://example.com/'},{title:'Portofolio',url:'https://example.org/'}]};
const post={id:'00000000-0000-4000-8000-000000000002',caption:'Video kreator',kind:'video',media_url:'',thumbnail_url:'',author:owner,views:1234,likes:50,following:false,is_mine:true,is_pinned:false,visibility:'public',mentions:[]};
const ai={id:'youtube',title:'YouTube',summary:'YouTube menyediakan ruang untuk berbagi cerita dan membangun komunitas.\n\nProduk YouTube mencakup YouTube Music, YouTube Kids, dan YouTube Studio.',images:[],sources:[{label:'YouTube resmi',url:'https://about.youtube/'}],studied_at:'2026-10-31T00:00:00Z'};
const qa=process.env.KOCEHIND_QA_DIR||'/tmp/kocehind-qa-v216';

async function scenario(site,path,handler,run){
 const calls=[];
 const server=createServer(async(req,res)=>{
  try{
   const url=new URL(req.url,'http://fixture');
   if(url.pathname.startsWith('/api/')){
    const chunks=[];for await(const chunk of req)chunks.push(chunk);const raw=Buffer.concat(chunks);
    const call={path:url.pathname.slice(4),method:req.method,query:url.searchParams,body:req.headers['content-type']?.includes('json')&&raw.length?JSON.parse(raw):null};calls.push(call);
    let data=await handler(call);
    if(data===undefined){if(call.path==='/users/me'||call.path==='/admin/me'||call.path==='/users/creator')data=owner;else if(call.path==='/users/me/privacy')data={revision:'test'};else data={items:[],next_offset:null,unread:0};}
    if(data?.fixtureFile){res.writeHead(200,{'content-type':data.contentType});res.end(await readFile(data.fixtureFile));return;}
    res.writeHead(data?.fixtureStatus||200,{'content-type':'application/json'});res.end(JSON.stringify(data?.fixtureStatus?data.body:data));return;
   }
   const relative=url.pathname.startsWith('/shared/')?url.pathname.slice(1):/\.(js|css|png)$/.test(url.pathname)?site+url.pathname:site+'/index.html';
   const file=resolve(root,relative);if(!file.startsWith(root+'/'))throw new Error('Invalid path');
   res.writeHead(200,{'content-type':({'.js':'text/javascript','.css':'text/css','.html':'text/html','.png':'image/png'}[extname(file)]||'application/octet-stream')});res.end(await readFile(file));
  }catch{res.writeHead(404);res.end('missing');}
 });
 const sockets=[],wsServer=new WebSocketServer({server,path:'/api/ws'});wsServer.on('connection',socket=>{sockets.push(socket);socket.on('message',value=>{if(String(value)==='ping')socket.send('{"type":"pong"}');});});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:390,height:844}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 try{await page.goto(origin+path);await run(page,calls,{sockets});assert.deepEqual(errors,[]);}finally{await browser.close();wsServer.close();await new Promise(r=>server.close(r));}
}

test('Comments show pending and confirmed rows without waiting for a list reload',async()=>{
 let release,confirmed=false;const gate=new Promise(r=>release=r);
 const comment={id:'confirmed-comment',body:'Komentar langsung',username:'creator',likes:0,created_at:'2026-11-02T00:00:00Z'};
 await scenario('web','/video/'+post.id,async c=>{
  if(c.path==='/posts/'+post.id)return {...post,kind:'image'};
  if(c.path.endsWith('/comments')&&c.method==='POST'){await gate;confirmed=true;return comment;}
  if(c.path.endsWith('/comments'))return {items:confirmed?[comment]:[],total:confirmed?1:0,next_offset:null};
 },async page=>{
  await page.locator('[data-action=comments]').click();await page.locator('.comment-form input').fill(comment.body);
  await page.locator('.comment-form button[type=submit]').click();
  await page.locator('[data-comment^=pending-]').waitFor();assert.match(await page.locator('.comments-list').textContent(),/Mengirim…/);
  assert.equal(await page.locator('.comment-form input').inputValue(),'');
  release();await page.locator('[data-comment="confirmed-comment"]').waitFor();
  await page.waitForFunction(()=>!document.querySelector('[data-comment^=pending-]'));
  assert.match(await page.locator('.comments-list').textContent(),/Komentar langsung/);
 });
});

test('Inbox messages render before a delayed write and use the confirmed POST response',async()=>{
 let release;const gate=new Promise(r=>release=r);
 await scenario('web','/inbox?tab=messages&chat=friend',async c=>{
  if(c.path==='/chats')return {items:[],requests:[]};
  if(c.path==='/chats/friend'&&c.method==='POST'){await gate;return {id:'sent',body:c.body.body,from_me:true,created_at:'2026-11-02T00:00:00Z'};}
  if(c.path==='/chats/friend')return {items:[],status:'accepted',can_send:true,peer:{username:'friend'}};
 },async page=>{
  await page.locator('.message-form input').fill('Pesan langsung');await page.locator('.message-form button').click();
  await page.locator('.message.pending').waitFor();assert.match(await page.locator('.messages').textContent(),/Pesan langsung.*Mengirim/s);
  release();await page.waitForFunction(()=>document.querySelector('.message.mine')&&!document.querySelector('.message.pending'));
  assert.match(await page.locator('.messages').textContent(),/Pesan langsung/);
 });
});

test('An incoming websocket event refreshes an open chat before its five-second fallback poll',async()=>{
 let incoming=false;
 await scenario('web','/inbox?tab=messages&chat=friend',async c=>{
  if(c.path==='/chats')return {items:[],requests:[]};
  if(c.path==='/chats/friend')return {items:incoming?[{id:'incoming',body:'Pesan realtime dari teman',from_me:false,created_at:'2026-11-02T00:00:00Z'}]:[],status:'accepted',can_send:true,peer:{username:'friend'}};
 },async(page,calls,{sockets})=>{
  await page.locator('.message-form').waitFor();assert(sockets.length);
  incoming=true;for(const socket of sockets)socket.send('{"type":"message","from_username":"friend"}');
  await page.getByText('Pesan realtime dari teman',{exact:true}).waitFor({timeout:1500});
 });
});

for(const [path,title] of [['/@absent','Oops maaf user tidak di temukan'],['/video/missing','Video yang Anda tuju tidak di temukan'],['/page-missing','Halaman/Page yang Anda Tuju sedang tidak ada atau mungkin telah di pindahkan']]){
 test('Designed missing state: '+path,async()=>{
  await scenario('web',path,async c=>{
   if(c.path==='/users/absent'||c.path==='/posts/missing')return {fixtureStatus:404,body:{detail:'Missing'}};
  },async page=>{
   await page.locator('.not-found h1').waitFor();assert.equal(await page.locator('.not-found h1').textContent(),title);
   for(const width of [320,390,768,1280]){await page.setViewportSize({width,height:844});assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));}
   await page.setViewportSize({width:390,height:844});await mkdir(qa,{recursive:true});await page.screenshot({path:qa+'/v2170-missing-'+(path.startsWith('/@')?'user':path.startsWith('/video')?'video':'page')+'.png'});
  });
 });
}

test('Feed, profile, comments, inbox, settings and upload fit narrow phones and tablets',async()=>{
 await scenario('web','/@creator',async c=>{
  if(c.path.startsWith('/users/creator/posts'))return {items:[post],next_offset:null};
  if(c.path==='/feed')return {items:[{...post,kind:'image'}],next_cursor:null};
  if(c.path==='/posts/'+post.id)return {...post,kind:'image'};
  if(c.path==='/search')return {users:[],posts:[],sounds:[],tags:[]};
  if(c.path==='/chats')return {items:[],requests:[]};
 },async page=>{
  for(const path of ['/@creator','/','/inbox','/settings','/upload','/search']){
   await page.goto(new URL(path,page.url()).href);await page.waitForFunction(()=>!document.querySelector('#content')?.textContent.includes('Memuat cerita…'));
   for(const width of [320,360,390,768,1024]){
    await page.setViewportSize({width,height:844});await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
    const overflow=await page.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth,offenders:[...document.querySelectorAll('body *')].filter(n=>n.getBoundingClientRect().right>innerWidth+1&&getComputedStyle(n).position!=='fixed').slice(0,8).map(n=>n.className||n.tagName)}));
    assert(overflow.scroll<=overflow.width+1,path+': '+JSON.stringify(overflow));
    if(width<=540){const boxes=await page.evaluate(()=>['.logo','#search-form','#header-actions'].map(s=>{const b=document.querySelector(s).getBoundingClientRect();return {left:b.left,right:b.right};}));assert(boxes[0].right<=boxes[1].left+1&&boxes[1].right<=boxes[2].left+1,'Header overlaps at '+width);}
   }
   if(path==='/@creator'){await page.setViewportSize({width:390,height:844});await mkdir(qa,{recursive:true});await page.screenshot({path:qa+'/v2170-profile-mobile.png'});}
  }
 });
});

test('Guest gallery is rendered inside its own tile when focus and seats change',async()=>{
 await scenario('web','/missing',async()=>undefined,async page=>{
  const state=await page.evaluate(async()=>{
   const {renderLiveStage}=await import('/live-stage.js');
   const stage=document.createElement('div');Object.assign(stage.style,{width:'320px',height:'580px',position:'relative',display:'grid'});document.body.append(stage);
   const info={together:true,seats:2,mode:'camera',host:{id:'host'},members:[{id:'host',username:'host',role:'host'},{id:'guest',username:'guest',role:'speaker'}],overlays:{version:1,items:[{id:'image',kind:'image',participant_id:'guest',x:.1,y:.1,width:.8,height:.8,image_url:''}]}};
   const result=[];
   for(const focus of ['', 'host','guest']){
    info.layout={focus_id:focus};renderLiveStage(stage,info,null);
    const tile=stage.querySelector('[data-person=guest]'),image=stage.querySelector('[data-overlay=image]'),a=tile.getBoundingClientRect(),b=image.getBoundingClientRect();
    result.push(image.closest('[data-person]')===tile&&b.left>=a.left&&b.right<=a.right&&b.top>=a.top&&b.bottom<=a.bottom);
   }
   const {liveVideoQuality}=await import('/live-quality.js');
   return {result,quality:liveVideoQuality({role:'host',together:true,seats:9,layout:{focus_id:'host'}},'guest')};
  });
  assert.deepEqual(state.result,[true,true,true]);assert.equal(state.quality,2);
 });
});

for(const site of ['main','admin'])test(site+' keeps its existing layout within phone and tablet widths',async()=>{
 await scenario(site,'/',async c=>{
  if(c.path==='/admin/overview')return {users:10,posts:5,comments:3,blocked:0,hidden:0,verified:1,open_reports:0,trends:[],recent_actions:[],push_configured:true,push_devices:2,push_pending:0};
 },async page=>{
  await page.locator(site==='main'?'.site-header':'.welcome').waitFor();
  for(const width of [320,360,390,768,1280]){
   await page.setViewportSize({width,height:844});await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
   const size=await page.evaluate(()=>({w:innerWidth,scroll:document.documentElement.scrollWidth}));
   assert(size.scroll<=size.w+1,site+JSON.stringify(size));
  }
 });
});
