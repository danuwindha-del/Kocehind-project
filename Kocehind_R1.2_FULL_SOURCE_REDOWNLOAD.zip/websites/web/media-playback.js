// Same-origin media keeps browser cookies and avoids CORS on segment requests.
export function playbackSource(value, origin=globalThis.location?.origin) {
 if(typeof value!=='string'||!value.trim())return '';
 try {
  const u=new URL(value,origin);
  if((u.hostname==='api.kocehind.web.id'||u.origin===origin)&&/^\/(media|streams)\//.test(u.pathname))return '/api'+u.pathname+u.search;
  return ['https:','http:'].includes(u.protocol)?u.href:'';
 }catch{return '';}
}

export function adaptivePlayback(video,post,{Hls=globalThis.Hls}={}){
 let disposed=false,instance=null,fallback=false;
 const original=playbackSource(post.media_url),hls=playbackSource(post.hls_url);
 const useOriginal=()=>{
  if(disposed||fallback)return;
  fallback=true;instance?.destroy();instance=null;
  video.preload='auto';video.src=original;video.load();if(video.closest('.post')?.watching&&!document.hidden)video.play().catch(()=>{});
 };
 video.preload='auto';
 if(hls&&video.canPlayType('application/vnd.apple.mpegurl'))video.src=hls;
 else if(hls&&Hls?.isSupported()){
  instance=new Hls({startLevel:0,maxBufferLength:8,maxMaxBufferLength:16,backBufferLength:4,
    capLevelToPlayerSize:true,maxBufferSize:20*1024*1024});
  instance.on(Hls.Events.ERROR,(_,data)=>{if(data.fatal)useOriginal();});
  instance.loadSource(hls);instance.attachMedia(video);
 }else video.src=original;
 if(!instance)video.load();
 return ()=>{disposed=true;video.ontimeupdate=null;video.onpause=null;video.onplay=null;video.onerror=null;instance?.destroy();instance=null;video.pause();video.removeAttribute('src');video.load();};
}
