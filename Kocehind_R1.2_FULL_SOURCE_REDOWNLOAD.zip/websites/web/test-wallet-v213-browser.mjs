import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile,mkdir} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {chromium} from 'playwright';
const sites=resolve(new URL('..',import.meta.url).pathname);
const user={id:'viewer',username:'viewer',name:'Nama Pengguna',is_admin:true,legal_required:false};
const methods={BRI:'Bank BRI',JAGO:'Bank Jago',DANA:'DANA',SHOPEEPAY:'ShopeePay',GOPAY:'GO-PAY'};
const b={coins:1000,earnings:150000,held:50000,earned_total:250000,paid_total:50000,minimum_withdrawal:50000,withdrawal_methods:methods,coin_debt:0};
async function fixture(site,handle){
 const server=createServer(async(req,res)=>{try{
  const u=new URL(req.url,'http://fixture');
  if(u.pathname.startsWith('/api/')){let raw='';for await(const part of req)raw+=part;const r=await handle({path:u.pathname.slice(4),query:u.searchParams,method:req.method,body:raw?JSON.parse(raw):null});res.writeHead(r?.statusCode||200,{'content-type':'application/json'});res.end(JSON.stringify(r?.data??r??{}));return;}
  const relative=u.pathname.startsWith('/shared/')?u.pathname.slice(1):/\.(js|css|png)$/.test(u.pathname)?site+u.pathname:site+'/index.html';const path=resolve(sites,relative);if(!path.startsWith(sites+'/'))throw Error('path');
  res.writeHead(200,{'content-type':{'.js':'text/javascript','.css':'text/css','.html':'text/html','.png':'image/png'}[extname(path)]||'application/octet-stream'});res.end(await readFile(path));
 }catch(e){res.writeHead(404);res.end('missing');}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));return {url:'http://127.0.0.1:'+server.address().port,close:()=>new Promise(r=>server.close(r))};
}
function base(r){
 if(r.path==='/users/me'||r.path==='/admin/me')return user;
 if(r.path==='/wallet')return b;
 if(r.path==='/web/coins/packages')return {items:[{id:'coin_100',name:'100 Koin',coins:100,price:10000},{id:'coin_1000',name:'1000 Koin',coins:1000,price:100000}]};
 if(r.path==='/web/coins/channels')return {items:[{code:'BRIVA',name:'BRI Virtual Account'},{code:'DANA',name:'DANA'}]};
 if(r.path==='/users/me/privacy')return {revision:'1'};
 return {items:[],next_offset:null,next_cursor:null};
}
async function scenario(site,path,handle,run){
 const f=await fixture(site,handle),browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE,args:['--no-sandbox']}),page=await browser.newPage({viewport:{width:412,height:860}}),errors=[];
 page.setDefaultTimeout(6000);page.on('pageerror',e=>errors.push(e.message));
 await page.route('https://accounts.google.com/**',route=>route.fulfill({body:''}));
 try{await page.goto(f.url+path);await run(page,f.url);assert.deepEqual(errors,[]);}finally{await browser.close();await f.close();}
}
test('Wallet renders on a phone, opens web checkout, and submits only supported withdrawal methods',async()=>{
 const calls=[],orders=[];
 await scenario('web','/wallet',r=>{calls.push(r);
  if(r.path==='/web/coins/orders'&&r.method==='POST'){orders.push({id:'order-1',coins:100,price:10000,status:'unpaid',checkout_url:'https://tripay.co.id/checkout/TEST',created_at:'2026-10-27T10:00:00Z'});return orders[0];}
  if(r.path==='/web/coins/orders')return {items:orders,next_offset:null};
  if(r.path==='/wallet/withdrawals'&&r.method==='POST')return {id:'w1',status:'pending',...r.body};
  return base(r);
 },async page=>{
  await page.getByRole('button',{name:'Buat tagihan',exact:true}).waitFor();
  await page.locator('#coin-form [type=submit]').click();await page.getByRole('link',{name:'Lanjut ke pembayaran'}).waitFor();
  assert.equal(await page.getByRole('link',{name:'Lanjut ke pembayaran'}).getAttribute('target'),'_blank');
  const create=calls.find(r=>r.path==='/web/coins/orders'&&r.method==='POST');assert.match(create.body.request_key,/^[a-f0-9-]{36}$/);assert.equal(create.body.package_id,'coin_100');assert.equal(create.body.method,'BRIVA');
  await page.locator('dialog .close').click();await page.getByRole('button',{name:'Tarik pendapatan',exact:true}).click();
  assert.equal(await page.locator('dialog select option').count(),5);
  await page.locator('dialog [name=amount]').fill('50000');await page.locator('dialog [name=method]').selectOption('GOPAY');await page.locator('dialog [name=account_name]').fill('Nama Pengguna');await page.locator('dialog [name=account_number]').fill('081234567890');await page.locator('dialog [type=checkbox]').check();await page.getByRole('button',{name:'Ajukan penarikan',exact:true}).click();
  await page.locator('dialog').waitFor({state:'detached'});assert(calls.some(r=>r.path==='/wallet/withdrawals'&&r.body?.method==='GOPAY'));
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth),true);
  await mkdir('/tmp/kocehind-qa',{recursive:true});await page.screenshot({path:'/tmp/kocehind-qa/wallet-phone.png',fullPage:true});
 });
});
test('Gift picker preserves the request key after an uncertain response and keeps LIVE open for web top up',async()=>{
 const requests=[];let fail=true;
 await scenario('web','/settings',r=>{
  if(r.path==='/gifts/catalog')return {items:[{id:'mahkota',name:'Mahkota',coins:500,image_url:'/shared/logo.png',video_url:'/mahkota.mp4',duration_seconds:10}]};
  if(r.path==='/live/rooms/room1/gifts'&&r.method==='POST'){requests.push(r.body);if(fail){fail=false;return {statusCode:503,data:{detail:'Coba lagi'}};}return {coins:500,gift:{id:'gift1'}};}
  return base(r);
 },async page=>{
  await page.evaluate(async()=>{const m=await import('/live-gifts.js');await m.giftPicker('room1');});
  assert.equal(await page.getByRole('link',{name:'Top up koin',exact:true}).getAttribute('target'),'_blank');
  await page.getByRole('button',{name:'Kirim gift',exact:true}).click();await page.locator('dialog .form-error').getByText('Coba lagi').waitFor();
  await page.getByRole('button',{name:'Kirim gift',exact:true}).click();await page.locator('#gift-coins').getByText('500',{exact:true}).waitFor();
  assert.equal(requests.length,2);assert.equal(requests[0].request_key,requests[1].request_key);
 });
});
test('Finance admin processes a payout with an explicit transfer reference',async()=>{
 const withdrawal={id:'w1',username:'host',user_id:'host',amount:50000,method:'BRI',account_name:'Nama Host',account_number:'123456789012',status:'pending',created_at:'2026-10-27T10:00:00Z',note:''},actions=[];
 await scenario('admin','/#wallet',r=>{
  if(r.path==='/admin/wallet')return {income_per_coin:50,minimum_withdrawal:50000,packages:[{id:'coin_100',name:'100 Koin',coins:100,price:10000,active:true}]};
  if(r.path==='/admin/wallet/withdrawals')return {items:[withdrawal],next_offset:null};
  if(r.path==='/admin/wallet/withdrawals/w1'){actions.push(r.body);Object.assign(withdrawal,r.body);return withdrawal;}
  return base(r);
 },async page=>{
  await page.getByRole('button',{name:'Mulai proses',exact:true}).click();await page.locator('dialog [name=note]').fill('Memeriksa rekening');await page.getByRole('button',{name:'Simpan tindakan'}).click();
  await page.getByRole('button',{name:'Tandai sudah dibayar',exact:true}).click();await page.locator('dialog [name=payment_reference]').fill('BRI-TEST-20261027');await page.locator('dialog [name=note]').fill('Transfer telah berhasil');await page.locator('dialog [type=checkbox]').check();await page.getByRole('button',{name:'Simpan tindakan'}).click();
  await page.locator('#admin-withdrawals').getByText('Referensi: BRI-TEST-20261027',{exact:false}).waitFor();assert.equal(actions.length,2);assert.equal(actions[1].payment_reference,'BRI-TEST-20261027');
  await page.setViewportSize({width:1440,height:1000});await page.screenshot({path:'/tmp/kocehind-qa/finance-admin.png',fullPage:true});
 });
});

test('Reloading the wallet recovers a sandbox PAID invoice even without its callback',async()=>{
 let paid=false,coins=0,checks=0;
 const order={id:'manual-paid',coins:1000,price:100000,status:'unpaid',provider_reference:'T-MANUAL',created_at:'2026-10-27T10:00:00Z'};
 await scenario('web','/wallet',r=>{
  if(r.path==='/wallet')return {...b,coins};
  if(r.path==='/web/coins/orders')return {items:[{...order,status:paid?'paid':'unpaid',credited_at:paid?'2026-10-27T10:01:00Z':null}],next_offset:null};
  if(r.path==='/web/coins/orders/manual-paid/refresh'&&r.method==='POST'){checks++;if(!paid){paid=true;coins=1000;}return {...order,status:'paid',credited_at:'2026-10-27T10:01:00Z'};}
  return base(r);
 },async page=>{
  await page.locator('#coin-sync-status').getByText('Pembayaran sudah diperiksa.',{exact:true}).waitFor();
  await page.locator('#wallet-balance .wallet-card').first().getByText('1.000',{exact:true}).waitFor();
  assert.match(await page.locator('#coin-orders').innerText(),/Dibayar/);
  assert.equal(checks,1);
  await page.reload();await page.locator('#coin-sync-status').getByText('Status pembayaran sudah diperbarui.',{exact:true}).waitFor();
  assert.equal(checks,1);assert.equal(coins,1000);
 });
});

test('Periksa pembayaran calls the provider and retains an actionable error until retry succeeds',async()=>{
 let actualPaid=false,credited=false,coins=0,checks=0,fail=true;
 const order={id:'manual-retry',coins:100,price:10000,status:'unpaid',provider_reference:'T-RETRY',created_at:'2026-10-27T10:00:00Z'};
 await scenario('web','/wallet',r=>{
  if(r.path==='/wallet')return {...b,coins};
  if(r.path==='/web/coins/orders')return {items:[{...order,status:credited?'paid':'unpaid',credited_at:credited?'2026-10-27T10:01:00Z':null}],next_offset:null};
  if(r.path==='/web/coins/orders/manual-retry/refresh'&&r.method==='POST'){
   checks++;if(fail)return {statusCode:502,data:{detail:'Tripay belum dapat dihubungi'}};
   if(actualPaid&&!credited){coins+=100;credited=true;}
   return {...order,status:credited?'paid':'unpaid'};
  }
  return base(r);
 },async page=>{
  await page.locator('#wallet-error').getByText('Tripay belum dapat dihubungi',{exact:true}).waitFor();
  assert.equal(coins,0);assert.equal(checks,1);
  fail=false;actualPaid=true;
  await page.getByRole('button',{name:'Periksa pembayaran',exact:true}).click();
  await page.locator('#coin-sync-status').getByText('Pembayaran sudah diperiksa.',{exact:true}).waitFor();
  assert.equal(await page.locator('#wallet-error').textContent(),'');
  assert.equal(coins,100);assert.equal(checks,2);
  await page.getByRole('button',{name:'Periksa pembayaran',exact:true}).click();
  await page.locator('#coin-sync-status').getByText('Status pembayaran sudah diperbarui.',{exact:true}).waitFor();assert.equal(checks,2);
 });
});

test('Returning to the wallet tab rechecks an unpaid invoice after a manual sandbox payment',async()=>{
 let actualPaid=false,credited=false,checks=0;
 const order={id:'manual-visible',coins:100,price:10000,provider_reference:'T-VISIBLE',created_at:'2026-10-27T10:00:00Z'};
 await scenario('web','/wallet',r=>{
  if(r.path==='/wallet')return {...b,coins:credited?100:0};
  if(r.path==='/web/coins/orders')return {items:[{...order,status:credited?'paid':'unpaid',credited_at:credited?'2026-10-27T10:01:00Z':null}],next_offset:null};
  if(r.path==='/web/coins/orders/manual-visible/refresh'){checks++;credited=actualPaid;return {...order,status:credited?'paid':'unpaid'};}
  return base(r);
 },async page=>{
  await page.locator('#coin-sync-status').getByText('Pembayaran sudah diperiksa.',{exact:true}).waitFor();assert.equal(credited,false);
  actualPaid=true;
  await page.evaluate(()=>document.dispatchEvent(new Event('visibilitychange')));
  await page.locator('#coin-orders').getByText(/Dibayar/).waitFor();assert.equal(credited,true);assert.equal(checks,2);
 });
});
