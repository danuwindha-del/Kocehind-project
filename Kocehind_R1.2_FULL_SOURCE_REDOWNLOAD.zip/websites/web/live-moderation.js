import {api,me,esc,avatar,openDialog,toast} from '/shared/api.js?v=2.18.0';
const labels={mute_comments:'Bisukan / buka bisukan komentar',block_accounts:'Blokir akun total atas nama host',mute_audio:'Matikan mikrofon tamu',approve_guests:'Setujui / turunkan tamu'};
export function longPress(node,action){
 let timer=null,start=null,held=false;
 const clear=()=>{clearTimeout(timer);timer=null;};
 node.addEventListener('pointerdown',e=>{held=false;start={x:e.clientX,y:e.clientY};clear();timer=setTimeout(()=>{held=true;action();},550);});
 node.addEventListener('pointermove',e=>{if(start&&Math.hypot(e.clientX-start.x,e.clientY-start.y)>12)clear();});
 for(const event of ['pointerup','pointercancel','pointerleave'])node.addEventListener(event,e=>{clear();if(held)e.preventDefault();});
 node.addEventListener('click',e=>{if(held){e.preventDefault();e.stopPropagation();held=false;}},true);
 node.addEventListener('contextmenu',e=>{e.preventDefault();clear();if(!held)action();});
 node.tabIndex=0;node.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();action();}});
 return clear;
}
export function liveModeration({root,base,getInfo,refresh,guestAction,navigate}){
 const clean=new Set();const host=()=>getInfo()?.host?.id===me.id,can=key=>host()||getInfo()?.capabilities?.[key]===true;
 const run=fn=>async()=>{try{await fn();}catch(e){toast(e.message);}};
 async function moderate(action,user_id,seconds=0){await api(base+'/moderation',{method:'POST',body:{action,user_id,seconds}});await refresh();}
 async function personMenu(person){
  const info=getInfo();if(!info)return;const user={...person,...info.members?.find(m=>m.id===person.id)},own=user.id===me.id,protectedUser=user.id===info.host.id||(!host()&&user.is_moderator);
  const options=[['profile','Kunjungi profil']];
  if(!own&&!protectedUser&&can('mute_comments'))options.push(['mute:60','Bisukan komentar 1 menit'],['mute:300','Bisukan komentar 5 menit'],['mute:600','Bisukan komentar 10 menit'],['mute:0','Bisukan sepanjang LIVE'],['unmute','Buka bisukan komentar']);
  if(!own&&!protectedUser&&can('mute_audio')&&user.role==='speaker')options.push(['audio','Matikan mikrofon tamu']);
  if(!own&&!protectedUser&&can('approve_guests')&&user.consent==='requested')options.push(['approve','Setujui naik sebagai tamu']);
  if(host()&&!own)options.push([user.is_moderator?'revoke':'grant',user.is_moderator?'Cabut moderator':'Jadikan moderator']);
  if(!own&&!protectedUser&&can('block_accounts'))options.push(['block','Blokir akun total dari host']);
  if(!own&&!can('block_accounts'))options.push(['personal','Blokir dari akun saya']);
  const d=openDialog('@'+user.username,`<div class="moderation-person">${avatar(user)}<span>${esc(user.name||'')}${user.is_moderator?' · Moderator':''}</span></div><div class="moderation-options">${options.map(([key,text])=>`<button class="btn" data-mod-action="${key}">${text}</button>`).join('')}</div>`);
  d.querySelectorAll('[data-mod-action]').forEach(b=>b.onclick=run(async()=>{const a=b.dataset.modAction;d.close();
   if(a==='profile'){navigate('/@'+encodeURIComponent(user.username));return;}
   if(a.startsWith('mute:'))return moderate('mute_comments',user.id,Number(a.split(':')[1]));
   if(a==='unmute')return moderate('unmute_comments',user.id);
   if(a==='audio')return moderate('mute_audio',user.id);
   if(a==='approve')return guestAction('approve',user.id);
   if(a==='grant'||a==='revoke'){await api(base+'/moderators/'+encodeURIComponent(user.id),{method:a==='grant'?'PUT':'DELETE',...(a==='grant'?{body:Object.fromEntries(Object.keys(labels).map(k=>[k,true]))}:{})});await refresh();return;}
   if(a==='block'||a==='personal'){
    const confirm=openDialog('Blokir akun?',`<p>Akun ini akan diblokir ${a==='block'?'dari host di seluruh Kocehind':'dari akun Anda'}. Hubungan mengikuti diputus. Buka blokir melalui Pengaturan.</p><button class="btn danger" data-confirm>Blokir</button>`);
    confirm.querySelector('button[data-confirm]').onclick=run(async()=>{confirm.close();if(a==='block')await moderate('block_account',user.id);else{await api('/users/'+encodeURIComponent(user.username)+'/block',{method:'POST'});navigate('/live');}});
   }
  }));
 }
 async function muted(){
  const r=await api(base+'/muted');const d=openDialog('Komentar dibisukan',`<div class="live-guests">${r.items.map(u=>`<div>${avatar(u)}<span>@${esc(u.username)}<small>${u.comment_muted_all?'Sepanjang LIVE':esc(new Date(u.comment_muted_until).toLocaleTimeString('id-ID'))}</small></span><button class="btn small" data-unmute="${esc(u.id)}">Buka bisukan</button></div>`).join('')||'<p>Belum ada komentar dibisukan.</p>'}</div>`);
  d.querySelectorAll('[data-unmute]').forEach(b=>b.onclick=run(async()=>{await moderate('unmute_comments',b.dataset.unmute);d.close();await muted();}));
 }
 async function moderators(){
  const r=await api(base+'/moderators');const d=openDialog('Hak akses moderator',`<p>Tekan tahan komentar atau peserta untuk menambahkan moderator. Peran berlaku di LIVE berikutnya sampai host mencabutnya. Moderator tidak dapat mengakhiri LIVE.</p><div class="live-guests">${r.items.map(u=>`<div>${avatar(u)}<span>@${esc(u.username)}</span><button class="btn small" data-rights="${esc(u.id)}">Hak akses</button><button class="btn danger small" data-revoke="${esc(u.id)}">Cabut</button></div>`).join('')||'<p>Belum ada moderator.</p>'}</div>`);
  d.querySelectorAll('[data-revoke]').forEach(b=>b.onclick=run(async()=>{await api(base+'/moderators/'+b.dataset.revoke,{method:'DELETE'});d.close();await refresh();await moderators();}));
  d.querySelectorAll('[data-rights]').forEach(b=>b.onclick=()=>{const u=r.items.find(u=>u.id===b.dataset.rights);const edit=openDialog('Hak @'+u.username,`<form>${Object.entries(labels).map(([key,text])=>`<label class="switch-row">${text}<input name="${key}" type="checkbox" ${u.permissions[key]?'checked':''}></label>`).join('')}<p class="form-error"></p><button class="btn primary" type="submit">Simpan hak akses</button></form>`);edit.querySelector('form').onsubmit=async e=>{e.preventDefault();try{const fd=new FormData(e.target);await api(base+'/moderators/'+u.id,{method:'PUT',body:Object.fromEntries(Object.keys(labels).map(k=>[k,fd.has(k)]))});edit.close();d.close();await refresh();}catch(err){edit.querySelector('.form-error').textContent=err.message;}};});
 }
 async function welcome(){const info=getInfo();const d=openDialog('Pesan pembuka otomatis',`<form><label class="switch-row">Sambut penonton baru<input type="checkbox" name="enabled" ${info.welcome_enabled?'checked':''}></label><label>Pesan<textarea name="text" maxlength="300" rows="4">${esc(info.welcome_text||'')}</textarea></label><p>Gunakan {username}. Dikirim sekali per penonton per LIVE; pengaturan dipakai lagi pada LIVE berikutnya.</p><p class="form-error"></p><button class="btn primary">Simpan</button></form>`);d.querySelector('form').onsubmit=async e=>{e.preventDefault();const fd=new FormData(e.target);try{await api(base+'/settings',{method:'PUT',body:{title:info.title,mode:info.mode,together:info.together,welcome_enabled:fd.has('enabled'),welcome_text:fd.get('text')}});d.close();await refresh();}catch(err){d.querySelector('.form-error').textContent=err.message;}};}
 const controls=root.querySelector('.live-controls');
 for(const [key,text,fn] of [['muted','☷ Komentar dibisukan',muted],['moderators','♧ Hak moderator',moderators],['welcome','✦ Pesan pembuka',welcome]]){const b=document.createElement('button');b.className='btn';b.dataset.moderationControl=key;b.textContent=text;b.onclick=run(fn);b.hidden=true;controls.append(b);}
 return {personMenu,bind(node,user){const clear=longPress(node,()=>personMenu(user));const release=()=>{clear();clean.delete(release);};node.livePressCleanup=release;clean.add(release);},controls(){for(const b of root.querySelectorAll('[data-moderation-control]'))b.hidden=b.dataset.moderationControl==='muted'?!can('mute_comments'):!host();},can,dispose(){clean.forEach(fn=>fn());clean.clear();}};
}
