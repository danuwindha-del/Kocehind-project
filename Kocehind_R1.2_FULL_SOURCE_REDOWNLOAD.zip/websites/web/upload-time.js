export function uploadTime(raw,now=new Date()){
 const date=new Date(raw),age=now-date;
 if(!raw||!Number.isFinite(date.getTime()))return '';
 if(age<60000)return 'Baru saja';
 if(age<3600000)return Math.floor(age/60000)+' menit';
 if(age<86400000)return Math.floor(age/3600000)+' jam';
 if(age<604800000)return Math.floor(age/86400000)+' hari';
 return new Intl.DateTimeFormat('id-ID',{day:'numeric',month:'long',year:'numeric'}).format(date);
}
export function uploadTimeHTML(raw,esc){
 const label=uploadTime(raw);
 return label?`<time class="post-upload-time" data-uploaded-at="${esc(raw)}" datetime="${esc(raw)}" aria-label="Diunggah ${esc(label)}">· ${esc(label)}</time>`:'';
}
