import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';

const dataModule=source=>'data:text/javascript;base64,'+Buffer.from(source).toString('base64');

test('SPA feed keeps a reusable view and clears it for privacy-sensitive changes',async()=>{
 const app=await readFile(new URL('./app.js',import.meta.url),'utf8');
 assert.match(app,/const postCache=new Map\(\),videoCollections=new Map\(\),feedViews=new Map\(\)/);
 assert.match(app,/function suspendActiveFeed\(\)/);
 assert.match(app,/function clearFeedViews\(\)/);
 assert.match(app,/function suspend\(\)/);
 assert.match(app,/function resume\(\)/);
 assert.match(app,/feed-loading-skeleton/);
 assert.match(app,/view\.destroyed\|\|feedViews\.get\(kind\)!==view/);
 assert.match(app,/if\(\!\(feedKind&&feedViews\.has\(feedKind\)\)\)content\.innerHTML=/);
});

class FakeVideo {
 constructor(source){this.dataset=source?{source}:{};this.readyState=0;this.currentTime=0;this.listeners=new Map();}
 addEventListener(name,fn,options={}){const list=this.listeners.get(name)||[];list.push({fn,once:Boolean(options.once)});this.listeners.set(name,list);}
 removeEventListener(name,fn){this.listeners.set(name,(this.listeners.get(name)||[]).filter(item=>item.fn!==fn));}
 emit(name){const list=[...(this.listeners.get(name)||[])];for(const item of list){item.fn();if(item.once)this.removeEventListener(name,item.fn);}}
}

test('Foreground media starts independently; background prefetch waits for readiness and warms one next video',async()=>{
 const messages=[],worker={postMessage:message=>messages.push(message)};
 let registrations=0;
 Object.defineProperty(globalThis,'navigator',{configurable:true,value:{connection:{saveData:false,effectiveType:'4g'},serviceWorker:{controller:worker,ready:Promise.resolve(),register:async()=>{registrations++;return {active:worker};}}}});
 Object.defineProperty(globalThis,'document',{configurable:true,value:{hidden:false}});
 Object.defineProperty(globalThis,'window',{configurable:true,value:{addEventListener(){}}});
 const sessionSource=await readFile(new URL('./session-video.js',import.meta.url),'utf8');
 const session=await import(dataModule(sessionSource));
 const current=new FakeVideo('/current.mp4'),next1=new FakeVideo('/next-1.mp4'),next2=new FakeVideo('/next-2.mp4');
 const card={watching:true,isConnected:true,querySelector:()=>current,nextElementSibling:{querySelector:()=>next1,nextElementSibling:{querySelector:()=>next2,nextElementSibling:null}}};
 session.warmNextVideos(card);
 assert.equal(registrations,0,'prefetch must not start before the current video can play');
 current.readyState=4;current.emit('canplaythrough');
 await new Promise(resolve=>setImmediate(resolve));
 assert.equal(registrations,1);
 assert.equal(messages.length,1);
 assert.equal(messages[0].type,'warm');
 assert.deepEqual(messages[0].urls,['/next-1.mp4'],'only one upcoming video should be prefetched');

 const mediaSource=await readFile(new URL('./media-playback.js',import.meta.url),'utf8');
 const media=await import(dataModule(mediaSource));
 const calls=[];
 const video={
  preload:'none',_src:'',
  set src(value){assert.equal(this.preload,'auto','preload should be enabled before assigning the source');this._src=value;calls.push('src');},
  get src(){return this._src;},
  canPlayType(){return '';},load(){calls.push('load');},pause(){},removeAttribute(name){if(name==='src')this._src='';},
  closest(){return null;},
 };
 const dispose=media.adaptivePlayback(video,{media_url:'https://media.test/foreground.mp4'});
 assert.equal(video.preload,'auto');
 assert.equal(video.src,'https://media.test/foreground.mp4');
 assert.deepEqual(calls,['src','load']);
 dispose();
});
