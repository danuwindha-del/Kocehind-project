let registration,signature='',session=crypto.randomUUID(),prepareTask;
async function worker(){
 if(!('serviceWorker' in navigator))return null;
 registration??=navigator.serviceWorker.register('/video-session-worker.js?v=2.18.0-feed-r1',{scope:'/'});
 const registered=await registration;await navigator.serviceWorker.ready;
 return navigator.serviceWorker.controller||registered.active;
}
export function prepareSessionVideos(){
 return prepareTask??=(async()=>{
  const w=await worker();if(!w)return;
  w.postMessage({type:'init',session});
  if(!navigator.serviceWorker.controller)await new Promise(resolve=>{
   const done=()=>{clearTimeout(timer);navigator.serviceWorker.removeEventListener('controllerchange',done);resolve();};
   const timer=setTimeout(done,1500);navigator.serviceWorker.addEventListener('controllerchange',done,{once:true});
  });
 })().catch(error=>{prepareTask=null;throw error;});
}
export function warmNextVideos(card){
 const current=card?.querySelector('video');if(!current)return;
 const connection=navigator.connection;
 if(connection?.saveData||/^(slow-2g|2g)$/.test(connection?.effectiveType||''))return;
 const start=()=>{
  if(card.watching===false||!card.isConnected||document.hidden)return;
  if(current.readyState<4)return;
  const urls=[];let next=card.nextElementSibling;
  while(next&&urls.length<1){const v=next.querySelector('video');if(v&&!v.dataset.hls)urls.push(v.dataset.source||v.currentSrc||v.src);next=next.nextElementSibling;}
  const key=urls.join('|');if(!key||key===signature)return;signature=key;
  worker().then(w=>w?.postMessage({type:'warm',session,urls})).catch(()=>{});
 };
 if(current.readyState>=4)start();
 else current.addEventListener('canplaythrough',start,{once:true});
}
export function clearSessionVideos(){signature='';prepareTask=null;worker().then(w=>w?.postMessage({type:'clear'})).catch(()=>{});session=crypto.randomUUID();}
window.addEventListener('pagehide',clearSessionVideos);
let owner;
window.addEventListener('sessionchange',event=>{const next=event.detail?.id||null;if(owner!==undefined&&owner!==next)clearSessionVideos();owner=next;});
