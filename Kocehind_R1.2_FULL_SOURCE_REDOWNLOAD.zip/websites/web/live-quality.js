// Room subscriptions are explicit; muted feed previews retain adaptive streaming.
export const liveRoomOptions={adaptiveStream:false,dynacast:true,
 videoCaptureDefaults:{resolution:{width:540,height:960,frameRate:24}},
 publishDefaults:{simulcast:true,degradationPreference:'maintain-resolution',videoEncoding:{maxBitrate:1500000,maxFramerate:24},videoSimulcastLayers:[
  {width:180,height:320,encoding:{maxBitrate:180000,maxFramerate:15}},
  {width:360,height:640,encoding:{maxBitrate:600000,maxFramerate:20}}]},
 audioCaptureDefaults:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}};

export function liveVideoQuality(info,id){
 if(info?.role==='host')return 2;
 const focus=info?.layout?.focus_id||'';
 return !info?.together||info.seats<=2||focus===id?2:focus?0:1;
}
export function updateLiveVideoQuality(room,info,visible=true){
 for(const participant of room?.remoteParticipants?.values()||[]){
  for(const publication of participant.videoTrackPublications.values()){
   const quality=liveVideoQuality(info,participant.identity);
   if(publication.kocehindEnabled!==visible){publication.setEnabled?.(visible);publication.kocehindEnabled=visible;}
   if(visible&&publication.kocehindQuality!==quality){publication.setVideoQuality?.(quality);publication.kocehindQuality=quality;}
  }
 }
}
