# Panduan update Kocehind 2.18.0

Versi aplikasi **2.18.0+47**. Paket sumber ini belum dipasang ke VPS dan belum menghasilkan APK/AAB bertanda tangan.

## Perubahan

### Sampul video

Pada halaman unggah satu video, pilih **Ubah sampul video**. Geser strip cuplikan atau slider, gunakan **Pratinjau**, lalu **Simpan**. **Impor** mengambil JPG/PNG/WebP dari galeri, maksimal 10 MB. Sampul tidak mengubah isi video. Draf aplikasi mempertahankan gambar dan waktu cuplikan pilihan. Album foto tetap memakai alur yang sudah ada.

Android mengambil cuplikan pada perangkat dengan MediaMetadataRetriever, maksimal sisi terpanjang 720 piksel untuk sampul tersimpan. Web mengambil cuplikan melalui decoder video/canvas browser. Jika decoder perangkat tidak mendukung video, impor gambar tetap tersedia. Sampul diunggah sebagai gambar milik akun yang sama, diperiksa kembali oleh backend dan ikut pemeriksaan moderasi gambar yang telah diaktifkan. Sampul bertahan saat memakai musik Kocehind.

### Profil lebih cepat

Identitas dan halaman pertama 24 video diambil bersama melalui `/users/{username}/profile`. Pagination berikutnya tetap melalui endpoint video existing. Aplikasi dapat menampilkan header yang telah dikenal tanpa menunggu seluruh halaman. Cache header dibatasi 20 profil, terpisah menurut akun dan revisi privasi, serta dibuang saat pergantian akun/privasi. Daftar video tetap menunggu pemeriksaan izin terbaru. Web melakukan prefetch ketika tautan profil diarahkan penunjuk. Waktu respons pertama tetap bergantung jaringan/server; pembaruan ini mengurangi permintaan berurutan dan tampilan loading satu halaman penuh.

### Permintaan pesan 24 jam

Penolakan menghitung 24 jam dari waktu keputusan server, bukan pergantian tanggal kalender. Setelah batas itu, pengirim dapat mengajukan satu pesan permintaan baru. Pesan berikutnya menunggu persetujuan. Blokir akun dan aturan pertemanan tetap berlaku. Percakapan yang sedang terbuka memeriksa status kembali secara berkala.

### Ubah email

Buka **Pengaturan → Ubah email**, masukkan email baru serta password saat ini. Akun Google tanpa password mengonfirmasi kepemilikan dengan kode ke email lama terlebih dahulu. Kode enam digit dikirim ke email baru dan berlaku 15 menit. Pengiriman ulang menunggu 60 detik. Email lama tetap menjadi email akun sampai verifikasi berhasil. Setelah berhasil, sesi lama dicabut, sesi perangkat saat ini diperbarui dan pemberitahuan keamanan dikirim ke email lama. Tautan Google existing tetap dipertahankan.

Fitur menggunakan antrean Mailjet dan worker email existing. Pastikan konfigurasi pengiriman email yang dipakai saat pendaftaran masih aktif. Jangan mengubah email langsung di database untuk melewati verifikasi.

## 1. Update backend dan web

Akhiri LIVE aktif, unggah dan ekstrak paket pada VPS backend/web:

```bash
cd /root
unzip Kocehind_v2.18.0_Sampul_Profil_Email.zip
cd Kocehind_v2.18.0_Sampul_Profil_Email
python3 UPDATE_BACKEND_WEB.py --check
python3 UPDATE_BACKEND_WEB.py
curl -fsS http://127.0.0.1:8000/health
```

Health harus menunjukkan **2.18.0**. Updater memakai backup/preflight existing dan migrasi tambahan `migrate_v2_18.py`. Tabel `email_change_requests` menyimpan tujuan perubahan email yang menunggu verifikasi; akun/postingan/saldo existing dipertahankan. Migrasi dapat diulang. Dari source lengkap, gunakan `sudo bash scripts/vps2_update_v2180.sh`.

Hotfix Inbox Web sudah menjadi bagian paket: updater memasang snippet Nginx dengan rute exact `/api/official/activities` agar endpoint koleksi tidak mendapat redirect 301 ke URI berslash. Helper menjalankan validasi `nginx -t`, backup, dan rollback otomatis. Pada instalasi backend baru, website hosts/snippet juga dipasang setelah API siap. Detail dan pemeriksaan HTTP ada di **PANDUAN_HOTFIX_INBOX_WEB.md**.

## Instalasi backend baru

Untuk VPS backend yang benar-benar baru, gunakan source lengkap `kocehind_realtime_v2/` dan jalankan `sudo bash scripts/vps2_instal_baru.sh` (atau installer backend dari source). Setelah API siap, installer sekarang otomatis menerbitkan website hosts dan snippet browser yang sudah memuat Hotfix Inbox Web. Pastikan tidak ada konfigurasi domain web/admin/vt lain yang bentrok. Setelah DNS diarahkan, aktifkan sertifikat TLS untuk domain utama/API dan web/vt/admin sesuai pesan installer.

## 2. Build Android dengan key lama

Ekstrak paket yang sama pada VPS builder dan gunakan proyek Firebase serta signing key lama:

```bash
python3 PINDAH_KEY_LAMA.py build --check-only
python3 PINDAH_KEY_LAMA.py build
```

Build minimum **47**; alat existing memilih nomor lebih tinggi jika riwayat publikasi memerlukannya. Pasang aplikasi baru agar editor sampul dan perubahan email tersedia di Android. Proses build memasang bridge cuplikan lokal secara otomatis. Paket tidak membuat signing key baru.

## 3. Uji setelah pemasangan

1. Unggah video dengan sampul dari tengah video, lalu ulangi dengan galeri. Periksa sampul di profil dan saat memakai sound; simpan/buka draf sekali.
2. Kunjungi profil melalui video, kembali dan buka lagi. Periksa daftar video teman/private tetap sesuai izin.
3. Tolak permintaan pesan pada akun pengujian. Sebelum 24 jam pengiriman ditolak, setelah batas waktu satu permintaan baru dapat dikirim.
4. Ubah email akun pengujian. Pastikan kode tiba di email baru, kode salah ditolak, email lama tetap aktif sebelum konfirmasi dan sesi lama berhenti setelah berhasil.
5. Periksa kamera/LIVE, aktivitas suka/simpan dan notifikasi dengan prosedur versi sebelumnya.

Pengujian perangkat Android fisik, pengiriman email produksi, FCM ke HP dan pemasangan VPS perlu dilakukan pada lingkungan Anda. Paket ini mempertahankan konfigurasi operasional existing.
