# Pengujian Kocehind 2.17.1+46

## Cakupan

- Format waktu: batas menit, jam, hari dan tepat tujuh hari; tanggal lama mencakup tahun.
- Flutter: waktu tersembunyi di For You dan terlihat pada pemutar koleksi profil; pelebaran gambar, pinch dua jari, penyimpanan setelah jari dilepas dan batas kotak peserta.
- Browser: pembukaan video dari profil sendiri/orang lain, pemuatan ulang halaman detail, kembali ke For You, pegangan pelebaran/pembesaran dan gambar tetap di kotak tamu.
- Android push: percobaan ulang pendaftaran setelah gagal tanpa ketukan tambahan; penolakan izin tidak memicu permintaan berulang; notifikasi foreground tidak tergantung sukses pendaftaran ulang; penolakan notifikasi untuk akun lain.
- Backend: antrean bertahan tanpa token, pendaftaran membangunkan antrean, catatan accepted/error, status worker, pembatasan akses status, konflik versi, proyek APK berbeda, uji khusus satu perangkat, batas frekuensi uji, kesalahan FCM yang disanitasi, migrasi berulang dan data postingan/perangkat tetap tersedia.
- API gambar: image_fit fill diterima untuk gambar milik tamu; ukuran/posisi di luar kotak dan nilai fit tidak sah ditolak. Waktu unggahan asli tetap sama setelah suka/simpan pada detail dan profil.
- Regresi kamera, LIVE, interaksi, privasi, sesi, pembayaran, installer dan alat signing existing.

## Hasil

**Flutter: 150 lulus, 0 gagal.** Analisis statis: tidak ada masalah.

**Web: 205 lulus, 0 gagal.** Chromium 134 dan pengujian DOM/API existing.

**Backend dan installer source: 102 lulus, 1 dilewati, 0 gagal.** Dua pengujian API gambar/tanggal tambahan juga lulus: **2 lulus, 0 gagal**.

**Alat paket/build: 44 lulus, 0 gagal.** Checksum source/web dan CRC arsip diverifikasi sebelum penyerahan.

## Batas verifikasi

Tidak ada deployment VPS, APK/AAB bertanda tangan, HP fisik, atau pengiriman ke FCM produksi dalam pengerjaan ini. Pengujian FCM memakai transport/respons pengganti dan database antrean nyata. Status accepted menunjukkan penerimaan oleh layanan FCM, bukan bukti tampil pada bilah HP. Uji HP dan server disediakan di Pengaturan untuk memisahkan masalah izin Android dari konfigurasi/pengiriman server.
