#!/usr/bin/env python3
from pathlib import Path
import subprocess
import sys
runtime=Path('/opt/kocehind/backend/setup_mycha.py')
if not runtime.is_file():
    raise SystemExit('Pasang backend 2.18.0 terlebih dahulu.')
raise SystemExit(subprocess.call(['/opt/kocehind/venv/bin/python',str(runtime),*sys.argv[1:]]))
