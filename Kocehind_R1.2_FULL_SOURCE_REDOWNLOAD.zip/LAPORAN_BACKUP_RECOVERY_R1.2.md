# Laporan Integrasi Kocehind Backup & Recovery Manager R1.2

## Cakupan
- Menyimpan metadata jaringan sumber (alamat interface, rute, IP publik yang dapat dideteksi/diatur melalui override).
- Opsi restore `--migration-mode` mempertahankan identitas dan konfigurasi jaringan VPS tujuan (hostname, hosts, firewall, SSH host keys, dan konfigurasi jaringan yang di-exclude oleh aturan migrasi).
- `migrate-check` menghasilkan laporan sumber/tujuan, kandidat literal IP di file konfigurasi aman, dan status resolusi domain Kocehind.
- `migrate-apply` mendukung dry-run default; apply membutuhkan token konfirmasi spesifik `REPLACE OLD_IP WITH NEW_IP`, membuat safety archive, melakukan penulisan atomik, validasi `nginx -t`, dan rollback bila validasi gagal.
- `migrate-auto` hanya bekerja otomatis jika backup merekam tepat satu IP publik sumber; default dry-run dan apply memerlukan `AUTO-MIGRATE-KOCEHIND`.
- Cloudflare, firewall provider, allowlist pembayaran, dan layanan eksternal tidak diubah otomatis.

## Perintah migrasi
```bash
sudo kocehind-backup restore /root/restore/backup.tar.gz \
  --confirm RESTORE-KOCEHIND --skip-safety-backup --migration-mode
sudo kocehind-backup migrate-check --archive /root/restore/backup.tar.gz
sudo kocehind-backup migrate-auto --archive /root/restore/backup.tar.gz
```

Untuk backup lama atau NAT, masukkan IP lama/baru setelah diverifikasi:
```bash
sudo kocehind-backup migrate-apply --old-ip OLD_IP --new-ip NEW_IP
sudo kocehind-backup migrate-apply --old-ip OLD_IP --new-ip NEW_IP \
  --apply --confirm 'REPLACE OLD_IP WITH NEW_IP' --reload-nginx
```

## Validasi yang dijalankan
- Python bytecode compilation: lulus.
- Bash syntax check installer: lulus.
- Backup Manager unit tests: 19/19 lulus.
- ZIP source internal dan paket final: diverifikasi setelah pembuatan.

## Batasan
- Belum dijalankan pada VPS produksi atau staging milik pengguna.
- Deteksi IP publik dapat tidak tersedia pada VPS NAT; berikan `--new-public-ip`/IP manual.
- DNS Cloudflare harus diubah pada dashboard/API Cloudflare setelah server baru diuji.
- Sertifikat SSL, payment/webhook allowlist, SMTP, Firebase, LiveKit, dan storage/CDN perlu diuji sesuai layanan aktif.
- Restore penuh bersifat destruktif. Uji di VPS staging dan jangan matikan VPS lama sampai seluruh uji lulus.
