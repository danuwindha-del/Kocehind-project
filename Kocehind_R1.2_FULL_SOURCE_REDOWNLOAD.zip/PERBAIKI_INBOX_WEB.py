#!/usr/bin/env python3
"""Fix the official inbox's Nginx slash redirect without restarting the API."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import tempfile
from datetime import datetime, timezone


SNIPPET = Path('/etc/nginx/snippets/kocehind-browser.locations.conf')
BACKUPS = Path('/opt/kocehind/web-backups')
MARKER = '# Kocehind inbox fix: collection URI must not acquire a trailing slash.'


def blocks(text):
    """Locate location blocks, ignoring braces/directives in comments and quotes."""
    token = re.compile(r'#[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[{};]|[^\s{};#\"\']+')
    tokens = [(m.group(), m.start(), m.end()) for m in token.finditer(text)
              if not m.group().startswith('#')]
    result = []
    for i, (word, start, _) in enumerate(tokens):
        if word != 'location':
            continue
        j = i + 1
        while j < len(tokens) and tokens[j][0] not in ('{', ';', '}'):
            j += 1
        if j == len(tokens) or tokens[j][0] != '{':
            raise RuntimeError('Deklarasi location Nginx tidak dikenali.')
        declaration = [x[0] for x in tokens[i+1:j]]
        depth, k = 1, j + 1
        while k < len(tokens) and depth:
            if tokens[k][0] == '{':
                depth += 1
            elif tokens[k][0] == '}':
                depth -= 1
            k += 1
        if depth:
            raise RuntimeError('Blok location Nginx tidak seimbang.')
        result.append((declaration, start, tokens[k-1][2], tokens[j][2]))
    return result


def patch(text):
    locations = blocks(text)
    prefixes = [x for x in locations if x[0] in (
        ['^~', '/api/official/activities/'], ['/api/official/activities/'])]
    exact = [x for x in locations if x[0] == ['=', '/api/official/activities']]
    if len(prefixes) != 1 or len(exact) > 1:
        raise RuntimeError('Diperlukan tepat satu rute /api/official/activities/ pada snippet browser existing.')
    _, start, end, body_start = prefixes[0]
    body = text[body_start:end-1]
    # Clone the existing upstream, headers, timeouts, log/cache policy and any
    # deployment-specific directives. Only remove the upstream URI's final slash.
    pattern = r'(?m)^(\s*proxy_pass\s+https?://[^\s;]+/official/activities)/\s*;'
    exact_body, count = re.subn(pattern, r'\1;', body)
    if count != 1:
        raise RuntimeError('Upstream official activities existing tidak dikenali; konfigurasi tidak diubah.')
    route = 'location = /api/official/activities {' + exact_body + '}'
    if exact:
        _, a, b, _ = exact[0]
        if text[a:b].split() == route.split():
            return text
        raise RuntimeError('Rute exact custom sudah ada dan berbeda; gabungkan secara manual agar tidak tertimpa.')
    return text[:start] + MARKER + '\n' + route + '\n' + text[start:]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def atomic_write(path, data, metadata):
    fd, name = tempfile.mkstemp(prefix='.' + path.name + '-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
            os.fchmod(stream.fileno(), stat.S_IMODE(metadata.st_mode))
            if os.geteuid() == 0:
                os.fchown(stream.fileno(), metadata.st_uid, metadata.st_gid)
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def nginx_test():
    subprocess.run(['nginx', '-t'], check=True, timeout=30)


def reload_nginx():
    subprocess.run(['systemctl', 'reload', 'nginx'], check=True, timeout=30)


def activate(path, data, previous, metadata):
    atomic_write(path, data, metadata)
    try:
        nginx_test()
        reload_nginx()
    except (Exception, KeyboardInterrupt):
        atomic_write(path, previous, metadata)
        try:
            nginx_test()
            reload_nginx()
        except Exception:
            print('Konfigurasi sebelumnya sudah dikembalikan di disk; periksa nginx -t dan status nginx.')
        raise


def install(path=SNIPPET, backup_root=BACKUPS, check_only=False):
    path = path.resolve(strict=True)
    original = path.read_bytes()
    updated = patch(original.decode('utf-8')).encode('utf-8')
    nginx_test()
    if original == updated:
        print('Rute inbox sudah diperbaiki; tidak ada perubahan.')
        return None
    if check_only:
        print('PREFLIGHT OK: rute exact akan ditambahkan. Belum ada perubahan.')
        return None
    metadata = path.stat()
    backup_root.mkdir(parents=True, exist_ok=True)
    folder = Path(tempfile.mkdtemp(prefix='inbox-' + datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S') + '-', dir=backup_root))
    folder.chmod(0o700)
    backup = folder / path.name
    shutil.copy2(path, backup)
    record = folder / 'rollback.json'
    record.write_text(json.dumps({'config': str(path), 'backup': backup.name,
        'original_sha256': digest(original), 'installed_sha256': digest(updated)}, indent=2) + '\n')
    record.chmod(0o600)
    activate(path, updated, original, metadata)
    print('PERBAIKAN INBOX TERPASANG. Nginx dimuat ulang; backend dan data tidak diubah.')
    print('Backup dan rollback:', record)
    print('Rollback: sudo python3 PERBAIKI_INBOX_WEB.py --rollback ' + str(record))
    return record


def rollback(record):
    record = record.resolve(strict=True)
    details = json.loads(record.read_text())
    name = details['backup']
    if Path(name).name != name:
        raise RuntimeError('Nama backup tidak valid.')
    backup = record.parent / name
    original = backup.read_bytes()
    if digest(original) != details['original_sha256']:
        raise RuntimeError('Checksum backup tidak sesuai.')
    path = Path(details['config']).resolve(strict=True)
    current = path.read_bytes()
    if digest(current) == details['original_sha256']:
        print('Konfigurasi sudah berada pada versi sebelum perbaikan.')
        return
    if digest(current) != details['installed_sha256']:
        raise RuntimeError('Konfigurasi berubah setelah hotfix; rollback dihentikan agar perubahan baru tetap aman.')
    nginx_test()
    activate(path, original, current, path.stat())
    print('Rollback inbox selesai; konfigurasi sebelum hotfix kembali aktif.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group()
    action.add_argument('--check', action='store_true', help='Periksa tanpa mengubah file')
    action.add_argument('--rollback', type=Path, metavar='RECORD_JSON')
    parser.add_argument('--snippet', type=Path, default=SNIPPET)
    args = parser.parse_args()
    if os.geteuid() != 0:
        parser.error('Jalankan dengan sudo pada VPS backend/web.')
    if args.rollback:
        rollback(args.rollback)
    else:
        install(args.snippet, check_only=args.check)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        raise SystemExit('BELUM BERHASIL: ' + str(error)) from None
