#!/usr/bin/env python3
"""Restore backend/web integration while deploying the bundled Studio R1 design."""
import argparse
from pathlib import Path
import subprocess
import sys
from package_ops import require_root, source_tree, runtime_environment, install_backend_tools
from UPDATE_UI_WEB import verify


def verify_inbox_hotfix(project):
    helper = project / 'backend/deploy/fix_inbox_nginx.py'
    snippet = project / 'backend/deploy/web/kocehind-browser.locations.conf'
    if not helper.is_file() or not snippet.is_file():
        raise RuntimeError('Helper/source snippet Hotfix Inbox Web tidak lengkap.')
    content = snippet.read_text()
    required = (
        'location = /api/official/activities {',
        'proxy_pass http://127.0.0.1:8000/official/activities;',
        'proxy_set_header Authorization $http_authorization;',
    )
    if not all(item in content for item in required):
        raise RuntimeError('Source snippet belum memuat Hotfix Inbox Web yang benar.')
    live_snippet = Path('/etc/nginx/snippets/kocehind-browser.locations.conf')
    if live_snippet.is_file():
        subprocess.run([sys.executable, str(helper), '--snippet', str(live_snippet), '--check'], check=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='Preflight tanpa perubahan pada VPS')
    args = parser.parse_args()
    require_root()
    if not Path('/etc/kocehind/backend.env').is_file():
        raise RuntimeError('Backend existing belum ditemukan. Updater ini bukan installer VPS kosong.')
    with source_tree() as project, runtime_environment() as env:
        verify(project / 'websites', project / 'UI_MANIFEST.json')
        verify_inbox_hotfix(project)
        subprocess.run(['nginx', '-t'], check=True)
        if args.check:
            print('PREFLIGHT OK: source, web Studio R1, Hotfix Inbox Web, Python backend dan Nginx siap. Belum ada perubahan.')
            print('Update akan mencadangkan database/media dan memulai ulang API/worker; akhiri LIVE dahulu.')
            return
        subprocess.run(['bash', str(project / 'scripts/vps2_update_v2180.sh')],
                       cwd=project, env=env, check=True)
        install_backend_tools(project)
    print('KOCEHIND 2.18.0 TERPASANG dengan desain Studio R1. Env, saldo, pesanan dan dokumen hukum aktif dipertahankan.')
    print('Periksa worker: /opt/kocehind/venv/bin/python DIAGNOSA_INTEGRASI.py')


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        raise SystemExit('BELUM SELESAI: ' + str(exc)) from None
