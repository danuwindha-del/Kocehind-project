# Hotfix Inbox Web — Kocehind v2.18.0

Hotfix ini sudah digabung ke source terpadu. Versi aplikasi tetap **2.18.0+47**; APK tidak perlu dibangun ulang.

## Perbaikan

Daftar aktivitas resmi meminta `/api/official/activities?offset=0&limit=30`. Sebelumnya Nginx hanya memiliki prefix `/api/official/activities/`, sehingga URI koleksi tanpa garis miring mendapat redirect 301 HTML sebelum mencapai backend. Backend memakai `/official/activities` tanpa garis miring.

Source browser snippet sekarang memuat `location = /api/official/activities` dengan upstream tanpa trailing slash. Cookie dan Authorization tetap diteruskan, query pagination dipertahankan, serta access log/cache dinonaktifkan seperti rute detail/media terkait. Autentikasi backend tidak dilemahkan: tanpa sesi respons 401 JSON tetap normal; sesi valid akan mendapat 200 JSON.

## Berlaku otomatis

- **Instalasi backend baru:** `backend/deploy/install_backend_ubuntu.sh` menjalankan `scripts/vps2_pasang_website.sh` setelah API siap. Website hosts dan snippet browser terpasang bersama hotfix. Setelah DNS diarahkan, aktifkan TLS untuk domain utama/API dan web/vt/admin sesuai panduan installer.
- **Update backend penuh:** `UPDATE_BACKEND_WEB.py` / `scripts/vps2_update_v2180.sh` menjalankan deployment website yang memakai snippet terbaru.
- **Update backend langsung:** `backend/deploy/update_backend_ubuntu.sh` menjalankan helper hotfix bila snippet browser sudah ada. Jika website belum dipasang, helper akan diterapkan saat `scripts/vps2_pasang_website.sh` dijalankan.
- **Deployment website terpisah:** `scripts/vps2_pasang_website.sh` menyalin snippet source lalu menjalankan helper idempoten.

Helper menjalankan `nginx -t`, membuat backup dengan permission terbatas, reload Nginx hanya jika ada perubahan, dan memulihkan file sebelumnya jika validasi/reload gagal. Backend API, database, saldo, media, env, TLS, dan APK tidak diubah oleh hotfix ini.

## Penerapan manual pada VPS yang sudah berjalan

Untuk hanya memasang hotfix tanpa menjalankan update backend: ekstrak paket terpadu, masuk ke folder paket, lalu jalankan:

```bash
sudo python3 PERBAIKI_INBOX_WEB.py --check
sudo python3 PERBAIKI_INBOX_WEB.py
```

Jika snippet memakai lokasi khusus:

```bash
sudo python3 PERBAIKI_INBOX_WEB.py --snippet /lokasi/snippet-browser.conf --check
sudo python3 PERBAIKI_INBOX_WEB.py --snippet /lokasi/snippet-browser.conf
```

Script menampilkan lokasi `rollback.json` yang tepat. Gunakan record tersebut untuk rollback:

```bash
sudo python3 PERBAIKI_INBOX_WEB.py --rollback /opt/kocehind/web-backups/inbox-TANGGAL-ID/rollback.json
```

Jangan menebak nama record; gunakan lokasi yang dicetak saat pemasangan. Rollback menolak menimpa konfigurasi yang telah diedit lagi setelah hotfix.

## Verifikasi

```bash
curl -sS --max-time 12 -D - -o /dev/null \
  'https://web.kocehind.web.id/api/official/activities?offset=0&limit=30'
```

Tanpa login, hasil yang diharapkan **HTTP 401** dan `Content-Type: application/json`, tanpa header `Location` ke `/activities/`. Setelah login, permintaan dari browser harus mendapat **200 JSON** (atau daftar kosong jika belum ada pengumuman). Periksa juga buka detail, tandai dibaca, dan media pengumuman. Jangan memakai `curl -L`, karena redirect awal harus terlihat.

Jika browser masih menyimpan redirect lama, lakukan reload tanpa cache atau bersihkan cache file situs; cookie tidak perlu dihapus.

## Tes regresi

Dari root source `kocehind_realtime_v2/`:

```bash
python3 -m unittest discover -s tests -p test_inbox_nginx_hotfix.py -v
```

Tes memeriksa reproduksi 301 lama, 401 JSON tanpa autentikasi, 200 JSON dengan cookie/Bearer, query pagination, detail/unread/media, POST read/refresh, proteksi access log, backup/idempotensi/rollback, pemulihan kegagalan Nginx, dan integrasi jalur instalasi/update. Tes proxy nyata menggunakan Nginx bila binary tersedia.

Paket ini hanya menyiapkan source; tidak memasang hotfix ke VPS secara otomatis saat ZIP dibuat.
