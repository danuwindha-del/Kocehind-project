# Pengujian Kocehind 2.16.1

2 November 2026. Dasar: source 2.16.0 pada repositori `danuwindha-del/Kocehind-project`, commit `4feb10d9a11e04da8018bbe7f77897fc4b3c55b7`. Perubahan dikerjakan pada salinan terisolasi. Tidak ada deployment VPS, build release memakai signing key pengguna, atau transaksi produksi.

## Hasil

| Pemeriksaan | Hasil aktual |
|---|---|
| Seluruh cakupan backend, dua bagian serial | **535 lulus, 9 dilewati, 0 gagal** |
| Interaksi, badge LIVE, privasi dan startup dua worker setelah perbaikan kompatibilitas | **29 lulus, 0 gagal** |
| Flutter 3.38.1 / Dart 3.10.0, `flutter analyze --no-pub` | **Tidak ada masalah** |
| Seluruh `flutter test --no-pub` | **132 lulus, 0 gagal** |
| Seluruh tes web/DOM/browser | **189 lulus, 0 gagal** |
| Ulang terfokus web sesudah perapihan avatar dan pengaturan encoder | **6 lulus, 0 gagal** |
| Alat build/paket dan diagnosis Google Play | **41 lulus, 0 gagal** |
| Pemasang UI dan setup Android/App Links/permissions | **10 lulus, 0 gagal** |
| Sintaks Python/shell, checksum source dan CRC ZIP | Diperiksa pada paket akhir |

Browser uji: Chrome Headless Shell 134.0.6998.35 dengan Playwright 1.62.1. Browser dipilih lewat opsi runner yang sudah tersedia; aplikasi tidak diberi pengaturan khusus untuk browser tersebut. Dependency aplikasi tidak ditingkatkan massal. Patch kompatibilitas LiveKit 2.6.4 existing tetap dipakai.

Pemeriksaan ulang backend sempat terputus setelah 354 hasil tes tercetak tanpa kegagalan. Pemeriksaan dilanjutkan pada bagian yang tersisa dengan empat tes tumpang tindih. Total pada tabel menghitung setiap kasus sekali. Ini merupakan cakupan seluruh suite dalam dua proses serial, bukan klaim satu proses yang selesai tanpa interupsi.

## Reproduksi masalah awal

Sebelum perbaikan, empat permintaan like bersamaan pada postingan yang sama menimbulkan `IntegrityError: UNIQUE constraint failed: likes.user_id, likes.post_id` melalui API/SQLite nyata. Permintaan dengan status tujuan yang diulang juga membalik status karena handler lama selalu melakukan toggle. Ini membuktikan dua kelemahan source lama; screenshot HTTP 500 tidak membuktikan bahwa exception VPS pengguna pasti identik. Penentuan penyebab khusus VPS tetap memerlukan traceback pada waktu kejadian.

Kasus tersebut kini menguji permintaan bersamaan, pengiriman ulang status sama, pembatalan status, jumlah baris, jumlah notifikasi dan metrik. Kegagalan antrean push yang disuntikkan membuktikan rollback like/notifikasi/metrik sebelum retry, sehingga respons gagal tidak meninggalkan like setengah selesai. Test juga mempertahankan klien lama tanpa body maupun dengan `{}`, serta penolakan setelah akses privat dicabut.

Pada run regresi awal ditemukan fixture pemeriksaan health yang masih mengharapkan versi 2.16.0 dan body kosong klien lama yang tervalidasi sebelum pemeriksaan akses. Ekspektasi versi diperbarui, body kosong dipertahankan sebagai toggle lama, lalu pengujian terkait diulang. Tidak ada penolakan privasi yang diubah menjadi akses yang dibolehkan.

## Perilaku yang diperiksa

- Aktivitas dari API menghasilkan tujuan postingan yang benar. Like/simpan dari tujuan itu dapat diaktifkan, dinonaktifkan dan dibuka kembali dengan status yang tersimpan.
- Flutter mengirim satu perubahan ketika ada dua pemanggilan like yang masih menunggu. Widget membuka postingan melalui Inbox, menekan like/simpan dan memperbarui ikon. Kegagalan pemuatan ulang koleksi diuji terpisah; keberhasilan tindakan utama tetap terlihat tanpa exception latar yang tidak tertangani.
- Badge tidak aktif ketika ruang masih starting. Sesudah webhook host terverifikasi, API profil, detail postingan, feed dan status avatar menampilkan room ID yang sama. End, blokir, kick serta perubahan privasi menghilangkan badge bagi viewer terkait.
- Widget avatar membuka room yang sesuai; setelah host selesai, avatar kembali membuka foto profil. Web menguji ring pada feed, navigasi ke LIVE, perubahan status pada profil tanpa reload, serta alur aktivitas dan klik ganda pada browser ponsel.
- Render web pada viewport ponsel diperiksa secara visual untuk posisi label, ring dan fallback foto. Hasil screenshot pengujian menggunakan fixture, bukan kondisi akun/VPS pengguna.
- Kamera sebelum LIVE memakai capture options yang sama dengan ruang LIVE dan mirror eksplisit off. Renderer ruang/pratinjau bersama dan web tetap tanpa pembalikan tambahan. Konfigurasi capture dan encoder 540p/24 fps, simulcast, anggaran bitrate serta pemilihan lapisan diuji pada source/klien.

## Reproduksi pengujian

Dari source lengkap, gunakan database sementara yang disediakan fixture; jangan arahkan tes ke produksi:

```bash
python3 -m venv .venv-test
.venv-test/bin/pip install -r backend/requirements.txt -r backend/requirements-test.txt
.venv-test/bin/python -m pytest backend/tests -q
.venv-test/bin/python -m pytest tools/test_ui_installer.py flutter/scripts/tests -q
```

```bash
cd flutter
flutter pub get
python3 scripts/fix_livekit_compat.py
flutter analyze --no-pub
flutter test --no-pub
```

Dari root source untuk web:

```bash
npm ci
npx playwright install chromium
npm run test:web
```

Runner uji di lingkungan pengerjaan memakai browser lokal dengan override yang sudah ada:

```bash
KOCEHIND_CHROMIUM_EXECUTABLE=/path/to/chrome-headless-shell \
node --import ./tools/playwright-runtime.mjs --test --test-force-exit --test-concurrency=2 websites/web/test*.mjs
```

Dari folder paket luar, dengan pytest tersedia: `python3 -m pytest tests -q`.

## Batas hasil

Uji API menggunakan database/media sementara dan pengganti terkendali untuk layanan eksternal. Pengujian ini tidak membuktikan performa atau kapasitas PostgreSQL/SFU produksi. Tes opsional yang membutuhkan PostgreSQL khusus, RTC nyata atau model tambahan mengikuti prasyarat masing-masing; hasil yang dilewati tidak dihitung sebagai lulus.

Belum dilakukan build native APK/AAB release, pemasangan di ponsel, uji gerakan kiri/kanan dua perangkat, fokus kamera, pengukuran bitrate aktual, packet loss, kualitas seluler atau kapasitas VPS. Target 540p dan bitrate lebih rendah adalah perubahan konfigurasi yang teruji, bukan jaminan bahwa gambar dari setiap kamera/jaringan pasti tajam. Ketiga lapisan simulcast dapat memakai bandwidth secara bersamaan. Ikuti uji penerimaan di PANDUAN_UPDATE_v2.16.1.md setelah backend dan APK diperbarui.
