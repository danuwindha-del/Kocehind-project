# Kocehind 2.17.1 — Waktu unggahan, gambar tamu dan notifikasi HP

Android **2.17.1+46**. Paket berisi source lengkap dan alat update/build. Paket belum dipasang ke VPS dan tidak berisi APK/AAB bertanda tangan.

## Waktu unggahan pada profil

Tanggal dibaca dari waktu pembuatan postingan asli, termasuk postingan lama. Menyukai, menyimpan atau membuka video tidak mengganti tanggal unggahannya.

- Kurang dari 1 menit: **Baru saja**.
- Kurang dari 1 jam: **1 menit**, **2 menit**, dan seterusnya.
- Kurang dari 1 hari: **1 jam**, **2 jam**, dan seterusnya.
- Kurang dari 7 hari: **1 hari** sampai **6 hari**.
- Mulai 7 hari: tanggal, bulan dan tahun, misalnya **10 November 2023**, mengikuti waktu lokal perangkat.

Waktu hanya muncul setelah membuka video dari profil sendiri atau profil orang lain. For You, penelusuran dan pembukaan biasa dari aktivitas/notifikasi tidak menambahkan label ini. Di web, asal pembukaan dari profil dipertahankan ketika halaman detail dimuat ulang. Label relatif diperbarui selama video aktif.

## Memperbesar gambar tamu

Buka pengaturan gambar saat menjadi tamu kamera, lalu pilih pengaturan langsung di layar. Tersedia:

- Pegangan kanan untuk melebarkan gambar.
- Pegangan bawah untuk mengubah tinggi gambar.
- Pegangan sudut untuk memperbesar kedua ukuran.
- Gerakan dua jari untuk memperbesar dan menggeser gambar.
- Slider ukuran/lebar/tinggi dan tombol **Penuhi kotak LIVE** pada editor.

Setelah ukurannya diubah, isi gambar ikut mengisi lebar/tinggi yang dipilih. Posisi dan ukuran selalu dibatasi ke kotak peserta, termasuk ketika fokus/kursi berubah. Batas server, kepemilikan gambar dan pemeriksaan moderasi existing tetap berlaku.

## Perbaikan notifikasi

Perbaikan ini menutup beberapa celah pengiriman:

- Antrean tidak langsung dihapus ketika token HP belum terdaftar atau token lama kedaluwarsa. Pendaftaran perangkat membangunkan kembali antrean yang menunggu.
- Pendaftaran token yang gagal dicoba ulang secara otomatis; rotasi token tidak lagi diabaikan saat status pendaftaran sebelumnya gagal.
- Saat aplikasi terbuka, notifikasi yang sudah diterima tetap dapat ditampilkan selama izin Android aktif, walaupun pendaftaran ulang token sedang gagal. Notifikasi milik akun lain tidak ditampilkan setelah pergantian akun.
- Proyek Firebase APK diperiksa terhadap proyek tujuan backend saat pendaftaran, bila konfigurasi server tersedia.
- Project ID backend dapat dibaca dari service account jika `FCM_PROJECT_ID` tidak diisi. `FCM_CREDENTIALS_FILE` tetap wajib mengarah ke service account backend yang benar dan dapat dibaca user service.
- Hasil antrean, penolakan FCM, ketiadaan token dan status worker dapat diperiksa. Kode kesalahan tidak menyertakan token, private key atau isi kredensial.

Notifikasi tetap memerlukan izin HP, kategori Aktivitas Kocehind yang aktif, preferensi aktivitas akun aktif, dan konfigurasi Firebase produksi yang benar. Respons diterima FCM belum membuktikan notifikasi sudah terlihat di HP.

## 1. Update backend dan web

Akhiri LIVE aktif, unggah paket pada VPS backend/web, lalu:

```bash
cd /root
unzip Kocehind_v2.17.1_Waktu_Gambar_Notifikasi.zip
cd Kocehind_v2.17.1_Waktu_Gambar_Notifikasi
python3 UPDATE_BACKEND_WEB.py --check
python3 UPDATE_BACKEND_WEB.py
curl -fsS http://127.0.0.1:8000/health
```

Health harus menunjukkan **2.17.1**. Updater menggunakan alur backup dan preflight existing. Dua tabel tambahan, `push_receipts` dan `push_worker_state`, menyimpan hasil pengiriman serta heartbeat worker. Migrasi idempoten tidak menghapus akun, postingan, saldo atau data existing. Riwayat hasil pengiriman disimpan maksimal tujuh hari; antrean pengiriman memakai batas dua hari yang sudah ada.

Dari source lengkap, gunakan `sudo bash scripts/vps2_update_v2171.sh`. Installer dan updater menyertakan migrasi serta alat diagnosis baru. Updater mengaktifkan worker push jika file kredensial existing tersedia. Jika file belum ada, lengkapi konfigurasi lalu jalankan `python3 AKTIFKAN_PUSH.py`.

## 2. Build dan pasang APK baru

Pada VPS builder, ekstrak paket yang sama dan gunakan key serta proyek Firebase lama:

```bash
python3 PINDAH_KEY_LAMA.py build --check-only
python3 PINDAH_KEY_LAMA.py build
```

Nomor build minimum **46**, atau lebih tinggi jika builder menemukan nomor yang sudah dipakai. Pasang APK pada **host, tamu dan penonton**. Source Android baru diperlukan untuk tampilan waktu, pegangan gambar dan perbaikan pendaftaran/penampilan notifikasi.

Keempat nilai Firebase APK harus lengkap: `FIREBASE_API_KEY`, `FIREBASE_APP_ID`, `FIREBASE_SENDER_ID`, `FIREBASE_PROJECT_ID`. Builder memulihkan konfigurasi existing dan menolak build yang tidak memiliki konfigurasi push lengkap. Jangan memasukkan JSON private service account backend ke APK.

## 3. Dua uji notifikasi pada HP

Masuk ke **Pengaturan**, aktifkan **Notifikasi Aktivitas**, lalu:

1. Pilih **Uji notifikasi di HP ini**. Uji ini memeriksa jalur penampilan notifikasi lokal. Jika tidak muncul, periksa izin Android dan kategori **Aktivitas Kocehind**. Aplikasi tidak memaksa membuka kategori yang dibisukan pengguna.
2. Pilih **Uji pengiriman dari server**. Uji ini hanya menargetkan instalasi HP dan akun yang sedang dipakai. Status menunjukkan layanan belum aktif, perangkat belum terdaftar, proyek berbeda, penolakan akses, antrean tertunda, atau pengiriman diterima layanan notifikasi.
3. Gunakan akun lain untuk menyukai dan menyimpan video Anda. Periksa bilah HP saat Kocehind terbuka, di latar belakang, serta ditutup. Ketuk notifikasi dan periksa video tujuan.

Jika uji pertama muncul tetapi uji server gagal, periksa VPS:

```bash
python3 DIAGNOSA_NOTIFIKASI.py
systemctl is-active kocehind-push
journalctl -u kocehind-push -n 40 --no-pager
```

`worker_online: false` berarti heartbeat pengiriman belum tersedia atau sudah kedaluwarsa. `credentials_unavailable` berarti file kredensial belum tersedia/dapat dibaca. `SENDER_ID_MISMATCH` menunjukkan proyek token APK berbeda dengan tujuan FCM. `PERMISSION_DENIED` atau `UNAUTHENTICATED` memerlukan perbaikan akses/otorisasi service account. `accepted` berarti FCM menerima pengiriman; bila bilah tetap kosong, lanjutkan pemeriksaan izin/kategori HP dan konfigurasi Android. Alat diagnosis tidak mencetak token atau private key.

## Batas pengujian

Pengujian otomatis mencakup UI, gesture nyata dalam pengujian widget/browser, API/database, pemulihan antrean dan transport FCM dengan respons pengganti. VPS pengguna, HP fisik dan FCM produksi tidak dapat diverifikasi dari lingkungan pengerjaan ini. Jika masih gagal, hasil dua uji HP dan keluaran diagnosis diperlukan untuk menentukan titik kegagalannya; jangan membagikan token atau kredensial.
