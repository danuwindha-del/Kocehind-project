"""A release promising Android notifications must not silently omit Firebase."""
import pytest
import latest_build as builder


def isolated(monkeypatch):
    for key in builder.ENV_KEYS:monkeypatch.delenv(key,raising=False)
    monkeypatch.setattr(builder,'read_env',lambda path:{})
    monkeypatch.setattr(builder,'default_environment',lambda:{})


def test_missing_firebase_blocks_a_silent_push_disabled_build(tmp_path,monkeypatch):
    isolated(monkeypatch)
    with pytest.raises(RuntimeError,match='Firebase'):
        builder.build_environment(tmp_path,'id.kocehind.app',allow_fetch=False)


def test_complete_existing_firebase_is_preserved_and_requires_push(tmp_path,monkeypatch):
    isolated(monkeypatch)
    values={'FIREBASE_API_KEY':'fixture-api-key','FIREBASE_APP_ID':'1:123:android:fixture',
            'FIREBASE_SENDER_ID':'123','FIREBASE_PROJECT_ID':'fixture-project'}
    for key,value in values.items():monkeypatch.setenv(key,value)
    result=builder.build_environment(tmp_path,'id.kocehind.app',allow_fetch=False)
    assert {key:result[key] for key in values}==values
    assert result['REQUIRE_PUSH']=='1'
