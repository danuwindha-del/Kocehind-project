from contextlib import contextmanager
import sys
import DIAGNOSA_NOTIFIKASI as command

def test_diagnosis_uses_installed_backend_and_only_read_commands(monkeypatch):
    calls=[]
    @contextmanager
    def environment():yield {'FIXTURE':'1'}
    monkeypatch.setattr(command,'require_root',lambda:None)
    monkeypatch.setattr(command,'runtime_environment',environment)
    monkeypatch.setattr(sys,'argv',['DIAGNOSA_NOTIFIKASI.py'])
    monkeypatch.setattr(command.subprocess,'run',lambda args,**options:calls.append((args,options)))
    command.main()
    assert calls[0][0]==['systemctl','is-active','kocehind-push']
    assert calls[1][0]==['/opt/kocehind/venv/bin/python','diagnose_push.py']
    assert calls[1][1]['cwd']=='/opt/kocehind/backend'
    assert all(c[1]['env']=={'FIXTURE':'1'} for c in calls)
