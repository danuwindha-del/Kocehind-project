# Pengujian Kocehind 2.16.2

2 November 2026. Dasar perubahan: source 2.16.1 yang telah disiapkan sebelumnya. Laporan ini membedakan hasil otomatis dari verifikasi perangkat yang belum dijalankan.

| Pemeriksaan pada 2.16.2 | Hasil |
|---|---|
| Flutter 3.38.1 / Dart 3.10.0, analyze | Tidak ada masalah |
| Seluruh tes Flutter | **137 lulus, 0 gagal** |
| Seluruh tes web/DOM/browser | **191 lulus, 0 gagal** |
| Backend interaksi, privasi, badge, startup dan pemasang terkait | **39 lulus, 0 gagal** |
| Alat paket/build dan diagnosis Google Play pada ZIP baru | **41 lulus, 0 gagal** |
| Checksum, CRC ZIP serta sintaks source/paket | Diperiksa pada paket akhir |

Suite backend lengkap 535 lulus/9 dilewati pada 2.16.1 adalah riwayat, bukan hasil menjalankan seluruh suite itu kembali pada 2.16.2. Pada pembaruan ini, logika bisnis backend tetap sama; versi health dan alat pemasangan diperbarui. Pengujian backend terfokus digunakan untuk memeriksa kompatibilitasnya.

## Bukti untuk perubahan langsung pada layar

Tes widget baru sengaja menahan balasan HTTP memakai completer. Sebelum server membalas, tes memeriksa ikon hati merah, bookmark ungu dan kenaikan angka suka pada rute detail yang sama. Kasus ini juga dilakukan sesudah alur perubahan privasi yang mengosongkan registrasi postingan dan memuat ulang objek detail.

Tes lain menolak request dari server dan memastikan ikon serta angka kembali pada layar yang sama, tanpa keluar dari video. Tes model membuat dua objek postingan dengan ID yang sama serta menunda respons feed lama. Keduanya harus tetap membaca status perubahan yang sedang berjalan. Penolakan server, status pending dan data terlambat tidak boleh menjadi keberhasilan palsu.

Pada web, browser sungguhan menahan respons like/simpan dan memeriksa kelas warna, angka serta status tombol sebelum respons dilepas. Rute tetap di `/video/...`. Regresi aktivitas, notifikasi, komentar, koleksi, privasi, pemutaran media, login dan LIVE yang sudah ada ikut dijalankan.

## Kamera depan

Implementasi SDK LiveKit/Flutter WebRTC yang terpasang diperiksa: pemilihan format kamera Android memakai ukuran dalam koordinat sensor, sedangkan orientasi frame ditangani WebRTC. Meminta ukuran portrait pada sensor depan yang menyediakan format landscape dapat memilih sumber yang kemudian harus diperbesar. Ini merupakan alasan perubahan permintaan sumber, bukan bukti hasil format nyata pada ponsel pengguna; tidak tersedia log ukuran sensor dari perangkat tersebut.

Uji konfigurasi memeriksa sumber depan Android 1280×720/24 fps, sumber belakang 540×960, anggaran utama 1,5 Mbps, serta fokus/exposure otomatis. Uji kebijakan tampilan memisahkan kamera depan lokal, kamera belakang lokal dan video penonton. Pratinjau sendiri dibuat mengikuti arah gerakan pengguna; video jarak jauh tidak dibalik oleh renderer. Pengujian web memeriksa pemisahan yang sama.

Profil yang sesuai dipilih pada awal capture, publikasi, tombol kamera dan pergantian depan/belakang. Kamera belakang memakai ukuran dan anggaran yang sama dengan 2.16.1. Tidak ada filter penajaman atau peningkatan bitrate yang dipakai untuk menyamarkan sumber yang rendah.

## Reproduksi

```bash
cd flutter
flutter pub get
python3 scripts/fix_livekit_compat.py
flutter analyze --no-pub
flutter test --no-pub
```

Tes baru: `flutter test --no-pub test/realtime_front_camera_v2162_test.dart`. Dari root source, instal dependency test backend sesuai panduan sebelumnya dan jalankan:

```bash
.venv-test/bin/python -m pytest backend/tests/test_v2161_interactions.py backend/tests/test_v2161_live_badges.py backend/tests/test_privacy_v27.py backend/tests/test_deploy_preflight_r2.py tools/test_ui_installer.py flutter/scripts/tests -q
npm ci
npm run test:web
```

Browser pengujian menggunakan Chrome Headless Shell 134.0.6998.35 dengan opsi runner `KOCEHIND_CHROMIUM_EXECUTABLE` yang sudah tersedia. Tidak ada perubahan dependency aplikasi secara massal. Alat paket luar diuji dengan `python3 -m pytest tests -q` dari folder paket luar.

## Batas hasil

Belum dilakukan deployment VPS produksi, build APK/AAB release bertanda tangan, pemasangan pada ponsel, pengukuran fokus/ketajaman sensor depan, uji gerakan dua perangkat, atau pengukuran packet loss/bitrate aktual. Tes konfigurasi dan widget tidak menggantikan uji tersebut. Hasil kejernihan serta arah di perangkat harus dinilai setelah memasang APK 2.16.2 pada host dan penonton.
