# Kocehind 2.16.2 — Kamera depan dan tombol yang langsung berubah

Android **2.16.2+44**. Gunakan paket ini untuk menggantikan 2.16.1. Source lengkap, alat update backend/web dan alat build Android disertakan. APK/AAB bertanda tangan belum dibuat dalam pengerjaan ini.

## Yang diperbaiki

- Warna suka/simpan dan jumlah suka berubah pada saat tombol ditekan, tanpa menunggu pindah halaman. Satu status interaksi per postingan dipakai bersama oleh feed, detail, aktivitas dan notifikasi. Indikator proses berukuran kecil tidak lagi mengganti ikon merah/ungu dengan spinner besar.
- Bila server menolak atau koneksi gagal, tindakan dikembalikan ke status sebelumnya dan pesan kesalahan ditampilkan. Klik ganda tetap dicegah dan backend tetap memakai perubahan status yang aman terhadap pengiriman ulang.
- Video detail yang dimuat ulang akibat perubahan privasi didaftarkan kembali ke status yang sama. Respons feed lama tidak menimpa perubahan yang sedang berlangsung.
- Pratinjau kamera depan pada layar host mengikuti arah gerakan host. Kamera belakang tetap memakai arah asli. Penonton menerima arah kamera asli agar tulisan yang disiarkan tidak ikut dibalik. Hanya gambar kamera lokal yang disesuaikan; teks, kontrol dan overlay tetap pada arahnya.
- Pada Android, kamera depan meminta ukuran dalam koordinat sensor **1280×720 pada 24 fps**; WebRTC menangani orientasi ponsel. Cara ini menghindari meminta format sensor depan secara terbalik yang dapat memilih format rendah lalu memperbesar crop. Profil kamera belakang tetap **540×960** seperti 2.16.1. Anggaran encoder tetap maksimum **1,5 Mbps** pada lapisan utama, dengan simulcast sebelumnya.
- Saat kamera diganti atau diaktifkan kembali, profil kamera yang sesuai dipakai lagi. Ukuran sumber depan tidak diwariskan ke kamera belakang atau sebaliknya.

Ukuran tangkapan dan arah lokal adalah perubahan konfigurasi yang diuji. Ketajaman pada sensor kamera pengguna belum diukur langsung; format nyata, fokus, cahaya dan jaringan tetap perlu diperiksa pada ponsel.

## 1. VPS backend dan web

Akhiri LIVE aktif sebelum update. Unggah ZIP baru ke `/root`, lalu:

```bash
cd /root
unzip Kocehind_v2.16.2_Kamera_Depan_Realtime.zip
cd Kocehind_v2.16.2_Kamera_Depan_Realtime
python3 UPDATE_BACKEND_WEB.py --check
python3 UPDATE_BACKEND_WEB.py
curl -fsS http://127.0.0.1:8000/health
```

Health harus menunjukkan **2.16.2**. Alur backup, pemeriksaan user service, migrasi tambahan dan rollback existing tetap dipakai. Update ini tidak menambah kolom database. Gunakan `KOCEHIND_NGINX_CONF` jika konfigurasi Nginx disimpan di lokasi khusus. Jangan gunakan installer server kosong pada layanan existing.

Dari source lengkap, jalankan `sudo bash scripts/vps2_update_v2162.sh` di folder `kocehind_realtime_v2`.

## 2. VPS builder Android

Backend/web diperbarui terlebih dahulu. Ekstrak paket yang sama pada VPS builder, masuk ke foldernya, lalu gunakan profil signing key lama:

```bash
python3 PINDAH_KEY_LAMA.py build --check-only
python3 PINDAH_KEY_LAMA.py build
```

Versi yang dihasilkan adalah **2.16.2+44**, kecuali builder memilih nomor lebih tinggi dari instalasi existing. Jika nomor 44 sudah terpakai, tentukan nomor lebih besar, misalnya:

```bash
python3 PINDAH_KEY_LAMA.py build --build-number 45
```

Pasang APK baru pada **host dan penonton**. Perbaikan tombol Android dan kamera depan berada di APK; restart backend saja tidak memperbarui kode yang ada di ponsel. Gunakan key lama agar aplikasi dapat diperbarui. Konfigurasi Google/Firebase existing mengikuti alur builder sebelumnya.

## 3. Pemeriksaan setelah pemasangan

1. Pastikan perangkat menampilkan versi 2.16.2. Buka video melalui Aktivitas, tekan suka dan simpan. Ikon harus langsung merah/ungu; jumlah suka berubah tanpa menutup video. Batalkan keduanya dan ulangi dari notifikasi Android.
2. Coba saat jaringan lambat: ikon tetap langsung berubah, indikator proses kecil tampil, dan ketukan ganda tidak mengirim perubahan ganda. Bila server menolak, ikon kembali ke status sebelumnya.
3. Mulai LIVE dari kamera depan. Gerakkan tubuh/tangan ke arah kanan dan kiri menurut posisi Anda; pratinjau sendiri harus mengikuti arah itu. Lihat dari ponsel kedua untuk memeriksa orientasi gambar penonton serta keterbacaan tulisan.
4. Ganti depan → belakang → depan, matikan/aktifkan kamera dan sambungkan kembali LIVE. Periksa arah serta detail wajah setelah setiap pergantian. Lakukan pada cahaya cukup, lalu bandingkan Wi-Fi dan seluler.

Lihat `LAPORAN_PENGUJIAN_v2.16.2.md` untuk hasil otomatis dan batas verifikasi. Paket belum dipasang ke VPS atau diuji pada kamera ponsel fisik dalam pengerjaan ini.
