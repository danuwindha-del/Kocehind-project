# Kocehind v2.18.0 dengan pembaruan UI web sosial

Paket source lengkap ini sudah menyertakan desain desktop/mobile terbaru dan **Hotfix Inbox Web**. Hotfix Nginx aktivitas resmi sudah diintegrasikan ke instalasi backend baru serta alur update backend/web. Buka [PANDUAN_HOTFIX_INBOX_WEB.md](PANDUAN_HOTFIX_INBOX_WEB.md) untuk cakupan, verifikasi, dan rollback. Untuk pemasangan UI web saja, baca [PANDUAN_UPDATE_WEB_UI.md](PANDUAN_UPDATE_WEB_UI.md).

# Kocehind 2.18.0 — Sampul video, profil cepat, permintaan pesan dan email

Android **2.18.0+47**. Baca **PANDUAN_UPDATE_v2.18.0.md** dan **LAPORAN_PENGUJIAN_v2.18.0.md**.

- Ubah sampul sebelum unggah melalui strip cuplikan video atau impor gambar dari galeri. Pilihan sampul ikut tersimpan di draf aplikasi.
- Profil mengambil identitas dan 24 video awal dalam satu permintaan. Header yang sudah dikenal tampil segera; daftar video diperiksa ulang terhadap privasi.
- Permintaan pesan yang ditolak dapat diajukan ulang setelah tepat 24 jam. Tetap satu pesan sampai permintaan diterima.
- Pengaturan memiliki Ubah email. Email baru menerima kode enam digit; email lama tetap aktif sampai berhasil diverifikasi.

Update backend/web dahulu dengan `python3 UPDATE_BACKEND_WEB.py --check`, lalu `python3 UPDATE_BACKEND_WEB.py`. Bangun aplikasi dengan key lama melalui `python3 PINDAH_KEY_LAMA.py build --check-only`, lalu `python3 PINDAH_KEY_LAMA.py build`.

Paket berisi source dan alat update/build. Checksum arsip dan manifest telah diselaraskan. Belum dipasang ke VPS dan tidak berisi APK/AAB bertanda tangan.


### Hotfix web terbaru — Feed & Video Fast Resume R1

Paket ini menyertakan percepatan pemuatan video foreground, prefetch video berikutnya yang lebih hemat bandwidth, skeleton saat feed dimuat, dan pemulihan DOM/scroll feed saat kembali dari Profil atau Kotak Masuk. Rincian ada di `CATATAN_HOTFIX_FEED_VIDEO_WEB.md`.

### Kocehind Backup & Recovery Manager R1.2 — Smart VPS Migration

Paket ini juga menyertakan `backup_manager/` untuk full backup PostgreSQL,
akun pengguna, saldo/ledger, video/foto, rekaman LIVE, source backend, website,
secret/config, Nginx, TLS, dan service. Pada instalasi backend baru serta update
backend v2.18.0, timer backup harian 02:00 dipasang otomatis.

Baca `PANDUAN_BACKUP_RESTORE_KOCEHIND.md`. Perintah utama setelah manager
terpasang: `sudo kocehind-backup backup`, `sudo kocehind-backup list`, dan
`sudo kocehind-backup verify <arsip>`. Restore membutuhkan konfirmasi eksplisit. Mode migrasi VPS baru tersedia melalui `sudo kocehind-backup restore <arsip> --confirm RESTORE-KOCEHIND --skip-safety-backup --migration-mode`, lalu audit dengan `sudo kocehind-backup migrate-check --archive <arsip>`. Perubahan IP hanya diterapkan lewat dry-run/konfirmasi eksplisit; Cloudflare DNS tetap diperbarui terpisah. Baca `PANDUAN_MIGRASI_VPS_KOCEHIND_R1.2.md`.


Validasi R1.2 dirangkum dalam `LAPORAN_BACKUP_RECOVERY_R1.2.md`. Restore produksi belum dijalankan; lakukan drill pada VPS staging terlebih dahulu.
