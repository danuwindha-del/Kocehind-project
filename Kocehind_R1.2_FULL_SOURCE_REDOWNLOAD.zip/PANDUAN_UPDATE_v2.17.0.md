# Kocehind 2.17.0 — LIVE tamu, komentar/pesan, notifikasi dan web mobile

Android **2.17.0+45**. Paket berisi source lengkap, pembaruan backend/web dan alat build memakai signing key lama. Paket ini belum dipasang di VPS dan tidak berisi APK/AAB bertanda tangan.

## Perubahan

- Kamera tamu meminta profil **540p pada 24 fps**, maksimum **1,5 Mbps** pada lapisan utama. Host meminta lapisan utama untuk semua tamu, termasuk grid 9 kursi dan tata letak dengan fokus. Tangkapan depan Android tamu meminta **960×540 dalam koordinat sensor**; WebRTC menangani rotasi ponsel. Kamera belakang tetap memakai profil 540×960. Pengaturan kamera depan host yang telah dikonfirmasi jernih tetap 1280×720/24 fps.
- Komentar video, komentar LIVE dan pesan langsung tampil saat dikirim. Baris yang belum diterima server berstatus **Mengirim…**; penolakan menghapus baris sementara dan menampilkan kesalahan. Respons POST langsung mengonfirmasi baris tanpa menunggu GET daftar. Respons GET lama tidak menghapus komentar/pesan yang sedang dikirim. Koneksi realtime dipakai untuk pembaruan penerima; polling tetap menjadi pemulihan ketika koneksi putus.
- Pengiriman HTTP tidak lagi menunggu timeout Redis untuk setiap event. Catatan database dan antrean push tetap tersimpan; event realtime diproses terpisah dalam antrean terbatas.
- Suka dan simpan membuat aktivitas serta antrean notifikasi Android secara transaksional. Pengulangan permintaan status yang sama tidak membuat notifikasi ganda. Notifikasi mengetuk ke video tujuan. Sesi browser memakai cookie HttpOnly dan pengecekan Origin untuk WebSocket.
- Tamu kamera yang sudah bergabung dapat membuka **Gambar di kotak Anda** lalu mengimpor maksimal **4 gambar galeri**. Gambar bisa diubah ukuran, digeser dan dihapus. Gambar melekat pada identitas peserta dan tetap di dalam kotaknya ketika kursi/fokus berubah. Tamu tidak dapat mengubah gambar host atau tamu lain. Gambar disembunyikan dan URL-nya ditolak setelah tamu turun, terputus, dikeluarkan atau diblokir. Pemeriksaan gambar existing tetap wajib sebelum ditayangkan.
- Web menampilkan desain 404 untuk pengguna, video dan halaman tidak ditemukan, dengan pesan yang diminta dan tombol menuju pencarian/beranda. Penyempurnaan mobile berlaku di web sosial, situs utama dan admin: header, tab, profil, form, dialog, percakapan, LIVE dan tabel.

Ukuran/fps adalah target permintaan tangkapan dan encoder. Format nyata bergantung pada dukungan sensor/WebRTC dan jaringan. Uji otomatis tidak menggantikan uji video dua HP atau pengiriman FCM produksi.

## 1. Perbarui backend dan web

Akhiri LIVE aktif sebelum menjalankan pembaruan. Pada VPS backend/web:

```bash
cd /root
unzip Kocehind_v2.17.0_LIVE_Realtime_Web.zip
cd Kocehind_v2.17.0_LIVE_Realtime_Web
python3 UPDATE_BACKEND_WEB.py --check
python3 UPDATE_BACKEND_WEB.py
curl -fsS http://127.0.0.1:8000/health
```

Health harus menunjukkan **2.17.0**. Alur backup, pemeriksaan user service, migrasi dan rollback existing digunakan kembali. Update ini tidak menambah kolom database. Dari source lengkap, jalankan `sudo bash scripts/vps2_update_v2170.sh`.

Updater memasang konfigurasi proxy WebSocket web dan mengaktifkan kembali `kocehind-push` jika `FCM_PROJECT_ID` serta `FCM_CREDENTIALS_FILE` existing sudah lengkap dan dapat dibaca. Kredensial existing tidak diganti.

## 2. Bangun Android dengan key lama

Ekstrak paket yang sama pada VPS builder, kemudian:

```bash
python3 PINDAH_KEY_LAMA.py build --check-only
python3 PINDAH_KEY_LAMA.py build
```

Nomor minimum adalah **45**; builder memilih nomor lebih tinggi jika diperlukan. Pasang APK baru pada **host, tamu dan penonton**. Pembaruan kamera tamu berada pada APK tamu dan pemilihan lapisan pada APK host. Pembaruan backend saja tidak mengubah aplikasi yang sudah terpasang.

Konfigurasi Firebase harus tetap memakai proyek lama yang sama: `FIREBASE_API_KEY`, `FIREBASE_APP_ID`, `FIREBASE_SENDER_ID` dan `FIREBASE_PROJECT_ID`. Builder memulihkan konfigurasi existing; pada paket ini build dihentikan jika konfigurasi push belum lengkap agar APK tidak diam-diam kehilangan notifikasi. Service account backend tidak dimasukkan ke APK.

## 3. Periksa notifikasi HP

```bash
systemctl is-active kocehind-push
journalctl -u kocehind-push -n 40 --no-pager
```

Jika konfigurasi backend belum siap, isi kedua variabel FCM di `/etc/kocehind/backend.env`, pastikan user service `kocehind` bisa membaca file service account, lalu jalankan `python3 AKTIFKAN_PUSH.py`. Pada HP, aktifkan izin notifikasi Kocehind dan preferensi aktivitas akun. Notifikasi ditujukan ke pembuat video ketika akun lain menyukai/menyimpan video yang dapat dilihatnya.

## 4. Uji setelah pemasangan

1. Dua akun bergabung sebagai host dan tamu kamera. Periksa kamera tamu dari layar host pada 2 dan 9 kursi, fokus host/tamu, serta setelah kamera diubah depan/belakang.
2. Kirim komentar video, LIVE dan pesan. Baris harus langsung terlihat; jika jaringan belum mengonfirmasi, terlihat status Mengirim…. Uji juga penolakan saat komentar dibisukan atau permintaan pesan belum diterima.
3. Akun lain menyukai dan menyimpan video. Periksa bilah notifikasi saat aplikasi penerima aktif, di latar belakang dan ditutup. Ketuk notifikasi dan pastikan video yang benar terbuka.
4. Tamu mengimpor gambar, mengubah ukuran, menggeser dan turun dari kursi. Gambar harus selalu berada di kotak tamu dan hilang setelah turun.
5. Buka tautan pengguna/video yang tidak ada dan rute halaman yang salah. Periksa profil, feed, pesan, pengaturan, upload, LIVE dan dialog pada browser HP.

Kinerja video HP nyata, layanan Firebase produksi dan VPS pengguna belum diverifikasi dari lingkungan pengerjaan ini.
