#!/usr/bin/env python3
"""Read-only push report; no tokens, service-account values or private keys."""
import argparse
import subprocess
from package_ops import require_root,runtime_environment

def main():
    argparse.ArgumentParser(description=__doc__).parse_args()
    require_root()
    with runtime_environment() as env:
        subprocess.run(['systemctl','is-active','kocehind-push'],check=False,env=env)
        subprocess.run(['/opt/kocehind/venv/bin/python','diagnose_push.py'],
            cwd='/opt/kocehind/backend',env=env,check=True)

if __name__=='__main__':
    try:main()
    except Exception as error:raise SystemExit('Diagnosis belum selesai; perbarui backend 2.18.0 dan periksa konfigurasi layanan.') from None
