# Pengujian Kocehind 2.17.0+45

## Cakupan

- Flutter: pesan/komentar terlihat sebelum respons POST, konfirmasi tanpa menunggu GET, respons GET lama tidak menghapus status lokal, penolakan memulihkan daftar, pilihan lapisan tamu untuk host, profil kamera tamu 540p/24 fps, dan gambar tamu tetap berada di dalam kotaknya ketika fokus berubah.
- Backend: otorisasi gambar host/tamu, batas gambar/posisi, perlindungan elemen peserta lain, konflik versi, penyembunyian aset setelah tamu turun, suka/simpan idempoten, aktivitas dan outbox Android, transport push dengan pengirim uji, antrean event yang tidak menghalangi pemanggil, cookie WebSocket dengan Origin yang diizinkan/ditolak, komentar dan permintaan pesan existing.
- Browser Chromium 134: pengiriman dengan respons tertahan, pesan masuk melalui WebSocket, ketiga halaman tidak ditemukan, gambar tamu di kotak yang benar dan profil kualitas host. Pemeriksaan layout lebar 320, 360, 390, 768, 1024/1280 piksel mencakup feed, profil, inbox, pengaturan, upload, pencarian, situs utama dan admin. Header diperiksa agar elemen tidak saling menimpa; screenshot ditinjau secara visual.
- Installer: pemeriksaan service-user, versi health, alat build/signing existing, checksum source/website dan integritas arsip.

## Hasil

**Flutter: 143 lulus, 0 gagal.** `flutter analyze`: tidak ada masalah.

**Web: 201 lulus, 0 gagal.** Chromium 134 dan pengujian DOM/API/privasi existing.

**Backend dan installer source: 88 lulus, 1 dilewati, 0 gagal.**

**Alat paket/build: 43 lulus, 0 gagal.** Integritas arsip dan checksum diperiksa sebelum penyerahan.

## Batas verifikasi

Tidak ada deployment VPS, pembuatan APK/AAB bertanda tangan, pengukuran gambar kamera pada HP fisik, atau pengiriman FCM produksi. Pengiriman push diuji dengan outbox nyata dan pengirim pengganti. Target kamera/fps diuji sebagai konfigurasi yang diminta ke SDK; format aktual tetap bergantung pada perangkat dan jaringan. Layanan moderasi gambar tetap memakai konfigurasi dan kebijakan existing.
