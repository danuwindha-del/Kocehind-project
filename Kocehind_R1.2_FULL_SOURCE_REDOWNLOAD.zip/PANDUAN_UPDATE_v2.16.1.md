# Kocehind 2.16.1 — Interaksi aktivitas dan indikator LIVE

Pembaruan berdasarkan source 2.16.0 dari repositori `danuwindha-del/Kocehind-project`, commit `4feb10d9a11e04da8018bbe7f77897fc4b3c55b7`. Android **2.16.1+43**. Paket berisi source serta alat update/build. Pemasangan server dan build APK/AAB release belum dilakukan dalam pengerjaan ini.

## Perubahan

1. **Like dan simpan dari aktivitas, notifikasi, tautan, profil serta feed.** Klien baru mengirim status tujuan (`liked`/`saved`), sehingga permintaan yang dikirim ulang tidak membalik status dua kali. Android dan web mencegah permintaan ganda selama tombol bekerja. Penyimpanan memakai operasi yang aman terhadap duplikat; PostgreSQL mengunci postingan selama perubahan. Notifikasi, antrean push, dan metrik like berada dalam satu transaksi. Klien lama tanpa body tetap mendapat perilaku toggle sebelumnya.
2. **Tombol langsung diperbarui setelah server mengonfirmasi.** Gagal memuat ulang daftar koleksi tidak lagi membatalkan hasil simpan atau menimbulkan error latar yang tidak tertangani. Respons sinkronisasi yang sudah kedaluwarsa tidak menimpa hasil klik baru. Error HTTP biasa tidak lagi dijelaskan sebagai masalah upload.
3. **Lingkaran merah muda dan label LIVE pada avatar.** Tampil pada video feed/detail dan profil yang dikunjungi ketika host benar-benar sudah terhubung dan ruang berstatus aktif. Ketuk avatar LIVE untuk membuka siaran; tekan lama avatar Android untuk tindakan profil/foto sebelumnya. Jika tidak LIVE, tindakan avatar sebelumnya tetap berlaku. Akun diblokir/privat dan pengguna yang dikeluarkan dari ruangan tidak mendapat akses melalui badge.
4. **Status LIVE diperbarui.** Android menggunakan event status dan pemeriksaan ringan saat avatar aktif; web memeriksa avatar yang terlihat. Pemeriksaan berkala setiap 20 detik, sehingga indikator dapat memerlukan hingga satu interval untuk berubah jika event tidak diterima. Tidak ada reset feed saat badge berubah.
5. **Kamera tanpa mirror pada pratinjau dan siaran.** Pratinjau sebelum mulai kini secara eksplisit memakai orientasi yang sama dengan panggung LIVE. Kamera depan/belakang tidak diberi pembalikan horizontal tambahan; tulisan yang disiarkan tetap terbaca. Kamera tidak dibalik pada byte siaran untuk menutupi perbedaan pratinjau.
6. **Profil video lebih ringan.** Target utama 540×960 pada 24 fps, maksimum 1,5 Mbps; lapisan menengah 360×640, maksimum 600 kbps/20 fps, dan lapisan rendah 180×320, maksimum 180 kbps/15 fps. Kamera solo/duo serta peserta fokus meminta lapisan utama. Preferensi encoder mempertahankan resolusi lebih dahulu dengan mengurangi laju frame ketika diperlukan. Ketiga lapisan simulcast, audio dan overhead jaringan berarti total upload bukan dibatasi tepat 1,5 Mbps.

Perbaikan ini tidak menambah kolom database. Jalur migrasi 2.16 yang sudah ada tetap dipakai untuk memastikan backend existing lengkap. Album, privasi akun, HLS, dompet, pembayaran, moderasi dan key Android mengikuti implementasi sebelumnya.

## 1. Update backend dan web pada VPS layanan

Akhiri LIVE yang aktif. Siapkan ruang untuk backup database/media. Unggah dan ekstrak ZIP baru ke folder baru, lalu masuk ke folder `Kocehind_v2.16.1_Interaksi_LIVE`:

```bash
cd /root
unzip Kocehind_v2.16.1_Interaksi_LIVE.zip
cd Kocehind_v2.16.1_Interaksi_LIVE
python3 UPDATE_BACKEND_WEB.py --check
python3 UPDATE_BACKEND_WEB.py
```

`--check` adalah pemeriksaan awal. Perintah kedua menjalankan jalur backup, pemeriksaan user service, update, migrasi tambahan yang sudah ada, serta pemasangan web. Konfigurasi, data dan signing key existing mengikuti alur perlindungan updater lama. Jangan menjalankan installer VPS kosong pada server yang sudah berisi Kocehind. Untuk konfigurasi Nginx khusus, tentukan `KOCEHIND_NGINX_CONF` seperti pada panduan 2.16.0.

Jika bekerja dari source lengkap:

```bash
unzip SOURCE_LENGKAP_v2.16.1.zip
cd kocehind_realtime_v2
sudo bash scripts/vps2_update_v2161.sh
```

Periksa hasil:

```bash
curl -fsS http://127.0.0.1:8000/health
systemctl is-active kocehind-api kocehind-live kocehind-streams
sudo nginx -t
```

Health harus menunjukkan **2.16.1**. Muat ulang web agar JavaScript/CSS dengan versi cache 2.16.1 terambil. Perintah web tidak memperbarui APK yang sudah terpasang pada ponsel.

## 2. Build ulang Android pada VPS builder

Update backend/web terlebih dahulu. Gunakan signing key dan konfigurasi Google/Firebase lama. Dari folder paket luar pada VPS builder:

```bash
python3 PINDAH_KEY_LAMA.py build --check-only
python3 PINDAH_KEY_LAMA.py build
```

Jika memakai VPS builder baru yang belum disiapkan, gunakan alur `BUILD_VPS_BARU.sh` dari paket dengan backup key lama sesuai panduan sebelumnya. Build baru memakai application ID existing `id.web.kocehind` dan versi **2.16.1+43**. Bila nomor 43 sudah digunakan, tentukan nomor yang lebih tinggi:

```bash
python3 PINDAH_KEY_LAMA.py build --build-number 44
```

Paket ini tidak berisi APK/AAB bertanda tangan atau private key. Jangan membuat key pengganti. Pasang APK baru pada **host dan penonton** sebelum menilai arah/kualitas kamera. Perubahan kamera dan interaksi Android berada dalam APK, sehingga restart backend saja tidak cukup.

## 3. Uji penerimaan singkat

- Dengan dua akun, buat aktivitas like/komentar pada video. Buka video melalui Aktivitas, lalu melalui notifikasi Android. Uji suka, batal suka, simpan, batal simpan dan ketukan cepat. Buka kembali video serta koleksi untuk memastikan status tersimpan.
- Mulai LIVE akun A dan tunggu sampai terhubung. Dari akun B, lihat video A di Untuk Anda dan buka profil A. Avatar harus berlingkaran merah muda dengan label LIVE. Ketuk untuk masuk, akhiri LIVE, lalu pastikan label hilang dalam satu interval pembaruan.
- Sebelum LIVE, saat LIVE dan setelah berganti kamera: gerakkan tangan dan tunjukkan kertas bertulisan. Periksa dari ponsel kedua bahwa gambar tidak dibalik horizontal dan tulisan tetap terbaca. Jika menggunakan aplikasi lama, ulangi setelah APK baru terpasang.
- Bandingkan siaran pada Wi-Fi dan seluler, ruangan terang, kamera solo dan bersama. Periksa wajah, gerakan, buffering dan audio selama beberapa menit. Gunakan perangkat kedua sebagai penonton; screenshot tidak dapat mengukur bitrate, fokus kamera atau kehilangan paket.

## 4. Jika HTTP 500 masih muncul di VPS

Kasus duplikat like berhasil direproduksi pada pengujian source lama dan telah diperbaiki. Screenshot sendiri tidak mengungkap exception VPS, sehingga penyebab khusus server pengguna belum dapat dipastikan. Bila error tetap terjadi sesudah backend **dan APK** diperbarui, catat waktu kejadian lalu periksa:

```bash
journalctl -u kocehind-api -n 120 --no-pager
tail -n 80 /var/log/nginx/error.log
```

Periksa traceback yang sesuai `POST /posts/.../like` atau `/save`. Bila tabel produksi memiliki modifikasi lokal, jangan menghapus tabel atau data untuk menyamakan source. Bagikan potongan traceback yang relevan setelah menutupi email, token dan konfigurasi rahasia; perubahan skema khusus perlu didasarkan pada error tersebut.

## 5. Batas verifikasi

Lihat `LAPORAN_PENGUJIAN_v2.16.1.md` untuk hasil aktual dan reproduksi. Pengujian otomatis memakai database sementara, HTTP lokal dan browser/Flutter test. Tidak ada deployment produksi, uji ponsel fisik, pemakaian signing key, transaksi nyata, atau pengukuran jaringan LIVE dua perangkat dalam pengerjaan ini. Kualitas kamera, cahaya, bandwidth, koneksi UDP/TURN, kehilangan paket dan beban SFU tetap memengaruhi kejernihan. Perubahan profil video ditujukan mengurangi beban; hasil kejernihan harus dinilai sesudah build dan pemasangan di perangkat.
