# Kocehind UI Integrasi R2

Paket lengkap berdasarkan Kocehind_UI_R1.zip milik Anda, dengan integrasi operasional yang dipulihkan. Nama versi aplikasi/API tetap 2.13.3; nomor build Android dipilih otomatis di atas build yang pernah dipakai. UI Studio R1 dipertahankan.

## Update VPS backend dan web yang sudah berjalan

Akhiri semua sesi LIVE, upload ZIP ini ke /root, lalu jalankan sebagai root:

```bash
unzip -o /root/Kocehind_UI_Integrasi_R2.zip -d /root
cd /root/Kocehind_UI_Integrasi_R2
sha256sum -c SHA256SUMS.txt &&
/opt/kocehind/venv/bin/python UPDATE_BACKEND_WEB.py --check &&
/opt/kocehind/venv/bin/python UPDATE_BACKEND_WEB.py
/opt/kocehind/venv/bin/python DIAGNOSA_INTEGRASI.py
```

Preflight --check memeriksa keutuhan source, manifest web, Python backend 3.11+, dan Nginx tanpa perubahan. Saat update penuh, jalur backup database/media, preflight user layanan, migrasi tambahan dan rollback kode dari proyek tetap digunakan. API dan worker akan dimulai ulang. Ini bukan installer untuk VPS kosong. Python OS tidak diganti.

Konfigurasi Kipay yang sudah bekerja, mode production/sandbox, Mailjet, Firebase, LiveKit, model lokal, saldo, riwayat dan dokumen hukum aktif tidak ditimpa. File tambahan situs existing dipertahankan saat rilis web disiapkan. Nginx diuji sebelum reload; APK unduhan dan kebijakan sertifikat web tidak diganti oleh update ini.

Buka ulang tab atau hard refresh setelah update. /coins dan /coins/ sekarang membuka halaman dompet/checkout yang sama dengan /wallet. HTML memakai versi cache baru untuk app.js; stylesheet Studio R1 tetap sama persis.

Jika hanya menerapkan web pada backend yang sudah lengkap:

```bash
/opt/kocehind/venv/bin/python UPDATE_UI_WEB.py --check
/opt/kocehind/venv/bin/python UPDATE_UI_WEB.py
```

Updater UI saja tidak memperbarui backend/worker. Command rollback web dicetak oleh updater; jangan menghapus rilis lama atau catatan rollback.

## Build Android dengan keystore dan Firebase lama

```bash
cd /root/Kocehind_UI_Integrasi_R2
python3 PINDAH_KEY_LAMA.py build --check-only
bash BUILD_VPS_BARU.sh
```

Pemeriksaan build sekarang mensyaratkan Google/Firebase lengkap juga pada --check-only. REQUIRE_PUSH=1 diteruskan saat build sehingga konfigurasi push yang hilang menghentikan build. Nomor build dipilih otomatis; bila Play Console sudah memiliki nomor lebih tinggi daripada profil lokal, berikan --build-number dengan nomor yang lebih tinggi itu. Jangan memakai ulang 37 atau nomor yang sudah diunggah ke Play.

Keystore, applicationId id.web.kocehind dan profil lama dipakai kembali. Tidak ada kunci privat, credential server atau APK/AAB bertanda tangan di paket. Untuk builder baru, impor backup KOCEHIND_KEY_LAMA.enc milik Anda; jangan membuat keystore pengganti. Build Android belum dijalankan dalam pekerjaan integrasi ini.

## Kipay yang sudah dikonfigurasi

Tidak perlu menjalankan setup lagi jika pembayaran sudah bekerja. Untuk memeriksa format konfigurasi lokal tanpa membuat pembayaran:

```bash
/opt/kocehind/venv/bin/python SETUP_KIPAY.py --check
```

Jika sengaja mengatur project sandbox atau production, gunakan salah satu:

Untuk sandbox:

```bash
/opt/kocehind/venv/bin/python SETUP_KIPAY.py --mode sandbox
```

Untuk production:

```bash
/opt/kocehind/venv/bin/python SETUP_KIPAY.py --mode production
```

Pilih mode yang sesuai; tidak perlu menjalankan keduanya. API key dan webhook secret diinput tersembunyi, tanpa validasi prefix buatan. Simpan credential project yang sesuai mode. Backend.env menyimpan Base64 untuk mencegah tanda baca credential dijalankan sebagai sintaks shell; Base64 bukan enkripsi, file tetap privat root:kocehind 0640, backup 0600. HMAC menggunakan secret asli setelah decode. Env plain lama tetap didukung runtime.

Webhook URL project: https://api.kocehind.web.id/payments/kipay/callback

Setup memblokir pergantian credential/mode bila masih ada pesanan Kipay creating/unknown/unpaid. Selesaikan atau periksa melalui Admin terlebih dahulu; jangan menghapus pesanan atau mengubah saldo. Pasangan API key/secret dibuktikan melalui checkout dan tes webhook di dashboard project yang sama, bukan sekadar pemeriksaan format lokal.

Untuk simulasi sandbox, ganti referensi berikut dengan SBX dari riwayat akun uji:

```bash
/opt/kocehind/venv/bin/python SIMULASI_KIPAY_SANDBOX.py SBX-REFERENSI-DARI-RIWAYAT
```

Simulasi ditolak untuk production. Pemenuhan pesanan tetap dilakukan oleh verifikasi backend; script tidak menambah saldo secara langsung. Tripay hanya dipertahankan untuk kewajiban pesanan lama. Google Play Billing tidak diaktifkan.

## Rekaman LIVE

Studio maintenance otomatis diaktifkan oleh updater. Egress yang sudah dikonfigurasi dan LIVE_RECORDING_ENABLED aktif dimulai kembali. Jika Egress belum pernah dipasang, akhiri semua LIVE, siapkan Docker Engine dan FFmpeg dari paket resmi, lalu:

```bash
systemctl enable --now docker redis-server
/opt/kocehind/venv/bin/python AKTIFKAN_REKAMAN_LIVE.py --check
/opt/kocehind/venv/bin/python AKTIFKAN_REKAMAN_LIVE.py
systemctl is-active kocehind-egress kocehind-studio-worker
```

Helper memakai digest resmi existing; untuk pemasangan pertama memakai livekit/egress:v1.15.0 lalu menguncinya ke digest aktual dari registry. Installer proyek mencadangkan env/konfigurasi LIVE, mengatur Redis privat yang sama, dan mengaktifkan perekaman server. LiveKit/API direstart. Ruang rekaman: /var/lib/kocehind/private-live, terpisah dari media publik. Jangan membuka Redis ke internet.

Buat LIVE baru sekitar satu menit, akhiri, lalu periksa rekaman privat di Studio. Siaran lama tidak dapat direkam kembali. Masa simpan sumber tujuh hari mengikuti implementasi existing. Layanan aktif belum membuktikan MP4 berhasil: hasil Egress dan ffprobe tetap harus selesai. Egress memerlukan sumber daya tambahan; dokumentasi resmi menyarankan setidaknya 4 CPU dan 4 GB RAM per instance, di luar kebutuhan worker model/API.

## Push dan model moderasi

Jika Firebase server sudah terisi namun worker belum aktif:

```bash
/opt/kocehind/venv/bin/python AKTIFKAN_PUSH.py
```

Service account tetap berada di /etc/kocehind, tidak dimasukkan ke source/APK. Izin notifikasi Android serta pengaturan akun/perangkat tetap diperlukan. Updater tidak mengubah izin HP.

Source OpenNSFW2, pemeriksaan kekerasan/gore/darah, model audio dan alur banding tetap ada. Model besar dan venv yang sudah dipasang di VPS dipertahankan, tidak diunduh ulang oleh updater. Jika model belum pernah dipasang, gunakan panduan PANDUAN_PERBAIKAN_VISION_v2.12.0.md dan PANDUAN_PERBAIKAN_AUDIO_v2.12.0.md pada source lengkap; jangan menganggap keberadaan source berarti model sudah siap.

DIAGNOSA_INTEGRASI.py melaporkan worker yang perlu aktif sesuai konfigurasi tanpa mencetak credential. Laporan tidak membuktikan pengiriman push, deteksi model, pembayaran nyata atau hasil rekaman.

## App Links dan APK unduhan

Gunakan APK yang sama dengan APK terpasang di HP untuk memeriksa sertifikat. API key/keystore tidak diperlukan. Jika tool belum tersedia, pasang paket apksigner dan aapt pada VPS. Setelah APK diupload sebagai /root/Kocehind-HP.apk:

```bash
/opt/kocehind/venv/bin/python PERBAIKI_APP_LINKS.py --apk /root/Kocehind-HP.apk --apply
```

Boleh mengulang --apk untuk APK Play dan build lokal. Hanya sertifikat build/Play Kocehind yang dikenali atau telah dipin di konfigurasi web yang diterima. Asosiasi lama, aplikasi lain dan aturan dinamis dipertahankan. Perbaikan ini tidak memublikasikan APK atau melewati kebijakan Play signing. Kedua host harus mengembalikan HTTPS 200, JSON, sertifikat cocok dan tanpa redirect. Status verifikasi/default di HP mengikuti Android dan pilihan pengguna; tidak dipaksa dari aplikasi.

Untuk publikasi APK web dengan kebijakan Play yang sudah dipin, upload Signed, universal APK asli dari Play Console, lalu:

```bash
/opt/kocehind/venv/bin/python PUBLIKASI_APK_PLAY.py /root/Kocehind-Play.apk
```

Pada konfigurasi pertama, script meminta fingerprint SHA-1 App signing key dari Play Console. Gunakan sertifikat app signing, bukan upload key. APK lama dicadangkan, metadata unduhan diperbarui dan dua host App Links diperiksa sebelum publikasi dinyatakan terverifikasi.

## Dokumen hukum

DOKUMEN_HUKUM berisi salinan dokumen aktif versi 2 dari endpoint resmi Kocehind pada 30 Oktober 2026: kebijakan privasi 25.657 karakter dan ketentuan layanan 28.650 karakter, keduanya versi pembaruan Kipay 28 Oktober 2026. Default backend diperbarui hanya untuk database yang belum memiliki dokumen. Dokumen dan persetujuan yang sudah ada tidak diganti. Revisi berikutnya tetap diterbitkan lewat Admin > Dokumen hukum agar riwayat dan persetujuan tercatat.

## Pengujian dan batas verifikasi

Lihat LAPORAN_INTEGRASI_R2.md. Pengujian menggunakan database terisolasi dan respons provider sintetis; tidak memakai credential/uang nyata. Tidak ada deploy ke VPS, pembuatan APK/AAB, uji HP fisik, pengiriman FCM nyata atau rekaman SFU nyata dalam pekerjaan ini.
