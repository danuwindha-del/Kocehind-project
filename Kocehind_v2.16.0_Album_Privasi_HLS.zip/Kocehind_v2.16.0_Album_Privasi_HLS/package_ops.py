"""Shared, verified access to the bundled source. Does not invoke Android SDKs."""
from contextlib import contextmanager
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import shlex
import shutil
import stat
import subprocess
import tempfile
import zipfile

HERE = Path(__file__).resolve().parent
RUNTIME_PYTHON = Path('/opt/kocehind/venv/bin/python')


def verify_bundle(here=HERE):
    config = json.loads((here / 'package.json').read_text())
    if config.get('version') != '2.16.0':
        raise RuntimeError('Versi paket tidak dikenali.')
    source = here / 'SOURCE_LENGKAP_v2.16.0.zip'
    payload = source.read_bytes()
    if hashlib.sha256(payload).hexdigest() != config.get('source_sha256'):
        raise RuntimeError('Checksum source tidak cocok. Ekstrak ulang paket lengkap.')
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or len(names) > 5000:
            raise RuntimeError('Daftar ZIP source tidak valid.')
        if sum(i.file_size for i in archive.infolist()) > 300_000_000:
            raise RuntimeError('Ukuran ZIP source tidak wajar.')
        for entry in archive.infolist():
            path = PurePosixPath(entry.filename)
            if (not path.parts or path.parts[0] != 'kocehind_realtime_v2'
                    or path.is_absolute() or '..' in path.parts
                    or '\\' in entry.filename or stat.S_ISLNK(entry.external_attr >> 16)):
                raise RuntimeError('Path ZIP source tidak aman.')
        if archive.testzip() is not None:
            raise RuntimeError('ZIP source rusak.')
    return payload, config


@contextmanager
def source_tree(here=HERE):
    payload, _ = verify_bundle(here)
    with tempfile.TemporaryDirectory(prefix='kocehind-integrasi-') as folder:
        with zipfile.ZipFile(io.BytesIO(payload)) as archive:
            archive.extractall(folder)
        yield Path(folder) / 'kocehind_realtime_v2'


def check_runtime(python=RUNTIME_PYTHON):
    if not python.is_file():
        raise RuntimeError('Python backend belum ditemukan: /opt/kocehind/venv/bin/python')
    subprocess.run([str(python), '-c',
                    'import sys; assert sys.version_info >= (3,11), "Gunakan Python backend 3.11+"'],
                   check=True, timeout=15)


@contextmanager
def runtime_environment(python=RUNTIME_PYTHON):
    """Use existing backend Python for child scripts, preserving the OS Python."""
    check_runtime(python)
    with tempfile.TemporaryDirectory(prefix='kocehind-python-') as folder:
        shim = Path(folder)
        # Exec the stable venv path: a symlink here makes newly created venvs
        # point into this private temporary directory and breaks service startup.
        launcher = shim / 'python3'
        launcher.write_text('#!/bin/sh\nexec ' + shlex.quote(str(python.absolute())) + ' "$@"\n')
        launcher.chmod(0o755)
        # No backup override inherited from an accidental interactive shell.
        env = {k: v for k, v in os.environ.items() if k != 'SKIP_BACKUP'}
        env['PATH'] = str(shim) + os.pathsep + env.get('PATH', '')
        yield env


def require_root():
    if os.geteuid() != 0:
        raise RuntimeError('Jalankan sebagai root pada VPS backend/web.')


def run_script(project, relative, *arguments, python=RUNTIME_PYTHON):
    with runtime_environment(python) as env:
        subprocess.run(['bash', str(project / relative), *map(str, arguments)],
                       cwd=project, env=env, check=True)


def install_backend_tools(project, runtime=Path('/opt/kocehind/backend')):
    """Copy command-line helpers only; no config/database/client changes."""
    for name in ('setup_kipay.py', 'simulate_kipay_sandbox.py', 'mailjet_preflight.py', 'setup_google_play.py', 'diagnose_google_play.py', 'setup_mycha.py'):
        source = project / 'backend' / name
        if not source.is_file():
            raise RuntimeError('Helper backend tidak tersedia: ' + name)
        target = runtime / name
        if target.is_symlink():
            raise RuntimeError('Helper runtime berupa symlink; periksa instalasi.')
        temp = target.with_name('.' + name + '.new')
        try:
            shutil.copyfile(source, temp)
            temp.chmod(0o644)
            os.replace(temp, target)
        finally:
            temp.unlink(missing_ok=True)
