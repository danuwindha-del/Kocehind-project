#!/usr/bin/env python3
"""Publish the original Play-signed universal APK with existing signing checks."""
import argparse
from pathlib import Path
from package_ops import require_root, source_tree, run_script


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('apk', type=Path)
    parser.add_argument('sha1_play', nargs='*', help='SHA-1 App signing key dari Play Console untuk konfigurasi pertama')
    args = parser.parse_args()
    require_root()
    apk = args.apk.expanduser().resolve(strict=True)
    if not apk.is_file():
        raise RuntimeError('File APK tidak ditemukan.')
    with source_tree() as project:
        run_script(project, 'scripts/vps2_pasang_apk_play.sh', apk, *args.sha1_play)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        raise SystemExit('BELUM SELESAI: ' + str(exc)) from None
