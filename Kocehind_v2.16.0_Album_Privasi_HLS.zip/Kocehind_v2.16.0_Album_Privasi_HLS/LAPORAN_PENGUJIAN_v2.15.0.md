# Pengujian Kocehind 2.15.0

31 Oktober 2026. Dasar: source gabungan Kocehind 2.14.0 pada commit GitHub `8f851e4`, ditambah SEO Video R1 yang disertakan dalam repositori. Semua perubahan dibuat dan diuji pada salinan terisolasi; tidak ada perubahan server atau transaksi produksi.

## Hasil akhir

| Pemeriksaan | Hasil |
|---|---|
| Suite backend, Python 3.12, dependensi backend terpasang, pytest-xdist empat proses | **518 lulus, 9 dilewati**, tanpa kegagalan pada run lengkap terakhir |
| Pengujian terfokus fitur 2.15, alur API lama dan avatar | **35 lulus** |
| Suite web/DOM/browser termasuk fitur baru | **175 lulus, 1 timeout lama** dari 176 kasus |
| Alat paket, pemilihan runtime Python, diagnosis Play | **41 lulus** |
| Updater UI dan konfigurasi runner Android/App Links/permissions | **10 lulus** |
| Sintaks Python dan shell | Lulus; shell diperiksa dengan `bash -n`, bukan menjalankan deploy |
| Sintaks Dart | Seluruh file Dart diperiksa dengan parser lokal tanpa error sintaks; tidak menggantikan Flutter analyze/test |
| Checksum, CRC arsip, daftar file aman, source SHA dan kesesuaian salinan website luar/dalam | Diverifikasi pada paket akhir |

Sembilan skip backend membutuhkan PostgreSQL uji terisolasi, LiveKit/RTC nyata, atau runtime model OpenNSFW2 nyata. Kondisi skip tidak dilonggarkan.

Suite backend mencakup batas tiga sematan, pemilik video, idempotensi, pagination profil, pencabutan privasi, dua tautan dan penolakan URL berbahaya, pembelajaran sumber sebelum publikasi MychaAI, penolakan respons model yang tidak bisa diverifikasi, pembaruan sumber, penarikan indeks, syarat popularitas berlapis, pencabutan indeks ketika konten menjadi privat, migrasi berulang, email pembelian web/Play, rollback transaksi, pending, retry, dan penghentian LIVE pada temuan gambar oleh kedua model.

Tes LIVE baru juga membuktikan satu model saja belum mengizinkan publikasi, perubahan kebijakan memerlukan pemeriksaan baru, skor tidak valid tetap pending, dan gambar yang belum disetujui ditolak oleh endpoint overlay. Model pada tes adalah pengganti sintetis, bukan pengukuran akurasi ketelanjangan/gore/darah di dunia nyata.

## Browser dan antarmuka

Pengujian nyata Chromium Headless Shell 134 menggunakan Playwright 1.51.1 yang tersedia untuk unduhan pada lingkungan ini. Paket tetap mencatat dependensi pengujian asli Playwright 1.62.1; adapter lokal hanya memilih runtime browser untuk pengujian, tidak dimasukkan ke aplikasi. DOM diuji dengan jsdom 26.1.0. Pemeriksaan visual dilakukan pada tangkapan layar ponsel, termasuk kartu MychaAI, sumber, tab Tanya, tautan profil, dan label sematan.

Kasus baru yang lulus meliputi ringkasan di atas hasil video, Lebih banyak/Lebih sedikit, sumber dapat dibuka, hasil lama tidak masuk ke query baru, keadaan kosong dan coba lagi, formulir admin mengirim fakta/URL/gambar/alias, edit dua tautan, tiga label Disematkan, semat/copot melalui Bagikan, serta gambar LIVE ditolak atau model belum siap tanpa menambah elemen pada panggung.

Satu timeout terjadi pada `websites/web/test-v27-browser.mjs`, saat menunggu video `/watch.webm` mencapai `currentTime > 1.3`. Pengujian yang sama pada source awal yang belum diubah menghasilkan timeout pada baris yang sama. Kasus dan assertion dipertahankan; suite web tidak dinyatakan seluruhnya lulus.

Pada run awal, beberapa fixture lama mengasumsikan versi cache 2.14 atau memakai database bersama lintas modul. Fixture disesuaikan untuk versi 2.15 dan isolasi data, tanpa mengurangi assertion otorisasi, saldo, privasi, atau perilaku produk. Tes geometri LIVE lama sekarang menyiapkan hasil aman sintetis melalui antrean pemeriksaan baru. Tes keselamatan baru tetap memeriksa pending, penolakan dan kegagalan tanpa melewati pemeriksaan.

Pengujian stres 24 transfer media dengan pool dua koneksi sempat timeout pada beberapa run paralel/terpisah, dan lulus pada suite lengkap akhir. Kasus yang sama lulus pada run terpisah source awal. Hasil tersebut sensitif terhadap penjadwalan pada lingkungan uji; tidak digunakan untuk menjamin kapasitas server. Alur autentikasi/media runtime existing dipertahankan, dan percobaan perubahan pelepasan koneksi tidak dimasukkan ke paket akhir.

## Perintah reproduksi

Dari source lengkap, setelah dependensi uji terpasang:

```bash
cd backend
python -m pytest -n 4 --dist loadfile -q
```

Jika pytest-xdist tidak terpasang, jalankan `python -m pytest -q`. Hasil waktu/kasus performa bisa berbeda. Dari root source:

```bash
npm ci
npm run test:web
python -m pytest tools/test_ui_installer.py flutter/scripts/tests -q
```

Gunakan browser Chromium yang cocok dengan Playwright pada lingkungan Anda. Tes memakai database, provider dan layanan sintetis. Jangan mengarahkan fixture ke database produksi. Dari folder paket luar: `python -m pytest tests -q`.

## Flutter dan batas verifikasi

Flutter analyze, Flutter test, kompilasi native, APK/AAB release, dan uji HP belum dijalankan pada source ini. Upaya menjalankan Flutter ditolak peninjauan persetujuan otomatis karena proses mencoba mengakses endpoint metadata cloud yang berpotensi membuka kredensial lingkungan. Proses tersebut tidak diulang melalui jalan lain. Pemeriksaan sintaks Dart lokal serta tes konfigurasi runner dilakukan sebagai pemeriksaan yang aman. Tiga tes widget baru disertakan untuk dijalankan di builder Anda.

Belum ada pemanggilan DattioAI dengan key nyata; adapter diuji dengan respons sintetis. Model, API key, kuota, akses internet VPS dan model ID akun Anda perlu diuji menggunakan SETUP_MYCHAAI.py --test. Belum mengirim email Mailjet nyata, membuat transaksi/produk Play Console, melakukan pembelian Kipay nyata, menguji SFU/rekaman nyata, atau mengukur akurasi model pada data produksi.

Source SEO Video R1 dan robots/sitemap dipertahankan dan diuji pada fixture privasi/video. Keputusan pengindeksan Google, akses CDN/WAF, sertifikat APK dan kesehatan VPS pengguna belum diverifikasi dari lingkungan ini. Ikuti panduan update serta uji penerimaan setelah pemasangan.
