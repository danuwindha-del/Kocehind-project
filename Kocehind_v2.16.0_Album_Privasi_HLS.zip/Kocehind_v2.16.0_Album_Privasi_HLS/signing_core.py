#!/usr/bin/env python3
"""Build Kocehind using an EXISTING key matching the Play Console screenshot.

Run from the Kocehind project on the VPS used to build your previous AAB:
  python3 /root/KOCEHIND_BUILD_AAB_KUNCI_LAMA_v2.py

The default pins the full SHA-1 of the old keystore reported by the user. Its
first 14 bytes match the expected certificate visible in the screenshot; the
rest of Play's expected fingerprint was cropped in that image. You can override
the target with --expected-sha1 if Play provides a different full fingerprint.
Signing and verification are self-contained; no helper script is required.
Never creates/deletes a keystore and never displays passwords. Passwords are
read from local key.properties where available, otherwise requested locally.
--check-only inspects certificates without changing signing or starting a build.
"""
import argparse
import getpass
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time

TARGET_SHA1 = '067641A14721B8CD440FB3B24B320A1948EA2975'
BEGIN = '// BEGIN KOCEHIND MATCHED KEY SIGNING'
END = '// END KOCEHIND MATCHED KEY SIGNING'
KOTLIN = '''// BEGIN KOCEHIND MATCHED KEY SIGNING
val kocehindMatchedKeyProperties = KocehindMatchedProperties().apply {
    rootProject.file("key.properties").inputStream().use { load(it) }
}
android {
    signingConfigs {
        create("kocehindMatchedUpload") {
            keyAlias = kocehindMatchedKeyProperties.getProperty("keyAlias")
            keyPassword = kocehindMatchedKeyProperties.getProperty("keyPassword")
            storeFile = file(kocehindMatchedKeyProperties.getProperty("storeFile"))
            storePassword = kocehindMatchedKeyProperties.getProperty("storePassword")
        }
    }
    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("kocehindMatchedUpload")
        }
    }
}
// END KOCEHIND MATCHED KEY SIGNING'''
GROOVY = '''// BEGIN KOCEHIND MATCHED KEY SIGNING
def kocehindMatchedKeyProperties = new java.util.Properties()
rootProject.file('key.properties').withInputStream {
    kocehindMatchedKeyProperties.load(it)
}
android {
    signingConfigs {
        kocehindMatchedUpload {
            keyAlias kocehindMatchedKeyProperties.getProperty('keyAlias')
            keyPassword kocehindMatchedKeyProperties.getProperty('keyPassword')
            storeFile file(kocehindMatchedKeyProperties.getProperty('storeFile'))
            storePassword kocehindMatchedKeyProperties.getProperty('storePassword')
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.kocehindMatchedUpload
        }
    }
}
// END KOCEHIND MATCHED KEY SIGNING'''


def patch_gradle(text, kotlin):
    block = KOTLIN if kotlin else GROOVY
    java_import = 'import java.util.Properties as KocehindMatchedProperties'
    if BEGIN in text or END in text:
        if text.count(BEGIN) != 1 or text.count(END) != 1:
            raise RuntimeError('Penanda signing tidak lengkap; konfigurasi belum diubah.')
        start, end = text.index(BEGIN), text.index(END)+len(END)
        if text[start:end] != block or (kotlin and java_import not in text):
            raise RuntimeError('Blok signing pernah diubah manual; perlu ditinjau sebelum build.')
        return text
    if 'kocehindMatchedUpload' in text or 'kocehindMatchedKeyProperties' in text:
        raise RuntimeError('Nama konfigurasi signing sudah digunakan tanpa penanda yang dikenali.')
    # A final Android DSL block selects the matched key for RELEASE only. Keep
    # existing build types, application ID, plugin setup and other signing keys.
    if kotlin: text = java_import+'\n\n'+text
    return text.rstrip()+'\n\n'+block+'\n'


def java_value(value):
    result = []
    for char in value:
        if char in '\\ =:#!': result.append('\\'+char)
        elif char in '\t\n\r': result.append({'\t': r'\t', '\n': r'\n', '\r': r'\r'}[char])
        elif 32 <= ord(char) <= 126: result.append(char)
        else:
            raw = char.encode('utf-16-be')
            result.extend('\\u'+raw[i:i+2].hex() for i in range(0,len(raw),2))
    return ''.join(result)


def unescape(value):
    result, i = [], 0
    while i < len(value):
        char = value[i]; i += 1
        if char != '\\' or i == len(value):
            result.append(char); continue
        char = value[i]; i += 1
        if char == 'u':
            part = value[i:i+4]
            if not re.fullmatch('[0-9a-fA-F]{4}', part):
                raise RuntimeError('Escape Unicode pada key.properties tidak valid.')
            result.append(chr(int(part, 16))); i += 4
        else:
            result.append({'n': '\n', 'r': '\r', 't': '\t', 'f': '\f'}.get(char, char))
    return ''.join(result).encode('utf-16-le', 'surrogatepass').decode('utf-16-le')


def properties(path):
    if not path.is_file(): return {}
    result, pending = {}, ''
    for raw in path.read_text(encoding='latin-1').splitlines():
        line = pending + raw.lstrip() if pending else raw.lstrip()
        if not pending and (not line or line.startswith(('#', '!'))): continue
        if (len(line)-len(line.rstrip('\\'))) % 2:
            pending = line[:-1]; continue
        pending = ''
        escaped, split = False, len(line)
        for i, char in enumerate(line):
            if not escaped and (char in '=:' or char.isspace()):
                split = i; break
            escaped = (not escaped) if char == '\\' else False
        key, tail = line[:split], line[split:]
        tail = tail.lstrip()
        if tail.startswith(('=', ':')): tail = tail[1:].lstrip()
        result[unescape(key)] = unescape(tail)
    if pending: raise RuntimeError('Baris key.properties terputus.')
    return result


def normalized(value):
    value = re.sub(r'[:\s]', '', value).upper()
    if not re.fullmatch('[0-9A-F]+', value):
        raise RuntimeError('SHA-1 harus terdiri dari angka dan huruf A–F.')
    return value


def fingerprint(value):
    return ':'.join(value[i:i+2] for i in range(0, len(value), 2))


def certificates(output):
    entries = []
    for block in re.split(r'(?m)^Alias name:\s*', output)[1:]:
        alias = block.splitlines()[0].strip()
        if not re.search(r'Entry type:\s*PrivateKeyEntry', block): continue
        match = re.search(r'(?m)^\s*SHA1:\s*([0-9A-Fa-f:]+)', block)
        owner = re.search(r'(?m)^Owner:\s*(.+)', block)
        if match and owner:
            entries.append(dict(alias=alias, sha1=normalized(match[1]), owner=owner[1].strip()))
    return entries


def inspect(path, password):
    env = os.environ.copy(); env['KOCEHIND_LOCAL_STOREPASS'] = password
    run = subprocess.run(['keytool', '-J-Duser.language=en', '-J-Duser.country=US',
        '-list', '-v', '-keystore', str(path), '-storepass:env', 'KOCEHIND_LOCAL_STOREPASS'],
        env=env, capture_output=True, text=True, timeout=25)
    return certificates(run.stdout) if run.returncode == 0 else None


def discover(project, configured):
    found = set()
    if configured and configured.is_file(): found.add(configured.resolve())
    # Covers the usual VPS signing directory, old projects and local backups.
    # Skip SDKs/dependencies; never read the contents of other project files.
    skipped = {'node_modules', '.git', '.cache', '.gradle', 'android-sdk', '.pub-cache',
               'build', '.dart_tool', 'sdk', 'test-venv'}
    for root in dict.fromkeys([project, Path.home()]):
        count = 0
        for base, dirs, files in os.walk(root, followlinks=False):
            dirs[:] = sorted(d for d in dirs if d not in skipped and not Path(base, d).is_symlink())
            for name in files:
                count += 1
                if Path(name).suffix.lower() in ('.jks', '.keystore', '.p12', '.pfx'):
                    path = Path(base, name)
                    if path.is_file() and not path.is_symlink(): found.add(path.resolve())
            if count > 60_000: break
    return sorted(found)


def project_at(path):
    for candidate in (path.resolve(), *path.resolve().parents):
        if (candidate / 'flutter/pubspec.yaml').is_file(): return candidate
    for candidate in (path.resolve()/'kocehind_realtime_v2', Path(__file__).resolve().parent/'kocehind_realtime_v2'):
        if (candidate / 'flutter/pubspec.yaml').is_file(): return candidate
    raise RuntimeError('Masuk dahulu ke folder utama project Kocehind yang dipakai build, lalu ulangi perintah.')


def backup(path):
    if not path.exists(): return
    dest = path.with_name(path.name+'.before-matching-key-'+str(time.time_ns()))
    shutil.copy2(path, dest); dest.chmod(0o600)


def write_private(path, data):
    fd, tmp = tempfile.mkstemp(prefix='.kocehind-signing-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as handle: handle.write(data)
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)


def flutter_tool(flutter):
    existing = shutil.which('flutter')
    if existing: return existing
    local = properties(flutter/'android/local.properties')
    roots = [local.get('flutter.sdk'), os.getenv('FLUTTER_ROOT'),
             '/opt/flutter', str(Path.home()/'flutter'), '/usr/local/flutter']
    for root in roots:
        if root:
            executable = Path(root).expanduser()/'bin/flutter'
            if executable.is_file() and os.access(executable,os.X_OK): return str(executable)
    raise RuntimeError('Flutter belum ditemukan pada VPS ini. Jalankan pada VPS yang sebelumnya dipakai build AAB.')


def build_commands(project):
    flutter = project/'flutter'
    runner = project/'scripts/vps1_build_apk_aab.sh'
    inner = flutter/'scripts/build_ubuntu.sh'
    if runner.is_file() and (inner.is_file() or 'scripts/build_ubuntu.sh' not in runner.read_text(errors='replace')):
        return [(['bash',str(runner)], project)]
    if inner.is_file(): return [(['bash',str(inner)], flutter)]
    executable = flutter_tool(flutter)
    defines = ['--dart-define=API_BASE_URL='+os.getenv('API_BASE_URL','https://api.kocehind.web.id')]
    for key in ('GOOGLE_WEB_CLIENT_ID','FIREBASE_API_KEY','FIREBASE_APP_ID','FIREBASE_SENDER_ID','FIREBASE_PROJECT_ID'):
        if os.getenv(key): defines.append('--dart-define='+key+'='+os.environ[key])
    return [([executable,'pub','get'],flutter),
            ([executable,'build','appbundle','--release',*defines],flutter)]


def verify_aab(path, expected):
    result = subprocess.run(['jarsigner','-J-Duser.language=en','-J-Duser.country=US','-verify',str(path)],
        text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120)
    if result.returncode or 'jar verified.' not in result.stdout or 'unsigned entries' in result.stdout.lower():
        raise RuntimeError('Tanda tangan AAB tidak lolos verifikasi. Jangan unggah file ini.')
    output = subprocess.check_output(['keytool','-J-Duser.language=en','-J-Duser.country=US',
        '-printcert','-jarfile',str(path)],text=True,stderr=subprocess.DEVNULL,timeout=30)
    if re.search(r'CN\s*=\s*Android Debug(?:\s*[,\n]|$)',output,re.I):
        raise RuntimeError('AAB masih menggunakan kunci Android Debug; bukan hasil signing rilis yang diminta.')
    actual = re.findall(r'(?m)^\s*SHA1:\s*([0-9A-Fa-f:]+)',output)
    if not actual or any(normalized(value) != expected for value in actual):
        raise RuntimeError('Sertifikat AAB hasil build berbeda dari keystore terpilih. Jangan unggah file ini.')


def build(project, selected, storepass, keypass):
    flutter = project / 'flutter'
    if not shutil.which('jarsigner'):
        raise RuntimeError('Java JDK belum lengkap. Pasang openjdk-17-jdk pada VPS build, lalu ulangi.')
    gradles = [p for p in [flutter/'android/app/build.gradle.kts', flutter/'android/app/build.gradle'] if p.is_file()]
    if len(gradles) != 1:
        raise RuntimeError('Runner Android belum ditemukan. Jalankan pada project yang sebelumnya menghasilkan AAB Anda.')
    gradle = gradles[0]
    updated = patch_gradle(gradle.read_text(), gradle.suffix == '.kts')
    commands = build_commands(project)  # Validate the build route before edits.
    props = flutter / 'android/key.properties'
    values = {'storeFile': str(selected['path']), 'storePassword': storepass,
              'keyAlias': selected['alias'], 'keyPassword': keypass}
    backup(props); backup(gradle)
    write_private(props, ''.join(key+'='+java_value(value)+'\n' for key,value in values.items()))
    if gradle.read_text() != updated:
        original_mode = gradle.stat().st_mode & 0o777
        write_private(gradle,updated)
        gradle.chmod(original_mode)
    print('Signing memakai keystore yang cocok. Mulai build; tunggu sampai verifikasi selesai.', flush=True)
    print('Pengaturan API/Google/Firebase mengikuti environment build pada terminal ini.',flush=True)
    if not os.getenv('GOOGLE_WEB_CLIENT_ID'):
        print('PERINGATAN: GOOGLE_WEB_CLIENT_ID kosong pada terminal ini; login Google dapat tidak aktif pada build baru.',flush=True)
    started = time.time_ns()
    for command,cwd in commands:
        subprocess.run(command,cwd=cwd,check=True)
    aab = flutter / 'build/app/outputs/bundle/release/app-release.aab'
    if not aab.is_file() or aab.stat().st_mtime_ns < started:
        raise RuntimeError('Build tidak menghasilkan AAB baru. File lama tidak dianggap hasil sukses.')
    verify_aab(aab,selected['sha1'])
    print('\nBUILD DAN VERIFIKASI SELESAI')
    print('SHA-1 AAB: '+fingerprint(selected['sha1']))
    print('File AAB baru: '+str(aab))
    print('Gunakan file pada lokasi ini, bukan unduhan AAB lama yang tersimpan di HP.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, default=Path.cwd())
    parser.add_argument('--keystore', type=Path, help='Opsional: lokasi keystore lama jika tersimpan di luar folder pencarian.')
    parser.add_argument('--expected-sha1', help='Opsional: SHA-1 lengkap 20 byte yang diharapkan Google Play.')
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    os.umask(0o077)
    java_bin = Path(os.environ.get('JAVA_HOME','/usr/lib/jvm/java-17-openjdk-amd64'))/'bin'
    os.environ['PATH'] = str(java_bin)+os.pathsep+os.environ.get('PATH','')
    if not shutil.which('keytool'): raise RuntimeError('keytool belum tersedia. Jalankan pada VPS build yang memiliki Java JDK.')
    project = project_at(args.project)
    expected = normalized(args.expected_sha1) if args.expected_sha1 else TARGET_SHA1
    if args.expected_sha1 and len(expected) != 40:
        raise RuntimeError('--expected-sha1 harus memuat SHA-1 lengkap, yaitu 20 pasangan angka/huruf.')
    print('Skrip build mandiri Kocehind v2')
    print('Target SHA-1 keystore: '+fingerprint(expected))
    print('Pemeriksaan ini hanya memakai keystore yang sudah ada. Password tidak ditampilkan.')
    config = properties(project/'flutter/android/key.properties')
    configured = None
    if config.get('storeFile'):
        configured = Path(config['storeFile']).expanduser()
        if not configured.is_absolute(): configured = project/'flutter/android/app'/configured
        configured = configured.resolve()
    paths = [args.keystore.expanduser().resolve()] if args.keystore else discover(project, configured)
    matches = []
    for path in paths:
        if not path.is_file(): continue
        print('\nMemeriksa: '+str(path), flush=True)
        password = config.get('storePassword') if path == configured else None
        if password is None and path.name == 'debug.keystore': password = 'android'
        entries = inspect(path, password) if password is not None else None
        if entries is None:
            if not sys.stdin.isatty():
                print('Perlu password lokal. Ulangi langsung dari terminal SSH interaktif.'); continue
            password = getpass.getpass('Password keystore ini (Enter untuk lewati): ')
            if not password: continue
            entries = inspect(path, password)
        if entries is None:
            print('Keystore tidak dapat dibuka dengan password tersebut.'); continue
        for entry in entries:
            print('Alias: '+entry['alias']+' | SHA-1: '+fingerprint(entry['sha1']))
            if entry['sha1'].startswith(expected):
                if re.search(r'CN\s*=\s*Android Debug(?:\s*[,\n]|$)',entry['owner'],re.I):
                    print('Yang cocok adalah kunci Android Debug; tidak dipakai untuk rilis Play.'); continue
                matches.append(({**entry,'path':path},password))
        if matches: break
    if not matches:
        raise RuntimeError('Keystore rilis yang cocok belum ditemukan pada VPS ini. Salin keystore LAMA dari VPS/backup tempat AAB pertama dibuat, lalu ulangi dengan --keystore diikuti lokasinya. Kunci tersebut tidak bisa dibuat ulang hanya dari angka SHA-1.')
    selected, password = matches[0]
    print('\nKunci cocok: '+str(selected['path'])+' (alias '+selected['alias']+')')
    print('SHA-1 lengkap keystore: '+fingerprint(selected['sha1']))
    if args.check_only: return
    keypass = config.get('keyPassword') if selected['path']==configured and selected['alias']==config.get('keyAlias') else None
    if keypass is None:
        keypass = getpass.getpass('Password alias/kunci (Enter jika sama dengan password keystore): ') or password
    build(project,selected,password,keypass)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\nDihentikan. Keystore tidak dihapus.', file=sys.stderr); sys.exit(130)
    except Exception as exc:
        # Arbitrary subprocess/provider errors may contain sensitive data.
        message = str(exc) if type(exc) is RuntimeError else (
            'Perintah build/verifikasi gagal; periksa pesan terminal sebelumnya.'
            if isinstance(exc,subprocess.CalledProcessError) else type(exc).__name__)
        print('\nBELUM BERHASIL: '+message, file=sys.stderr); sys.exit(1)
