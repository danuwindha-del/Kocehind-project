# Laporan pengujian Kocehind 2.14.0

Tanggal: 30 Oktober 2026. Dasar perubahan: paket Kocehind UI Integrasi R2 yang diberikan pengguna. Pemeriksaan menggunakan data dan layanan uji terisolasi; tidak memakai transaksi uang nyata atau saldo produksi.

## Perubahan yang disertakan

1. Pembelian koin Android melalui Google Play: harga dari Play, katalog koin dari server, verifikasi ProductPurchaseV2 di backend, pengikatan akun, kredit satu kali, penyimpanan token terenkripsi, antrean konsumsi, pemulihan pembayaran pending, dan rekonsiliasi refund.
2. Admin dapat mencari pengguna, menambah/mengirim koin, mengurangi koin, serta memindahkan koin antar pengguna. Alasan wajib, saldo diperiksa, transaksi memakai kunci idempoten, dan perubahan tercatat pada ledger serta audit.
3. Kamera LIVE meminta potret 720 × 1280 sampai 30 fps dengan bitrate sampai 2,5 Mbps dan simulcast. Penonton pada panggung utama meminta kualitas tinggi; tampilan banyak peserta menyesuaikan kualitas menurut tata letak. Video dijeda saat tampilan tidak aktif.
4. Gambar LIVE dapat diperbesar, diatur lebar/tingginya, atau dibuat sebesar panggung. Pratinjau memakai ukuran tersimpan dan perubahan tersinkron kepada penonton.
5. Halaman Aktivitas Kocehind memvalidasi respons API sebelum menyaring daftar. Respons tidak valid ditampilkan sebagai keadaan gagal yang dapat dicoba kembali, tanpa membuat halaman berhenti dengan error `undefined.filter`.

## Hasil pemeriksaan

| Pemeriksaan | Hasil |
| --- | --- |
| Seluruh tes backend (`python -m pytest -q`) | 449 lulus, 9 dilewati oleh kondisi lingkungan pengujian yang sudah ada; tidak ada kegagalan |
| Tes terfokus pembayaran, koin admin, runner dan migrasi | 25 lulus; juga tercakup dalam suite backend penuh |
| Seluruh tes Flutter (`flutter test --no-pub --reporter expanded`) | 121 lulus |
| Pemeriksaan Flutter setelah perapian gaya (`flutter analyze --no-pub`) | Tidak ada masalah |
| Tes Flutter terfokus setelah perapian | 3 lulus: pengikatan akun tanpa konsumsi dini, pemulihan transaksi, pembesaran gambar dan prioritas kualitas LIVE |
| Kompilasi bundle Flutter debug untuk Android ARM64 (`flutter build bundle --debug --no-pub --target-platform android-arm64`) | Lulus; kompilasi Dart dan aset menghasilkan kernel bundle |
| Suite web/DOM/browser | 164 lulus, 1 timeout pada tes browser lama pemutaran video v2.7 |
| Browser terfokus pada ponsel | Tambah/kurangi/pindah koin admin dan pemulihan Aktivitas Kocehind lulus |
| Browser editor gambar LIVE | Host mengubah gambar/teks; penonton menerima canvas yang sama; lulus |
| Pengujian utilitas paket (`python -m pytest tests -q` dari folder paket) | 13 lulus setelah hotfix launcher Python |

Tes backend yang dilewati mencakup prasyarat integrasi khusus, seperti PostgreSQL terisolasi, server/RTC LiveKit, dan model moderasi nyata. Kondisi skip bawaan tidak dilonggarkan untuk meluluskan pembaruan.

Timeout web terjadi ketika tes `test-v27-browser.mjs` menunggu pemutaran video. Pengujian pada salinan paket asli mereproduksi timeout yang sama. Tes tetap dipertahankan dan kegagalannya dicatat; suite web tidak dinyatakan lulus seluruhnya.

Kasus pembayaran yang diperiksa mencakup pembelian duplikat, produk yang tidak cocok, akun berbeda, pending/cancelled, konsumsi gagal lalu dicoba kembali, refund parsial/penuh, utang refund, dan pemulihan worker. Pengujian mutasi pada syarat pembelian PURCHASED membuat tes pending/cancelled gagal sebagaimana diharapkan; kode semula dipulihkan sebelum pengujian akhir.

## Lingkungan Flutter

Flutter 3.38.10 dan Dart 3.10.9. Dependency pembayaran dipasang melalui resolver resmi dan dicatat pada `pubspec.lock`: `in_app_purchase` 3.3.1, implementasi Android 0.5.0, platform interface 1.4.1, dan StoreKit 0.4.13. Dependensi aplikasi lama dipertahankan; `meta` dan `test_api` mengikuti versi yang diwajibkan SDK Flutter ini. Patch kompatibilitas LiveKit 2.6.4 bawaan dijalankan sebelum analisis dan kompilasi.

## Yang perlu diverifikasi pada pemasangan sebenarnya

- APK/AAB release bertanda tangan belum dibuat di lingkungan ini. Bundle debug di atas memeriksa kompilasi Dart/aset dan tidak menggantikan build native APK/AAB. Builder yang disertakan menggunakan runner, identitas paket, konfigurasi Firebase, dan key lama milik pengguna.
- Produk, harga, negara penjualan, service account dan izin Google Play harus disiapkan pemilik. Uji license tester/internal testing dan refund nyata di Play belum dijalankan. Kode tidak mengaktifkan akun Play Console secara otomatis.
- Pembaruan belum dipasang pada VPS produksi. Backup, migrasi, kesehatan service dan rollback harus diperiksa ketika menjalankan updater di VPS pengguna.
- Kejernihan dan kestabilan LIVE pada HP dan VPS produksi belum diuji dengan dua perangkat. Resolusi kamera, pencahayaan, upload host, koneksi penonton dan kapasitas SFU tetap memengaruhi hasil. Pengaturan kualitas tidak dapat menjamin gambar selalu identik dengan pratinjau lokal host.
- Dokumen hukum yang sedang aktif tidak diganti otomatis. Pengelola dapat meninjau penjelasan pembayaran Google Play sebelum menerbitkan revisi melalui panel admin.

Ikuti `PANDUAN_GOOGLE_PLAY_v2.14.0.md` untuk urutan pemasangan, aktivasi, dan pengujian penerimaan sebelum rilis.

## Hotfix launcher updater, 30 Oktober 2026

Laporan VPS menunjukkan `runuser: failed to execute .../bin/python: Permission denied` saat preflight, sebelum pergantian API. Reproduksi menemukan wrapper `python3` berupa symlink pada direktori sementara privat. Python membuat virtualenv baru yang bergantung pada symlink sementara tersebut; pengguna service tidak dapat melewati direktori privat, dan interpreter menjadi putus setelah direktori sementara dihapus.

Wrapper kini berupa launcher shell yang menjalankan path Python backend yang tetap. Direktori sementara tetap privat dan konfigurasi virtualenv backend tetap dipakai. Tes regresi mula-mula gagal pada versi lama, lalu seluruh 13 tes paket lulus setelah perbaikan. Pemeriksaan izin untuk pengguna tanpa hak root dan eksekusi virtualenv juga lulus setelah launcher sementara dibersihkan. Tidak ada perubahan pada kode API, database, kredensial atau build Flutter untuk hotfix ini. Rilis ini tetap 2.14.0 dengan metadata `runtime_python_launcher_hotfix: 1`.
