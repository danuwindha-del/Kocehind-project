const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function url(value){try{const u=new URL(value);return ['http:','https:'].includes(u.protocol)&&!u.username&&!u.password?u.href:'';}catch{return '';}}
export const officialCategories={promotion:'Promosi',announcement:'Pengumuman',information:'Informasi',update:'Pembaruan',event:'Acara'};
export function officialBlocksHTML(blocks=[]){
 return blocks.map((b,index)=>{
  if(b.type==='heading')return `<h2>${esc(b.text)}</h2>`;
  if(b.type==='text')return `<p class="official-text">${esc(b.text)}</p>`;
  if(b.type==='image'&&url(b.media_url))return `<figure><img data-official-media="${index}" src="${esc(url(b.media_url))}" alt="${esc(b.alt||b.text||'Gambar dari Kocehind')}" loading="lazy">${b.text?`<figcaption>${esc(b.text)}</figcaption>`:''}</figure>`;
  if(b.type==='video'&&url(b.media_url))return `<figure><video data-official-media="${index}" src="${esc(url(b.media_url))}" poster="${esc(url(b.thumbnail_url))}" controls playsinline preload="metadata" aria-label="${esc(b.alt||b.text||'Video dari Kocehind')}"></video>${b.text?`<figcaption>${esc(b.text)}</figcaption>`:''}</figure>`;
  if(b.type==='link'&&url(b.url))return `<p><a class="btn official-link" href="${esc(url(b.url))}" target="_blank" rel="noopener noreferrer">${esc(b.text||'Buka tautan')} ↗</a></p>`;
  return '';
 }).join('');
}

// These are the installed public backend origin and the documented local backend.
// Only media paths enter the browser proxy; arbitrary external URLs never do.
function mediaProbeURL(value,location){
 try{
  const page=new URL(location.href),media=new URL(value,page);
  if(!['http:','https:'].includes(media.protocol)||media.username||media.password)return null;
  const loopback=host=>['localhost','127.0.0.1','[::1]'].includes(host);
  const trusted=media.origin===page.origin||media.origin==='https://api.kocehind.web.id'||
   (loopback(page.hostname)&&loopback(media.hostname)&&media.protocol==='http:'&&media.port==='8000');
  if(!trusted)return null;
  const path=media.origin===page.origin&&media.pathname.startsWith('/api/')?media.pathname.slice(4):media.pathname;
  if(!/^\/official\/activities\/[^/]+\/media\/\d+$/.test(path)&&!/^\/media\/.+/.test(path))return null;
  return '/api'+path+media.search;
 }catch{return null;}
}

// Media events do not expose HTTP or transport errors. Probe only the failing scoped URL.
export function bindOfficialMedia(root,{refresh,isCurrent=()=>true,probe=(...args)=>fetch(...args),timeoutMs=5000}={}){
 let disposed=false;const clean=[];
 const current=()=>!disposed&&root.isConnected&&isCurrent();
 root.querySelectorAll('[data-official-media]').forEach(media=>{
  const figure=media.closest('figure'),box=document.createElement('div');box.hidden=true;box.setAttribute('role','status');
  const message=document.createElement('p'),retry=document.createElement('button');retry.type='button';retry.className='btn';retry.dataset.mediaRetry='';retry.textContent='Coba lagi';box.append(message,retry);figure.append(box);
  let version=0,controller,timer;
  const cancel=()=>{clearTimeout(timer);controller?.abort();controller=null;};
  const show=text=>{box.hidden=false;message.textContent=text;};
  const failed=async()=>{
   if(!current())return;const ticket=++version;cancel();show('Memeriksa media…');retry.disabled=true;
   controller=new AbortController();let timedOut=false;
   try{
    const target=mediaProbeURL(media.currentSrc||media.src,root.ownerDocument.location);
    if(!target)throw new Error('Sumber media tidak didukung.');
    const timeout=new Promise((_,reject)=>{timer=setTimeout(()=>{timedOut=true;controller?.abort();reject(new Error('Anda sedang Offline periksa jaringan Anda'));},timeoutMs);});
    const response=await Promise.race([probe(target,{method:'HEAD',credentials:'same-origin',cache:'no-store',signal:controller.signal}),timeout]);
    if(!current()||ticket!==version)return;
    show(response.ok?'Media belum dapat ditampilkan. Format atau codec tidak didukung.':`Media tidak tersedia (HTTP ${response.status}).`);
   }catch(error){if(current()&&ticket===version)show(timedOut?error.message:(error instanceof TypeError||globalThis.navigator?.onLine===false?'Anda sedang Offline periksa jaringan Anda':error.message));}
   finally{if(ticket===version){cancel();if(current())retry.disabled=false;}}
  };
  const reload=async()=>{
   if(!current())return;const ticket=++version;cancel();retry.disabled=true;
   try{
    const item=await refresh();if(!current()||ticket!==version)return;
    const block=item.blocks?.[Number(media.dataset.officialMedia)];
    if(!block||!url(block.media_url))throw new Error('Media tidak tersedia.');
    media.src=url(block.media_url);if(media.tagName==='VIDEO'){media.poster=url(block.thumbnail_url);media.load();}
    box.hidden=true;
   }catch(error){if(current()&&ticket===version)show(error.message);}
   finally{if(current()&&ticket===version)retry.disabled=false;}
  };
  media.addEventListener('error',failed);retry.addEventListener('click',reload);
  clean.push(()=>{++version;cancel();media.removeEventListener('error',failed);retry.removeEventListener('click',reload);if(media.tagName==='VIDEO'){media.pause();media.removeAttribute('src');media.load();}box.remove();});
 });
 return ()=>{if(disposed)return;disposed=true;clean.forEach(fn=>fn());};
}
