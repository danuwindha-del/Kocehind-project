// Consent belongs to the currently displayed document versions, never a saved preference.
export class LegalConsent {
 constructor(){this.documents=null;this.checked=false;}
 replace(documents){
  this.checked=false;this.documents=null;
  for(const kind of ['privacy','terms']){const doc=documents?.[kind];if(!doc||doc.kind!==kind||typeof doc.title!=='string'||typeof doc.content!=='string'||!Number.isSafeInteger(doc.version)||doc.version<1)throw new Error('Dokumen hukum belum tersedia. Muat ulang untuk mencoba lagi.');}
  this.documents=documents;return documents;
 }
 choose(value){this.checked=Boolean(value)&&Boolean(this.documents);}
 acceptance(){if(!this.documents)throw new Error('Dokumen hukum belum tersedia.');if(!this.checked)throw new Error('Baca dan setujui Kebijakan Privasi serta Ketentuan Penggunaan untuk melanjutkan.');return {privacy_version:this.documents.privacy.version,terms_version:this.documents.terms.version};}
}
export function legalUpdate(document,{title,content,reason}){
 title=String(title??'').trim();reason=String(reason??'').trim();
 if(!title||title.length>150)throw new Error('Judul wajib diisi, maksimal 150 karakter.');
 if(typeof content!=='string'||content.trim().length<100||content.length>100000)throw new Error('Isi dokumen wajib 100–100.000 karakter, dengan minimal 100 karakter selain spasi.');
 if(title.includes('\0')||content.includes('\0'))throw new Error('Karakter NUL tidak diizinkan pada judul atau isi dokumen.');
 if(reason.length<3||reason.length>1000)throw new Error('Alasan pembaruan wajib 3–1.000 karakter.');
 if(!Number.isSafeInteger(document?.version)||document.version<1)throw new Error('Muat dokumen terbaru sebelum menyimpan.');
 return {title,content,expected_version:document.version,reason};
}
