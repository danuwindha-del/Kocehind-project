export const OFFLINE_MESSAGE='Anda sedang Offline periksa jaringan Anda';
export async function networkFetch(input,options={},fetcher=globalThis.fetch){
 try{return await fetcher(input,options);}catch(error){
  if(error?.name==='AbortError')throw error;
  if(error instanceof TypeError||globalThis.navigator?.onLine===false){
   const offline=new Error(OFFLINE_MESSAGE);offline.status=0;throw offline;
  }
  throw error;
 }
}
