import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile,mkdir} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {chromium} from 'playwright';
const sites=resolve(new URL('..',import.meta.url).pathname);
const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+cRncAAAAASUVORK5CYII=','base64');
const user={id:'buyer',username:'buyer',name:'Buyer',legal_required:false};
const balance={coins:0,earnings:0,held:0,earned_total:0,paid_total:0,minimum_withdrawal:50000,withdrawal_methods:{BRI:'Bank BRI'},coin_debt:0};
const invoice={id:'invoice-123',gateway:'kipay',payment_mode:'sandbox',coins:100,price:10000,unique_code:215,total_amount:10215,fee_amount:100,fee_bearer:'merchant',status:'unpaid',provider_reference:'SBX-20261028-TEST',expires_at:'2026-10-28 14:15:00',created_at:'2026-10-28T14:00:00Z',qr_url:'/api/web/coins/orders/invoice-123/qr',checkout_url:''};
async function scenario({existing=false,qrFails=false,unconfigured=false}={},run){
 let order=existing?{...invoice}:null,actual='pending';const requests=[];
 const server=createServer(async(req,res)=>{try{
  const url=new URL(req.url,'http://fixture');requests.push({method:req.method,path:url.pathname});
  if(url.pathname==='/api/web/coins/orders/invoice-123/qr'){res.writeHead(qrFails?502:200,{'content-type':qrFails?'application/json':'image/png'});res.end(qrFails?'{}':png);return;}
  if(url.pathname.startsWith('/api/')){
   let raw='';for await(const c of req)raw+=c;const path=url.pathname.slice(4);let data={items:[],next_offset:null,next_cursor:null},status=200;
   if(path==='/users/me')data=user;
   if(path==='/web/coins/packages')data={items:[{id:'coin_100',coins:100,price:10000}]};
   if(path==='/web/coins/channels'){if(unconfigured){status=503;data={detail:'Pembayaran Kipay belum diaktifkan oleh pengelola'};}else data={gateway:'kipay',mode:'sandbox',items:[{code:'QRIS',name:'QRIS · Kipay'}]};}
   if(path==='/wallet')data={...balance,coins:order?.status==='paid'?100:0};
   if(path==='/web/coins/orders'&&req.method==='POST'){const body=JSON.parse(raw);assert.equal(body.method,'QRIS');assert.equal(body.package_id,'coin_100');assert.match(body.request_key,/^[a-f0-9-]{36}$/);order={...invoice};data=order;status=201;}
   else if(path==='/web/coins/orders')data={items:order?[order]:[],next_offset:null};
   if(path.endsWith('/refresh')&&order){if(actual!=='pending')order={...order,status:actual,credited_at:actual==='paid'?'2026-10-28T14:01:00Z':null};data=order;}
   res.writeHead(status,{'content-type':'application/json'});res.end(JSON.stringify(data));return;
  }
  const relative=url.pathname.startsWith('/shared/')?url.pathname.slice(1):/\.(js|css|png)$/.test(url.pathname)?'web'+url.pathname:'web/index.html';
  const path=resolve(sites,relative);if(!path.startsWith(sites+'/'))throw Error('path');
  res.writeHead(200,{'content-type':{'.js':'text/javascript','.css':'text/css','.png':'image/png','.html':'text/html'}[extname(path)]||'application/octet-stream'});res.end(await readFile(path));
 }catch(e){res.writeHead(404);res.end('missing');}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE,args:['--no-sandbox']}),page=await browser.newPage({viewport:{width:360,height:860}}),errors=[];
 page.setDefaultTimeout(7000);page.on('pageerror',e=>errors.push(e.message));await page.route('https://accounts.google.com/**',r=>r.fulfill({body:''}));
 try{await page.goto(base+'/wallet');await run({page,requests,setActual:v=>{actual=v;}});assert.deepEqual(errors,[]);}finally{await browser.close();await new Promise(r=>server.close(r));}
}
test('Kipay QRIS checkout shows exact amount and updates the open dialog after verified payment',async()=>{
 await scenario({},async({page,requests,setActual})=>{
  await page.locator('#coin-form [type=submit]:not([disabled])').waitFor();await page.getByRole('button',{name:'Buat tagihan',exact:true}).click();
  await page.locator('dialog .payment-qr').waitFor();assert.match(await page.locator('dialog').innerText(),/10.215/);assert.match(await page.locator('dialog').innerText(),/ditanggung merchant/);
  assert.match(await page.locator('#payment-mode').innerText(),/sandbox/);assert.match(await page.locator('dialog .payment-qr').getAttribute('src'),/^\/api\/web\/coins\/orders\/invoice-123\/qr$/);
  assert.match(await page.getByRole('link',{name:'Simpan QRIS',exact:true}).getAttribute('download'),/\.png$/);
  for(const width of [360,1440]){await page.setViewportSize({width,height:900});assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));}
  await mkdir('/tmp/kocehind-v11-qa',{recursive:true});await page.setViewportSize({width:360,height:860});await page.screenshot({path:'/tmp/kocehind-v11-qa/kipay-qris-phone.png',fullPage:true});
  setActual('paid');await page.getByRole('button',{name:'Saya sudah membayar · cek status',exact:true}).click();
  await page.locator('dialog').getByText('Koin sudah diproses ke saldo akun Anda.',{exact:true}).waitFor();assert.equal(await page.locator('dialog img').count(),0);
  await page.locator('#wallet-balance .wallet-card').first().getByText('100',{exact:true}).waitFor();
  assert.equal(requests.filter(r=>r.method==='POST'&&r.path==='/api/web/coins/orders').length,1);assert.equal(requests.some(r=>r.path.includes('apg_')),false);
 });
});
test('Existing QRIS invoice can reopen and expired QR is removed from the dialog',async()=>{
 await scenario({existing:true},async({page,setActual})=>{
  await page.getByRole('button',{name:'Lihat QRIS',exact:true}).click();await page.locator('dialog .payment-qr').waitFor();setActual('expired');
  await page.getByRole('button',{name:'Saya sudah membayar · cek status',exact:true}).click();await page.locator('dialog').getByText('Kedaluwarsa',{exact:true}).waitFor();assert.equal(await page.locator('dialog img').count(),0);
  await page.locator('dialog .close').click();await page.locator('dialog').waitFor({state:'detached'});
 });
});
test('QR image failure gives a retry instruction',async()=>{
 await scenario({existing:true,qrFails:true},async({page})=>{await page.getByRole('button',{name:'Lihat QRIS',exact:true}).click();await page.locator('dialog .qr-error:not([hidden])').waitFor();assert.match(await page.locator('dialog').innerText(),/Tutup lalu buka lagi/);});
});
test('Missing Kipay configuration keeps checkout disabled',async()=>{
 await scenario({unconfigured:true},async({page})=>{await page.locator('#coin-form .form-error').getByText('Pembayaran Kipay belum diaktifkan oleh pengelola',{exact:true}).waitFor();assert.equal(await page.locator('#coin-form [type=submit]').isDisabled(),true);});
});
