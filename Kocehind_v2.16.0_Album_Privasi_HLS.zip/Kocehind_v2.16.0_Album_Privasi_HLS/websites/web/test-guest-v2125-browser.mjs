// Real Chromium UI with deterministic API responses; no production account/network.
import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {createRequire} from 'node:module';
const {chromium}=createRequire(import.meta.url)('playwright');
const sites=resolve(new URL('..',import.meta.url).pathname);
const user={id:'owner',username:'kreator',name:'Kreator Publik',bio:'Profil dapat dibaca tamu',followers:2,following_count:1,likes_received:3,relationship_label:'Ikuti'};
const viewer={id:'viewer',username:'viewer',name:'Viewer',legal_required:false};
const post={id:'guest-post',kind:'image',caption:'Cerita publik',author:user,media_url:'',thumbnail_url:'',visibility:'public',likes:0,comments:2,views:3,is_mine:false};
const comment={id:'c1',username:'pembaca',body:'Komentar dapat dibaca tamu',likes:2,created_at:'2026-10-25T00:00:00Z',can_delete:false};

test('Guest reads profile/comments/paging while writes prompt login; signed-in writes still work',async()=>{
 let signedIn=false;
 const calls=[];
 const server=createServer(async(req,res)=>{
  try{
   const url=new URL(req.url,'http://fixture');
   if(url.pathname.startsWith('/api/')){
    let text='';for await(const c of req)text+=c;
    const path=url.pathname.slice(4);calls.push({path,query:url.search,method:req.method,body:text?JSON.parse(text):null});
    let status=200,data={};
    if(path==='/users/me'||path==='/web/auth/refresh'){
     if(signedIn)data=path==='/users/me'?viewer:{user:viewer};
     else{status=401;data={detail:'Harus login'};}
    }else if(path==='/users/kreator'||path==='/users/pembaca')data={...user,username:path.split('/').pop()};
    else if(path.startsWith('/users/')&&path.endsWith('/posts'))data={items:[post],next_offset:null};
    else if(path==='/posts/guest-post')data=post;
    else if(path==='/posts/guest-post/comments')data=req.method==='GET'?{items:url.searchParams.get('offset')==='1'?[{...comment,id:'c2',parent_id:'c1',body:'Balasan publik'}]:[comment],total:2,next_offset:url.searchParams.get('offset')==='1'?null:1}:{...comment,id:'new',body:JSON.parse(text).body};
    else if(path==='/users/kreator/follow')data={following:true,relationship_label:'Mengikuti'};
    else if(path==='/comments/c1/like')data={...comment,liked:true,likes:3};
    else if(path==='/legal/documents')data={privacy:{version:1,title:'Privasi',content:'Privasi'},terms:{version:1,title:'Ketentuan',content:'Ketentuan'}};
    else if(path==='/web/config')data={google_web_client_id:''};
    else if(path==='/feed')data={items:[post],next_cursor:null};
    else if(path==='/users/me/privacy')data={revision:1};
    else data={items:[],next_offset:null,next_cursor:null};
    res.writeHead(status,{'content-type':'application/json'});res.end(JSON.stringify(data));return;
   }
   const relative=url.pathname.startsWith('/shared/')?url.pathname.slice(1):url.pathname.endsWith('.js')||url.pathname.endsWith('.css')?'web'+url.pathname:'web/index.html';
   const file=resolve(sites,relative);
   if(!file.startsWith(sites+'/'))throw new Error('path');
   const body=await readFile(file);res.writeHead(200,{'content-type':({'.js':'text/javascript','.css':'text/css','.html':'text/html'}[extname(file)]||'application/octet-stream')});res.end(body);
  }catch(error){res.writeHead(404);res.end('missing');}
 });
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const url='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:420,height:850}}),errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 const interactions=()=>calls.filter(c=>c.method!=='GET'&&(/\/comments$|\/follow$|\/like$/.test(c.path)));
 const expectLogin=async click=>{
  await click();await page.locator('dialog #auth-form').waitFor();
  assert.equal(interactions().length,0);
  await page.locator('dialog .close').click();
 };
 try{
  await page.goto(url+'/@kreator');
  await page.locator('.profile-hero').waitFor();
  assert.match(await page.locator('.profile-hero').innerText(),/Profil dapat dibaca tamu/);
  assert.equal(await page.locator('#gate-login').count(),0);
  assert.equal(calls.filter(c=>c.path.endsWith('/visit')).length,0);
  await expectLogin(()=>page.locator('#profile-follow').click());
  await page.goto(url+'/video/guest-post');
  await page.locator('[data-action="comments"]').click();
  await page.getByText(comment.body,{exact:true}).waitFor();
  assert.equal(await page.locator('dialog').count(),0);
  assert.equal(await page.locator('.comment-form input').count(),0);
  await page.locator('.comment-read-more').click();
  await page.getByText('Balasan publik',{exact:true}).waitFor();
  await expectLogin(()=>page.locator('[data-comment-login]').click());
  await expectLogin(()=>page.locator('[data-comment="c1"] [data-reply]').click());
  await expectLogin(()=>page.locator('[data-comment="c1"] [data-comment-like]').click());
  await page.locator('[data-comment="c1"] .comment-content a[data-link]').click();
  await page.locator('.profile-hero').waitFor();
  assert.equal(new URL(page.url()).pathname,'/@pembaca');
  assert.equal(interactions().length,0);
  signedIn=true;
  await page.goto(url+'/@kreator');await page.locator('#profile-follow').click();
  await page.getByRole('button',{name:'Mengikuti',exact:true}).waitFor();
  assert(calls.some(c=>c.path==='/users/kreator/follow'&&c.method==='POST'));
  await page.goto(url+'/video/guest-post');await page.locator('[data-action="comments"]').click();
  await page.locator('.comment-form input').fill('Komentar dari akun');
  await page.locator('.comment-form button[type="submit"]').click();
  await page.waitForFunction(()=>!document.querySelector('.comment-form button[type="submit"]').disabled);
  assert(calls.some(c=>c.path==='/posts/guest-post/comments'&&c.method==='POST'&&c.body.body==='Komentar dari akun'));
  assert.deepEqual(errors,[]);
 }finally{await browser.close();await new Promise(r=>server.close(r));}
});
