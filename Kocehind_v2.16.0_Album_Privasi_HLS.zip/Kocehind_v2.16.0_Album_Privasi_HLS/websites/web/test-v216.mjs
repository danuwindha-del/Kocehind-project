import test from 'node:test';
import assert from 'node:assert/strict';
import {JSDOM} from 'jsdom';
import {recentSearches,mountRecent,mountInboxSearch} from './search-tools.js';
import {adaptivePlayback,playbackSource} from './media-playback.js';
import {albumHTML,bindAlbum} from './albums.js';
const esc=v=>String(v).replaceAll('<','&lt;').replaceAll('"','&quot;');

test('guest search history deduplicates, caps six and deletes without storing account data',async()=>{
 const values=new Map(),storage={getItem:k=>values.get(k),setItem:(k,v)=>values.set(k,v)};
 const history=recentSearches({api:()=>{throw Error('unexpected API');},user:()=>null,storage});
 for(let i=0;i<8;i++)await history.remember('Query '+i);
 assert.deepEqual(await history.load(),['Query 7','Query 6','Query 5','Query 4','Query 3','Query 2']);
 await history.remember('  QUERY   3 ');assert.equal((await history.load())[0],'QUERY 3');
 assert.equal((await history.remove('QUERY 3')).length,5);assert.deepEqual(await history.remove(),[]);
});

test('authenticated history uses account-scoped endpoints and never reads guest storage',async()=>{
 const calls=[];const history=recentSearches({user:()=>({id:'a'}),storage:{getItem(){throw Error('guest access');}},
  api:async(path,options)=>{calls.push([path,options]);return {items:['query']};}});
 await history.load();await history.remember('query');await history.remove('query');await history.remove();
 assert.deepEqual(calls.map(([p])=>p),['/search/history','/search/history','/search/history?term=query','/search/history']);
 assert.equal(calls[1][1].method,'POST');assert.equal(calls[2][1].method,'DELETE');
});

test('HLS starts on the small variant, adapts, falls back once, and destroys decoders',()=>{
 const calls=[];class Hls {static Events={ERROR:'error'};static isSupported=()=>true;
  constructor(options){calls.push(options);this.handlers={};Hls.instance=this;}
  on(event,handler){this.handlers[event]=handler;}loadSource(url){calls.push(url);}attachMedia(v){calls.push('attached');}
  destroy(){calls.push('destroyed');}}
 const video={canPlayType:()=>'',preload:'',load(){calls.push('load');},pause(){calls.push('pause');},removeAttribute(){},closest:()=>null};
 const cleanup=adaptivePlayback(video,{hls_url:'https://api.kocehind.web.id/streams/p/f/master.m3u8?stream_token=t',media_url:'https://api.kocehind.web.id/media/p.mp4'},{Hls});
 assert.equal(calls[0].startLevel,0);assert.equal(calls[1],'/api/streams/p/f/master.m3u8?stream_token=t');
 Hls.instance.handlers.error(null,{fatal:true});assert.equal(video.src,'/api/media/p.mp4');cleanup();assert(calls.includes('pause'));
 assert.equal(playbackSource('javascript:alert(1)','https://web.kocehind.web.id'),'');
});

test('album renders ordered photos with accessible count and keyboard navigation',()=>{
 const dom=new JSDOM('<article></article>',{url:'https://web.kocehind.web.id'}),{document}=dom.window;
 globalThis.document=document;globalThis.location=dom.window.location;
 const post={kind:'image',caption:'<unsafe>',photos:Array.from({length:20},(_,i)=>({media_url:`https://api.kocehind.web.id/media/${i}.jpg`}))};
 const root=document.querySelector('article');root.innerHTML=albumHTML(post,{esc});
 assert.equal(root.querySelectorAll('.photo-slide').length,20);assert.equal(root.querySelector('.photo-counter').textContent,'1/20');
 const slides=root.querySelector('.photo-slides');Object.defineProperty(slides,'clientWidth',{value:390});slides.scrollTo=({left})=>{slides.scrollLeft=left;slides.dispatchEvent(new dom.window.Event('scroll'));};
 const state=bindAlbum(root,post);root.querySelector('.photo-next').click();assert.equal(root.querySelector('.photo-counter').textContent,'2/20');
 slides.dispatchEvent(new dom.window.KeyboardEvent('keydown',{key:'ArrowRight'}));assert.equal(root.querySelector('.photo-counter').textContent,'3/20');
 state.dispose();dom.window.close();delete globalThis.document;delete globalThis.location;
});
