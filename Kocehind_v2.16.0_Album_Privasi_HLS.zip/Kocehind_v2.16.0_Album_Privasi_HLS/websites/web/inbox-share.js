import {api,me,esc,avatar,badge,openDialog,requireAccount,toast} from '/shared/api.js?v=2.16.0';
export async function shareToInbox(type,id,title){
 if(!await requireAccount())return;
 const page=await api('/users/'+encodeURIComponent(me.username)+'/connections?kind=friends');
 const dialog=openDialog('Kirim ke inbox','<form class="recipient-search"><label>Cari akun<input name="q" maxlength="100" placeholder="Username atau nama"></label><button class="btn">Cari</button></form><div class="share-recipients"></div>');
 let ticket=0;const root=dialog.querySelector('.share-recipients');
 function render(users){root.innerHTML=users.filter(u=>u.id!==me.id).map(u=>`<button class="user-row" data-recipient="${esc(u.username)}">${avatar(u)}<span class="user-info"><strong>${esc(u.name)}${badge(u)}</strong><small>@${esc(u.username)}</small></span></button>`).join('')||'<p>Belum ada akun. Cari username untuk mengirim permintaan pesan.</p>';root.querySelectorAll('[data-recipient]').forEach(button=>button.onclick=async()=>{button.disabled=true;try{await api('/chats/'+encodeURIComponent(button.dataset.recipient),{method:'POST',body:{body:title,shared_type:type,shared_id:id}});toast('Dibagikan ke inbox');dialog.close();}catch(error){toast(error.message);button.disabled=false;}});}
 render(page.items||[]);dialog.querySelector('form').onsubmit=async event=>{event.preventDefault();const current=++ticket,q=new FormData(event.target).get('q').trim();try{const result=q?await api('/search?q='+encodeURIComponent(q)):page;if(current===ticket&&dialog.open)render(q?(result.users||[]):(result.items||[]));}catch(error){toast(error.message);}};
}
