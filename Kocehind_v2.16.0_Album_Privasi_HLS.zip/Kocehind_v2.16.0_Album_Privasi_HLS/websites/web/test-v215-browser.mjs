import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile,mkdir} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {createRequire} from 'node:module';
const {chromium}=createRequire(import.meta.url)('playwright');
const root=resolve(new URL('..',import.meta.url).pathname);
const owner={id:'00000000-0000-4000-8000-000000000001',username:'creator',name:'Kreator Kocehind',bio:'Cerita sehari-hari dari komunitas.',is_admin:true,legal_required:false,profile_limits:{},followers:1500,following_count:15,likes_received:4200,links:[{title:'Situs resmi',url:'https://example.com/'},{title:'Portofolio',url:'https://example.org/'}]};
const post={id:'00000000-0000-4000-8000-000000000002',caption:'Video kreator',kind:'video',media_url:'',thumbnail_url:'',author:owner,views:1234,likes:50,following:false,is_mine:true,is_pinned:false,visibility:'public',mentions:[]};
const ai={id:'youtube',title:'YouTube',summary:'YouTube menyediakan ruang untuk berbagi cerita dan membangun komunitas.\n\nProduk YouTube mencakup YouTube Music, YouTube Kids, dan YouTube Studio.',images:[],sources:[{label:'YouTube resmi',url:'https://about.youtube/'}],studied_at:'2026-10-31T00:00:00Z'};
const qa=process.env.KOCEHIND_QA_DIR||'/tmp/kocehind-qa-v215';

async function scenario(site,path,handler,run){
 const calls=[];
 const server=createServer(async(req,res)=>{
  try{
   const url=new URL(req.url,'http://fixture');
   if(url.pathname.startsWith('/api/')){
    const chunks=[];for await(const chunk of req)chunks.push(chunk);const raw=Buffer.concat(chunks);
    const call={path:url.pathname.slice(4),method:req.method,query:url.searchParams,body:req.headers['content-type']?.includes('json')&&raw.length?JSON.parse(raw):null};calls.push(call);
    let data=await handler(call);
    if(data===undefined){if(call.path==='/users/me'||call.path==='/admin/me'||call.path==='/users/creator')data=owner;else if(call.path==='/users/me/privacy')data={revision:'test'};else data={items:[],next_offset:null,unread:0};}
    res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(data));return;
   }
   const relative=url.pathname.startsWith('/shared/')?url.pathname.slice(1):/\.(js|css|png)$/.test(url.pathname)?site+url.pathname:site+'/index.html';
   const file=resolve(root,relative);if(!file.startsWith(root+'/'))throw new Error('Invalid path');
   res.writeHead(200,{'content-type':({'.js':'text/javascript','.css':'text/css','.html':'text/html','.png':'image/png'}[extname(file)]||'application/octet-stream')});res.end(await readFile(file));
  }catch{res.writeHead(404);res.end('missing');}
 });
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:390,height:844}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 try{await page.goto(origin+path);await run(page,calls);assert.deepEqual(errors,[]);}finally{await browser.close();await new Promise(r=>server.close(r));}
}

test('Phone search shows MychaAI above real results and Tanya retains the sourced answer',async()=>{
 await scenario('web','/search?q=apa%20itu%20youtube',c=>{
  if(c.path==='/search/mycha')return {name:'MychaAI',items:[ai]};
  if(c.path==='/search')return {posts:[post],users:[],sounds:[],hashtags:[],entries:[{type:'post',post}],next_cursor:null};
 },async page=>{
  await page.getByText('Ringkasan bersumber',{exact:true}).waitFor();await page.locator('.grid-card').waitFor();
  assert((await page.locator('.mycha-card').boundingBox()).y<(await page.locator('.grid-card').boundingBox()).y);
  await page.getByRole('button',{name:'Lebih banyak'}).click();assert.equal(await page.locator('.mycha-expand').getAttribute('aria-expanded'),'true');
  await page.getByRole('button',{name:'Tanya',exact:true}).click();await page.getByRole('heading',{name:'YouTube',exact:true}).waitFor();
  assert.equal(await page.locator('.mycha-sources a').getAttribute('href'),'https://about.youtube/');
  await mkdir(qa,{recursive:true});await page.screenshot({path:qa+'/mycha-phone.png',fullPage:true});
 });
});

test('Profile links edit and three pin labels are visible to a visitor',async()=>{
 let user=structuredClone(owner);
 await scenario('web','/@creator',c=>{
  if(c.path==='/users/creator'||c.path==='/users/me')return user;
  if(c.path==='/users/creator/posts')return {items:Array.from({length:4},(_,i)=>({...post,id:post.id.slice(0,-1)+(i+2),is_pinned:i<3})),next_offset:null};
  if(c.path==='/users/me'&&c.method==='PUT'){user={...user,...c.body};return user;}
 },async(page,calls)=>{
  await page.locator('.profile-links a').first().waitFor();assert.equal(await page.locator('.profile-links a').count(),2);
  assert.equal(await page.locator('.pinned-label').count(),3);
  await page.getByRole('button',{name:'Edit profil',exact:true}).click();
  await page.locator('[name=link_url_0]').fill('https://updated.example.com/');await page.locator('[name=link_title_0]').fill('Tautan baru');
  await page.getByRole('button',{name:'Simpan perubahan'}).click();await page.locator('dialog').waitFor({state:'detached'});
  const saved=calls.find(c=>c.path==='/users/me'&&c.method==='PUT');assert.equal(saved.body.links.length,2);assert.equal(saved.body.links[0].url,'https://updated.example.com/');
  await mkdir(qa,{recursive:true});await page.screenshot({path:qa+'/profile-phone.png',fullPage:true});
 });
});

test('Video share toggles pin and unpin through owner-only server endpoints',async()=>{
 let pinned=false;
 await scenario('web','/video/'+post.id,c=>{
  if(c.path==='/posts/'+post.id)return {...post,is_pinned:pinned};
  if(c.path==='/posts/'+post.id+'/pin'){pinned=c.method==='PUT';return {post_id:post.id,is_pinned:pinned};}
 },async(page,calls)=>{
  await page.locator('[data-action=share]').click();await page.getByRole('button',{name:'Sematkan di profil'}).click();
  await page.waitForTimeout(100);assert(calls.some(c=>c.path.endsWith('/pin')&&c.method==='PUT'));
  await page.locator('[data-action=share]').click();await page.getByRole('button',{name:'Copot sematkan',exact:true}).click();
  await page.waitForTimeout(100);assert(calls.some(c=>c.path.endsWith('/pin')&&c.method==='DELETE'));
 });
});
