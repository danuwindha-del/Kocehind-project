import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
import vm from 'node:vm';
const {JSDOM}=createRequire(import.meta.url)('jsdom');
const read=name=>readFile(new URL(name,import.meta.url),'utf8');
const data=s=>'data:text/javascript;base64,'+Buffer.from(s).toString('base64');
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const avatar=m=>m.avatar_url?`<img class="avatar" src="${esc(m.avatar_url)}">`:`<span class="avatar letter">${esc(m.name[0])}</span>`;

async function stageFixture(){
 const dom=new JSDOM('<div id="stage"></div>');globalThis.document=dom.window.document;
 const layout=await read('live-layout.js');
 const functions=layout.slice(layout.indexOf('export function stageSlots'),layout.indexOf('export function openLiveLayout'));
 globalThis.stageHelpers={avatar,esc};
 const source=(await read('live-stage.js')).replace(/^import .*;\n/gm,'');
 const {renderLiveStage}=await import(data('const {avatar,esc}=globalThis.stageHelpers;\n'+functions+source));
 const stage=document.querySelector('#stage');Object.defineProperties(stage,{clientWidth:{value:390},clientHeight:{value:560}});
 const people=Array.from({length:3},(_,i)=>({id:'p'+i,name:'Person '+i,username:'person'+i,role:i?'speaker':'host',avatar_url:i?'/api/media/avatar'+i+'.png':''}));
 const rtc={remoteParticipants:new Map(people.map(m=>[m.id,{videoTrackPublications:new Map([['cam',{track:{attach(){const v=document.createElement('video');v.play=async()=>{};return v;},detach(){return[];}},isMuted:false}]])}]))};
 const info={together:true,seats:9,mode:'camera',host:people[0],members:people,layout:{slots:people.map(m=>m.id),focus_id:null}};
 return {dom,stage,info,rtc,renderLiveStage};
}

test('Preview renders host, guests, empty seats and shared focus without replacing tracks',async()=>{
 const f=await stageFixture();f.renderLiveStage(f.stage,f.info,f.rtc);
 assert.equal(f.stage.querySelectorAll('video').length,3);assert.equal(f.stage.querySelectorAll('.empty-seat').length,6);
 const video=f.stage.querySelector('[data-person=p0] video');
 f.info.layout.focus_id='p1';f.renderLiveStage(f.stage,f.info,f.rtc);
 assert.equal(f.stage.querySelector('[data-person=p1]').style.gridColumn,'1 / -1');
 assert.equal(f.stage.querySelector('[data-person=p0] video'),video);
 f.dom.window.close();
});

test('Audio and muted camera show current avatar, refresh it and fall back on image failure',async()=>{
 const f=await stageFixture();f.info.mode='audio';f.renderLiveStage(f.stage,f.info,f.rtc);
 assert.equal(f.stage.querySelectorAll('video').length,0);
 const photo=f.stage.querySelector('[data-person=p1] img');assert(photo.src.endsWith('avatar1.png'));
 f.info.members[1].avatar_url='/api/media/updated.png';f.renderLiveStage(f.stage,f.info,f.rtc);
 const updated=f.stage.querySelector('[data-person=p1] img');assert(updated.src.endsWith('updated.png'));
 updated.dispatchEvent(new f.dom.window.Event('error'));
 assert.equal(f.stage.querySelector('[data-person=p1] .avatar.letter').textContent,'P');
 f.dom.window.close();
});

test('Solo stage has one tile; camera CSS covers the entire tile and phone viewport',async()=>{
 const f=await stageFixture();f.info.together=false;f.info.members=f.info.members.slice(0,1);f.renderLiveStage(f.stage,f.info,f.rtc);
 assert.equal(f.stage.querySelectorAll('.live-tile').length,1);assert(f.stage.classList.contains('solo'));
 const css=await read('app.css');assert.match(css,/\.live-tile video\{inset:0;width:100%;height:100%;object-fit:cover/);
 assert.match(css,/\.live-room\.camera-room\{position:fixed;inset:0;height:100dvh/);
 f.dom.window.close();
});

async function workerFixture(){
 const handlers={},stores=new Map(),gets=new Map(),heads=new Map();let permitted=true;
 const caches={async open(name){if(!stores.has(name))stores.set(name,new Map());const entries=stores.get(name);return {async match(key){return entries.get(key)?.clone();},async put(key,response){const body=await response.arrayBuffer();entries.set(key,new Response(body,{status:response.status,headers:response.headers}));},async delete(key){return entries.delete(key);}};},async keys(){return [...stores.keys()];},async delete(key){return stores.delete(key);}};
 const self={location:{origin:'https://web.test'},clients:{claim:async()=>{},matchAll:async()=>[{id:'tab-a'},{id:'tab-b'}]},skipWaiting:async()=>{},addEventListener(name,fn){handlers[name]=fn;}};
 const payload=Uint8Array.from({length:64},(_,i)=>i);
 const fetch=async(input,options={})=>{const url=typeof input==='string'?input:input.url,method=options.method||input.method||'GET';if(method==='HEAD'){heads.set(url,(heads.get(url)||0)+1);return new Response(null,{status:permitted?200:404});}gets.set(url,(gets.get(url)||0)+1);return new Response(payload,{headers:{'content-type':'video/mp4','content-length':String(payload.length),'cache-control':'private, no-store'}});};
 vm.runInNewContext(await read('video-session-worker.js'),{self,caches,fetch,URL,Request,Response,Headers,Map,Set});
 const message=async(data,client='tab-a')=>{let work;handlers.message({source:{id:client},data,waitUntil(p){work=p;}});await work;};
 const request=async(url,{range,client='tab-a'}={})=>{let response;const waiting=[];handlers.fetch({clientId:client,request:new Request(url,{headers:range?{range}:{}}),respondWith(p){response=p;},waitUntil(p){waiting.push(p);}});const result=await response;await Promise.all(waiting);return result;};
 return {message,request,gets,heads,stores,payload,revoke(){permitted=false;}};
}

test('Web session streams once, replays byte ranges without GET, and rechecks access with HEAD',async()=>{
 const f=await workerFixture(),url='https://web.test/api/media/a.mp4?media_token=one';
 await f.message({type:'warm',session:'s1',urls:[]});
 assert.deepEqual(new Uint8Array(await(await f.request(url)).arrayBuffer()),f.payload);
 const replay=await f.request(url,{range:'bytes=8-15'});assert.equal(replay.status,206);
 assert.deepEqual(new Uint8Array(await replay.arrayBuffer()),f.payload.slice(8,16));
 assert.equal(f.gets.get(url),1);assert.equal(f.heads.get(url),1);
 const rotated='https://web.test/api/media/a.mp4?media_token=two';
 assert.equal((await f.request(rotated,{range:'bytes=-5'})).status,206);assert.equal(f.gets.get(rotated),undefined);
 f.revoke();assert.equal((await f.request(rotated)).status,404);
});

test('Web prefetch downloads only three upcoming videos and deduplicates replay',async()=>{
 const f=await workerFixture(),urls=Array.from({length:4},(_,i)=>'https://web.test/api/media/a'+i+'.mp4');
 await f.message({type:'warm',session:'s1',urls});
 assert.equal(f.gets.size,3);assert(!f.gets.has(urls[3]));
 await f.request(urls[1]);assert.equal(f.gets.get(urls[1]),1);
 await f.message({type:'warm',session:'s1',urls});assert.equal(f.gets.get(urls[1]),1);
});

test('Web cache is scoped to a tab and is cleared at logout/new session',async()=>{
 const f=await workerFixture(),url='https://web.test/api/media/a.mp4';
 await f.message({type:'warm',session:'s1',urls:[url]});
 await f.message({type:'warm',session:'s2',urls:[url]},'tab-b');assert.equal(f.gets.get(url),2);
 await f.message({type:'clear'});assert.equal(f.stores.size,1);
 await f.message({type:'warm',session:'s3',urls:[url]});assert.equal(f.gets.get(url),3);
});
