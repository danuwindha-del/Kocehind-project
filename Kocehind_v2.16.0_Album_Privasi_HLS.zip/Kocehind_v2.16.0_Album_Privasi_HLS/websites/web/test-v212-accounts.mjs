import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
const {JSDOM}=createRequire(import.meta.url)('jsdom');
const settle=()=>new Promise(resolve=>setTimeout(resolve,15));
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function moduleUI(path,api) {
 const dom=new JSDOM('<main></main>',{url:'https://web.kocehind.web.id',runScripts:'outside-only'}),w=dom.window;
 w.__deps={api,esc:escape,date:x=>x,toast:()=>{},busy:(f,value)=>f.querySelectorAll('button[type="submit"]').forEach(b=>b.disabled=value),
  openDialog:(title,html)=>{const d=w.document.createElement('dialog');d.innerHTML=html;d.open=true;d.close=()=>{d.open=false;d.dispatchEvent(new w.Event('close'));d.remove();};w.document.body.append(d);return d;}};
 let source=await readFile(new URL(path,import.meta.url),'utf8');
 source=source.replace(/^import[^;]+;/gm,'const {api,openDialog,busy,esc,toast,date}=window.__deps;').replaceAll('export ','');
 w.eval(source+'\nwindow.moduleExports={'+(path.includes('/admin/')?'mountAccountsAdmin':'verifyEmailDialog,passwordResetDialog,mountAccountDeletion')+'};');
 return {dom,w,mod:w.moduleExports};
}
test('Email verification does not finish login until the code succeeds',async()=>{
 const calls=[];const {dom,w,mod}=await moduleUI('../shared/accounts.js',async(path,opts)=>{calls.push([path,opts]);return {user:{id:'owner'}};});
 const result=mod.verifyEmailDialog('opaque-challenge');const form=w.document.querySelector('form');
 form.querySelector('input').value='123456';form.dispatchEvent(new w.Event('submit',{cancelable:true}));
 assert.equal((await result).user.id,'owner');assert.equal(calls[0][0],'/web/auth/verify-email');
 assert.equal(calls[0][1].body.challenge,'opaque-challenge');dom.window.close();
});
test('Resend replaces the challenge used by the next verification',async()=>{
 const calls=[];const {dom,w,mod}=await moduleUI('../shared/accounts.js',async(path,opts)=>{calls.push([path,opts]);return path.includes('resend')?{challenge:'replacement',message:'Sent'}:{user:{id:'owner'}};});
 const result=mod.verifyEmailDialog('old');w.document.querySelector('#resend-code').click();await settle();
 w.document.querySelector('input').value='123456';w.document.querySelector('form').dispatchEvent(new w.Event('submit',{cancelable:true}));await result;
 assert.equal(calls[1][1].body.challenge,'replacement');dom.window.close();
});
test('Password reset requires matching passwords and uses the mailed challenge',async()=>{
 const calls=[];const {dom,w,mod}=await moduleUI('../shared/accounts.js',async(path,opts)=>{calls.push([path,opts]);return {ok:true};});
 const d=mod.passwordResetDialog('owner-recovery-token'),form=d.querySelector('#reset-confirm');
 form.querySelector('[name="code"]').value='123456';form.querySelector('[name="password"]').value='Longpassword123';form.querySelector('[name="confirmation"]').value='different';
 form.dispatchEvent(new w.Event('submit',{cancelable:true}));await settle();assert.equal(calls.length,0);
 form.querySelector('[name="confirmation"]').value='Longpassword123';form.dispatchEvent(new w.Event('submit',{cancelable:true}));await settle();
 assert.equal(calls[0][0],'/auth/password-reset/confirm');assert.equal(calls[0][1].body.challenge,'owner-recovery-token');dom.window.close();
});
test('Deletion is a two-step owner-confirmed request and retains a cancellable history',async()=>{
 const calls=[];const {dom,w,mod}=await moduleUI('../shared/accounts.js',async(path,opts={})=>{calls.push([path,opts]);if(path==='/account/security')return {has_password:true};if(path.endsWith('/code'))return {challenge:'delete-owner-token'};return {items:[]};});
 await mod.mountAccountDeletion(w.document.querySelector('main'));w.document.querySelector('#request-deletion').click();
 const form=w.document.querySelector('dialog form');form.querySelector('[name="password"]').value='Password123';form.querySelector('[name="reason"]').value='Ingin menutup akun';
 form.dispatchEvent(new w.Event('submit',{cancelable:true}));await settle();assert.equal(form.querySelector('#deletion-code-label').hidden,false);
 form.querySelector('[name="code"]').value='123456';form.dispatchEvent(new w.Event('submit',{cancelable:true}));await settle();
 const sent=calls.find(([p,o])=>p==='/account/deletion/requests'&&o.method==='POST');assert.equal(sent[1].body.challenge,'delete-owner-token');dom.window.close();
});
test('Admin email composer sends selected IDs and never exposes a credential',async()=>{
 const calls=[];const {dom,w,mod}=await moduleUI('../admin/accounts.js',async(path,opts={})=>{calls.push([path,opts]);if(path==='/admin/email/status')return {configured:true,transport:'Mailjet HTTPS API',port:443,from_email:'no-reply@example.com',counts:{}};if(path.includes('/admin/users?'))return {items:[{id:'target-user',username:'target',email:'target@example.com'}]};if(path==='/admin/content-safety/status')return {message:'Ready'};if(opts.method==='POST')return {id:'campaign',recipients:1};return {items:[]};});
 await mod.mountAccountsAdmin(w.document.querySelector('main'),()=>true);
 const search=w.document.querySelector('#find-recipient');search.querySelector('input').value='target';search.dispatchEvent(new w.Event('submit',{cancelable:true}));await settle();
 const checkbox=w.document.querySelector('[data-select]');checkbox.checked=true;checkbox.dispatchEvent(new w.Event('change'));
 const form=w.document.querySelector('#email-campaign');form.querySelector('[name="subject"]').value='Info aplikasi';form.querySelector('[name="body"]').value='Pembaruan terbaru tersedia.';form.querySelector('[name="confirmed"]').checked=true;
 form.dispatchEvent(new w.Event('submit',{cancelable:true}));await settle();
 const sent=calls.find(([p,o])=>p==='/admin/email/campaigns'&&o.method==='POST');assert.deepEqual([...sent[1].body.user_ids],['target-user']);assert.equal(sent[1].body.audience,'selected');assert.equal(sent[1].body.request_key.length,36);dom.window.close();
});
