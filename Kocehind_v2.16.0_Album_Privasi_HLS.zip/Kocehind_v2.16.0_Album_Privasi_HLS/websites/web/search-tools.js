export function recentSearches({api,user,storage=globalThis.localStorage}){
 const key='kocehind_recent_searches_guest';
 const clean=term=>String(term||'').trim().replace(/\s+/g,' ');
 const load=async()=>user()? (await api('/search/history')).items : JSON.parse(storage.getItem(key)||'[]').slice(0,6);
 return {load,
  async remember(value){const term=clean(value);if(!term||term.length>200)return load();
   if(user())return (await api('/search/history',{method:'POST',body:{term}})).items;
   const items=[term,...(await load()).filter(v=>v.toLocaleLowerCase()!==term.toLocaleLowerCase())].slice(0,6);storage.setItem(key,JSON.stringify(items));return items;},
  async remove(term){if(user())return (await api('/search/history'+(term===undefined?'':'?term='+encodeURIComponent(term)),{method:'DELETE'})).items;
   const items=term===undefined?[]:(await load()).filter(v=>v!==term);storage.setItem(key,JSON.stringify(items));return items;}
 };
}
export async function mountRecent(root,{history,esc,search,isCurrent=()=>true,toast}){
 try{
  const draw=items=>{if(!isCurrent()||!root.isConnected)return;
   root.innerHTML=items.length?`<div class="recent-heading"><h2>Riwayat pencarian</h2><button class="text-btn" data-clear>Hapus semua</button></div><ul class="recent-list">${items.slice(0,6).map((term,i)=>`<li><button data-search="${i}">◷ ${esc(term)}</button><button data-remove="${i}" aria-label="Hapus ${esc(term)}">×</button></li>`).join('')}</ul>`:'';
   root.querySelector('[data-clear]')?.addEventListener('click',()=>history.remove().then(draw).catch(e=>toast(e.message)));
   root.querySelectorAll('[data-remove]').forEach(b=>b.onclick=()=>history.remove(items[+b.dataset.remove]).then(draw).catch(e=>toast(e.message)));
   root.querySelectorAll('[data-search]').forEach(b=>b.onclick=()=>search(items[+b.dataset.search]));
  };draw(await history.load());
 }catch{/* Browsing/search remains available when history storage is unavailable. */}
}
export function mountInboxSearch(root,{api,esc,avatar,navigate,isCurrent=()=>true}){
 const holder=document.createElement('section');holder.className='inbox-search';
 holder.innerHTML='<label>Cari pesan atau akun<input type="search" maxlength="100" placeholder="Nama, username, atau isi pesan" aria-label="Cari pesan atau akun"></label><div class="inbox-search-results" aria-live="polite"></div>';
 root.prepend(holder);let timer,ticket=0,disposed=false;const input=holder.querySelector('input'),results=holder.querySelector('.inbox-search-results');
 async function search(){const id=++ticket,q=input.value.trim();if(!q){results.replaceChildren();return;}results.textContent='Mencari…';
  try{const data=await api('/inbox/search?q='+encodeURIComponent(q));if(disposed||id!==ticket||!isCurrent())return;
   const items=[...data.users.map(u=>({...u,body:'@'+u.username})),...data.messages];
   results.innerHTML=items.map((u,i)=>`<button class="user-row" data-result="${i}">${avatar(u)}<span><strong>${esc(u.name||u.username)}</strong><p>${esc(u.body)}</p></span></button>`).join('')||'<p>Pesan atau akun tidak ditemukan.</p>';
   results.querySelectorAll('[data-result]').forEach(b=>b.onclick=()=>navigate('/inbox?tab=messages&chat='+encodeURIComponent(items[+b.dataset.result].username)));
  }catch(e){if(!disposed&&id===ticket&&isCurrent())results.textContent=e.message;}
 }
 input.oninput=()=>{clearTimeout(timer);++ticket;timer=setTimeout(search,300);};
 return ()=>{disposed=true;++ticket;clearTimeout(timer);};
}
