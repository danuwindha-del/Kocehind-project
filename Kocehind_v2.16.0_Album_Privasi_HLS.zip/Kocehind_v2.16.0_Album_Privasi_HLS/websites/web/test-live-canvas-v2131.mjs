import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
const {JSDOM}=createRequire(import.meta.url)('jsdom');
const read=name=>readFile(new URL(name,import.meta.url),'utf8');
const data=s=>'data:text/javascript;base64,'+Buffer.from(s).toString('base64');
async function fixture(){
 const dom=new JSDOM('<div id="stage"></div>');globalThis.document=dom.window.document;
 const code=(await read('live-overlays.js')).replace(/^import .*;\n/gm,'');
 const helper=await import(data('const safeUrl=s=>s;\n'+code));
 const stage=document.querySelector('#stage');Object.defineProperties(stage,{clientWidth:{value:400},clientHeight:{value:800}});
 stage.getBoundingClientRect=()=>({width:400,height:800});
 return {dom,stage,...helper};
}
const item={id:'e1',kind:'text',x:.1,y:.2,width:.7,height:.2,text:'Halo <script>test</script>',color:'#FFFFFF',background:null,font_size:.05};
test('Plain text is safe, optional background is independent and viewing passes gestures through',async()=>{
 const f=await fixture();f.renderLiveOverlays(f.stage,{items:[item]});
 let node=f.stage.querySelector('.live-canvas-item');assert.equal(node.textContent,item.text);assert.equal(node.querySelector('script'),null);
 assert.equal(node.firstElementChild.style.backgroundColor,'transparent');assert.equal(node.firstElementChild.style.fontSize,'20px');assert.equal(node.onpointerdown,null);
 f.renderLiveOverlays(f.stage,{items:[{...item,background:'#2563EB'}]},{editable:true});
 node=f.stage.querySelector('.live-canvas-item');assert.equal(node.firstElementChild.style.backgroundColor,'rgb(37, 99, 235)');assert.equal(typeof node.onpointerdown,'function');
 f.dom.window.close();
});
test('Host drag clamps elements to stage bounds and emits only on release',async()=>{
 const f=await fixture(),moves=[];f.renderLiveOverlays(f.stage,{items:[item]},{editable:true,onMove:i=>moves.push(i)});
 const n=f.stage.querySelector('.live-canvas-item'),event={button:0,clientX:100,clientY:200,pointerId:1,preventDefault(){},stopPropagation(){}};
 n.onpointerdown(event);n.onpointermove({...event,clientX:9999,clientY:9999});assert.equal(moves.length,0);n.onpointerup({...event,type:'pointerup'});
 assert.equal(moves.length,1);assert(Math.abs(moves[0].x-.3)<1e-9);assert.equal(moves[0].y,.8);
 f.dom.window.close();
});
test('Shared images reuse the node and removing the item clears its layer',async()=>{
 const f=await fixture();const image={...item,kind:'image',text:'',image_url:'/live/rooms/r/overlays/e1/image'};
 f.renderLiveOverlays(f.stage,{items:[image]});const n=f.stage.querySelector('img');assert(n.src.endsWith('/image'));
 f.renderLiveOverlays(f.stage,{items:[image]});assert.equal(f.stage.querySelector('img'),n);
 f.renderLiveOverlays(f.stage,{items:[]});assert.equal(f.stage.querySelector('.live-canvas').children.length,0);f.dom.window.close();
});
test('All ordinary gifts are excluded from the animation queue, including malformed metadata',async()=>{
 const code=(await read('live-gifts.js')).replace(/^import .*;\n/gm,'');
 const {isExclusiveVideoGift}=await import(data(code));
 assert.equal(isExclusiveVideoGift({display_mode:'comment',exclusive_video:false,video_url:null}),false);
 assert.equal(isExclusiveVideoGift({display_mode:'exclusive_video',exclusive_video:true,video_url:'/mahkota.mp4'}),true);
 assert.equal(isExclusiveVideoGift({display_mode:'comment',exclusive_video:false,video_url:'/bad.mp4'}),false);
 assert.equal(isExclusiveVideoGift({video_url:'/bad.mp4'}),false);
});

test('Bring to front changes DOM stacking without replacing the video stage',async()=>{
 const f=await fixture(),a={...item,id:'a'},b={...item,id:'b'};
 f.renderLiveOverlays(f.stage,{items:[a,b]});
 const node=f.stage.querySelector('[data-overlay=a]');
 f.renderLiveOverlays(f.stage,{items:[b,a]});
 assert.equal(f.stage.querySelector('.live-canvas').lastElementChild,node);f.dom.window.close();
});
