import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {createRequire} from 'node:module';
const {chromium}=createRequire(import.meta.url)('playwright');
const sites=resolve(new URL('..',import.meta.url).pathname);
const viewer={id:'v',username:'viewer',name:'Viewer',legal_required:false};
const creator={id:'c',username:'creator',name:'Creator'};
const host={id:'h',username:'host',name:'Host',legal_required:false};
const people=[host,...Array.from({length:8},(_,i)=>({id:'g'+i,username:'guest'+i,name:'Guest '+i}))].map((m,i)=>({...m,role:i?'speaker':'host',connected:true}));
const sdk=`
export const RoomEvent={TrackSubscribed:'track',TrackUnsubscribed:'untrack',Disconnected:'disconnect',Reconnecting:'reconnecting',Reconnected:'connected'};
function participant(id){const track={attach(){const v=document.createElement('video');v.dataset.track=id;return v;},detach(v){return v?[v]:[];}};return {identity:id,isSpeaking:false,videoTrackPublications:new Map([['camera',{track,trackSid:id,isMuted:false}]]),async setCameraEnabled(){window.cameraCalls=(window.cameraCalls||0)+1;},async setMicrophoneEnabled(){},async unpublishTrack(){}};}
export class Room{constructor(){this.state='connected';this.localParticipant=participant(window.fixtureUser);this.remoteParticipants=new Map(${JSON.stringify(people)}.filter(p=>p.id!==window.fixtureUser).map(p=>[p.id,participant(p.id)]));}on(){return this;}async connect(){window.rtcConnects=(window.rtcConnects||0)+1;}async disconnect(){}async startAudio(){}}
`;

async function fixture(handle){
 const server=createServer(async(req,res)=>{
  try{
   const url=new URL(req.url,'http://fixture');
   if(url.pathname==='/shared/livekit.js'){res.writeHead(200,{'content-type':'text/javascript'});res.end(sdk);return;}
   if(url.pathname.startsWith('/api/')){
    let text='';for await(const part of req)text+=part;
    const result=await handle({path:url.pathname.slice(4),query:url.searchParams,method:req.method,body:text?JSON.parse(text):null,user:req.headers['x-fixture-user']||'v'});
    res.writeHead(Number.isInteger(result?.status)?result.status:200,{'content-type':'application/json'});res.end(JSON.stringify(result?.data??result??{}));return;
   }
   if(url.pathname.endsWith('.mp4')){res.writeHead(200,{'content-type':'video/mp4'});res.end();return;}
   const relative=url.pathname.startsWith('/shared/')?url.pathname.slice(1):/\.(js|css)$/.test(url.pathname)?'web'+url.pathname:'web/index.html';
   const path=resolve(sites,relative);if(!path.startsWith(sites+'/'))throw Error('path');
   const bytes=await readFile(path);res.writeHead(200,{'content-type':({'.js':'text/javascript','.css':'text/css','.html':'text/html'}[extname(path)]||'application/octet-stream')});res.end(bytes);
  }catch(e){res.writeHead(404);res.end('missing');}
 });
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 return {url:'http://127.0.0.1:'+server.address().port,close:()=>new Promise(r=>server.close(r))};
}
const launch=()=>chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE,args:['--no-sandbox']});

test('Follow preserves feed order, current video element, scroll and comment draft through privacy polling',async()=>{
 let followed=false,revoked=false,feeds=0;const calls=[];
 const posts=()=>['a','b','c'].map(id=>({id,kind:'video',caption:'Story '+id,media_url:'/fixture-'+id+'.mp4',thumbnail_url:'',author:creator,visibility:'public',following:followed,is_friend:false,relationship_label:followed?'Mengikuti':'Ikuti',likes:0,comments:0}));
 const f=await fixture(r=>{
  calls.push(r);
  if(r.path==='/users/me')return viewer;
  if(r.path==='/feed'){feeds++;return {items:posts(),next_cursor:null};}
  if(r.path==='/users/creator/follow'){followed=!followed;return {following:followed,is_friend:false,relationship_label:followed?'Mengikuti':'Ikuti'};}
  if(r.path==='/users/me/privacy')return {revision:revoked?'3':followed?'2':'1'};
  if(r.path==='/discovery/post-state')return {items:posts().filter(p=>!revoked||p.id!=='b'),unavailable_ids:revoked?['b']:[]};
  if(r.path.endsWith('/comments'))return {items:[],next_offset:null,total:0};
  if(r.path.endsWith('/like'))return {liked:true};
  return {items:[],next_offset:null,next_cursor:null};
 });
 const browser=await launch(),page=await browser.newPage({viewport:{width:420,height:850}}),errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{const interval=window.setInterval;window.setInterval=(fn,ms,...args)=>{if(ms===10000){window.privacyTick=fn;return interval(fn,600000,...args);}return interval(fn,ms,...args);};});
 try{
  await page.goto(f.url);await page.locator('.post[data-id=b]').waitFor();
  await page.evaluate(()=>window.privacyTick());
  await page.evaluate(()=>{const root=document.querySelector('#feed');root.scrollTop=root.clientHeight;window.savedVideo=document.querySelector('.post[data-id=b] video');});
  const card=page.locator('.post[data-id=b]');
  const before=await page.locator('#feed').evaluate(n=>n.scrollTop);
  await card.locator('[data-action=follow]').click();
  await card.getByText('Mengikuti',{exact:true}).waitFor();
  assert.equal(await page.evaluate(()=>savedVideo===document.querySelector('.post[data-id=b] video')),true);
  assert(Math.abs(await page.locator('#feed').evaluate(n=>n.scrollTop)-before)<2);
  await card.locator('[data-action=like]').click();
  assert(calls.some(c=>c.path==='/posts/b/like'));
  await card.locator('[data-action=comments]').click();
  await page.locator('.comment-form input').fill('Draft tetap di sini');
  const scroll=await page.locator('#feed').evaluate(n=>n.scrollTop);
  await page.evaluate(()=>window.privacyTick());
  assert.equal(await page.locator('.comment-form input').inputValue(),'Draft tetap di sini');
  assert.equal(await page.evaluate(()=>savedVideo===document.querySelector('.post[data-id=b] video')),true);
  assert(Math.abs(await page.locator('#feed').evaluate(n=>n.scrollTop)-scroll)<2);
  assert.equal(feeds,1);
  revoked=true;await page.evaluate(()=>window.privacyTick());
  assert.equal(await card.locator('video').count(),0);assert.equal(await page.locator('.post').count(),3);assert.equal(feeds,1);
  assert.deepEqual(errors,[]);
 }catch(error){console.log('PAGE ERRORS',errors);console.log('PAGE BODY',await page.locator('#content').innerText());throw error;}finally{await browser.close();await f.close();}
});

async function fits(page){
 const bounds=await page.locator('#live-stage').evaluate(stage=>{const outer=stage.getBoundingClientRect();return {outer:{x:outer.x,y:outer.y,right:outer.right,bottom:outer.bottom},tiles:[...stage.querySelectorAll('.live-tile,.empty-seat')].map(n=>{const b=n.getBoundingClientRect();return {x:b.x,y:b.y,right:b.right,bottom:b.bottom,width:b.width,height:b.height};})};});
 for(const b of bounds.tiles){assert(b.width>0&&b.height>0);assert(b.x>=bounds.outer.x-.5&&b.y>=bounds.outer.y-.5&&b.right<=bounds.outer.right+.5&&b.bottom<=bounds.outer.bottom+.5);}
}

test('Shared LIVE grid/focus/moves and camera one/eight guest control retain the host media connection',async()=>{
 let info={id:'room',title:'Shared stage',host,mode:'camera',together:true,seats:9,camera_guest_limit:8,status:'active',likes:0,viewers:8,members:structuredClone(people),layout:{version:0,slots:people.map(p=>p.id),focus_id:null}};
 const f=await fixture(r=>{
  const own=r.user==='h'?host:viewer,room=()=>({...structuredClone(info),role:r.user==='h'?'host':'viewer',can_manage_layout:r.user==='h',capabilities:{}});
  if(r.path==='/users/me')return own;
  if(r.path.endsWith('/join'))return {url:'wss://fixture',token:'fixture',role:r.user==='h'?'host':'viewer',room:room()};
  if(r.path.endsWith('/heartbeat')||r.path==='/live/rooms/room')return room();
  if(r.path.endsWith('/comments'))return {items:[],cursor:0};
  if(r.path.endsWith('/layout')&&r.method==='PUT'){
   const {action,user_id,slot}=r.body;
   if(action==='swap'){const i=info.layout.slots.indexOf(user_id);[info.layout.slots[i],info.layout.slots[slot]]=[info.layout.slots[slot],info.layout.slots[i]];}
   if(action==='focus')info.layout.focus_id=user_id;
   if(action==='reset'){info.layout.slots=people.map(p=>p.id);info.layout.focus_id=null;}
   info.layout.version++;return room();
  }
  if(r.path.endsWith('/camera-seats')){
   info.seats=r.body.guest_limit+1;info.camera_guest_limit=r.body.guest_limit;
   if(info.seats===2){const kept=r.body.keep_user_id;for(const m of info.members)if(m.id!=='h'&&m.id!==kept)m.role='viewer';info.layout.slots=['h',kept];}
   info.layout.focus_id=null;info.layout.version++;return room();
  }
  if(r.path==='/users/me/privacy')return {revision:'fixed'};
  return {items:[],next_cursor:null,next_offset:null};
 });
 const browser=await launch(),page=await browser.newPage({viewport:{width:420,height:850}}),watch=await browser.newPage({viewport:{width:390,height:844}}),errors=[];
 for(const [p,id]of [[page,'h'],[watch,'v']]){await p.setExtraHTTPHeaders({'x-fixture-user':id});await p.addInitScript(user=>window.fixtureUser=user,id);p.on('pageerror',e=>errors.push(e.message));}
 try{
  await page.goto(f.url+'/live/room');await page.waitForSelector('.live-tile video',{timeout:6000});assert.equal(await page.locator('.live-tile video').count(),9);await fits(page);
  await watch.goto(f.url+'/live/room');await watch.waitForFunction(()=>document.querySelectorAll('.live-tile video').length===9);
  assert.equal(await watch.locator('#live-layout').isHidden(),true);
  await page.evaluate(()=>window.hostVideo=document.querySelector('[data-person=h] video'));
  await page.locator('#live-layout').click();let dialog=page.locator('dialog:has([name=layout-person])');
  await dialog.locator('select').selectOption('g2');await dialog.locator('[data-slot="0"]').click();
  await page.waitForFunction(()=>!document.querySelector('dialog[open]'));await fits(page);
  await page.locator('#live-layout').click();dialog=page.locator('dialog:has([name=layout-person])');
  await dialog.locator('select').selectOption('g2');await dialog.locator('[data-focus]').click();
  await page.waitForFunction(()=>!document.querySelector('dialog[open]'));await fits(page);
  await watch.waitForFunction(()=>document.querySelector('[data-person=g2]')?.style.gridColumn==='1 / -1');
  await page.locator('#live-layout').click();await page.locator('dialog [data-unfocus]').click();await page.waitForFunction(()=>!document.querySelector('dialog[open]'));
  await page.locator('#live-layout').click();dialog=page.locator('dialog:has([name=layout-person])');
  await dialog.locator('select').selectOption('g2');await dialog.locator('[data-capacity="1"]').click();await page.locator('dialog [data-confirm]').click();
  await page.waitForFunction(()=>document.querySelectorAll('.live-tile').length===2);await fits(page);
  await watch.waitForFunction(()=>document.querySelectorAll('.live-tile').length===2);await fits(watch);
  const stage=await page.locator('#live-stage').boundingBox(),tile=await page.locator('[data-person=h]').boundingBox();assert(tile.height>stage.height*.45);
  await page.setViewportSize({width:1280,height:900});await fits(page);
  assert.equal(await page.locator('[data-person=h] video').evaluate(v=>getComputedStyle(v).objectFit),'cover');
  await page.locator('#live-layout').click();await page.locator('dialog [data-capacity="8"]').click();await page.waitForFunction(()=>document.querySelectorAll('.empty-seat').length===7);await fits(page);
  assert.equal(await page.evaluate(()=>window.rtcConnects),1);
  assert.equal(await page.evaluate(()=>hostVideo===document.querySelector('[data-person=h] video')),true);
  assert.deepEqual(errors,[]);
 }catch(error){console.log('PAGE ERRORS',errors);console.log('PAGE BODY',await page.locator('#content').innerText());throw error;}finally{await browser.close();await f.close();}
});
