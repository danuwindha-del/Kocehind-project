import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
const {JSDOM}=createRequire(import.meta.url)('jsdom');
const moduleURL=s=>'data:text/javascript;base64,'+Buffer.from(s).toString('base64');
const settle=()=>new Promise(r=>setTimeout(r,15));
async function ui(file){
 const dom=new JSDOM('<main id="root"></main>',{url:'https://admin.kocehind.web.id'});
 dom.window.HTMLMediaElement.prototype.pause=function(){};dom.window.HTMLMediaElement.prototype.load=function(){};
 for(const key of ['window','document','FormData','Event'])globalThis[key]=dom.window[key];
 const content=moduleURL(await readFile(new URL('../shared/official-content.js',import.meta.url),'utf8'));
 const helper=moduleURL(`export const api=(...args)=>globalThis.uiApi(...args);export const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));export const badge=()=>'';export const date=v=>String(v||'');export const count=v=>String(v||0);export const toast=()=>{};export const safeUrl=v=>v;export const busy=(f,b)=>f.querySelectorAll('button[type=submit]').forEach(x=>x.disabled=b);export function openDialog(title,html){const d=document.createElement('dialog');d.innerHTML='<h2>'+esc(title)+'</h2>'+html;document.body.append(d);d.close=()=>d.remove();return d;}`);
 const source=(await readFile(new URL(file,import.meta.url),'utf8')).replace(/from ['"]\/shared\/api\.js[^'"]*['"]/g,'from '+JSON.stringify(helper)).replace(/from ['"]\/shared\/official-content\.js[^'"]*['"]/g,'from '+JSON.stringify(content));
 return {dom,root:document.querySelector('#root'),module:await import(moduleURL(source))};
}

test('Admin composer sends structured blocks, chosen recipients and UTC schedule',async()=>{
 const {dom,root,module}=await ui('../admin/growth.js');let sent;
 globalThis.uiApi=async(path,options={})=>{
  if(path.startsWith('/admin/users'))return {items:[{id:'user-1',username:'kreator',name:'Kreator'}]};
  if(options.method==='POST'){sent=options.body;return {id:'new',version:1};}
  return {items:[],next_offset:null};
 };
 await module.mountAnnouncements(root);root.querySelector('[data-create]').click();
 const form=document.querySelector('dialog form');
 form.elements.namedItem('title').value='Promosi <script>literal</script>';
 form.querySelector('[data-field=text]').value='Halo kreator';
 document.querySelector('[data-add-block=link]').click();
 form.querySelector('[data-block-index="1"] [data-field=text]').value='Buka promosi';
 form.querySelector('[data-field=url]').value='https://kocehind.web.id/about';
 form.elements.namedItem('audience').value='selected';form.elements.namedItem('audience').dispatchEvent(new Event('change'));
 form.querySelector('[data-find-user]').click();await settle();form.querySelector('[data-select-user]').click();
 form.elements.namedItem('starts_at').value='2027-01-01T09:30';
 form.dispatchEvent(new Event('submit',{cancelable:true}));await settle();
 assert.deepEqual(sent.user_ids,['user-1']);assert.equal(sent.blocks[0].text,'Halo kreator');
 assert.equal(sent.blocks[1].type,'link');assert.match(sent.starts_at,/Z$/);
 assert.equal(document.querySelector('script'),null);dom.window.close();
});

test('Admin priority selects an eligible video, bounds duration and supports early stop',async()=>{
 const {dom,root,module}=await ui('../admin/growth.js');const calls=[];
 globalThis.uiApi=async(path,options={})=>{
  calls.push({path,...options});
  if(path.startsWith('/admin/posts'))return {items:[{id:'video-1',kind:'video',visibility:'public',moderation_status:'approved',caption:'Cerita',thumbnail_url:'https://example.com/cover.jpg',author:{username:'kreator'}}]};
  if(options.method==='POST')return {};
  return {items:[{id:'priority-1',target_type:'post',title:'Cerita',username:'kreator',intensity:3,status:'active',starts_at:'2026-10-23',ends_at:'2026-10-24'}],next_offset:null};
 };
 await module.mountPromotions(root);root.querySelector('[data-create-priority]').click();
 const f=document.querySelector('dialog form');assert.equal(f.elements.namedItem('duration_days').max,'7');
 f.querySelector('[data-find]').click();await settle();f.querySelector('[data-choose]').click();
 f.elements.namedItem('duration_days').value='7';f.elements.namedItem('intensity').value='5';f.elements.namedItem('reason').value='Pilihan tim Kocehind';
 f.dispatchEvent(new Event('submit',{cancelable:true}));await settle();
 const created=calls.find(c=>c.path==='/admin/promotions'&&c.method==='POST');
 assert.equal(created.body.target_id,'video-1');assert.equal(created.body.duration_days,7);assert.equal(created.body.intensity,5);
 root.querySelector('[data-stop]').click();const stop=document.querySelector('dialog form');stop.elements.namedItem('reason').value='Program selesai lebih awal';stop.dispatchEvent(new Event('submit',{cancelable:true}));await settle();
 assert(calls.some(c=>c.path==='/admin/promotions/priority-1/stop'&&c.body.reason==='Program selesai lebih awal'));dom.window.close();
});

test('Official activity detail marks read only after authorized detail loads',async()=>{
 const {dom,root,module}=await ui('./official.js');const paths=[];
 globalThis.uiApi=async(path,options={})=>{paths.push({path,method:options.method||'GET'});return {id:'a1',title:'Kabar',category:'information',summary:'Ringkasan',published_at:'2026-10-23',blocks:[{type:'text',text:'<script>literal</script>'}]};};
 await module.mountOfficial(root,'a1',()=>{});
 assert.deepEqual(paths.map(p=>p.method),['GET','POST']);assert.equal(root.querySelector('script'),null);assert.match(root.textContent,/<script>literal/);dom.window.close();
});

for(const failure of ['transport',403,404,'codec'])test('Official media error is classified and retries scoped detail: '+failure,async()=>{
 const {dom,root,module}=await ui('./official.js');let recovered=false,details=0;
 globalThis.fetch=async(_url,options)=>{assert.equal(options.method,'HEAD');if(failure==='transport')throw new TypeError('Failed to fetch');return {ok:failure==='codec',status:failure==='codec'?200:failure};};
 globalThis.uiApi=async(path)=>{if(!path.endsWith('/read'))details++;return {id:'media',title:'Kabar',category:'information',blocks:[{type:failure==='codec'?'video':'image',media_url:'https://api.kocehind.web.id/official/activities/media/media/0?token='+(recovered?'fresh':'old')}]};};
 const dispose=await module.mountOfficial(root,'media',()=>{});root.querySelector('img,video').dispatchEvent(new Event('error'));await settle();
 const expected=failure==='transport'?'Anda sedang Offline periksa jaringan Anda':failure==='codec'?'Media belum dapat ditampilkan. Format atau codec tidak didukung.':'Media tidak tersedia (HTTP '+failure+').';
 assert.match(root.textContent,new RegExp(expected.replace(/[().]/g,'\\$&')));recovered=true;root.querySelector('[data-media-retry]').click();await settle();assert.equal(details,2);assert.match(root.querySelector('img,video').src,/fresh$/);dispose?.();dom.window.close();
});
test('Official media ignores late probe and retry results after navigation and aborts bounded probe',async()=>{
 const {dom,root,module}=await ui('./official.js');let resolveProbe,signal,current=true;
 globalThis.fetch=(_u,o)=>{signal=o.signal;return new Promise(r=>resolveProbe=r);};
 globalThis.uiApi=async()=>({id:'a',title:'A',category:'information',blocks:[{type:'image',media_url:'https://api.kocehind.web.id/official/activities/a/media/0?token=old'}]});
 const dispose=await module.mountOfficial(root,'a',()=>{},()=>current);root.querySelector('img').dispatchEvent(new Event('error'));await settle();current=false;dispose?.();resolveProbe({ok:false,status:403});await settle();assert.equal(signal.aborted,true);assert(!root.textContent.includes('HTTP 403'));dom.window.close();
});

test('Official media transport timeout aborts its request and uses the exact offline copy',async()=>{
 const {dom,root}=await ui('./official.js');const content=await import(moduleURL(await readFile(new URL('../shared/official-content.js',import.meta.url),'utf8')));let signal;
 root.innerHTML=content.officialBlocksHTML([{type:'image',media_url:'https://api.kocehind.web.id/official/activities/a/media/0?token=slow'}]);
 const dispose=content.bindOfficialMedia(root,{timeoutMs:5,refresh:async()=>({}),probe:(_u,o)=>{signal=o.signal;return new Promise(()=>{});}});
 root.querySelector('img').dispatchEvent(new Event('error'));await settle();assert(signal.aborted);assert.match(root.textContent,/Anda sedang Offline periksa jaringan Anda/);assert(!root.querySelector('[data-media-retry]').disabled);dispose();dom.window.close();
});
test('Official media retry preserves detail authorization errors and ignores a later stale detail',async()=>{
 const {dom,root,module}=await ui('./official.js');let rejectDetail=false,late=false,resolveDetail,current=true;
 globalThis.fetch=async()=>({ok:false,status:404});
 const item={id:'a',title:'A',category:'information',blocks:[{type:'image',media_url:'https://api.kocehind.web.id/official/activities/a/media/0?token=old'}]};
 globalThis.uiApi=async path=>{if(path.endsWith('/read'))return {};if(rejectDetail)throw Object.assign(new Error('Media telah ditarik'),{status:404});if(late)return new Promise(r=>resolveDetail=r);return item;};
 const dispose=await module.mountOfficial(root,'a',()=>{},()=>current);
 root.querySelector('img').dispatchEvent(new Event('error'));await settle();rejectDetail=true;root.querySelector('[data-media-retry]').click();await settle();assert.match(root.textContent,/Media telah ditarik/);
 rejectDetail=false;late=true;root.querySelector('[data-media-retry]').click();await settle();current=false;dispose();root.innerHTML='<p>Halaman baru</p>';resolveDetail({...item,blocks:[{type:'image',media_url:'https://api.kocehind.web.id/official/activities/a/media/0?token=fresh'}]});await settle();assert.equal(root.textContent,'Halaman baru');dom.window.close();
});

test('Admin footer shows the installed release',async()=>{
 const dom=new JSDOM(await readFile(new URL('../admin/index.html',import.meta.url),'utf8'));
 assert.match(dom.window.document.querySelector('footer').textContent,/Versi 2\.15\.0 · Indonesia/);dom.window.close();
});
