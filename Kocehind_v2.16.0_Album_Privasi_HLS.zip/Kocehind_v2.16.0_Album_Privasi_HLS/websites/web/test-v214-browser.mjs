// Real-browser flows with isolated HTTP fixtures, never production credentials.
import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile,mkdir} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {createRequire} from 'node:module';
const {chromium}=createRequire(import.meta.url)('playwright');
const sites=resolve(new URL('..',import.meta.url).pathname);
const owner={id:'00000000-0000-4000-8000-000000000001',username:'admin',name:'Administrator',is_admin:true,legal_required:false};
const target={id:'00000000-0000-4000-8000-000000000002',username:'receiver',name:'Penerima',coins:0,coin_debt:0};
const sender={id:'00000000-0000-4000-8000-000000000003',username:'sender',name:'Pengirim',coins:1000,coin_debt:0};
const qa=process.env.KOCEHIND_QA_DIR||'/tmp/kocehind-qa-v214';

async function scenario(site,path,handler,run){
 const calls=[],server=createServer(async(req,res)=>{
  try{
   const url=new URL(req.url,'http://fixture');
   if(url.pathname.startsWith('/api/')){
    let text='';for await(const part of req)text+=part;
    const call={path:url.pathname.slice(4),query:url.searchParams,method:req.method,body:text?JSON.parse(text):null};calls.push(call);
    let data=await handler(call);
    if(data===undefined){
     if(call.path==='/users/me'||call.path==='/admin/me')data=owner;
     else if(call.path==='/admin/wallet')data={income_per_coin:50,minimum_withdrawal:50000,packages:[]};
     else if(call.path==='/users/me/privacy')data={revision:'test'};
     else data={items:[],next_offset:null,unread:0};
    }
    res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(data));return;
   }
   const relative=url.pathname.startsWith('/shared/')?url.pathname.slice(1):/\.(js|css|png)$/.test(url.pathname)?site+url.pathname:site+'/index.html';
   const file=resolve(sites,relative);if(!file.startsWith(sites+'/'))throw new Error('Outside fixture');
   res.writeHead(200,{'content-type':({'.js':'text/javascript','.css':'text/css','.html':'text/html','.png':'image/png'}[extname(file)]||'application/octet-stream')});res.end(await readFile(file));
  }catch{res.writeHead(404);res.end('missing');}
 });
 await new Promise(done=>server.listen(0,'127.0.0.1',done));
 const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:390,height:844}}),errors=[];
 page.on('pageerror',error=>errors.push(error.message));
 try{await page.goto('http://127.0.0.1:'+server.address().port+path);await run(page,calls);assert.deepEqual(errors,[]);}
 finally{await browser.close();await new Promise(done=>server.close(done));}
}

test('Finance admin credits, debits and transfers coins with account identities and reasons',async()=>{
 let balance=0;const operations=[];
 await scenario('admin','/#wallet',call=>{
  if(call.path==='/admin/wallet/users')return {items:call.query.get('exact')==='true'?[sender]:[{...target,coins:balance}],next_offset:null};
  if(call.path==='/admin/wallet/coins'){
   operations.push(call.body);balance+=call.body.action==='debit'?-call.body.amount:call.body.amount;
   return {id:'operation-'+operations.length,...call.body};
  }
 },async page=>{
  for(const [action,amount] of [['credit',125],['debit',25],['transfer',50]]){
   await page.getByRole('button',{name:'Kelola koin',exact:true}).click();
   const form=page.locator('dialog form');await form.locator('[name=action]').selectOption(action);
   if(action==='transfer')await form.locator('[name=source_username]').fill('sender');
   await form.locator('[name=amount]').fill(String(amount));await form.locator('[name=reason]').fill('Pengujian perubahan koin terisolasi');
   await form.locator('[type=submit]').click();await page.locator('dialog').waitFor({state:'detached'});
   await page.waitForFunction(expected=>document.querySelector('[data-coin-users]')?.textContent.includes(String(expected)),balance);
  }
  assert.equal(operations.length,3);assert.equal(balance,150);
  assert(operations.every(op=>op.target_user_id===target.id&&op.reason&&/^[a-f0-9-]{36}$/.test(op.request_key)));
  assert.equal(operations[2].source_user_id,sender.id);
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
  await mkdir(qa,{recursive:true});await page.screenshot({path:qa+'/admin-coins-phone.png',fullPage:true});
 });
});

test('Official activity handles malformed success and recovers within the inbox',async()=>{
 let attempts=0;
 await scenario('web','/inbox?tab=official',call=>{
  if(call.path==='/official/activities')return ++attempts===1?{}:{items:[{id:'notice1',category:'information',title:'Informasi Kocehind',summary:'Aktivitas berhasil dimuat',published_at:'2026-10-30T00:00:00Z',read:false}],next_offset:null,unread:1};
 },async page=>{
  await page.locator('[data-official-retry]').waitFor();
  assert(!((await page.locator('#content').textContent()).includes('Cannot read')));
  await page.locator('[data-official-retry]').click();await page.locator('[data-official=notice1]').waitFor();
  assert.equal(attempts,2);assert.equal(await page.locator('[data-official-retry]').count(),0);
  await mkdir(qa,{recursive:true});await page.screenshot({path:qa+'/official-inbox-phone.png',fullPage:true});
 });
});
