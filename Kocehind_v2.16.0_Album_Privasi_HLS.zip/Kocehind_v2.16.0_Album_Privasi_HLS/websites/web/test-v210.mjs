import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
const {JSDOM}=createRequire(import.meta.url)('jsdom');
const moduleURL=s=>'data:text/javascript;base64,'+Buffer.from(s).toString('base64');

test('Network failures use offline copy while HTTP failures retain their response',async()=>{
 const source=await readFile(new URL('../shared/network.js',import.meta.url),'utf8');
 const {networkFetch,OFFLINE_MESSAGE}=await import(moduleURL(source));
 await assert.rejects(networkFetch('/api/feed',{},async()=>{throw new TypeError('Failed to fetch');}),error=>error.message===OFFLINE_MESSAGE&&error.status===0);
 const response={ok:false,status:503};
 assert.equal(await networkFetch('/api/feed',{},async()=>response),response);
});

test('Official structured content escapes text and refuses executable links',async()=>{
 const source=await readFile(new URL('../shared/official-content.js',import.meta.url),'utf8');
 const {officialBlocksHTML}=await import(moduleURL(source));
 const dom=new JSDOM('<main></main>');
 dom.window.document.querySelector('main').innerHTML=officialBlocksHTML([
  {type:'heading',text:'<img src=x onerror=bad()>'},
  {type:'text',text:'<script>bad()</script>'},
  {type:'link',text:'Bad',url:'javascript:alert(1)'},
  {type:'image',media_url:'https://example.com/photo.jpg',alt:'" onerror="bad()'},
  {type:'video',media_url:'https://example.com/clip.mp4',thumbnail_url:'https://example.com/cover.jpg'},
  {type:'link',text:'Buka',url:'https://kocehind.web.id/about'}
 ]);
 const root=dom.window.document;
 assert.equal(root.querySelector('script'),null);
 assert.equal(root.querySelector('[onerror]'),null);
 assert.equal(root.querySelector('a[href^="javascript"]'),null);
 assert.equal(root.querySelectorAll('video[controls]').length,1);
 assert.equal(root.querySelector('a').getAttribute('rel'),'noopener noreferrer');
 dom.window.close();
});

test('History continuation uses snapshot cursor and avoids duplicate items',async()=>{
 const source=await readFile(new URL('./v27.js',import.meta.url),'utf8');
 const {createHistoryController}=await import(moduleURL(source));
 const paths=[];
 const state=createHistoryController(async path=>{
  paths.push(path);
  return paths.length===1?{items:[{post:{id:'a'}}],next_offset:1,next_cursor:'snap:1',total:2}
   :{items:[{post:{id:'a'}},{post:{id:'b'}}],next_offset:null,next_cursor:null,total:2};
 });
 await state.load();await state.load(true);
 assert.match(paths[1],/cursor=snap%3A1/);
 assert.deepEqual(state.items.map(r=>r.post.id),['a','b']);
});
