import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
const {JSDOM}=createRequire(import.meta.url)('jsdom');
const source=await readFile(new URL('../shared/official-content.js',import.meta.url),'utf8');
const content=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
const settle=()=>new Promise(resolve=>setTimeout(resolve,10));
const query='?token=a%2Fb%2Bz%3D&thumbnail=true&nonce=x%20y&nonce=two';
async function media(origin,input,result=200){
 const dom=new JSDOM('<main></main>',{url:origin});globalThis.document=dom.window.document;const root=document.querySelector('main'),calls=[];
 globalThis.fetch=async(input,options)=>{calls.push({input:String(input),options});if(result==='transport')throw new TypeError('Failed to fetch');return {ok:result<400,status:result};};
 root.innerHTML=content.officialBlocksHTML([{type:'image',media_url:input}]);
 const dispose=content.bindOfficialMedia(root,{refresh:async()=>({})});
 root.querySelector('img').dispatchEvent(new dom.window.Event('error'));await settle();
 return {dom,root,calls,dispose};
}
for(const origin of ['https://web.kocehind.web.id','https://admin.kocehind.web.id']){
 for(const path of ['/official/activities/notice-1/media/0','/media/uploads/pending.jpg']){
  for(const status of [200,403,404,'transport'])test(`Default HEAD uses ${origin} proxy for ${path}, ${status}`,async()=>{
   const {dom,root,calls,dispose}=await media(origin,'https://api.kocehind.web.id'+path+query,status);
   assert.equal(calls.length,1);const request=new URL(calls[0].input,origin);
   assert.equal(request.origin,origin);assert.equal(request.pathname,'/api'+path);assert.equal(request.search,query);
   assert.equal(calls[0].options.method,'HEAD');assert.equal(calls[0].options.credentials,'same-origin');
   const expected=status==='transport'?'Anda sedang Offline periksa jaringan Anda':status===200?'Media belum dapat ditampilkan. Format atau codec tidak didukung.':`Media tidak tersedia (HTTP ${status}).`;
   assert.equal(root.querySelector('[role=status] p').textContent,expected);dispose();dom.window.close();
  });
 }
 for(const host of ['https://evil.example','https://api.kocehind.web.id.evil.example','https://api.kocehind.web.id:8443'])test(`Untrusted media origin is not probed or proxied on ${origin}: ${host}`,async()=>{
  const {dom,root,calls,dispose}=await media(origin,host+'/official/activities/notice-1/media/0'+query);
  assert.equal(calls.length,0);assert.equal(root.querySelector('[role=status] p').textContent,'Sumber media tidak didukung.');dispose();dom.window.close();
 });
}
for(const [origin,input,expected] of [
 ['http://localhost:8080','http://localhost:8000/media/pending.jpg','/api/media/pending.jpg'],
 ['http://127.0.0.1:8080','http://127.0.0.1:8000/official/activities/local/media/0','/api/official/activities/local/media/0'],
 ['https://web.kocehind.web.id','https://web.kocehind.web.id/api/media/pending.jpg','/api/media/pending.jpg'],
 ['https://admin.kocehind.web.id','https://admin.kocehind.web.id/media/pending.jpg','/api/media/pending.jpg']
])test('Known local/same-origin backend media shape: '+input,async()=>{
 const {dom,calls,dispose}=await media(origin,input+query);assert.equal(calls.length,1);const request=new URL(calls[0].input,origin);assert.equal(request.origin,origin);assert.equal(request.pathname,expected);assert.equal(request.search,query);dispose();dom.window.close();
});
test('A production page never proxies a loopback or unrelated backend path',async()=>{
 for(const input of ['http://localhost:8000/media/file.jpg','https://api.kocehind.web.id/admin/users','https://api.kocehind.web.id/official/activities/notice-1']){
  const {dom,calls,root,dispose}=await media('https://admin.kocehind.web.id',input+query);assert.equal(calls.length,0);assert.equal(root.querySelector('[role=status] p').textContent,'Sumber media tidak didukung.');dispose();dom.window.close();
 }
});
