import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';

const source=await readFile(new URL('./v27.js',import.meta.url),'utf8');
const feature=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));

test('a mounted playback keeps its ID across cumulative reports and retries; reopen gets a new ID',()=>{
 let sequence=0;const id=()=>`playback-${++sequence}`;
 const first=feature.createPlaybackSignals(id),reopened=feature.createPlaybackSignals(id);
 assert.deepEqual(first({watch_ms:1000}),{watch_ms:1000,playback_id:'playback-1'});
 assert.equal(first({watch_ms:2000}).playback_id,'playback-1');
 assert.equal(first({watch_ms:2000}).playback_id,'playback-1');
 assert.equal(reopened({watch_ms:1000}).playback_id,'playback-2');
});

test('resolved mentions are clickable and escaped; unknown names stay plain',()=>{
 const html=feature.richText('<img src=x> @alice @missing #cerita', [{id:'a',username:'alice'}]);
 assert.match(html,/&lt;img src=x&gt;/);
 assert.match(html,/class="mention" href="\/@alice" data-link>@alice<\/a>/);
 assert.doesNotMatch(html,/href="\/@missing/);
 assert.match(html,/href="\/hashtag\/cerita"/);
 assert.match(feature.richText('@ALICE',[{username:'alice'}]),/href="\/@alice"/);
 assert.match(feature.richText('Hi @alice.',[{username:'alice'}]),/>@alice<\/a>\./);
 assert.equal(feature.richText('mail@alice.com', [{username:'alice'}]),'mail@alice.com');
});

test('history removes selected post IDs, then all, without touching posts or views',async()=>{
 const calls=[];
 const api=async(path,options={})=>{calls.push({path,...options});return options.method==='DELETE'?{deleted:1}:{items:[{id:'history-row',post:{id:'post-1'}}],next_offset:null,total:1};};
 const history=feature.createHistoryController(api);
 await history.load();history.selected.add('post-1');await history.remove(false);
 assert.deepEqual(calls[1],{path:'/users/me/history',method:'DELETE',body:{ids:['post-1'],all:false}});
 await history.remove(true);
 assert.deepEqual(calls.at(-1),{path:'/users/me/history',method:'DELETE',body:{all:true}});
 assert.ok(calls.every(c=>c.path.startsWith('/users/me/history')));
});

test('comment notification resolves the complete target thread beyond page one',async()=>{
 const calls=[];
 const r=await feature.loadCommentTarget(async(path)=>{calls.push(path);return {comment:{id:'reply'},thread:[{id:'root'},{id:'reply'}],root_id:'root'};},'post','reply');
 assert.equal(calls[0],'/posts/post/comments/target/reply');
 assert.deepEqual(r.thread.map(c=>c.id),['root','reply']);
 const missing=await feature.loadCommentTarget(async()=>{throw Object.assign(Error('deleted'),{status:404});},'post','deleted');
 assert.equal(missing,null);
 await assert.rejects(feature.loadCommentTarget(async()=>{throw Object.assign(Error('offline'),{status:503});},'post','reply'));
});

test('clip bounds reject invalid and expired requests before sending',async()=>{
 const recording={status:'ready',duration_seconds:120,expires_at:'2099-01-01T00:00:00Z'};
 let calls=0;const api=async()=>{calls++;return {id:'clip',status:'queued'};};
 for(const bounds of [[-1,5],[10,10],[30,20],[0,121],[NaN,10],[0,0]])await assert.rejects(feature.queueClip(api,'room',recording,...bounds));
 await assert.rejects(feature.queueClip(api,'room',{...recording,expires_at:'2000-01-01T00:00:00Z'},0,10));
 await assert.rejects(feature.queueClip(api,'room',{...recording,duration_seconds:900},0,601));
 assert.equal(calls,0);
 const queued=await feature.queueClip(api,'room',recording,5,25);assert.equal(queued.status,'queued');assert.equal(calls,1);
});

test('ready clip publishes through existing posts API and carries visibility',async()=>{
 let call;
 await feature.publishClip(async(path,options)=>{call={path,...options};return {id:'post'};},{id:'clip',status:'ready',media_url:'/media/clip.mp4',thumbnail_url:'/media/clip.jpg'},'Cerita @alice','friends');
 assert.equal(call.path,'/posts');assert.equal(call.method,'POST');
 assert.deepEqual(call.body,{kind:'video',media_url:'/media/clip.mp4',thumbnail_url:'/media/clip.jpg',caption:'Cerita @alice',visibility:'friends'});
 await assert.rejects(feature.publishClip(async()=>assert.fail('must not send'),{status:'queued'},'','public'));
});

test('queued clips refresh while processing and stop after terminal status',async()=>{
 let step=0,painted=[];const callbacks=new Map();let timer=0;
 const stop=feature.watchClips(async()=>({items:[{id:'clip',status:step++?'ready':'queued'}]}),rows=>painted.push(rows[0].status),{setInterval:fn=>{callbacks.set(++timer,fn);return timer;},clearInterval:id=>callbacks.delete(id)});
 await stop.refresh();assert.deepEqual(painted,['queued']);
 await [...callbacks.values()][0]();assert.deepEqual(painted,['queued','ready']);assert.equal(callbacks.size,0);stop();
});

test('a clip queued during an in-flight refresh is re-read and starts polling',async()=>{
 let finish,calls=0,paints=[];const timers=new Set();
 const first=new Promise(resolve=>finish=resolve);
 const stop=feature.watchClips(async()=>++calls===1?first:{items:[{id:'new-clip',status:'queued'}]},items=>paints.push(items.length),{setInterval:()=>{timers.add(1);return 1;},clearInterval:id=>timers.delete(id)});
 const initial=stop.refresh();await stop.refresh();finish({items:[]});await initial;
 assert.equal(calls,2);assert.deepEqual(paints,[0,1]);assert.equal(timers.size,1);stop();
});

test('all APK controls point at binary after successful probe',async()=>{
 const downloadSource=await readFile(new URL('../main/download.js',import.meta.url),'utf8');
 const {applyApkAvailability}=await import('data:text/javascript;base64,'+Buffer.from(downloadSource).toString('base64'));
 const links=Array.from({length:3},()=>({attrs:{href:'#unduh'},setAttribute(k,v){this.attrs[k]=v;},removeAttribute(k){delete this.attrs[k];}}));
 assert.equal(applyApkAvailability(links,{ok:true,headers:{get:()=> 'application/octet-stream'}}),true);
 for(const link of links){assert.equal(link.attrs.href,'/downloads/Kocehind.apk');assert.equal(link.attrs.download,'Kocehind.apk');assert.equal(link.attrs['aria-disabled'],'false');}
 assert.equal(applyApkAvailability(links,{ok:true,headers:{get:()=> 'text/html'}}),false);
 assert.equal(applyApkAvailability(links,{ok:false,headers:{get:()=> 'application/octet-stream'}}),false);
});
