// DOM regression tests; useful in CI environments which cannot open Chromium sockets.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
const {JSDOM}=createRequire(import.meta.url)('jsdom');
const moduleURL=source=>'data:text/javascript;base64,'+Buffer.from(source).toString('base64');
const helper=moduleURL(`export const api=(...a)=>globalThis.trustApi(a[0].split('?')[0],...a.slice(1));export const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));export const date=v=>String(v??'');export const toast=()=>{};export const busy=(f,b)=>{for(const x of f.querySelectorAll('button[type=submit]'))x.disabled=b;};export const safeUrl=v=>v;`);
async function ui(name){
 const dom=new JSDOM('<!doctype html><main id="root"></main>',{url:'http://localhost'});
 for(const key of ['window','document','FormData'])globalThis[key]=dom.window[key];
 dom.window.HTMLElement.prototype.scrollIntoView=function(){};
 const source=(await readFile(new URL(name,import.meta.url),'utf8')).replace(/from ['"]\/shared\/api\.js[^'"]*['"]/g,'from '+JSON.stringify(helper));
 return {root:document.querySelector('#root'),module:await import(moduleURL(source)),dom};
}
const settle=()=>new Promise(resolve=>setTimeout(resolve,15));

test('Removed photo opens its own reason and appeal without requesting public media',async()=>{
 const {root,module,dom}=await ui('./trust.js');const paths=[];let appealed=false;
 globalThis.trustApi=async(path,opts={})=>{
  paths.push(path);
  if(path.endsWith('/appeal')){appealed=true;assert.match(opts.body.message,/foto/);return {};}
  return {id:'photo-case',target_type:'post',media_kind:'image',status:appealed?'appealed':'removed',
   category:'violence',rule:'Gore/darah/kekerasan dalam foto. <img src=x>',policy_version:1,
   can_appeal:!appealed,appeal_deadline:'2026-11-01'};
 };
 await module.mountCases(root,'/moderation/photo-case',()=>{});
 assert.match(root.querySelector('h2').textContent,/Foto dihapus/);
 assert.equal(root.querySelector('img'),null);
 root.querySelector('textarea').value='Mohon tinjau konteks foto saya.';
 root.querySelector('form').dispatchEvent(new window.Event('submit',{cancelable:true}));
 await settle();assert(appealed);assert(paths.every(path=>path.startsWith('/moderation/cases/')));dom.window.close();
});

test('Photo case list distinguishes photos from LIVE',async()=>{
 const {root,module,dom}=await ui('./trust.js');
 globalThis.trustApi=async()=>({items:[{id:'photo-case',target_type:'post',media_kind:'image',status:'removed'},
  {id:'live-case',target_type:'live',media_kind:'live',status:'removed'}],next_offset:null});
 await module.mountCases(root,'/moderation',()=>{});
 const titles=[...root.querySelectorAll('.trust-card strong')].map(node=>node.textContent);
 assert.match(titles[0],/^Foto/);assert.match(titles[1],/^LIVE/);dom.window.close();
});

test('User opens an independent moderation case and submits an escaped appeal',async()=>{
 const {root,module,dom}=await ui('./trust.js');let appealed=false;
 globalThis.trustApi=async(path,opts={})=>{
  if(path.endsWith('/appeal')){appealed=true;assert.match(opts.body.message,/konteks/);return {};}
  return {id:'case-1',target_type:'post',status:appealed?'appealed':'removed',rule:'Aturan <img src=x onerror="bad()">',policy_version:1,can_appeal:!appealed,appeal_deadline:'2026-11-01',appeal_text:appealed?'Mohon tinjau konteks.':''};
 };
 await module.mountCases(root,'/moderation/case-1',()=>{});
 assert.equal(root.querySelector('img'),null);
 root.querySelector('textarea').value='Mohon tinjau konteks video saya.';
 root.querySelector('form').dispatchEvent(new window.Event('submit',{bubbles:true,cancelable:true}));
 await settle();assert(appealed);assert.match(root.textContent,/Banding ditinjau/);dom.window.close();
});

test('Help ticket form sends its category, subject and message; user can close the thread',async()=>{
 const {root,module,dom}=await ui('./trust.js');let route='',closed=false;
 globalThis.trustApi=async(path,opts={})=>{
  if(path==='/support/tickets'&&opts.method==='POST'){assert.equal(opts.body.subject,'Kamera bermasalah');return {id:'ticket-1'};}
  if(path.includes('/status')){closed=opts.body.status==='closed';return {};}
  if(path==='/support/tickets')return {items:[],next_offset:null};
  return {id:'ticket-1',subject:'Kamera bermasalah',category:'live',status:closed?'closed':'open',messages:[{staff:true,body:'Periksa izin kamera.'}]};
 };
 await module.mountHelp(root,'/help',p=>{route=p;});
 root.querySelector('[name=subject]').value='Kamera bermasalah';root.querySelector('[name=message]').value='Kamera tidak muncul.';
 root.querySelector('form').dispatchEvent(new window.Event('submit',{cancelable:true}));await settle();assert.equal(route,'/help/ticket-1');
 await module.mountHelp(root,route,()=>{});root.querySelector('[data-status]').click();await settle();assert(closed);assert.match(root.textContent,/Buka kembali/);dom.window.close();
});

test('Admin policy keeps expected version and decisions submit an explicit reason',async()=>{
 const {root,module,dom}=await ui('../admin/trust.js');let updated=false,resolved=false;
 globalThis.trustApi=async(path,opts={})=>{
  if(path==='/admin/moderation/policy'&&opts.method==='PUT'){updated=true;assert.equal(opts.body.expected_version,1);return {};}
  if(path==='/admin/moderation/policy')return {enabled:true,version:updated?2:1,threshold:.95,consecutive_frames:3,sample_seconds:.5,appeal_days:14,rule:'Aturan konten yang cukup lengkap.',video_worker_ready:true,live_worker_ready:true};
  if(path==='/admin/moderation/cases')return {items:[{id:'c1',target_type:'post',status:'appealed',rule:'Aturan',score:.99}],total:1};
  if(path==='/admin/moderation/jobs')return {items:[],next_offset:null};
  if(path.endsWith('/evidence'))return {id:'c1',status:'appealed',rule:'Aturan',target_type:'post'};
  if(path.endsWith('/decision')){assert.equal(opts.body.reason,'Konteks aman setelah ditinjau.');resolved=true;return {};}
  return {};
 };
 await module.mountSafety(root);root.querySelector('[name=reason]').value='Kalibrasi aturan.';root.querySelector('[data-policy]').dispatchEvent(new window.Event('submit',{cancelable:true}));await settle();assert(updated);
 root.querySelector('[data-case]').click();await settle();root.querySelector('[data-review] textarea').value='Konteks aman setelah ditinjau.';root.querySelector('[data-review] form').dispatchEvent(new window.Event('submit',{cancelable:true}));await settle();assert(resolved);dom.window.close();
});

test('Admin support reply retains a private conversation and updates ticket status',async()=>{
 const {root,module,dom}=await ui('../admin/trust.js');let replied=false;
 globalThis.trustApi=async(path,opts={})=>{
  if(path==='/admin/support/tickets')return {items:[{id:'t1',subject:'Kendala akun',status:'open',category:'account'}],total:1};
  if(path.endsWith('/messages')){replied=true;assert.equal(opts.body.status,'waiting_user');return {};}
  return {id:'t1',subject:'Kendala akun',status:replied?'waiting_user':'open',messages:[{staff:false,body:'<script>bad()</script>'}]};
 };
 await module.mountSupport(root);root.querySelector('[data-ticket]').click();await settle();assert.equal(root.querySelector('script'),null);
 root.querySelector('textarea').value='Silakan periksa pengaturan akun.';root.querySelector('form').dispatchEvent(new window.Event('submit',{cancelable:true}));await settle();assert(replied);assert.match(root.textContent,/Menunggu pengguna/);dom.window.close();
});


test('Decision list never presents all published uploads as a manual approval queue',async()=>{
 const {root,module,dom}=await ui('./trust.js');const paths=[];
 globalThis.trustApi=async(path)=>{paths.push(path);return {items:[],next_offset:null};};
 await module.mountCases(root,'/moderation',()=>{});
 assert(paths.every(path=>!path.startsWith('/moderation/uploads')));
 assert.match(root.textContent,/Unggahan langsung terbit/);
 assert.equal(root.querySelector('[data-pending]'),null);dom.window.close();
});

test('Admin detection health separates completed scans from failed automatic retries',async()=>{
 const {root,module,dom}=await ui('../admin/trust.js');
 globalThis.trustApi=async(path)=>{
  if(path==='/admin/moderation/policy')return {enabled:true,version:2,threshold:.95,consecutive_frames:3,sample_seconds:.5,appeal_days:14,rule:'Aturan konten yang cukup lengkap.',video_worker_ready:true,live_worker_ready:true,job_counts:{done:7,queued:2,processing:1,retrying:1}};
  if(path==='/admin/moderation/jobs')return {items:[{post_id:'p1',status:'queued',error:'ImportError: <script>bad()</script>'}],next_offset:null};
  return {items:[],total:0};
 };
 await module.mountSafety(root);
 assert.match(root.querySelector('[data-job-counts]').textContent,/Selesai: 7/);
 assert.match(root.querySelector('[data-job-counts]').textContent,/Gagal, mencoba ulang: 1/);
 assert.equal(root.querySelector('script'),null);
 assert.match(root.querySelector('[data-jobs]').textContent,/ImportError:/);
 dom.window.close();
});
