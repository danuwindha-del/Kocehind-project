export function mountAlbumComposer(root,{api,esc,icon,visibilityOptions,initialSound,navigate,toast,isCurrent=()=>true}){
 let files=[],urls=[],sound=initialSound,disposed=false,uploading=false,searchTicket=0;
 root.innerHTML=`<h1>Bagikan cerita Anda.</h1><p class="muted">Satu video atau album hingga 20 foto dengan musik dari Kocehind.</p><div class="upload-layout"><div class="upload-preview"><div id="file-preview"><h3>Pilih video atau foto</h3><p>Video MP4/WebM maks. 80 MB. Maks. 20 foto JPG/PNG/WebP, masing-masing 10 MB.</p><input multiple type="file" id="upload-file" accept="video/mp4,video/webm,image/jpeg,image/png,image/webp" aria-label="Pilih media"><div id="album-previews"></div></div></div><form id="upload-form"><label>Keterangan<textarea name="caption" maxlength="2000" placeholder="Ceritakan sesuatu… #tagar @teman"></textarea></label><label>Siapa yang dapat menonton?<select name="visibility">${visibilityOptions()}</select></label><fieldset><legend>Musik dari Kocehind</legend><div class="sound-search"><input type="search" id="sound-query" placeholder="Cari sound atau tampilkan yang terbaru" aria-label="Cari musik"><button type="button" class="btn" id="find-sounds">Cari sound</button></div><div id="sound-results" aria-live="polite"></div><div id="chosen-sound"></div></fieldset><p class="upload-note">Gunakan konten dan musik yang Anda miliki atau berhak bagikan.</p><p class="form-error" role="alert"></p><button class="btn primary" type="submit">Unggah cerita</button></form></div>`;
 const input=root.querySelector('#upload-file'),form=root.querySelector('#upload-form'),error=form.querySelector('.form-error'),previews=root.querySelector('#album-previews');
 function paintSound(){const area=root.querySelector('#chosen-sound');area.innerHTML=sound?`<p>♪ ${esc(sound.title)} <button type="button" id="remove-sound" class="text-btn">Hapus sound</button></p>`:'<p class="muted">Tanpa musik tambahan.</p>';area.querySelector('#remove-sound')?.addEventListener('click',()=>{sound=null;paintSound();});}
 function paint(){urls.forEach(url=>URL.revokeObjectURL(url));urls=files.map(file=>URL.createObjectURL(file));
  previews.innerHTML=`<p>${files.length}${files[0]?.type.startsWith('image/')?'/20 foto':''}</p><div class="composer-photos">${files.map((file,i)=>`<div>${file.type.startsWith('video/')?`<video src="${urls[i]}" controls playsinline></video>`:`<img src="${urls[i]}" alt="Foto ${i+1}">`}<span>${i+1}</span><div><button type="button" data-left="${i}" aria-label="Pindahkan foto ${i+1} ke kiri" ${i?'':'disabled'}>‹</button><button type="button" data-right="${i}" aria-label="Pindahkan foto ${i+1} ke kanan" ${i===files.length-1?'disabled':''}>›</button><button type="button" data-remove="${i}" aria-label="Hapus foto ${i+1}">×</button></div></div>`).join('')}</div>`;
  previews.querySelectorAll('[data-left],[data-right],[data-remove]').forEach(b=>b.onclick=()=>{if(uploading)return;const i=Number(b.dataset.left??b.dataset.right??b.dataset.remove);if(b.hasAttribute('data-remove'))files.splice(i,1);else{const next=i+(b.hasAttribute('data-left')?-1:1);[files[i],files[next]]=[files[next],files[i]];}paint();});
 }
 input.onchange=()=>{const chosen=[...input.files];if(!chosen.length)return;error.textContent='';
  const video=chosen.some(f=>f.type.startsWith('video/'));
  if(chosen.length>20||(video&&chosen.length!==1)){error.textContent='Pilih satu video atau maksimal 20 foto. Video dan foto tidak dapat dicampur.';input.value='';return;}
  if(chosen.some(f=>!['video/mp4','video/webm','image/jpeg','image/png','image/webp'].includes(f.type)||f.size>(f.type.startsWith('video/')?80:10)*1024*1024)){error.textContent='Format atau ukuran file tidak sesuai batas.';input.value='';return;}
  files=chosen;paint();
 };
 async function findSound(){const ticket=++searchTicket,area=root.querySelector('#sound-results');area.textContent='Mencari…';
  try{const r=await api('/sounds/catalog?q='+encodeURIComponent(root.querySelector('#sound-query').value.trim()));if(disposed||ticket!==searchTicket)return;
   area.innerHTML=r.items.map((s,i)=>`<button type="button" class="user-row" data-sound="${i}"><span>♪ ${esc(s.title)}<small>@${esc(s.username)}</small></span></button>`).join('')||'<p>Sound tidak ditemukan.</p>';
   area.querySelectorAll('[data-sound]').forEach(b=>b.onclick=()=>{sound=r.items[+b.dataset.sound];paintSound();area.replaceChildren();});
  }catch(e){if(!disposed&&ticket===searchTicket)area.textContent=e.message;}
 }
 root.querySelector('#find-sounds').onclick=findSound;root.querySelector('#sound-query').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();findSound();}};paintSound();
 form.onsubmit=async e=>{e.preventDefault();if(uploading)return;if(!files.length){error.textContent='Pilih media terlebih dahulu.';return;}uploading=true;input.disabled=true;form.querySelector('button[type=submit]').disabled=true;
  try{const media=[];for(const [i,file] of files.entries()){error.textContent=`Mengunggah ${i+1}/${files.length}…`;const body=new FormData();body.set('file',file);media.push(await api('/media/upload',{method:'POST',body}));}
   const fd=new FormData(form),first=media[0];const post=await api('/posts',{method:'POST',body:{...first,caption:fd.get('caption'),visibility:fd.get('visibility'),sound_id:sound?.id||null,...(first.kind==='image'?{photos:media.map(m=>({media_url:m.media_url,thumbnail_url:m.thumbnail_url}))}:{})}});
   if(!disposed&&isCurrent()){toast('Cerita berhasil dibagikan');navigate('/video/'+post.id);}
  }catch(e){if(!disposed)error.textContent=e.message;}finally{uploading=false;if(!disposed){input.disabled=false;form.querySelector('button[type=submit]').disabled=false;}}
 };
 return ()=>{disposed=true;++searchTicket;urls.forEach(url=>URL.revokeObjectURL(url));previews.querySelectorAll('video').forEach(v=>v.pause());};
}
