// Browser QA against deterministic API fixtures. Not a real media/SFU/server test.
// Run with Playwright installed: CHROMIUM_EXECUTABLE=/path/to/chrome node --test websites/web/test-v27-browser.mjs
import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {createRequire} from 'node:module';
const {chromium}=createRequire(import.meta.url)('playwright');
const sites=resolve(new URL('..',import.meta.url).pathname);
const me={id:'owner',username:'alice',name:'Alice',email:'alice@example.test',bio:'Hello',is_admin:true,notifications_enabled:true,followers:12,following_count:5,likes_received:20};
const makePost=(id='post-1')=>({id,author:me,is_mine:true,kind:'image',caption:'Cerita @bob #hariini',mentions:[{id:'bob',username:'bob'}],media_url:'/fixture.png',thumbnail_url:'/fixture.png',visibility:'public',views:5,likes:2,comments:52,created_at:'2026-10-22T12:00:00Z'});
let post=makePost(),calls=[],historyIds=['post-1','post-2'],clipStatus='queued',apkReady=true;
const rootComment={id:'root-99',username:'bob',body:'Komentar utama jauh',created_at:'2026-10-22T12:00:00Z',likes:0};
const targetComment={id:'reply-99',parent_id:'root-99',username:'bob',body:'Balasan target @alice',mentions:[{id:'owner',username:'alice'}],created_at:'2026-10-22T12:01:00Z',likes:1};
let targetDeleted=false;
const watchVideo=Buffer.from('GkXfo59ChoEBQveBAULygQRC84EIQoKEd2VibUKHgQJChYECGFOAZwEAAAAAAAOZEU2bdLpNu4tTq4QVSalmU6yBoU27i1OrhBZUrmtTrIHYTbuMU6uEElTDZ1OsggEeTbuMU6uEHFO7a1OsggOD7AEAAAAAAABZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVSalmsirXsYMPQkBNgI1MYXZmNjAuMTYuMTAwV0GNTGF2ZjYwLjE2LjEwMESJiECfQAAAAAAAFlSua8GuAQAAAAAAADjXgQFzxYis5mw+zeB4P5yBACK1nIN1bmSIgQCGhVZfVlA4g4EBI+ODhAX14QDgibCBILqBIJqBAhJUw2f8c3OgY8CAZ8iaRaOHRU5DT0RFUkSHjUxhdmY2MC4xNi4xMDBzc9ZjwItjxYis5mw+zeB4P2fIoUWjh0VOQ09ERVJEh5RMYXZjNjAuMzEuMTAyIGxpYnZweGfIoUWjiERVUkFUSU9ORIeTMDA6MDA6MDIuMDAwMDAwMDAwAB9DtnVB3ueBAKOkgQAAgDACAJ0BKiAAIAAARwiFhYiFhIgCAgAHkPPJwP7/q1CAo5WBAGQAsQEABRCsABgAGFgv9AAIcACjlYEAyACxAQAFEKwAGAAYWC/0AAhwAKOVgQEsALEBAAUQrAAYABhYL/QACHAAo5WBAZAAsQEABRCsABgAGFgv9AAIcACjlYEB9ACxAQAFEKwAGAAYWC/0AAhwAKOVgQJYALEBAAUQrAAYABhYL/QACHAAo5WBArwAsQEABRAQFGAAYWC/0AAhwACjlYEDIACxAQAFEKwAGAAYWC/0AAhwAKOVgQOEALEBAAUQrAAYABhYL/QACHAAo5WBA+gAsQEABRCsABgAGFgv9AAIcACjlYEETACxAQAFEKwAGAAYWC/0AAhwAKOVgQSwALEBAAUQrAAYABhYL/QACHAAo5WBBRQAsQEABRCsABgAGFgv9AAIcACjlYEFeACxAQAFEKwAGAAYWC/0AAhwAKOVgQXcALEBAAUQrAAYABhYL/QACHAAo5WBBkAAsQEABRCsABgAGFgv9AAIcACjlYEGpACxAQAFEKwAGAAYWC/0AAhwAKOVgQcIALEBAAUQEBRgAGFgv9AAIcAAo5WBB2wAsQEABRCsABgAGFgv9AAIcAAcU7trkbuPs4EAt4r3gQHxggGf8IED','base64');
const room={id:'live-1',title:'Siaran privat',status:'live',mode:'camera',role:'viewer',host:{id:'bob',username:'bob',name:'Bob'},members:[],likes:7,viewers:4,together:false};
const recording={status:'ready',expires_at:'2099-01-01T00:00:00Z',duration_seconds:120,playback_url:'/api/studio/live/live-1/playback?token=fixture'};
async function api(req,url){
 let input='';for await(const chunk of req)input+=chunk;
 let body;try{body=JSON.parse(input);}catch{}
 calls.push({path:url.pathname+url.search,method:req.method,body});
 const path=url.pathname.replace(/^\/api/,'');
 if(path==='/users/me')return me;
 if(path==='/users/me/privacy')return {revision:1};
 if(path==='/trending')return {items:[]};
 if(path==='/feed')return {items:[post],next_cursor:null};
 if(path==='/notifications')return {items:[{id:'notification',kind:'mention',username:'bob',text:'Bob membalas komentar Anda',post_id:'post-1',comment_id:'reply-99',created_at:'2026-10-22T12:00:00Z'}],unread:1};
 if(path==='/notifications/read')return {};
 if(path==='/users/alice')return me;
 if(path==='/users/bob')return {...me,id:'bob',username:'bob',name:'Bob'};
 if(path==='/users/alice/posts'||path==='/users/bob/posts')return {items:[{...post,visibility:url.searchParams.get('visibility')||'public'}],next_offset:null};
 if(path==='/posts/post-1/privacy'){post={...post,...body};return post;}
 if(path==='/posts/post-1'&&req.method==='DELETE')return {};
 if(path==='/posts/post-1')return post;
 if(path==='/posts/post-1/comments/target/reply-99')return targetDeleted?{_status:404,detail:'Komentar dihapus'}:{comment:targetComment,thread:[rootComment,targetComment],root_id:rootComment.id};
 if(path==='/posts/post-1/comments')return {items:[{...rootComment,id:'first-page',body:'Komentar halaman pertama'}],total:52,next_offset:null};
 if(path==='/users/me/history'){
  if(req.method==='DELETE'){const before=historyIds.length;historyIds=body.all?[]:historyIds.filter(id=>!body.ids.includes(id));return {deleted:before-historyIds.length};}
  return {items:historyIds.map((id,i)=>({id:'history-'+i,post:makePost(id),watched_at:'2026-10-22T12:00:00Z'})),total:historyIds.length,next_offset:null};
 }
 if(path==='/studio/overview')return {days:Number(url.searchParams.get('days')),account:{followers:12,following:5,posts:3,views:99,likes:20,comments:7,follower_change:2},video:{views:9,likes:4,comments:2,watch_ms:120000,completed:3},live:{sessions:1,viewers:4,likes:7,duration_seconds:120},tracking_since:'2026-10-21T00:00:00Z',daily:[{date:'2026-10-22',views:9,likes:4,comments:2,followers:12,new_followers:2,live_views:4}]};
 if(path==='/studio/videos')return {items:[{...post,kind:'video',metrics:{views:99,likes:20,comments:7,watch_ms:120000,completed:3}}],total:1,next_offset:null};
 if(path==='/studio/live')return {items:[{...room,status:'ended',started_at:'2026-10-22T12:00:00Z',views:4,peak_viewers:3,duration_seconds:120,recording}],retention_days:7};
 if(path==='/studio/clips')return {items:[{id:'clip-1',room_id:'live-1',status:clipStatus,start_seconds:5,end_seconds:25,media_url:'/media/clip.mp4',thumbnail_url:'/media/clip.jpg',kind:'video'}]};
 if(path==='/studio/live/live-1/clips'){clipStatus='queued';return {id:'clip-1',status:'queued'};}
 if(path==='/posts'&&req.method==='POST'){post={...post,...body};return post;}
 if(path==='/media/upload')return {kind:'video',media_url:'/media/upload.mp4',thumbnail_url:'/media/upload.jpg'};
 if(path==='/live/rooms/live-1/join')return {room,role:'viewer',url:'wss://fixture.test',token:'fixture'};
 if(path==='/live/rooms/live-1/heartbeat')return room;
 if(path==='/live/rooms/live-1/comments')return {items:[],cursor:0};
 if(path==='/reports')return {id:'report-1',status:'open'};
 if(path==='/admin/me')return me;
 if(path==='/admin/reports')return {items:[{id:'report-1',target_type:'live',target_id:'live-1',reporter:'alice',reason:'Pelanggaran LIVE',created_at:'2026-10-22T12:00:00Z',status:'open'}],total:1,next_offset:null};
 return {};
}
function server(site){return createServer(async(req,res)=>{
 const url=new URL(req.url,'http://localhost');
 if(url.pathname.startsWith('/api/')){const data=await api(req,url);res.writeHead(data._status||200,{'content-type':'application/json'});res.end(JSON.stringify(data));return;}
 if(url.pathname==='/downloads/Kocehind.apk'){res.writeHead(apkReady?200:404,{'content-type':apkReady?'application/octet-stream':'text/plain','content-disposition':'attachment; filename="Kocehind.apk"'});res.end(apkReady?'APK-fixture':'Missing');return;}
 if(url.pathname==='/downloads/app-info.json'){res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify({bytes:1024,published_at:'2026-10-22T12:00:00Z'}));return;}
 if(url.pathname==='/watch.webm'){res.writeHead(200,{'content-type':'video/webm'});res.end(watchVideo);return;}
 if(url.pathname==='/fixture.png'){res.writeHead(200,{'content-type':'image/png'});res.end(Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jGacAAAAASUVORK5CYII=','base64'));return;}
 if(url.pathname==='/shared/livekit.js'){res.writeHead(200,{'content-type':'text/javascript'});res.end("export const RoomEvent={};export class Room {constructor(){this.localParticipant={videoTrackPublications:new Map(),setCameraEnabled:async()=>{},setMicrophoneEnabled:async()=>{}};this.remoteParticipants=new Map();this.state='connected';}on(){return this;}async connect(){}async disconnect(){}async startAudio(){}} ");return;}
 const relative=url.pathname.startsWith('/shared/')?url.pathname.slice(1):(site+'/'+(extname(url.pathname)?url.pathname.slice(1):'index.html'));
 const path=resolve(sites,relative);
 if(!path.startsWith(sites+'/')){res.writeHead(404);res.end();return;}
 try{const data=await readFile(path);res.writeHead(200,{'content-type':({'.js':'text/javascript','.css':'text/css','.png':'image/png','.html':'text/html'}[extname(path)]||'application/octet-stream')});res.end(data);}catch{res.writeHead(404);res.end();}
});}
const listen=async server=>{await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));return 'http://127.0.0.1:'+server.address().port;};

test('v2.7 browser flows: privacy, profile tabs, history, notification target, Studio, clips, reports, APK',async()=>{
 const web=server('web'),main=server('main'),admin=server('admin');
 const [webURL,mainURL,adminURL]=await Promise.all([listen(web),listen(main),listen(admin)]);
 const browser=await chromium.launch({headless:true,...(process.env.CHROMIUM_EXECUTABLE?{executablePath:process.env.CHROMIUM_EXECUTABLE}:{}),args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:1280,height:900},timezoneId:'UTC'}),errors=[];
 page.on('pageerror',error=>errors.push(error.message));
 try{
  await page.goto(webURL+'/video/post-1');
  await page.locator('[data-action="share"]').waitFor();
  await page.locator('[data-action="share"]').click();
  assert.equal(await page.locator('#share-privacy').count(),1);assert.equal(await page.locator('#share-delete').count(),1);
  await page.locator('#share-privacy').click();
  await page.locator('dialog select[name="visibility"]').selectOption('friends');
  await page.locator('dialog button[type="submit"]').click();
  await page.locator('.friends-only').waitFor();
  assert.equal(calls.find(c=>c.path==='/api/posts/post-1/privacy').body.visibility,'friends');
  assert.equal(await page.locator('.caption .mention').getAttribute('href'),'/@bob');
  post={...post,is_mine:false};await page.reload();await page.locator('[data-action="share"]').click();
  assert.equal(await page.locator('#share-privacy').count(),0);assert.equal(await page.locator('#share-delete').count(),0);
  post={...post,is_mine:true};


  await page.goto(webURL+'/@alice');
  await page.locator('.profile-tabs [aria-label="Video Hanya Saya"]').click();
  await page.locator('.profile-tabs [aria-label="Video Hanya Saya"].active').waitFor();
  assert.ok(calls.some(c=>c.path==='/api/users/alice/posts?visibility=private'));
  assert.equal(await page.locator('.grid-card .mention').getAttribute('href'),'/@bob');
  await page.goto(webURL+'/@bob');await page.locator('.profile-tabs').waitFor();
  assert.equal(await page.locator('.profile-tabs [aria-label="Video Hanya Saya"]').count(),0);

  await page.goto(webURL+'/history');
  await page.locator('[data-history-id="post-1"]').check();
  await page.locator('#history-delete').click();await page.locator('dialog [data-confirm]').click();
  await page.waitForFunction(()=>document.querySelectorAll('[data-history-id]').length===1);
  assert.deepEqual(calls.find(c=>c.path==='/api/users/me/history'&&c.method==='DELETE').body,{ids:['post-1'],all:false});
  await page.locator('#history-delete-all').click();await page.locator('dialog [data-confirm]').click();
  await page.getByText('Belum ada riwayat tontonan.').waitFor();
  assert.deepEqual(calls.filter(c=>c.path==='/api/users/me/history'&&c.method==='DELETE').at(-1).body,{all:true});

  await page.goto(webURL+'/inbox');await page.locator('[data-activity]').click();
  await page.locator('[data-comment="reply-99"].comment-target').waitFor();
  assert.equal(await page.locator('[data-comment="root-99"]').count(),1);
  assert.equal(await page.locator('[data-comment="reply-99"] .mention').getAttribute('href'),'/@alice');
  targetDeleted=true;await page.goto(webURL+'/video/post-1?comment=reply-99');
  await page.locator('.comment-target-note').waitFor();targetDeleted=false;

  await page.goto(webURL+'/settings');await page.getByRole('link',{name:'Kocehind Studio'}).click();
  await page.locator('.studio-metric').first().waitFor();
  assert.match(await page.locator('#studio-overview').innerText(),/99/);
  assert.match(await page.locator('#studio-overview').innerText(),/21 Okt 2026/);
  await page.locator('#studio-days').selectOption('30');
  await page.waitForFunction(()=>document.querySelector('#studio-overview').textContent.includes('30 hari'));
  assert.equal(await page.locator('#studio-videos .studio-video').count(),1);
  assert.equal(await page.locator('#studio-videos-more').isVisible(),false);
  const clipForm=page.locator('[data-clip-room="live-1"]');
  await clipForm.locator('[name="start"]').fill('25');await clipForm.locator('[name="end"]').fill('5');
  await clipForm.locator('[type="submit"]').click();
  await clipForm.locator('.form-error').filter({hasText:'Akhir'}).waitFor();
  assert.equal(calls.filter(c=>c.path==='/api/studio/live/live-1/clips').length,0);
  await clipForm.locator('[name="start"]').fill('5');await clipForm.locator('[name="end"]').fill('25');await clipForm.locator('[type="submit"]').click();
  await page.getByText('Klip masuk antrean pemrosesan',{exact:true}).waitFor();
  clipStatus='ready';await page.locator('#studio-clips-refresh').click();await page.locator('[data-publish-clip]').click();
  await page.locator('dialog [name="caption"]').fill('Klip baru');await page.locator('dialog [name="visibility"]').selectOption('private');await page.locator('dialog [type="submit"]').click();
  await page.locator('.detail-view').waitFor();
  assert.equal(calls.filter(c=>c.path==='/api/posts'&&c.method==='POST').at(-1).body.visibility,'private');

  await page.goto(webURL+'/upload');await page.locator('#upload-form [name="visibility"]').selectOption('friends');
  await page.locator('#upload-file').setInputFiles({name:'fixture.mp4',mimeType:'video/mp4',buffer:Buffer.from('fixture')});
  await page.locator('#upload-form [type="submit"]').click();await page.locator('.detail-view').waitFor();
  assert.equal(calls.filter(c=>c.path==='/api/posts'&&c.method==='POST').at(-1).body.visibility,'friends');
  const impressionViews=calls.filter(c=>c.path==='/api/posts/post-1/view').length;
  await page.waitForTimeout(1250);
  assert.equal(calls.filter(c=>c.path==='/api/posts/post-1/view').length,impressionViews);
  post={...makePost(),kind:'video',media_url:'/watch.webm'};await page.reload();
  await page.waitForFunction(()=>document.querySelector('.post video')?.currentTime>1.3);
  let signalResponse=page.waitForResponse(r=>r.url().includes('/discovery/signals/post-1'));
  await page.locator('.post video').evaluate(v=>v.pause());await signalResponse;
  const firstSignal=calls.filter(c=>c.path==='/api/discovery/signals/post-1'&&c.body?.watch_ms).at(-1).body;
  assert.ok(firstSignal.watch_ms>=1000);assert.ok(firstSignal.playback_id);
  await page.locator('.post video').evaluate(v=>v.play());await page.waitForTimeout(750);
  signalResponse=page.waitForResponse(r=>r.url().includes('/discovery/signals/post-1'));
  await page.locator('.post video').evaluate(v=>v.pause());await signalResponse;
  const secondSignal=calls.filter(c=>c.path==='/api/discovery/signals/post-1'&&c.body?.watch_ms).at(-1).body;
  assert.equal(secondSignal.playback_id,firstSignal.playback_id);assert.ok(secondSignal.watch_ms>firstSignal.watch_ms);
  await page.reload();await page.waitForFunction(()=>document.querySelector('.post video')?.currentTime>1.3);
  signalResponse=page.waitForResponse(r=>r.url().includes('/discovery/signals/post-1'));
  await page.locator('.post video').evaluate(v=>v.pause());await signalResponse;
  assert.notEqual(calls.filter(c=>c.path==='/api/discovery/signals/post-1'&&c.body?.watch_ms).at(-1).body.playback_id,firstSignal.playback_id);
  const watchedViews=calls.filter(c=>c.path==='/api/posts/post-1/view').length;
  post=makePost();await page.reload();await page.locator('.post-image').waitFor();
  await page.waitForFunction(()=>document.querySelector('.post-image')?.naturalWidth>0);
  await page.waitForTimeout(1700);
  assert.equal(calls.filter(c=>c.path==='/api/posts/post-1/view').length,watchedViews+1);


  await page.goto(webURL+'/live/live-1');await page.locator('#live-title').filter({hasText:'Siaran privat'}).waitFor();
  await page.locator('#live-report').click();await page.locator('dialog [name="reason"]').fill('Pelanggaran LIVE');await page.locator('dialog [type="submit"]').click();
  await page.getByText('Laporan LIVE masuk ke antrean moderator',{exact:true}).waitFor();
  assert.deepEqual(calls.filter(c=>c.path==='/api/reports').at(-1).body,{target_type:'live',target_id:'live-1',reason:'Pelanggaran LIVE'});
  await page.goto(adminURL+'/#reports');await page.getByRole('link',{name:'Buka LIVE ↗'}).waitFor();assert.equal(await page.getByRole('link',{name:'Buka LIVE ↗'}).getAttribute('href'),'https://web.kocehind.web.id/live/live-1');

  // v2.8 root is intentionally a web redirect. About keeps direct official APK links.
  await page.goto(mainURL+'/about.html');
  const apkLinks=page.locator('a[href="https://kocehind.web.id/downloads/Kocehind.apk"]');
  assert.equal(await apkLinks.count(),2);
  assert.equal(await page.getByRole('heading',{name:'Cerita dekat. Obrolan nyambung.'}).count(),1);

  await page.setViewportSize({width:375,height:812});await page.goto(webURL+'/studio');await page.locator('.studio-metric').first().waitFor();
  if(process.env.V27_QA_DIR)await page.screenshot({path:process.env.V27_QA_DIR+'/studio-mobile.png',fullPage:true});
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
  await page.emulateMedia({reducedMotion:'reduce'});await page.setViewportSize({width:812,height:375});
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
  assert.deepEqual(errors,[]);
 }finally{await browser.close();await Promise.all([web,main,admin].map(s=>new Promise(resolve=>s.close(resolve))));}
});
