import {execFileSync} from 'node:child_process';
import {mkdtemp,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile,mkdir} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {createRequire} from 'node:module';
const {chromium}=createRequire(import.meta.url)('playwright');
const root=resolve(new URL('..',import.meta.url).pathname);
const owner={id:'00000000-0000-4000-8000-000000000001',username:'creator',name:'Kreator Kocehind',bio:'Cerita sehari-hari dari komunitas.',is_admin:true,legal_required:false,profile_limits:{},followers:1500,following_count:15,likes_received:4200,links:[{title:'Situs resmi',url:'https://example.com/'},{title:'Portofolio',url:'https://example.org/'}]};
const post={id:'00000000-0000-4000-8000-000000000002',caption:'Video kreator',kind:'video',media_url:'',thumbnail_url:'',author:owner,views:1234,likes:50,following:false,is_mine:true,is_pinned:false,visibility:'public',mentions:[]};
const ai={id:'youtube',title:'YouTube',summary:'YouTube menyediakan ruang untuk berbagi cerita dan membangun komunitas.\n\nProduk YouTube mencakup YouTube Music, YouTube Kids, dan YouTube Studio.',images:[],sources:[{label:'YouTube resmi',url:'https://about.youtube/'}],studied_at:'2026-10-31T00:00:00Z'};
const qa=process.env.KOCEHIND_QA_DIR||'/tmp/kocehind-qa-v216';

async function scenario(site,path,handler,run){
 const calls=[];
 const server=createServer(async(req,res)=>{
  try{
   const url=new URL(req.url,'http://fixture');
   if(url.pathname.startsWith('/api/')){
    const chunks=[];for await(const chunk of req)chunks.push(chunk);const raw=Buffer.concat(chunks);
    const call={path:url.pathname.slice(4),method:req.method,query:url.searchParams,body:req.headers['content-type']?.includes('json')&&raw.length?JSON.parse(raw):null};calls.push(call);
    let data=await handler(call);
    if(data===undefined){if(call.path==='/users/me'||call.path==='/admin/me'||call.path==='/users/creator')data=owner;else if(call.path==='/users/me/privacy')data={revision:'test'};else data={items:[],next_offset:null,unread:0};}
    if(data?.fixtureFile){res.writeHead(200,{'content-type':data.contentType});res.end(await readFile(data.fixtureFile));return;}
    res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(data));return;
   }
   const relative=url.pathname.startsWith('/shared/')?url.pathname.slice(1):/\.(js|css|png)$/.test(url.pathname)?site+url.pathname:site+'/index.html';
   const file=resolve(root,relative);if(!file.startsWith(root+'/'))throw new Error('Invalid path');
   res.writeHead(200,{'content-type':({'.js':'text/javascript','.css':'text/css','.html':'text/html','.png':'image/png'}[extname(file)]||'application/octet-stream')});res.end(await readFile(file));
  }catch{res.writeHead(404);res.end('missing');}
 });
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:390,height:844}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 try{await page.goto(origin+path);await run(page,calls);assert.deepEqual(errors,[]);}finally{await browser.close();await new Promise(r=>server.close(r));}
}

test('Phone album swipes horizontally with count, badge beside username and next button',async()=>{
 const album={...post,kind:'image',photos:[1,2,3].map(()=>({media_url:'/shared/logo.png'})),photo_count:3};
 await scenario('web','/video/'+post.id,c=>c.path==='/posts/'+post.id?album:undefined,async page=>{
  await page.locator('.photo-slide').first().waitFor();assert.equal(await page.locator('.photo-slide').count(),3);
  assert.equal(await page.locator('.author-line .photo-badge').textContent(),'▣ Foto');
  await page.locator('.photo-next').click();await page.waitForFunction(()=>document.querySelector('.photo-counter')?.textContent==='2/3');
  await page.locator('.photo-slides').focus();await page.keyboard.press('ArrowRight');
  await page.waitForFunction(()=>document.querySelector('.photo-counter')?.textContent==='3/3');
  await mkdir(qa,{recursive:true});await page.screenshot({path:qa+'/album-phone.png',fullPage:true});
 });
});

test('Upload rejects 21 photos and sends ordered album media plus the selected sound',async()=>{
 let index=0,created;
 await scenario('web','/upload',c=>{
  if(c.path==='/media/upload')return {kind:'image',media_url:'/media/'+(++index)+'.jpg',thumbnail_url:'/media/'+index+'.jpg'};
  if(c.path==='/sounds/catalog')return {items:[{id:'music',title:'Suara komunitas',username:'creator',media_url:''}]};
  if(c.path==='/posts'&&c.method==='POST'){created={...post,...c.body};return created;}
  if(c.path==='/posts/'+post.id)return created||post;
 },async(page,calls)=>{
  const buffer=await readFile(resolve(root,'shared/logo.png'));
  const photos=Array.from({length:21},(_,i)=>({name:'photo'+i+'.png',mimeType:'image/png',buffer}));
  await page.locator('#upload-file').setInputFiles(photos);
  await page.getByText('Pilih satu video atau maksimal 20 foto.',{exact:false}).waitFor();
  assert(!calls.some(c=>c.path==='/media/upload'));
  await page.locator('#upload-file').setInputFiles(photos.slice(0,3));
  await page.locator('[data-left="2"]').click();
  await page.locator('#find-sounds').click();await page.locator('[data-sound="0"]').click();
  await page.locator('[name=caption]').fill('Album dengan musik');await page.getByRole('button',{name:'Unggah cerita',exact:true}).click();
  await page.waitForFunction(()=>location.pathname.startsWith('/video/'));
  const made=calls.find(c=>c.path==='/posts'&&c.method==='POST');assert.equal(made.body.photos.length,3);assert.equal(made.body.sound_id,'music');
  assert.equal(made.body.media_url,made.body.photos[0].media_url);assert.equal(index,3);
 });
});

test('Search history shows six recent queries, opens one, and can delete all',async()=>{
 let terms=['query6','query5','query4','query3','query2','query1'];
 await scenario('web','/search',c=>{
  if(c.path==='/search/history'){if(c.method==='DELETE')terms=[];return {items:terms};}
  if(c.path==='/search')return {entries:[],posts:[],users:[],sounds:[],hashtags:[],next_cursor:null};
  if(c.path==='/search/mycha')return {items:[]};
 },async page=>{
  await page.locator('.recent-list li').first().waitFor();assert.equal(await page.locator('.recent-list li').count(),6);
  await page.getByRole('button',{name:'Hapus semua',exact:true}).click();await page.waitForFunction(()=>!document.querySelector('.recent-list'));
 });
});

test('Edit profile sends the requested account privacy mode',async()=>{
 await scenario('web','/@creator',c=>{
  if(c.path==='/users/creator/posts')return {items:[],next_offset:null};
 },async(page,calls)=>{
  await page.getByRole('button',{name:'Edit profil',exact:true}).click();
  await page.locator('[name=account_privacy]').selectOption('friends');await page.getByRole('button',{name:'Simpan perubahan'}).click();
  await page.locator('dialog').waitFor({state:'detached'});
  assert.equal(calls.find(c=>c.path==='/users/me'&&c.method==='PUT').body.account_privacy,'friends');
 });
});

test('Inbox search finds a message and opens its conversation',async()=>{
 await scenario('web','/inbox?tab=messages',c=>{
  if(c.path==='/chats')return {items:[],requests:[]};
  if(c.path==='/inbox/search')return {users:[],messages:[{id:'message',username:'friend',name:'Teman',body:'Jadwal rapat komunitas',avatar_url:''}]};
  if(c.path==='/chats/friend')return {items:[],status:'accepted',peer:{username:'friend'}};
 },async page=>{
  await page.getByRole('searchbox',{name:'Cari pesan atau akun'}).fill('rapat');
  await page.getByText('Jadwal rapat komunitas',{exact:true}).click();await page.waitForFunction(()=>location.search.includes('chat=friend'));
 });
});

test('Browser decodes real HLS segments without downloading the original MP4',async(t)=>{
 const folder=await mkdtemp(tmpdir()+'/kocehind-hls-browser-');
 try{
  await mkdir(folder+'/360');
  execFileSync('ffmpeg',['-nostdin','-v','error','-y','-f','lavfi','-i','testsrc2=size=180x320:rate=30',
   '-f','lavfi','-i','sine=frequency=440:sample_rate=44100','-t','4.5','-c:v','libx264','-threads','1','-pix_fmt','yuv420p',
   '-g','60','-keyint_min','60','-sc_threshold','0','-c:a','aac','-f','hls','-hls_time','2','-hls_playlist_type','vod',
   '-hls_segment_filename',folder+'/360/seg%05d.ts',folder+'/360/index.m3u8']);
  await writeFile(folder+'/master.m3u8','#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=500000,RESOLUTION=180x320\n360/index.m3u8\n');
  await scenario('web','/video/'+post.id,c=>{
   if(c.path==='/posts/'+post.id)return {...post,media_url:'/should-not-load.mp4',hls_url:'/api/streams/fixture/master.m3u8'};
   if(c.path.startsWith('/streams/fixture/'))return {fixtureFile:resolve(folder,c.path.slice('/streams/fixture/'.length)),contentType:c.path.endsWith('.ts')?'video/mp2t':'application/vnd.apple.mpegurl'};
  },async(page,calls)=>{
   const codec=await page.evaluate(()=>document.createElement('video').canPlayType('video/mp4; codecs="avc1.42E01E, mp4a.40.2"'));
   if(!codec){t.skip('Chromium uji tidak menyediakan decoder H.264/AAC; jalankan juga pada Chrome/Android');return;}
   await page.waitForFunction(()=>document.querySelector('.post video')?.currentTime>1,{},{timeout:15000});
   assert.equal(await page.locator('.post video').evaluate(v=>v.videoWidth),180);
   assert(calls.some(c=>c.path.endsWith('.ts')));
  });
 }finally{await rm(folder,{recursive:true,force:true});}
});
