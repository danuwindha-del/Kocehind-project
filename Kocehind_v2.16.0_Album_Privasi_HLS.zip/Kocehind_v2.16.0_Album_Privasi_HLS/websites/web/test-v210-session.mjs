import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
const {JSDOM}=createRequire(import.meta.url)('jsdom');
const url=s=>'data:text/javascript;base64,'+Buffer.from(s).toString('base64');
let serial=0;
async function session(){
 const dom=new JSDOM('',{url:'https://web.kocehind.web.id'});
 for(const k of ['window','document','localStorage','CustomEvent','Event','FormData','location'])globalThis[k]=dom.window[k];
 const network=url(await readFile(new URL('../shared/network.js',import.meta.url),'utf8'));
 const legal=url(await readFile(new URL('../shared/legal-state.js',import.meta.url),'utf8'));
 const source=(await readFile(new URL('../shared/api.js',import.meta.url),'utf8')).replace(/['"]\.\/network\.js(?:\?[^'"]*)?['"]/g,JSON.stringify(network)).replace(/['"]\.\/legal-state\.js(?:\?[^'"]*)?['"]/g,JSON.stringify(legal));
 return {dom,api:await import(url(source+'\n//'+serial++))};
}
const response=(status,body)=>({status,ok:status<400,json:async()=>body});
for(const failure of ['transport',503,401,403])test('Actual API refresh preserves recoverable session: '+failure,async()=>{
 const {dom,api}=await session();api.setMe({id:'viewer'});let recovered=false;
 globalThis.fetch=async path=>path.endsWith('/refresh')?(recovered?response(200,{user:{id:'viewer'}}):failure==='transport'?Promise.reject(new TypeError('Failed to fetch')):response(failure,{detail:'Refresh '+failure})):recovered?response(200,{id:'viewer'}):response(401,{detail:'Access expired'});
 await assert.rejects(api.api('/users/me'),e=>e.status===(failure==='transport'?0:failure)&&e.message===(failure==='transport'?'Anda sedang Offline periksa jaringan Anda':'Refresh '+failure));
 assert.equal(api.me?.id,[401,403].includes(failure)?undefined:'viewer');
 recovered=true;assert.equal((await api.api('/users/me')).id,'viewer');dom.window.close();
});
test('Startup restore resolves offline state and recovers on online without a login detour',async()=>{
 const {dom,api}=await session();globalThis.fetch=async()=>{throw new TypeError('Failed to fetch');};
 assert.equal(await api.restore(),null);assert.equal(api.restoreError?.message,'Anda sedang Offline periksa jaringan Anda');
 globalThis.fetch=async()=>response(200,{id:'restored'});window.dispatchEvent(new Event('online'));
 await new Promise(r=>setTimeout(r,10));assert.equal(api.me?.id,'restored');assert.equal(api.restoreError,null);dom.window.close();
});
test('Successful explicit login and logout clear a previous restore failure',async()=>{
 const {dom,api}=await session();globalThis.fetch=async()=>{throw new TypeError('Failed to fetch');};
 await api.restore();assert(api.restoreError);api.setMe({id:'signed-in'});assert.equal(api.restoreError,null);
 await api.restore();assert(api.restoreError);globalThis.fetch=async()=>response(200,{});await api.logout();assert.equal(api.me,null);assert.equal(api.restoreError,null);dom.window.close();
});
test('Admin startup unavailable session offers restoration retry before login',async()=>{
 const html=await readFile(new URL('../admin/index.html',import.meta.url),'utf8');const dom=new JSDOM(html,{url:'https://admin.kocehind.web.id',runScripts:'outside-only'}),w=dom.window;let restored=0;
 w.__deps={me:null,restoreError:new Error('Anda sedang Offline periksa jaringan Anda'),restore:async()=>{restored++;return null;},esc:v=>String(v),icon:()=>'',api:async()=>({})};
 const source=(await readFile(new URL('../admin/admin.js',import.meta.url),'utf8')).replace(/^import\s+\{([^}]+)\}\s+from\s+[^;]+;/gm,'const {$1}=window.__deps;');
 await w.eval('(async()=>{'+source+'})()');assert.match(w.document.querySelector('#content').textContent,/Anda sedang Offline periksa jaringan Anda/);assert(!w.document.querySelector('#login'));w.document.querySelector('#session-retry').click();await new Promise(r=>setTimeout(r,10));assert.equal(restored,2);dom.window.close();
});
test('Startup server failure stays recoverable and an explicit restore retries successfully',async()=>{
 const {dom,api}=await session();api.setMe({id:'viewer'});globalThis.fetch=async()=>response(503,{detail:'Pemeliharaan server'});
 assert.equal((await api.restore()).id,'viewer');assert.equal(api.restoreError.status,503);assert.equal(api.restoreError.message,'Pemeliharaan server');
 globalThis.fetch=async()=>response(200,{id:'viewer'});assert.equal((await api.restore()).id,'viewer');assert.equal(api.restoreError,null);dom.window.close();
});

test('Feed cursor failure resumes once without losing exclusions or query settings',async()=>{
 const {dom,api}=await session(),calls=[];
 globalThis.fetch=async path=>{calls.push(path);return calls.length===1?response(400,{detail:'Feed kedaluwarsa. Muat ulang untuk melanjutkan.'}):response(200,{items:[{id:'next'}]});};
 const page=await api.discovery('/feed?limit=20&cursor=old&seen_ids=first,second&include_live=1');
 assert.equal(page.items[0].id,'next');assert.equal(calls.length,2);
 const url=new URL(calls[1],'https://web.kocehind.web.id');
 assert(!url.searchParams.has('cursor'));assert.equal(url.searchParams.get('seen_ids'),'first,second');assert.equal(url.searchParams.get('include_live'),'1');
 dom.window.close();
});

test('Feed recovery never retries permission denials or loops on a second bad page',async()=>{
 const {dom,api}=await session();let calls=0;
 globalThis.fetch=async()=>{calls++;return response(403,{detail:'Denied'});};
 await assert.rejects(api.discovery('/feed?cursor=old'),e=>e.status===403);assert.equal(calls,1);
 calls=0;globalThis.fetch=async()=>{calls++;return response(400,{detail:'Invalid'});};
 await assert.rejects(api.discovery('/feed?cursor=old'),e=>e.status===400);assert.equal(calls,2);
 dom.window.close();
});
