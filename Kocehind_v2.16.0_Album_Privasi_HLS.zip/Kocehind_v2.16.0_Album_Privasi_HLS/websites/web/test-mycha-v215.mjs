import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {JSDOM} from 'jsdom';
const escape=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pause=()=>new Promise(resolve=>setTimeout(resolve,20));
const source=await readFile(new URL('mycha.js',import.meta.url),'utf8');
const entry={id:'entry',title:'YouTube',summary:'Ringkasan dari sumber yang diperiksa.',images:['https://example.com/image.jpg'],sources:[{url:'https://about.youtube/',label:'YouTube resmi'}],studied_at:'2026-10-31T00:00:00Z'};

function fixture(api){
 const dom=new JSDOM('<main id="root"></main>',{url:'https://web.kocehind.web.id/search?q=youtube',runScripts:'outside-only'});
 dom.window.deps={api,esc:escape,safeUrl:v=>/^https:\/\//.test(v)?v:'',date:v=>v};
 const code=source.replace(/^import[^;]+;/gm,'').replaceAll('export ','');
 const mount=dom.window.eval('(()=>{const {api,esc,safeUrl,date}=window.deps;'+code+';return mountMycha;})()');
 return {dom,root:dom.window.document.querySelector('#root'),mount};
}

test('MychaAI shows sourced overview, images, safe links and expands',async()=>{
 const {root,mount}=fixture(async()=>({items:[entry,{...entry,id:'two',title:'YouTube Studio'}]}));
 await mount(root,'Apa itu YouTube?');
 assert.match(root.textContent,/MychaAI/);assert.match(root.textContent,/YouTube resmi/);
 assert.equal(root.querySelector('img').src,'https://example.com/image.jpg');
 assert.equal(root.querySelector('.mycha-sources a').rel,'noopener noreferrer');
 root.querySelector('button').click();assert.equal(root.querySelector('button').getAttribute('aria-expanded'),'true');
});

test('MychaAI escapes model-source titles, summaries and labels',async()=>{
 const {root,mount}=fixture(async()=>({items:[{...entry,title:'<img src=x onerror=bad()>',summary:'<script>bad()</script>',sources:[{url:'javascript:alert(1)',label:'<b>fake</b>'}],images:[]}]}));
 await mount(root,'unknown');assert.equal(root.querySelector('script'),null);assert.equal(root.querySelector('img'),null);
 assert.equal(root.querySelector('.mycha-sources a').getAttribute('href'),'');
 assert.match(root.textContent,/<script>bad\(\)<\/script>/);
});

test('An unknown subject has an explicit empty state in Tanya',async()=>{
 const {root,mount}=fixture(async()=>({items:[],message:'Belum ada sumber terverifikasi.'}));
 await mount(root,'unknown',{showEmpty:true});assert.match(root.textContent,/Belum ada sumber/);
 await mount(root,'unknown');assert.equal(root.textContent,'');
});

test('MychaAI retries failures without erasing ordinary search results',async()=>{
 let calls=0;const {root,mount}=fixture(async()=>{if(!calls++)throw new Error('offline');return {items:[entry]};});
 await mount(root,'youtube');assert.match(root.textContent,/Coba lagi/);root.querySelector('button').click();await pause();
 assert.match(root.textContent,/Ringkasan dari sumber/);
});

test('A superseded search cannot publish its old MychaAI response',async()=>{
 let resolve;const {root,mount}=fixture(()=>new Promise(r=>resolve=r));let current=true;
 const pending=mount(root,'youtube',{isCurrent:()=>current});current=false;root.textContent='New search';
 resolve({items:[entry]});await pending;assert.equal(root.textContent,'New search');
});

test('Admin can add sourced facts, images, aliases and request study',async()=>{
 const adminSource=(await readFile(new URL('../admin/mycha.js',import.meta.url),'utf8')).replace(/^import[^;]+;/gm,'').replaceAll('export ','');
 const dom=new JSDOM('<main id="root"></main>',{url:'https://admin.kocehind.web.id/#mycha',runScripts:'outside-only'}),w=dom.window,calls=[];
 w.deps={esc:escape,safeUrl:v=>v,date:v=>v,toast:()=>{},busy:()=>{},api:async(path,options={})=>{calls.push({path,options});if(options.method==='POST')return {id:'new'};return {items:[],next_offset:null,provider_configured:true,thresholds:{followers:1000,posts:5,engaged_users:100,age_days:30}};},openDialog:(title,html)=>{const d=w.document.createElement('dialog');d.innerHTML=html;d.close=()=>d.remove();w.document.body.append(d);return d;}};
 const mount=w.eval('(()=>{const {api,esc,date,openDialog,toast,busy,safeUrl}=window.deps;'+adminSource+';return mountMychaAdmin;})()');
 await mount(w.document.querySelector('#root'));w.document.querySelector('[data-new]').click();
 const form=w.document.querySelector('form');
 for(const [name,value] of Object.entries({title:'YouTube',aliases:'youtube, yt',fact_text:entry.summary,fact_url:'https://about.youtube/',fact_label:'YouTube resmi',images:'https://example.com/image.jpg',reason:'Sumber resmi sudah diperiksa'}))form.elements[name].value=value;
 form.dispatchEvent(new w.Event('submit',{cancelable:true}));await pause();
 const saved=calls.find(c=>c.path==='/admin/mycha'&&c.options.method==='POST');
 assert.equal(saved.options.body.facts[0].url,'https://about.youtube/');assert.equal(saved.options.body.images.length,1);
 assert.deepEqual(JSON.parse(JSON.stringify(saved.options.body.aliases)),['youtube','yt']);
});
