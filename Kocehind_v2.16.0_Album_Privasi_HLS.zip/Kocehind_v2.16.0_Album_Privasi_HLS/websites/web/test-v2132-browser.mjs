import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile,mkdir} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {createRequire} from 'node:module';
const {chromium}=createRequire(import.meta.url)('playwright');
const sites=resolve(new URL('..',import.meta.url).pathname);
const viewer={id:'v',username:'viewer',name:'Viewer',legal_required:false};
const creator={id:'c',username:'creator',name:'Creator'};
const host={id:'h',username:'host',name:'Host',avatar_url:'/shared/logo.png',legal_required:false};
const people=[host,...Array.from({length:8},(_,i)=>({id:'g'+i,username:'guest'+i,name:'Guest '+i}))].map((m,i)=>({...m,role:i?'speaker':'host',connected:true}));
const sdk=`
export const RoomEvent={TrackSubscribed:'track',TrackUnsubscribed:'untrack',Disconnected:'disconnect',Reconnecting:'reconnecting',Reconnected:'connected'};
function participant(id){const track={attach(){const v=document.createElement('video');v.dataset.track=id;return v;},detach(v){return v?[v]:[];}};return {identity:id,isSpeaking:false,videoTrackPublications:new Map([['camera',{track,trackSid:id,isMuted:false}]]),async setCameraEnabled(){window.cameraCalls=(window.cameraCalls||0)+1;},async setMicrophoneEnabled(){},async unpublishTrack(){}};}
export class Room{constructor(){this.state='connected';this.localParticipant=participant(window.fixtureUser);this.remoteParticipants=new Map(${JSON.stringify(people)}.filter(p=>p.id!==window.fixtureUser).map(p=>[p.id,participant(p.id)]));}on(){return this;}async connect(){window.rtcConnects=(window.rtcConnects||0)+1;}async disconnect(){}async startAudio(){}}
`;

async function fixture(handle,mode='web'){
 const server=createServer(async(req,res)=>{
  try{
   const url=new URL(req.url,'http://fixture');
   if(url.pathname==='/shared/livekit.js'){res.writeHead(200,{'content-type':'text/javascript'});res.end(sdk);return;}
   if(url.pathname.startsWith('/api/')){
    let text='';for await(const part of req)text+=part;
    const result=await handle({path:url.pathname.slice(4),query:url.searchParams,method:req.method,body:text&&!req.headers['content-type']?.includes('multipart/')?JSON.parse(text):null,user:req.headers['x-fixture-user']||'v'});
    res.writeHead(Number.isInteger(result?.status)?result.status:200,{'content-type':'application/json'});res.end(JSON.stringify(result?.data??result??{}));return;
   }
   if(url.pathname.endsWith('.mp4')){res.writeHead(200,{'content-type':'video/mp4'});res.end();return;}
   const relative=url.pathname.startsWith('/shared/')?url.pathname.slice(1):mode==='main'?'main/'+(url.pathname==='/'?'index.html':url.pathname.slice(1).replace(/^(kontak|pembayaran)$/,'$1.html')):/\.(js|css)$/.test(url.pathname)?'web'+url.pathname:'web/index.html';
   const path=resolve(sites,relative);if(!path.startsWith(sites+'/'))throw Error('path');
   const bytes=await readFile(path);res.writeHead(200,{'content-type':({'.js':'text/javascript','.css':'text/css','.html':'text/html'}[extname(path)]||'application/octet-stream')});res.end(bytes);
  }catch(e){res.writeHead(404);res.end('missing');}
 });
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 return {url:'http://127.0.0.1:'+server.address().port,close:()=>new Promise(r=>server.close(r))};
}
const launch=()=>chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE,args:['--no-sandbox']});


const other={...host,id:'other',username:'other',name:'Other'};
const recap={total_gifts:5,total_coins:75,income_rupiah:7250,top_senders:[{id:'s',rank:1,username:'supporter',name:'Supporter',coins:75,gift_count:5}]};
const fallback={items:[],next_cursor:null,next_offset:null,cursor:0};
function handler(){let ended=false;const room=()=>({id:'room',title:'Ringkasan pengujian',mode:'camera',together:false,seats:9,status:ended?'ended':'active',host,role:'host',members:[people[0]],layout:{version:0,slots:['h']},overlays:{version:0,items:[]},likes:2,total_viewers:4,peak_viewers:3,duration_seconds:120,capabilities:{},...(ended?{gift_summary:recap}:{})});return r=>{if(r.path==='/users/me')return host;if(r.path==='/users/host')return host;if(r.path==='/users/other')return other;if(r.path.endsWith('/join'))return {url:'wss://fixture',token:'fixture',role:'host',room:room()};if(r.path.endsWith('/end')){ended=true;return room();}if(r.path==='/live/rooms/room'||r.path.endsWith('/heartbeat'))return room();if(r.path==='/users/me/privacy')return {revision:'fixed'};return fallback;};}
test('Homepage is public, uses current catalog prices, and fits mobile and desktop',async()=>{
 const f=await fixture(r=>r.path==='/coins/packages'?{items:[{id:'coin_100',name:'100 Koin',coins:100,price:12500},{id:'coin_500',name:'500 Koin',coins:500,price:50000}]}:fallback,'main');const b=await launch(),p=await b.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
 try{for(const width of [360,1440]){await p.setViewportSize({width,height:900});await p.goto(f.url+'/');await p.locator('.coin-package').first().waitFor();assert.equal(new URL(p.url()).pathname,'/');assert.match(await p.locator('#coin-packages').innerText(),/12.500/);assert.equal(await p.locator('meta[http-equiv=refresh]').count(),0);assert(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));}for(const path of ['/kontak','/pembayaran']){await p.goto(f.url+path);assert(await p.locator('h1').isVisible());}assert.deepEqual(errors,[]);}finally{await b.close();await f.close();}
});
test('Unavailable product catalog keeps honest fallback and checkout link',async()=>{
 const f=await fixture(()=>({status:503,data:{detail:'temporary'}}),'main'),b=await launch(),p=await b.newPage();try{await p.goto(f.url+'/');await p.locator('#coin-packages[aria-busy=false]').waitFor();assert.match(await p.locator('#coin-packages').innerText(),/belum dapat dimuat/);assert.equal(await p.locator('#coin-packages a').getAttribute('href'),'https://web.kocehind.web.id/coins');}finally{await b.close();await f.close();}
});
test('Own and visited profile photos open large uncropped previews and close',async()=>{
 const f=await fixture(handler()),b=await launch(),p=await b.newPage({viewport:{width:390,height:844}}),errors=[];p.on('pageerror',e=>errors.push(e.message));try{for(const name of ['host','other']){await p.goto(f.url+'/@'+name);await p.locator('#profile-photo').click();await p.locator('dialog.profile-photo-dialog img').waitFor();assert.match(await p.locator('dialog h2').innerText(),new RegExp('@'+name));assert.equal(await p.locator('dialog img').evaluate(e=>getComputedStyle(e).objectFit),'contain');await p.locator('dialog .close').click();await p.locator('dialog').waitFor({state:'detached'});}assert.deepEqual(errors,[]);}finally{await b.close();await f.close();}
});
test('Ending LIVE displays receipt totals, earned IDR and top contributors without stale stage callbacks',async()=>{
 const f=await fixture(handler()),b=await launch(),p=await b.newPage({viewport:{width:390,height:844}}),errors=[];p.on('pageerror',e=>errors.push(e.message));try{await p.addInitScript(()=>window.fixtureUser='h');await p.goto(f.url+'/live/room');await p.locator('#live-leave').click();await p.locator('#confirm-end').click();await p.locator('.live-gift-summary').waitFor();assert.match(await p.locator('.live-gift-summary').innerText(),/7.250/);assert.match(await p.locator('.top-gift-senders').innerText(),/@supporter/);assert(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));assert.deepEqual(errors,[]);}finally{await b.close();await f.close();}
});
