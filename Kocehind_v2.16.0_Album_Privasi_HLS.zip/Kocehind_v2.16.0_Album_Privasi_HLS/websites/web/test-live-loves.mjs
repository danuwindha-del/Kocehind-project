// Run: node websites/web/test-live-loves.mjs (Node 20+). No browser/SFU required.
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {webcrypto} from 'node:crypto';
globalThis.crypto??=webcrypto;
const source=await readFile(new URL('./live-loves.js',import.meta.url),'utf8');
const {LiveLoves}=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
let calls=[],attempt=0;
const loves=new LiveLoves(async(n,id)=>{calls.push({n,id});if(!attempt++)throw Error('lost response');return {likes:15,credited:0,duplicate:true};},()=>{},10);
for(let i=0;i<5;i++)loves.tap();assert.equal(loves.total,15);
await loves.flush();loves.update(15);assert.equal(loves.total,15);await loves.flush();assert.equal(calls[0].id,calls[1].id);assert.equal(loves.total,15);
for(let i=0;i<1000;i++)loves.tap();assert.equal(loves.queued+loves.inflight,100);
let resolve;const pending=new Promise(r=>resolve=r);let sent=0;
const concurrent=new LiveLoves(async(n)=>{sent++;assert.equal(n,20);return pending;},()=>{});
for(let i=0;i<30;i++)concurrent.tap();const first=concurrent.flush();await concurrent.flush();assert.equal(sent,1);resolve({likes:20});await first;assert.equal(concurrent.total,30);
concurrent.dispose();loves.dispose();console.log('Web love batching: lost-response retry, reconciliation, quota and serialization passed.');
