/* Media bytes live in a tab-scoped cache, never in a shared offline library. */
const prefix='kocehind-video-session-';
const sessions=new Map(),pending=new Map(),windows=new Map();
self.addEventListener('install',event=>event.waitUntil(self.skipWaiting()));
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
const canonical=url=>{const u=new URL(url);u.searchParams.delete('media_token');return u.href;};
const allowed=url=>{const u=new URL(url,self.location.origin);return u.origin===self.location.origin&&u.pathname.startsWith('/api/media/');};

async function store(client,url){
 const name=sessions.get(client);if(!name||!allowed(url))return null;
 const key=canonical(url),id=name+'|'+key;
 const cache=await caches.open(name),hit=await cache.match(key);
 if(hit)return hit;
 if(pending.has(id)){await pending.get(id);return cache.match(key);}
 const task=(async()=>{
  const response=await fetch(url,{credentials:'same-origin',cache:'no-store',redirect:'error'});
  if(!response.ok||Number(response.headers.get('content-length')||0)>100*1024*1024)throw Error('Media unavailable');
  if(sessions.get(client)!==name)return;
  await cache.put(key,response);
  if(sessions.get(client)!==name)await caches.delete(name);
 })();
 pending.set(id,task);
 try{await task;return cache.match(key);}finally{pending.delete(id);}
}

async function cachedRange(request,response){
 const range=request.headers.get('range');
 if(!range)return response;
 const blob=await response.blob(),match=/^bytes=(\d*)-(\d*)$/.exec(range);
 if(!match||(!match[1]&&!match[2]))return new Response(null,{status:416,headers:{'Content-Range':'bytes */'+blob.size}});
 const start=match[1]?Number(match[1]):Math.max(0,blob.size-Number(match[2]));
 const end=match[1]&&match[2]?Math.min(blob.size-1,Number(match[2])):blob.size-1;
 if(start>end||start>=blob.size)return new Response(null,{status:416,headers:{'Content-Range':'bytes */'+blob.size}});
 const headers=new Headers(response.headers);headers.set('Content-Range',`bytes ${start}-${end}/${blob.size}`);
 headers.set('Content-Length',String(end-start+1));headers.set('Accept-Ranges','bytes');headers.set('Cache-Control','no-store');
 return new Response(blob.slice(start,end+1,blob.type),{status:206,headers});
}

self.addEventListener('fetch',event=>{
 const request=event.request,name=sessions.get(event.clientId);
 if(request.method!=='GET'||!name||!allowed(request.url))return;
 event.respondWith((async()=>{
  const cache=await caches.open(name),key=canonical(request.url),id=name+'|'+key;
  let hit=await cache.match(key);
  if(!hit&&pending.has(id)){await pending.get(id).catch(()=>{});hit=await cache.match(key);}
  if(hit){
   // Every cached activation/range still checks current block/ban/privacy at
   // the server. HEAD transfers no video bytes and cannot expose stale access.
   const check=await fetch(request.url,{method:'HEAD',credentials:'same-origin',cache:'no-store',redirect:'error'});
   if(!check.ok){await cache.delete(key);return check;}
   return cachedRange(request,hit);
  }
  // Stream the first response immediately while a clone fills the disk cache.
  const headers=new Headers(request.headers);headers.delete('range');
  const response=await fetch(new Request(request,{headers,cache:'no-store',redirect:'error'}));
  if(response.ok&&response.status===200){
   const copy=response.clone();
   const task=cache.put(key,copy).then(async()=>{if(sessions.get(event.clientId)!==name)await caches.delete(name);});
   pending.set(id,task);
   event.waitUntil(task.catch(()=>{}).finally(()=>pending.delete(id)));
  }
  return response;
 })().catch(()=>fetch(request)));
});

self.addEventListener('message',event=>{
 const client=event.source?.id;if(!client)return;
 const data=event.data||{};
 event.waitUntil((async()=>{
  if(data.type==='clear'){
   const old=sessions.get(client);sessions.delete(client);windows.delete(client);if(old)await caches.delete(old);return;
  }
  if(!['init','warm'].includes(data.type)||typeof data.session!=='string')return;
  const name=prefix+client+'-'+data.session;
  const previous=sessions.get(client);sessions.set(client,name);
  if(previous&&previous!==name)await caches.delete(previous);
  const active=new Set((await self.clients.matchAll({type:'window'})).map(c=>prefix+c.id+'-'));
  for(const key of await caches.keys())if(key.startsWith(prefix)&&![...active].some(p=>key.startsWith(p)))await caches.delete(key);
  if(data.type==='init')return;
  const window={};windows.set(client,window);
  // At most three upcoming videos. Sequential prefetch leaves the foreground
  // player its own connection and avoids a burst of decoders/downloads.
  for(const url of (data.urls||[]).slice(0,3)){
   if(sessions.get(client)!==name||windows.get(client)!==window)return;
   try{await store(client,url);}catch{/* Normal playback can retry. */}
  }
 })());
});
