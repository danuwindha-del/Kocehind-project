// Retain the same ID after a lost response so a retry cannot duplicate credits.
export class LiveLoves {
 constructor(send,onChange,total=0){this.send=send;this.onChange=onChange;this.server=total;this.base=total;this.queued=0;this.inflight=0;this.batch=null;this.busy=false;this.disposed=false;}
 get total(){return Math.max(this.server,this.base+this.queued+this.inflight);}
 notify(){if(!this.disposed)this.onChange(this.total);}
 update(n){this.server=Math.max(this.server,n);this.notify();}
 tap(){if(this.disposed||this.queued+this.inflight>=100)return;if(!this.queued&&!this.inflight)this.base=this.server;this.queued++;this.notify();}
 async flush(){if(this.busy||(!this.queued&&!this.inflight))return;this.busy=true;if(!this.inflight){this.inflight=Math.min(20,this.queued);this.queued-=this.inflight;this.batch=crypto.randomUUID();}try{const r=await this.send(this.inflight,this.batch);this.server=Math.max(this.server,r.likes);this.base=Math.max(this.base,r.likes);this.inflight=0;this.batch=null;}catch{}finally{this.busy=false;this.notify();}}
 dispose(){this.disposed=true;}
}
