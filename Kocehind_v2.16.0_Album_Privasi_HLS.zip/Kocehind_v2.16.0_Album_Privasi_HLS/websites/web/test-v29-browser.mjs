import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {createRequire} from 'node:module';
const {chromium}=createRequire(import.meta.url)('playwright');
const sites=resolve(new URL('..',import.meta.url).pathname);

async function scenario(mode,run){
 const calls=[];
 let decision={id:'case-1',target_type:'post',target_id:'post-1',user_id:'owner',status:'removed',
   rule:'Konten ketelanjangan seksual tidak diizinkan. Konteks ditinjau saat banding.',policy_version:1,
   score:.99,threshold:.95,model:'OpenNSFW2',model_sha256:'a'.repeat(64),appeal_text:'',resolution:'',
   created_at:'2026-10-22T00:00:00Z',appeal_deadline:'2026-11-05T00:00:00Z',can_appeal:true};
 let ticket={id:'ticket-1',subject:'Kendala kamera LIVE',category:'live',status:'open',user_id:'owner',
   updated_at:'2026-10-22T00:00:00Z',messages:[{id:'m1',staff:false,body:'Kamera tidak muncul.',created_at:'2026-10-22T00:00:00Z'}]};
 let made=false;
 let policy={enabled:true,version:1,threshold:.95,consecutive_frames:3,sample_seconds:.5,appeal_days:14,
   rule:decision.rule,video_worker_ready:true,live_worker_ready:true};
 const server=createServer(async(req,res)=>{
  const url=new URL(req.url,'http://localhost');
  if(url.pathname.startsWith('/api/')){
   let input='';for await(const part of req)input+=part;const body=input?JSON.parse(input):{};
   const path=url.pathname.slice(4);calls.push({path,method:req.method,body});let data={};
   if(path==='/support/tickets'&&req.method==='POST'){ticket={...ticket,...body};made=true;data=ticket;}
   else if(path==='/support/tickets')data={items:made?[ticket]:[],next_offset:null};
   else if(path==='/support/tickets/ticket-1/messages'){ticket.messages.push({id:'m2',staff:false,body:body.message});data=ticket;}
   else if(path==='/support/tickets/ticket-1/status'){ticket.status=body.status;data=ticket;}
   else if(path==='/support/tickets/ticket-1')data=ticket;
   else if(path==='/moderation/uploads')data={items:[],next_offset:null};
   else if(path==='/moderation/cases')data={items:[decision],next_offset:null};
   else if(path==='/moderation/cases/case-1/appeal'){decision={...decision,status:'appealed',can_appeal:false,appeal_text:body.message};data=decision;}
   else if(path==='/moderation/cases/case-1')data=decision;
   else if(path==='/admin/moderation/policy'&&req.method==='PUT'){policy={...policy,...body,version:policy.version+1};data=policy;}
   else if(path==='/admin/moderation/policy')data=policy;
   else if(path==='/admin/moderation/jobs')data={items:[],next_offset:null};
   else if(path==='/admin/moderation/cases')data={items:[decision],total:1};
   else if(path==='/admin/moderation/cases/case-1/evidence')data=decision;
   else if(path==='/admin/moderation/cases/case-1/decision'){decision={...decision,status:'restored',resolution:body.reason};data=decision;}
   else if(path==='/admin/support/tickets')data={items:[ticket],total:1};
   else if(path==='/admin/support/tickets/ticket-1')data=ticket;
   else if(path==='/admin/support/tickets/ticket-1/messages'){ticket={...ticket,status:body.status,messages:[...ticket.messages,{staff:true,body:body.message}]};data=ticket;}
   res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(data));return;
  }
  if(url.pathname==='/'){
   res.writeHead(200,{'content-type':'text/html'});
   res.end(`<!doctype html><html><meta name="viewport" content="width=device-width"><link rel="stylesheet" href="/shared/base.css"><link rel="stylesheet" href="/web/app.css"><body><main id="root" style="max-width:800px;margin:20px auto;padding:15px"></main><script type="module">
    import {setMe} from '/shared/api.js?v=2.9.0';
    import {mountHelp,mountCases} from '/web/trust.js?v=2.9.0';
    import {mountSafety,mountSupport} from '/admin/trust.js?v=2.9.0';
    setMe({id:'owner',username:'owner',is_admin:true,legal_required:false});
    const root=document.querySelector('#root');
    const go=async path=>{history.pushState({},'',path);await(path.startsWith('/help')?mountHelp(root,path,go):mountCases(root,path,go));};
    document.addEventListener('click',e=>{const a=e.target.closest('a[data-link]');if(a){e.preventDefault();go(a.getAttribute('href'));}});
    await (${JSON.stringify(mode)}==='safety'?mountSafety(root):${JSON.stringify(mode)}==='staff'?mountSupport(root):${JSON.stringify(mode)}==='case'?go('/moderation/case-1'):go('/help'));
    window.ready=true;
   </script></body></html>`);return;
  }
  const path=resolve(sites,url.pathname.slice(1));if(!path.startsWith(sites+'/')){res.writeHead(404).end();return;}
  try{const bytes=await readFile(path);res.writeHead(200,{'content-type':extname(path)==='.js'?'text/javascript':'text/css'});res.end(bytes);}catch{res.writeHead(404).end();}
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 let browser;
 try{
  browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE,args:['--no-sandbox']});
  const page=await browser.newPage({viewport:{width:390,height:844}});page.setDefaultTimeout(5000);
  const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://127.0.0.1:'+server.address().port);await page.waitForFunction(()=>window.ready);
  await run(page,calls);assert.deepEqual(errors,[]);
 }finally{if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));}
}

test('Help ticket create, private thread, close and reopen fit a phone',()=>scenario('help',async(page,calls)=>{
 await page.locator('[data-new-ticket] [name=subject]').fill('Kamera LIVE tidak muncul');
 await page.locator('[data-new-ticket] [name=message]').fill('Saya sudah mengizinkan kamera tetapi tidak tampil.');
 await page.getByRole('button',{name:'Kirim tiket',exact:true}).click();
 await page.waitForURL('**/help/ticket-1');await page.locator('[data-reply]').waitFor();
 await page.locator('[data-reply] textarea').fill('Saya menggunakan aplikasi Android terbaru.');
 await page.getByRole('button',{name:'Kirim',exact:true}).click();
 await page.getByRole('button',{name:'Tutup tiket',exact:true}).click();
 await page.getByRole('button',{name:'Buka kembali tiket',exact:true}).waitFor();
 assert(calls.some(x=>x.path==='/support/tickets'&&x.body.subject==='Kamera LIVE tidak muncul'));
 assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
}));

test('Removal notice has its own actionable appeal and renders submitted markup as text',()=>scenario('case',async(page,calls)=>{
 await page.locator('textarea[name=message]').fill('Konteks video aman <img src=x onerror="window.pwned=true">. Mohon diperiksa.');
 await page.getByRole('button',{name:'Ajukan banding',exact:true}).click();
 await page.getByText('Banding ditinjau',{exact:false}).waitFor();
 assert(calls.some(x=>x.path==='/moderation/cases/case-1/appeal'));
 assert.equal(await page.evaluate(()=>window.pwned),undefined);
}));

test('Administrator changes policy and resolves a moderation decision',()=>scenario('safety',async(page,calls)=>{
 await page.locator('[data-policy] [name=reason]').fill('Kalibrasi berdasarkan sampel lokal.');
 await page.getByRole('button',{name:'Simpan aturan',exact:true}).click();
 await page.getByText('Versi 2',{exact:false}).waitFor();
 await page.getByRole('button',{name:'Tinjau keputusan',exact:true}).click();
 await page.locator('[data-review] textarea[name=reason]').fill('Peninjauan manusia memastikan konten tidak melanggar.');
 await page.getByRole('button',{name:'Simpan keputusan',exact:true}).click();
 await page.waitForFunction(()=>document.body.textContent.includes('Dipulihkan'));
 assert(calls.some(x=>x.path.endsWith('/decision')&&x.body.action==='restore'));
}));

test('Administrator replies to a support ticket with a visible status',()=>scenario('staff',async(page,calls)=>{
 await page.getByRole('button',{name:'Buka percakapan',exact:true}).click();
 await page.locator('[data-thread] textarea').fill('Periksa izin kamera, lalu buka ulang aplikasi.');
 await page.getByRole('button',{name:'Kirim balasan',exact:true}).click();
 await page.locator('[data-thread] .panel-body > p').filter({hasText:'Menunggu pengguna'}).waitFor();
 assert(calls.some(x=>x.path.endsWith('/messages')&&x.body.status==='waiting_user'));
}));
