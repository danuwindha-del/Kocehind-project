import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {JSDOM} from 'jsdom';

const settle = () => new Promise(resolve => setTimeout(resolve, 20));
const esc = value => String(value ?? '').replace(/[&<>"']/g,
  character => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[character]));
const announcement = (id, title = 'Pengumuman ' + id) => ({
  id, title, summary: 'Informasi resmi untuk pengguna', category: 'information',
  published_at: '2026-10-30T00:00:00Z', read: false, blocks: [{type: 'text', text: 'Isi pengumuman'}],
});

async function officialFixture(api) {
  const dom = new JSDOM('<main id="official"></main>', {
    url: 'https://web.kocehind.web.id/inbox?tab=official', runScripts: 'outside-only',
  });
  const {window} = dom;
  const mediaSource = (await readFile(new URL('../shared/official-content.js', import.meta.url), 'utf8'))
    .replaceAll('export ', '');
  const content = window.eval('(() => {' + mediaSource + ';return {officialBlocksHTML,officialCategories,bindOfficialMedia};})()');
  const navigations = [], notifications = [];
  window.__deps = {api, badge: () => '', esc, date: value => value || '', toast: message => notifications.push(message), ...content};
  const source = (await readFile(new URL('official.js', import.meta.url), 'utf8'))
    .replace(/^import\s+\{([^}]+)\}\s+from\s+[^;]+;/gm, 'const {$1}=window.__deps;')
    .replaceAll('export ', '');
  const mount = window.eval('(() => {' + source + ';return mountOfficial;})()');
  const root = window.document.querySelector('#official');
  return {dom, window, root, navigations, notifications,
    mount: () => mount(root, null, destination => navigations.push(destination))};
}

test('Official inbox renders the canonical backend list response and paginates unique announcements', async () => {
  const calls = [];
  const fixture = await officialFixture(async path => {
    calls.push(path);
    return path.includes('offset=0')
      ? {items: [announcement('one', '<script>literal title</script>')], next_offset: 1, unread: 2}
      : {items: [announcement('one'), announcement('two')], next_offset: null, unread: 2};
  });
  try {
    await fixture.mount();
    assert.equal(fixture.root.querySelectorAll('[data-official]').length, 1);
    assert.equal(fixture.root.querySelector('script'), null);
    assert.match(fixture.root.textContent, /<script>literal title<\/script>/);
    fixture.root.querySelector('[data-more]').click();
    await settle();
    assert.deepEqual(calls, ['/official/activities?offset=0&limit=30', '/official/activities?offset=1&limit=30']);
    assert.equal(fixture.root.querySelectorAll('[data-official]').length, 2);
    assert.equal(fixture.root.querySelector('[data-more]'), null);
    fixture.root.querySelector('[data-official="two"]').click();
    assert.deepEqual(fixture.navigations, ['/inbox?tab=official&activity=two']);
  } finally {fixture.dom.window.close();}
});

test('An empty canonical official inbox has a real empty state without a pagination button', async () => {
  const fixture = await officialFixture(async () => ({items: [], next_offset: null, unread: 0}));
  try {
    await fixture.mount();
    assert.match(fixture.root.textContent, /Belum ada kabar dari Kocehind/);
    assert.equal(fixture.root.querySelector('[data-more]'), null);
  } finally {fixture.dom.window.close();}
});

for (const malformed of [{}, {detail: 'Server tidak merespons dengan benar'}, {items: null}, {items: {}}]) {
  test('A malformed successful official response displays a recoverable error: ' + JSON.stringify(malformed), async () => {
    let attempts = 0;
    const fixture = await officialFixture(async () => ++attempts === 1
      ? malformed : {items: [announcement('recovered')], next_offset: null, unread: 1});
    try {
      await fixture.mount();
      assert.doesNotMatch(fixture.root.textContent, /Cannot read|filter|Belum ada kabar dari Kocehind/);
      const retry = fixture.root.querySelector('[data-official-retry]');
      assert(retry, 'The official inbox needs an inline retry action after a malformed response');
      assert.match(fixture.root.textContent, /belum dapat|tidak valid|tidak merespons/i);
      retry.click();
      await settle();
      assert.equal(attempts, 2);
      assert.equal(fixture.root.querySelector('[data-official="recovered"]')?.textContent.includes('recovered'), true);
      assert.equal(fixture.root.querySelector('[data-official-retry]'), null);
    } finally {fixture.dom.window.close();}
  });
}

test('A transient official API error stays inside the inbox and retry loads the same page', async () => {
  let attempts = 0;
  const fixture = await officialFixture(async () => {
    if (++attempts === 1) throw new Error('Server sementara belum dapat dihubungi');
    return {items: [announcement('connected')], next_offset: null, unread: 1};
  });
  try {
    await fixture.mount();
    assert.match(fixture.root.textContent, /Server sementara belum dapat dihubungi/);
    const retry = fixture.root.querySelector('[data-official-retry]');
    assert(retry);
    retry.click();
    await settle();
    assert.equal(fixture.root.querySelectorAll('[data-official]').length, 1);
    assert.equal(attempts, 2);
  } finally {fixture.dom.window.close();}
});
