import {installV216Deps} from './v216-test-deps.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
import {VideoCollection,MixedCollection} from './collections.js';
import {createPlaybackSignals,richText,visibilityOptions,visibilityNames,mountWatchHistory} from './v27.js';
const {JSDOM}=createRequire(import.meta.url)('jsdom');
const settle=()=>new Promise(r=>setTimeout(r,25));
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const post=id=>({id,kind:'image',caption:'Kopi '+id,media_url:'https://example.com/'+id+'.jpg',thumbnail_url:'https://example.com/'+id+'.jpg',views:125,visibility:'public',author:{id:'owner',username:'kreator',name:'Kreator'},likes:0,comments:0});
async function app(path,api,overrides={}){
 const html=(await readFile(new URL('./index.html',import.meta.url),'utf8')).replace(/<script[^>]*>.*?<\/script>/g,'');
 const dom=new JSDOM(html,{url:'https://web.kocehind.web.id'+path,runScripts:'outside-only'}),w=dom.window;
 w.__livePaths=[];w.__observers=[];w.IntersectionObserver=class{constructor(callback,options){this.callback=callback;this.options=options;this.targets=[];w.__observers.push(this);}observe(node){this.targets.push(node);}disconnect(){}emit(node,visible){this.callback([{target:node,isIntersecting:visible,intersectionRatio:visible?1:0}]);}};Object.defineProperty(w.HTMLElement.prototype,'offsetTop',{get(){return this.classList.contains('collection-entry')?[...this.parentElement.children].indexOf(this)*600:0;}});w.CSS={escape:v=>v};w.setInterval=()=>0;w.clearInterval=()=>{};
 const me={id:'viewer',username:'viewer',name:'Viewer',legal_required:false};
 w.__deps={api,me,restore:async()=>me,setMe:()=>{},logout:async()=>{},authDialog:async()=>true,requireAccount:async()=>true,requireLegalAcceptance:async()=>true,esc,safeUrl:v=>v,count:n=>String(n||0),date:v=>String(v||''),badge:()=>'',avatar:()=>'<span class="avatar">K</span>',icon:()=>'<svg></svg>',toast:()=>{},openDialog:(title,html)=>{const d=w.document.createElement('dialog');d.innerHTML=html;d.open=true;d.close=()=>{d.open=false;d.remove();};w.document.body.append(d);return d;},busy:()=>{},legalLinks:'',VideoCollection,MixedCollection,createPlaybackSignals,richText,visibilityOptions,visibilityNames,loadCommentTarget:()=>{},mountStudio:()=>{},mountWatchHistory,mountHelp:()=>{},mountCases:()=>{},mountOfficial:()=>{},mountLive:(_root,path)=>{w.__livePaths.push(path);return ()=>{};},previewHTML:l=>`<article class="live-preview-card" data-live="${l.id}"><a href="/live/${l.id}" data-link>LIVE ${l.title}</a></article>`,bindPreviews:()=>()=>{},...overrides};
 const errors=[];w.addEventListener('error',e=>errors.push(e.message));
 const source=(await readFile(new URL('./app.js',import.meta.url),'utf8')).replace(/^import\s+\{([^}]+)\}\s+from\s+[^;]+;/gm,'const {$1}=window.__deps;');
 await installV216Deps(w);w.eval(source);await settle();return {dom,w,errors};
}


test('Verified badge uses accessible Material-style SVG and unverified accounts get none',async()=>{
 const source=await readFile(new URL('../shared/api.js',import.meta.url),'utf8');
 const line=source.split('\n').find(s=>s.startsWith('export const badge='));
 const badge=Function(line.replace('export const badge=','return '))();
 const dom=new JSDOM('<main>'+badge({is_verified:true})+badge({is_verified:false})+'</main>');
 const badgeNode=dom.window.document.querySelector('.verified');
 assert.equal(dom.window.document.querySelectorAll('.verified').length,1);
 assert.equal(badgeNode.getAttribute('role'),'img');
 assert.equal(badgeNode.getAttribute('aria-label'),'Akun terverifikasi');
 assert.equal(badgeNode.querySelectorAll('svg path').length,2);
 assert.equal(badgeNode.textContent,'');dom.window.close();
});
for(const n of [0,1,3])test('Owner profile renders '+n+' visitor avatars and private paged list',async()=>{
 const calls=[],visitors=Array.from({length:n},(_,i)=>({id:'g'+i,username:'guest'+i,name:'Guest '+i,visited_at:'2026-10-23T00:00:00Z',new:true}));
 const page={items:visitors,total:n,unread:n,next_offset:null,seen_through:n?'2026-10-23T00:00:00Z':null};
 const {dom,w,errors}=await app('/@viewer',async(path,options={})=>{
  calls.push({path,...options});
  if(path==='/users/viewer')return {id:'viewer',username:'viewer',name:'Viewer',followers:0,following_count:0,likes_received:0};
  if(path.startsWith('/users/viewer/posts'))return {items:[],next_offset:null};
  if(path.startsWith('/users/me/profile-visits'))return page;
  return {items:[],unread:0};
 });
 assert.equal(w.document.querySelectorAll('#profile-visitors .avatar').length,n);
 if(!n)assert.match(w.document.querySelector('#profile-visitors').textContent,/Belum ada pengunjung/);
 assert(!calls.some(c=>c.path.endsWith('/visit')));
 w.document.querySelector('.profile-visitors-button').click();await settle();
 assert.equal(w.document.querySelectorAll('dialog .visitor-list a').length,n);
 assert.equal(calls.some(c=>c.path.endsWith('/profile-visits/read')),n>0);
 assert.deepEqual(errors,[]);dom.window.close();
});
test('Opening another profile explicitly records a visit only after profile loads',async()=>{
 const calls=[];
 const {dom,w,errors}=await app('/@guest',async(path,options={})=>{
  calls.push({path,...options});
  if(path==='/users/guest')return {id:'guest',username:'guest',name:'Guest'};
  if(path.startsWith('/users/guest/posts'))return {items:[],next_offset:null};
  return {items:[],unread:0};
 });
 assert(calls.some(c=>c.path==='/users/guest/visit'&&c.method==='POST'));
 assert.equal(w.document.querySelector('#profile-visitors'),null);
 assert.deepEqual(errors,[]);dom.window.close();
});
for(const type of ['post','live'])test('Inbox renders clickable '+type+' preview and disables revoked cards',async()=>{
 const id='f03461bb-2de8-4f5c-8d6d-bf96b15a17f2';
 const {dom,w,errors}=await app('/inbox?tab=messages&chat=host',async path=>{
  if(path==='/chats')return {items:[{username:'host',last_message:'Video',status:'accepted'}],requests:[]};
  if(path==='/chats/host')return {status:'accepted',can_send:true,items:[
   {body:'Lihat https://kocehind.web.id/video/'+id,attachment:{type,id,available:true,title:'Preview <script>alert(1)</script>',username:'host'}},
   {body:'old link',attachment:{type,id:'gone',available:false,title:'Konten tidak tersedia'}}
  ]};
  if(path.startsWith('/posts/'))return post(id);
  return {items:[],unread:0};
 });
 assert.equal(w.document.querySelectorAll('.shared-card').length,2);
 assert.equal(w.document.querySelectorAll('a.shared-card').length,1);
 assert.equal(w.document.querySelector('.messages script'),null);
 assert(!w.document.querySelector('.messages').textContent.includes('https://'));
 const card=w.document.querySelector('a.shared-card');assert.equal(card.getAttribute('href'),(type==='live'?'/live/':'/video/')+id);
 card.click();await settle();assert.equal(w.location.pathname,(type==='live'?'/live/':'/video/')+id);
 if(type==='live')assert.equal(w.__livePaths[0],'/live/'+id);
 assert.deepEqual(errors,[]);dom.window.close();
});

for(const type of ['post','live'])test('Inbox picker sends a typed '+type+' reference instead of a plain URL',async()=>{
 const dom=new JSDOM('<main></main>',{url:'https://web.kocehind.web.id'});
 for(const key of ['window','document','FormData','Event'])globalThis[key]=dom.window[key];
 const requests=[];globalThis.shareApi=async(path,options={})=>{requests.push({path,...options});return path.includes('/connections')?{items:[{id:'friend',username:'friend',name:'Teman'}]}:{};};
 const helper='data:text/javascript;base64,'+Buffer.from(`export const api=(...args)=>globalThis.shareApi(...args);export const me={id:'viewer',username:'viewer'};export const esc=v=>String(v??'');export const avatar=()=>'<span></span>';export const badge=()=>'';export const requireAccount=async()=>true;export const toast=()=>{};export const openDialog=(title,html)=>{const d=document.createElement('dialog');d.innerHTML=html;d.open=true;d.close=()=>d.remove();document.body.append(d);return d;};`).toString('base64');
 const source=(await readFile(new URL('./inbox-share.js',import.meta.url),'utf8')).replace(/from ['"]\/shared\/api\.js[^'"]*['"]/g,'from '+JSON.stringify(helper));
 const module=await import('data:text/javascript;base64,'+Buffer.from(source+'\n//'+type).toString('base64'));
 await module.shareToInbox(type,'content-1','Judul');document.querySelector('[data-recipient]').click();await settle();
 const sent=requests.find(r=>r.method==='POST');assert.equal(sent.path,'/chats/friend');assert.deepEqual(sent.body,{body:'Judul',shared_type:type,shared_id:'content-1'});
 assert.equal(document.querySelector('dialog'),null);dom.window.close();
});
