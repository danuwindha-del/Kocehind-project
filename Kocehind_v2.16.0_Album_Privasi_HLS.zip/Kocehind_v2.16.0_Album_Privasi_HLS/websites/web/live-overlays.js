import {api,esc,safeUrl,openDialog,toast} from '/shared/api.js?v=2.16.0';

export function clampOverlay(item,x,y){return {...item,x:Math.max(0,Math.min(1-item.width,x)),y:Math.max(0,Math.min(1-item.height,y))};}
export function resizeImageOverlay(item,size){
 const longest=Math.max(item.width,item.height),w=item.width/longest,h=item.height/longest;
 const target=Math.min(1,Math.max(size,.08/w,.04/h));
 return clampOverlay({...item,width:w*target,height:h*target},item.x,item.y);
}
export function newOverlay(kind){return {id:crypto.randomUUID(),kind,x:.15,y:.2,width:.7,height:kind==='image'?.4:.2,text:'',color:'#FFFFFF',background:null,font_size:.05};}

export function renderLiveOverlays(stage,state,{editable=false,onMove}={}){
 let layer=stage.querySelector(':scope > .live-canvas');
 if(!layer){layer=document.createElement('div');layer.className='live-canvas';stage.append(layer);}
 layer.classList.toggle('editing',editable);
 const items=state?.items||[],ids=new Set(items.map(i=>i.id));
 for(const node of layer.children)if(!ids.has(node.dataset.overlay))node.remove();
 for(const item of items){
  let node=[...layer.children].find(n=>n.dataset.overlay===item.id);
  if(!node){node=document.createElement('div');node.className='live-canvas-item';node.dataset.overlay=item.id;layer.append(node);}
  if(node.dragging)continue;
  layer.append(node); // Preserve the saved stacking order when bringing an element forward.
  const signature=JSON.stringify(item);
  if(signature!==node.signature){
   node.signature=signature;node.replaceChildren();node.classList.toggle('is-text',item.kind==='text');
   if(item.kind==='image'){const image=document.createElement('img');image.src=safeUrl(item.image_url);image.alt='Gambar dari host LIVE';image.draggable=false;node.append(image);}
   else {const label=document.createElement('span');label.textContent=item.text;label.style.color=item.color;label.style.backgroundColor=item.background||'transparent';label.style.fontSize=`${item.font_size*stage.clientWidth}px`;node.append(label);}
  }else if(item.kind==='text')node.firstElementChild.style.fontSize=`${item.font_size*stage.clientWidth}px`;
  function position(value){Object.assign(node.style,{left:`${value.x*100}%`,top:`${value.y*100}%`,width:`${value.width*100}%`,height:`${value.height*100}%`});}
  position(item);node.setAttribute('aria-label',item.kind==='text'?'Teks LIVE: '+item.text:'Gambar LIVE');
  node.onpointerdown=editable?event=>{
   if(event.button!==0)return;event.preventDefault();event.stopPropagation();
   const bounds=stage.getBoundingClientRect(),startX=event.clientX,startY=event.clientY;let moved=item;node.dragging=true;
   node.setPointerCapture?.(event.pointerId);
   node.onpointermove=e=>{e.preventDefault();e.stopPropagation();moved=clampOverlay(item,item.x+(e.clientX-startX)/bounds.width,item.y+(e.clientY-startY)/bounds.height);position(moved);};
   const finish=e=>{e.stopPropagation();node.dragging=false;node.onpointermove=node.onpointerup=node.onpointercancel=null;if(e.type==='pointercancel')position(item);else if(moved!==item)onMove?.(moved);};
   node.onpointerup=finish;node.onpointercancel=finish;
  }:null;
  node.onclick=editable?e=>{e.stopPropagation();}:null;
 }
}

export function openLiveOverlays({getState,save,startDragging,roomId}){
 const dialog=openDialog('Gambar & teks LIVE','<p>Tambah gambar dari galeri atau teks. Setelah disimpan, pilih Geser di layar untuk menempatkannya.</p><div class="buttons"><button class="btn" data-add-image>+ Gambar galeri</button><button class="btn" data-add-text>+ Teks</button><button class="btn primary" data-drag>Geser di layar</button></div><input type="file" accept="image/jpeg,image/png,image/webp" data-image hidden><div data-items></div><p class="form-error" role="alert"></p>');
 const error=dialog.querySelector('.form-error'),list=dialog.querySelector('[data-items]');let busy=false;
 const fail=e=>error.textContent=e.message;
 async function commit(items){if(busy)return false;busy=true;error.textContent='';dialog.querySelectorAll('button').forEach(b=>b.disabled=true);try{await save(items);draw();return true;}catch(e){fail(e);return false;}finally{busy=false;dialog.querySelectorAll('button').forEach(b=>b.disabled=false);}}
 function draw(){list.innerHTML=(getState().items||[]).map(item=>`<div class="live-overlay-row"><strong>${item.kind==='image'?'Gambar galeri':esc(item.text)}</strong><button class="btn small" data-edit="${esc(item.id)}">Edit</button><button class="btn small" data-front="${esc(item.id)}">Ke depan</button><button class="btn small danger" data-delete="${esc(item.id)}">Hapus</button></div>`).join('')||'<p>Belum ada gambar atau teks.</p>';
  list.querySelectorAll('[data-front]').forEach(b=>b.onclick=()=>{const items=getState().items,item=items.find(i=>i.id===b.dataset.front);commit([...items.filter(i=>i.id!==item.id),item]);});
  list.querySelectorAll('[data-delete]').forEach(b=>b.onclick=()=>commit(getState().items.filter(i=>i.id!==b.dataset.delete)));
  list.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>edit(getState().items.find(i=>i.id===b.dataset.edit)));
 }
 function edit(original){
  let item={...original};const text=item.kind==='text';
  const d=openDialog(text?'Teks LIVE':'Ukuran gambar',`<form>${text?`<label>Teks<textarea name="text" required maxlength="200" rows="3">${esc(item.text)}</textarea></label><label>Versi teks<select name="style"><option value="plain" ${item.background?'':'selected'}>Teks biasa</option><option value="background" ${item.background?'selected':''}>Teks berbackground</option></select></label><label>Warna background<input name="background" type="color" value="${esc(item.background||'#000000')}"></label><label>Warna teks<input name="color" type="color" value="${esc(item.color)}"></label><label>Ukuran teks<input name="font_size" type="range" min="0.02" max="0.12" step="0.005" value="${item.font_size}"></label>`:''}${!text?`<label>Ukuran gambar<input name="image_size" type="range" min="0.08" max="1" step="0.01" value="${Math.max(item.width,item.height)}"></label><button type="button" class="btn" data-fill-stage>Sebesar panggung</button>`:''}<label>Lebar<input name="width" type="range" min="0.08" max="1" step="0.01" value="${item.width}"></label><label>Tinggi<input name="height" type="range" min="0.04" max="1" step="0.01" value="${item.height}"></label><div class="live-overlay-preview" aria-label="Pratinjau elemen"></div><p class="form-error" role="alert"></p><button type="submit" class="btn primary">Simpan ke LIVE</button></form>`),f=d.querySelector('form');
  function value(){const fd=new FormData(f);return clampOverlay({...item,...(text?{text:String(fd.get('text')).trim(),background:fd.get('style')==='background'?fd.get('background'):null,color:fd.get('color'),font_size:Number(fd.get('font_size'))}:{}),width:Number(fd.get('width')),height:Number(fd.get('height'))},item.x,item.y);}
  function preview(){const v=value(),p=d.querySelector('.live-overlay-preview');
   Object.assign(p.style,{position:'relative',height:'auto',aspectRatio:'9 / 16',width:'min(100%, 210px)',margin:'12px auto'});
   renderLiveOverlays(p,{items:[v]});
   if(text)f.elements.background.disabled=f.elements.style.value==='plain';
   else f.elements.image_size.value=Math.max(v.width,v.height);
  }
  if(!text){
   f.elements.image_size.oninput=event=>{event.stopPropagation();item=resizeImageOverlay(value(),Number(event.target.value));f.elements.width.value=item.width;f.elements.height.value=item.height;preview();};
   f.querySelector('[data-fill-stage]').onclick=()=>{item={...value(),x:0,y:0,width:1,height:1};f.elements.width.value=1;f.elements.height.value=1;preview();};
  }
  f.oninput=preview;preview();f.onsubmit=async event=>{event.preventDefault();const changed=value();if(text&&!changed.text)return;const items=[...(getState().items||[])],index=items.findIndex(i=>i.id===item.id);if(index<0)items.push(changed);else items[index]=changed;const ok=await commit(items);if(ok)d.close();else d.querySelector('.form-error').textContent=error.textContent;};
 }
 dialog.querySelector('[data-add-text]').onclick=()=>{if(getState().items.length>=12){fail(new Error('Maksimal 12 elemen LIVE'));return;}edit(newOverlay('text'));};
 const input=dialog.querySelector('[data-image]');dialog.querySelector('[data-add-image]').onclick=()=>input.click();
 input.onchange=async()=>{const file=input.files?.[0];input.value='';if(!file||busy)return;if(getState().items.length>=12){fail(new Error('Maksimal 12 elemen LIVE'));return;}if(file.size>10*1024*1024){fail(new Error('Gambar maksimal 10 MB'));return;}
  try{busy=true;error.textContent='Mengunggah gambar…';const body=new FormData();body.set('file',file);const result=await api('/media/upload',{method:'POST',body});error.textContent='Memeriksa ketelanjangan dan gore/darah pada gambar…';let scan=await api('/live/rooms/'+roomId+'/overlay-assets',{method:'POST',body:{media_url:result.media_url}});const deadline=Date.now()+60000;while(scan.status==='pending'&&Date.now()<deadline&&dialog.open){await new Promise(resolve=>setTimeout(resolve,1000));scan=await api('/live/rooms/'+roomId+'/overlay-assets/'+scan.id);}if(!dialog.open)return;if(scan.status!=='approved')throw new Error(scan.status==='rejected'?scan.message:'Pemeriksaan masih berjalan. Coba lagi sesaat; gambar belum ditayangkan.');busy=false;await commit([...getState().items,{...newOverlay('image'),media_url:result.media_url}]);}catch(e){fail(e);}finally{busy=false;}
 };
 dialog.querySelector('[data-drag]').onclick=()=>{startDragging();dialog.close();toast('Geser gambar atau teks pada layar. Ketuk Selesai geser setelah selesai.');};draw();
 return dialog;
}
