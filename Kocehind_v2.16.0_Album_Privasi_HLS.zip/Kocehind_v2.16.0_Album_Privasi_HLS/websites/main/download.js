export const APK_PATH='/downloads/Kocehind.apk';
export function applyApkAvailability(links,response){
 const type=(response.headers.get('content-type')||'').toLowerCase();
 const ready=response.ok&&!type.includes('text/html');
 for(const link of links){
  link.setAttribute('aria-disabled',String(!ready));
  if(ready){link.setAttribute('href',APK_PATH);link.setAttribute('download','Kocehind.apk');link.textContent='↓ Unduh APK Android';}
  else link.removeAttribute('download');
 }
 return ready;
}
