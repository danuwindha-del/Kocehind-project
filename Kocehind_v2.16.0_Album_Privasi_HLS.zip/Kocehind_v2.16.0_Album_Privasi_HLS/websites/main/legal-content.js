export function documentSections(content){
 return String(content??'').split(/\n\s*\n/).map(x=>x.trim()).filter(Boolean).flatMap(block=>{
  const [first,...rest]=block.split('\n');
  if(/^\d+\.\s+[^\n]+$/.test(first))return [{heading:true,text:first},...(rest.join('\n').trim()?[{heading:false,text:rest.join('\n').trim()}]:[])];
  return [{heading:false,text:block}];
 });
}
