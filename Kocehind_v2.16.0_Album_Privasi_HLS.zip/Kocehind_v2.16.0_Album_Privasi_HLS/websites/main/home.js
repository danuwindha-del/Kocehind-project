import {applyApkAvailability} from './download.js?v=2.16.0';
const catalog=document.querySelector('#coin-packages'),controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),8000);
fetch('/api/coins/packages',{credentials:'omit',cache:'no-store',signal:controller.signal}).then(async response=>{
 if(!response.ok)throw Error('Paket belum tersedia');
 const data=await response.json(),items=(data.items||[]).filter(p=>Number.isSafeInteger(p.coins)&&p.coins>0&&Number.isSafeInteger(p.price)&&p.price>0);
 if(!items.length)throw Error('Belum ada paket aktif');catalog.replaceChildren();
 for(const item of items){
  const article=document.createElement('article');article.className='coin-package';
  for(const [tag,cls,text] of [['h3','',item.name],['strong','coin-count',new Intl.NumberFormat('id-ID').format(item.coins)+' koin'],['p','coin-price',new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(item.price)]]){
   const el=document.createElement(tag);el.className=cls;el.textContent=text;article.append(el);
  }
  const link=document.createElement('a');link.href='https://web.kocehind.web.id/coins';link.textContent='Pilih di web →';article.append(link);catalog.append(article);
 }
}).catch(()=>{catalog.innerHTML='<p>Paket belum dapat dimuat. <a href="https://web.kocehind.web.id/coins">Periksa paket dan harga terbaru di halaman pembelian</a>.</p>';}).finally(()=>{clearTimeout(timeout);catalog.setAttribute('aria-busy','false');});
const links=[...document.querySelectorAll('[data-apk-link]')],status=document.querySelector('#download-status');let ready=false;
for(const link of links)link.addEventListener('click',e=>{if(!ready){e.preventDefault();status.textContent='Unduhan APK belum tersedia. Anda dapat membuka Kocehind Web.';}});
fetch('/downloads/Kocehind.apk',{method:'HEAD',cache:'no-store'}).then(r=>{ready=applyApkAvailability(links,r);status.textContent=ready?'Unduhan langsung dari situs resmi Kocehind.':'Unduhan APK belum tersedia. Kocehind Web tetap dapat digunakan.';}).catch(()=>{status.textContent='Unduhan belum dapat diperiksa. Anda dapat membuka Kocehind Web.';});
