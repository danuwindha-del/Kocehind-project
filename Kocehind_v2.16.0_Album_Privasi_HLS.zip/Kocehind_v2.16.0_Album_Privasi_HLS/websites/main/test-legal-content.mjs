import test from 'node:test';import assert from 'node:assert/strict';
import {documentSections} from './legal-content.js';
test('legal section headings split from their first paragraph and markup stays literal',()=>{
 const result=documentSections('Dokumen\n\n1. Data akun\nEmail disimpan.\n\n<img src=x onerror=alert(1)>');
 assert.deepEqual(result,[{heading:false,text:'Dokumen'},{heading:true,text:'1. Data akun'},{heading:false,text:'Email disimpan.'},{heading:false,text:'<img src=x onerror=alert(1)>'}]);
});
