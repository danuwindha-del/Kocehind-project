import base64
from contextlib import contextmanager
import hashlib
import importlib.util
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest.mock import Mock
import pytest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('detail_check', ROOT / 'CEK_GOOGLE_PLAY_DETAIL.py')
detail = importlib.util.module_from_spec(spec)
spec.loader.exec_module(detail)


@pytest.mark.parametrize('status,reason,expected', [
    (401, 'permissionDenied', 'PLAY_PERMISSION'),
    (401, 'insufficientPermissions', 'PLAY_PERMISSION'),
    (403, 'PERMISSION_DENIED', 'PLAY_PERMISSION'),
    (401, 'authError', 'PLAY_AUTH_REJECTED'),
    (403, 'SERVICE_DISABLED', 'PLAY_API_DISABLED'),
    (403, 'accessNotConfigured', 'PLAY_API_DISABLED'),
    (403, 'unknown', 'PLAY_ACCESS_DENIED'),
    (404, 'notFound', 'PLAY_NOT_FOUND'),
    (400, 'badRequest', 'PLAY_RECEIPT_REJECTED'),
    (429, 'quotaExceeded', 'PLAY_QUOTA'),
    (503, 'backendError', 'PLAY_GOOGLE_UNAVAILABLE'),
])
def test_publisher_reason_precedes_http_401_label(status, reason, expected):
    code, safe = detail.analyse_response(status, {'error': {'errors': [{'reason': reason}]}})
    assert code == expected
    assert ('unknown' not in safe) if reason == 'unknown' else reason in safe


def test_permission_phrase_is_classified_without_echoing_provider_content():
    secret = 'PRIVATE-PURCHASE-TOKEN-DO-NOT-PRINT'
    code, safe = detail.analyse_response(401, {'error': {
        'message': 'The current user has insufficient permissions to perform the requested operation. ' + secret,
        'errors': [{'reason': secret}]}})
    assert code == 'PLAY_PERMISSION'
    assert secret not in safe


@pytest.mark.parametrize('payload', [None, [], {'error': []}, {'error': {'errors': 'bad'}}, {'error': {'details': [{'reason': []}]}}])
def test_malformed_provider_errors_are_safe(payload):
    code, _ = detail.analyse_response(401, payload)
    assert code == 'PLAY_AUTH_REJECTED'


@pytest.mark.parametrize('description,phrase', [
    ('Invalid JWT Signature: PRIVATE-KEY', 'tanda tangan'),
    ('Token must be a short-lived token: PRIVATE-KEY', 'jam VPS'),
    ('Account has been disabled: PRIVATE-KEY', 'dinonaktifkan'),
    ('Service account not found: PRIVATE-KEY', 'masih ada'),
])
def test_oauth_error_hints_never_echo_raw_descriptions(description, phrase):
    error = Exception('private request URL', {'error': 'invalid_grant', 'error_description': description})
    code, hint = detail.oauth_failure(error)
    assert code == 'invalid_grant' and phrase.lower() in hint.lower()
    assert 'PRIVATE-KEY' not in hint and 'private request URL' not in hint


def test_fresh_oauth_failure_does_not_query_receipt(capsys):
    sample = Mock()
    def fail(credentials):
        raise Exception('SECRET', {'error': 'invalid_grant', 'error_description': 'Invalid JWT Signature: SECRET'})
    result = detail.check(load=lambda: (object(), 'project', 'publisher@project.iam.gserviceaccount.com'),
                          oauth=fail, sample=sample, request=Mock())
    sample.assert_not_called()
    output = capsys.readouterr().out
    assert result == 2 and 'OAuth: GAGAL' in output and 'SECRET' not in output


def test_google_permission_denied_is_printed_after_successful_oauth(capsys):
    result = detail.check(load=lambda: (object(), 'project', 'publisher@project.iam.gserviceaccount.com'),
        oauth=lambda credentials: None, sample=lambda: 'PRIVATE-TOKEN',
        request=lambda credentials, token: (401, {'error': {'errors': [{'reason': 'permissionDenied'}]}}))
    output = capsys.readouterr().out
    assert result == 2 and 'OAuth: BERHASIL' in output and 'HTTP: 401' in output
    assert 'Hasil: PLAY_PERMISSION' in output and 'PRIVATE-TOKEN' not in output


def test_success_shows_google_state_without_granting_coins(capsys):
    request = Mock(return_value=(200, {'purchaseStateContext': {'purchaseState': 'PURCHASED'},
                                     'orderId': 'PRIVATE-ORDER'}))
    result = detail.check(load=lambda: (object(), 'project', 'publisher@project.iam.gserviceaccount.com'),
                          oauth=lambda credentials: None, sample=lambda: 'PRIVATE-TOKEN', request=request)
    output = capsys.readouterr().out
    assert result == 0 and 'Status pembelian: PURCHASED' in output
    assert 'PRIVATE-TOKEN' not in output and 'PRIVATE-ORDER' not in output


def test_database_receipt_is_read_without_changes(tmp_path, monkeypatch):
    from sqlalchemy import create_engine, text
    from cryptography.fernet import Fernet
    engine = create_engine('sqlite:///' + str(tmp_path / 'receipt.db'))
    secret, token = 'test-jwt-secret', 'private-purchase-token'
    key = base64.urlsafe_b64encode(hashlib.sha256(('kocehind-play-token-v1:' + secret).encode()).digest())
    encrypted = Fernet(key).encrypt(token.encode()).decode()
    with engine.begin() as connection:
        connection.execute(text('CREATE TABLE google_play_verification_queue (product_id TEXT, encrypted_token TEXT, state TEXT, created_at TEXT)'))
        connection.execute(text('INSERT INTO google_play_verification_queue VALUES (:product,:encrypted,:state,:created)'),
                           {'product': 'kocehind_coin_100', 'encrypted': encrypted, 'state': 'retry', 'created': '2026-10-30'})
    monkeypatch.setitem(sys.modules, 'app', SimpleNamespace(__path__=[]))
    monkeypatch.setitem(sys.modules, 'app.core', SimpleNamespace(engine=engine, JWT_SECRET=secret))
    assert detail.read_sample() == token
    with engine.connect() as connection:
        row = connection.execute(text('SELECT encrypted_token,state FROM google_play_verification_queue')).one()
        assert row == (encrypted, 'retry')
    engine.dispose()


def test_bad_local_credentials_do_not_print_private_exception(capsys):
    def load():
        raise ValueError('PRIVATE-KEY')
    assert detail.check(load=load) == 2
    assert 'PRIVATE-KEY' not in capsys.readouterr().out


def test_transport_does_not_consume_receipt_and_does_not_retry_401(monkeypatch):
    import google.auth.transport.requests as google_requests
    response = Mock(status_code=401)
    response.iter_content.return_value = [b'{"error":{"errors":[{"reason":"permissionDenied"}]}}']
    response.__enter__ = Mock(return_value=response)
    response.__exit__ = Mock(return_value=False)
    session = Mock()
    session.get.return_value = response
    session.__enter__ = Mock(return_value=session)
    session.__exit__ = Mock(return_value=False)
    factory = Mock(return_value=session)
    monkeypatch.setattr(google_requests, 'AuthorizedSession', factory)
    status, data = detail.get_receipt(object(), 'PRIVATE-TOKEN')
    assert status == 401 and data['error']['errors'][0]['reason'] == 'permissionDenied'
    assert factory.call_args.kwargs['refresh_status_codes'] == ()
    assert session.get.call_count == 1
    assert '/purchases/productsv2/tokens/' in session.get.call_args.args[0]
    assert not session.post.called
