"""Archive, Python selection and recording image tests; no VPS mutation or SDK calls."""
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
import zipfile

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import package_ops


def bundle(tmp_path, name='kocehind_realtime_v2/file.txt', symlink=False):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w') as z:
        info = zipfile.ZipInfo(name)
        if symlink:
            info.external_attr = (stat.S_IFLNK | 0o777) << 16
        z.writestr(info, 'fixture')
    data = buffer.getvalue()
    (tmp_path / 'SOURCE_LENGKAP_v2.16.0.zip').write_bytes(data)
    (tmp_path / 'package.json').write_text(json.dumps({'version': '2.16.0', 'source_sha256': hashlib.sha256(data).hexdigest()}))
    return data


def test_source_archive_integrity_and_temporary_extract(tmp_path):
    data = bundle(tmp_path)
    assert package_ops.verify_bundle(tmp_path)[0] == data
    with package_ops.source_tree(tmp_path) as project:
        assert (project / 'file.txt').read_text() == 'fixture'
    assert not project.exists()
    (tmp_path / 'SOURCE_LENGKAP_v2.16.0.zip').write_bytes(data + b'tamper')
    with pytest.raises(RuntimeError, match='Checksum'):
        package_ops.verify_bundle(tmp_path)


@pytest.mark.parametrize('name', ['../outside', '/tmp/outside', 'other-project/file', 'kocehind_realtime_v2/../../outside', 'kocehind_realtime_v2\\file'])
def test_archive_refuses_paths_outside_source_root(tmp_path, name):
    bundle(tmp_path, name)
    with pytest.raises(RuntimeError, match='Path ZIP'):
        package_ops.verify_bundle(tmp_path)


def test_archive_refuses_symlink(tmp_path):
    bundle(tmp_path, symlink=True)
    with pytest.raises(RuntimeError, match='Path ZIP'):
        package_ops.verify_bundle(tmp_path)


def test_child_python_uses_existing_interpreter_and_cannot_skip_backups(monkeypatch):
    monkeypatch.setenv('SKIP_BACKUP', '1')
    with package_ops.runtime_environment(Path(sys.executable)) as env:
        first = Path(env['PATH'].split(':')[0]) / 'python3'
        completed = subprocess.run(
            ['python3', '-c', 'import json,sys; print(json.dumps([sys.executable,sys.prefix]))'],
            env=env, text=True, capture_output=True, check=True)
        executable, prefix = json.loads(completed.stdout)
        assert Path(executable) == Path(sys.executable).absolute()
        assert Path(prefix) == Path(sys.prefix)
        assert 'SKIP_BACKUP' not in env
    assert not first.exists()


def test_created_virtualenv_survives_private_runtime_launcher_cleanup():
    with tempfile.TemporaryDirectory(prefix='kocehind-stable-venv-', dir='/tmp') as folder:
        root = Path(folder)
        root.chmod(0o755)
        target = root / 'next-venv'
        with package_ops.runtime_environment(Path(sys.executable)) as env:
            shim = Path(env['PATH'].split(':')[0])
            assert shim.stat().st_mode & 0o777 == 0o700
            subprocess.run(['python3', '-m', 'venv', '--without-pip', str(target)],
                           env=env, check=True, umask=0o022)
        assert not shim.exists()
        assert (target / 'bin/python').is_file()
        completed = subprocess.run(
            [str(target / 'bin/python'), '-c', 'import sys; print(sys.prefix)'],
            text=True, capture_output=True, check=True)
        assert Path(completed.stdout.strip()) == target


def test_recording_installer_reuses_pinned_image_and_refuses_latest(tmp_path):
    spec = importlib.util.spec_from_file_location('recording_cli', ROOT / 'AKTIFKAN_REKAMAN_LIVE.py')
    recording = importlib.util.module_from_spec(spec); spec.loader.exec_module(recording)
    config = tmp_path / 'egress.env'
    assert recording.selected_image(config=config) == 'livekit/egress:v1.15.0'
    digest = 'livekit/egress@sha256:' + 'a' * 64
    config.write_text('LIVEKIT_EGRESS_IMAGE=' + digest + '\n')
    assert recording.selected_image(config=config) == digest
    with pytest.raises(RuntimeError):
        recording.selected_image('livekit/egress:latest', config)
    config.write_text('LIVEKIT_EGRESS_IMAGE=untrusted/image:latest\n')
    with pytest.raises(RuntimeError):
        recording.selected_image(config=config)


@pytest.mark.parametrize('case', ['install-and-rollback', 'tamper', 'check-only'])
def test_ui_installer_keeps_custom_files_and_can_restore_previous_release(tmp_path, case):
    import UPDATE_UI_WEB as updater
    base, source = tmp_path / 'site', tmp_path / 'payload'
    old = base / 'releases/old'
    for folder in ('web', 'main', 'admin', 'shared'):
        (old / folder).mkdir(parents=True)
    (old / 'shared/studio-design.css').write_text('previous-design')
    (old / 'custom.txt').write_text('preserve-deployment-file')
    (base / 'current').symlink_to(old, target_is_directory=True)
    (source / 'shared').mkdir(parents=True)
    css = source / 'shared/studio-design.css'; css.write_text('owner-studio-r1')
    manifest = tmp_path / 'manifest.json'
    manifest.write_text(json.dumps({'web_files': {'shared/studio-design.css': hashlib.sha256(css.read_bytes()).hexdigest()}}))
    if case == 'tamper':
        css.write_text('tampered')
        with pytest.raises(RuntimeError, match='Checksum'):
            updater.install(base, source, manifest)
        assert (base / 'current').resolve() == old
    elif case == 'check-only':
        updater.install(base, source, manifest, check_only=True)
        assert (base / 'current').resolve() == old
        assert list((base / 'releases').iterdir()) == [old]
    else:
        new = updater.install(base, source, manifest)
        assert (base / 'current').resolve() == new
        assert (new / 'custom.txt').read_text() == 'preserve-deployment-file'
        assert (new / 'shared/studio-design.css').read_text() == 'owner-studio-r1'
        record = json.loads(next(base.glob('rollback-*.json')).read_text())
        assert Path(record['previous']) == old
        updater.activate(base, old)
        assert (base / 'current').resolve() == old


def test_complete_package_installs_google_play_diagnosis_with_backend_tools(tmp_path):
    runtime = tmp_path / 'runtime'
    runtime.mkdir()
    with package_ops.source_tree(ROOT) as project:
        package_ops.install_backend_tools(project, runtime=runtime)
        for name in ('setup_kipay.py', 'simulate_kipay_sandbox.py', 'mailjet_preflight.py',
                     'setup_google_play.py', 'diagnose_google_play.py'):
            target = runtime / name
            assert target.read_bytes() == (project / 'backend' / name).read_bytes()
            assert stat.S_IMODE(target.stat().st_mode) == 0o644
