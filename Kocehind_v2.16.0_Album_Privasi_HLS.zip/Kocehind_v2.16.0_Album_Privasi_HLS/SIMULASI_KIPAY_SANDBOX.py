#!/usr/bin/env python3
"""Run the sandbox-only server command; never change wallet balances directly."""
import subprocess
import sys
from package_ops import require_root, source_tree, RUNTIME_PYTHON, check_runtime


def main():
    require_root()
    check_runtime()
    with source_tree() as project:
        subprocess.run([str(RUNTIME_PYTHON), str(project / 'backend/simulate_kipay_sandbox.py'), *sys.argv[1:]],
                       cwd='/opt/kocehind/backend', check=True)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        raise SystemExit('BELUM SELESAI: ' + str(exc)) from None
