# Aktivasi Google Play dan pembaruan Kocehind 2.14.0

Paket ini berisi source dan alat pembaruan. Produk, harga, hak API, dan rilis Play Console harus diaktifkan pada akun pemilik. Tidak ada credential server atau keystore di dalam paket.

## 1. Perbarui backend dan web

Akhiri semua LIVE. Upload ZIP, lalu pada VPS backend existing:

```bash
unzip -o /root/Kocehind_v2.14.0_Gabungan_Gabungan.zip -d /root
cd /root/Kocehind_v2.14.0_Gabungan
sha256sum -c SHA256SUMS.txt
/opt/kocehind/venv/bin/python UPDATE_BACKEND_WEB.py --check
/opt/kocehind/venv/bin/python UPDATE_BACKEND_WEB.py
/opt/kocehind/venv/bin/python DIAGNOSA_INTEGRASI.py
```

Health yang diharapkan: `2.14.0`. Updater mempertahankan alur backup dan rollback kode sebelumnya, menambah tabel receipt Google Play, pemindaian refund, dan operasi koin admin. Saldo, ledger, pembayaran Kipay/Tripay lama, key, Firebase, dan dokumen hukum aktif tidak direset. Mode Google Play default nonaktif sampai dikonfigurasi.

## 2. Buat produk pada aplikasi yang sama di Play Console

Gunakan aplikasi dengan package `id.web.kocehind`. Siapkan profil pembayaran penjual, lalu buka bagian monetisasi dan produk sekali beli (One-time products; pada tampilan lama bernama In-app products).

| Product ID persis | Total koin satu unit, tanpa bonus | Harga target Indonesia |
| --- | ---: | ---: |
| `kocehind_coin_25` | 25 | Rp1.000 |
| `kocehind_coin_75` | 75 | Rp3.000 |
| `kocehind_coin_160` | 160 | Rp6.000 |
| `kocehind_coin_350` | 350 | Rp12.000 |
| `kocehind_coin_750` | 750 | Rp25.000 |
| `kocehind_coin_1600` | 1.600 | Rp50.000 |
| `kocehind_coin_3500` | 3.500 | Rp100.000 |

Atur harga, negara penjualan dan opsi pembelian; aktifkan produknya. Koin diperlakukan sebagai produk konsumabel oleh kode aplikasi dan backend, sehingga dapat dibeli lagi setelah konsumsi dikonfirmasi. Harga aplikasi berasal dari Google Play, bukan harga web atau angka rupiah yang ditanam di aplikasi. Jumlah koin berasal dari tabel di atas; jangan mengganti nilai suatu ID yang sudah terjual. Gunakan ID baru dan perubahan katalog kode jika ingin denominasi baru.

Empat ID lama 100/500/1000/5000 tetap diterima untuk verifikasi receipt, retry dan refund; tidak ditawarkan pada katalog baru. Total koin pada tabel sudah final dan tanpa bonus tambahan. Harga tersebut target pemilik, dengan validasi dan pengaturan harga di Play Console. Tarif pendapatan host tetap mengikuti admin.

## 3. Beri akses backend

Jika pembelian pada VPS Anda sudah berhasil, pertahankan konfigurasi dan credential yang aktif. Langkah setup berikut untuk backend yang belum dikonfigurasi.

Pada Google Cloud, aktifkan Google Play Developer API dan buat service account khusus backend. Di Play Console > Users and permissions, undang email service account untuk aplikasi Kocehind dengan izin Billing yang diperlukan:

- View financial data, orders, and cancellation survey responses.
- Manage orders and subscriptions.

Simpan key JSON privat pada VPS, misalnya `/root/play-service-account.json`. Key Firebase untuk push tidak otomatis mempunyai izin Google Play; gunakan identitas yang memang diberi akses pada aplikasi ini. Jangan memasukkan JSON tersebut ke APK, source, Git, halaman web, atau percakapan.

Setelah update backend selesai:

```bash
cd /root/Kocehind_v2.14.0_Gabungan
/opt/kocehind/venv/bin/python SETUP_GOOGLE_PLAY.py --credentials /root/play-service-account.json --check
/opt/kocehind/venv/bin/python SETUP_GOOGLE_PLAY.py --credentials /root/play-service-account.json
systemctl is-active kocehind-api kocehind-play
```

Helper memvalidasi bentuk key, menyimpan salinan privat root:kocehind 0640, mencadangkan konfigurasi, mengaktifkan flag dan worker, serta memulai ulang API. Pemeriksaan format lokal belum membuktikan izin Play API; pembelian license tester di langkah 5 membuktikan integrasi sebenarnya. Jangan mengubah JWT_SECRET yang sudah digunakan: receipt antrean dan email dienkripsi dengan kunci yang diturunkan dari secret tersebut.

## 4. Bangun Android baru dengan key lama

Versi `2.14.0`; build dasar 40 pada source gabungan ini. Builder memilih nomor lebih tinggi bila riwayat lokal mengharuskannya. Jika Play Console sudah memakai nomor lebih tinggi, gunakan `--build-number` yang belum pernah diunggah.

Build memerlukan Flutter minimal 3.38.1 dan Dart 3.10 stabil. Default baru 3.38.10; Android minimum API 24. Flutter 3.38.0 membawa Dart beta dan tidak cocok untuk batas versi plugin pembayaran ini.

Jika SDK pada builder masih lama, pasang versi baru berdampingan:

```bash
git clone --depth 1 --branch 3.38.10 https://github.com/flutter/flutter.git /opt/flutter-3.38.10
export KOCEHIND_FLUTTER_ROOT=/opt/flutter-3.38.10
export PATH="$KOCEHIND_FLUTTER_ROOT/bin:$PATH"
cd /root/Kocehind_v2.14.0_Gabungan
python3 PINDAH_KEY_LAMA.py build --check-only
bash BUILD_VPS_BARU.sh
```

Runner, applicationId, signing dan konfigurasi Firebase lama tetap dipakai. Jangan membuat keystore pengganti. Gunakan AAB baru pada internal testing Play Console. Instal melalui tautan tester dengan akun Google yang sesuai. Host dan penonton perlu aplikasi baru untuk perubahan kualitas kamera dan editor gambar; backend/web baru dapat digunakan oleh aplikasi lama untuk kemampuan yang sudah didukungnya.

## 5. Uji license tester sebelum rilis

Tambahkan akun Google pengujian sebagai license tester dan tester internal. Gunakan metode pembayaran pengujian yang ditandai Google; akun tester internal saja masih dapat dikenai pembayaran sungguhan.

1. Login ke akun Kocehind A, buka Koin dan pendapatan > Beli koin. Pastikan harga Google Play terlihat.
2. Beli paket 25 menggunakan metode uji berhasil. Saldo bertambah sekali dan riwayat menampilkan Pembelian Google Play.
3. Beli produk yang sama lagi. Pembelian berikutnya tersedia setelah konsumsi server selesai.
4. Uji pembayaran ditolak, dibatalkan dan pending: koin belum bertambah sebelum Google menyatakan PURCHASED.
5. Putuskan jaringan setelah membayar, tutup aplikasi, lalu buka dan tekan Periksa pembelian. Koin masuk sekali. Token antrean disimpan dalam secure storage; keluar akun tidak menghapus antrean pembelian.
6. Coba akun Kocehind B pada perangkat sama: pembelian A tidak boleh dikreditkan ke B. Login kembali ke A untuk pemulihan.
7. Refund/revoke melalui Play Console; jalankan worker dan periksa penyesuaian saldo/utang. Pemindaian voided purchases berjalan tiap jam, dengan pemeriksaan langsung receipt pending dan receipt terbaru. Ini bukan notifikasi refund seketika.
8. Periksa `journalctl -u kocehind-play -n 50 --no-pager` jika antrean tertunda. Jangan memublikasikan log yang memuat credential dari konfigurasi lain.

Backend memakai ProductPurchaseV2 dan mengikat obfuscated account ID ke pengguna Kocehind. Nilai token saja tidak membuktikan pembayaran. Kredit dicatat atomik dan satu kali; konfirmasi konsumsi dilakukan server setelah kredit. Jika jaringan gagal, worker mencoba lagi. Pembelian di luar alur aplikasi tanpa account ID tidak dikredit otomatis; arahkan kasus tersebut ke bantuan dan nonaktifkan promosi pembelian di luar aplikasi sebelum peluncuran bila diperlukan.

## 6. Pengelolaan koin admin

Buka Control Center > Gift dan penarikan > Koin pengguna. Cari username/nama/ID, lalu Kelola koin.

- Tambah / kirim: admin memberi koin ke akun tujuan.
- Kurangi: mengurangi saldo tersedia tanpa membuat saldo negatif.
- Pindahkan: masukkan username pengirim; koin berpindah dari saldo pengirim ke akun tujuan.

Jumlah harus positif dan alasan wajib. Percobaan ulang permintaan yang sama memakai ID transaksi sama. Operasi tercatat pada ledger pengguna dan riwayat tindakan admin. Penambahan menyelesaikan utang refund terlebih dahulu. Koin berbeda dari pendapatan rupiah; menu ini tidak membuat catatan pembayaran provider palsu.

## 7. LIVE dan gambar

Pada LIVE kamera, source baru meminta potret 720 × 1280, maksimal 30 fps dan 2,5 Mbps, dengan lapisan 360 × 640 dan 180 × 320. Tampilan utama/dua peserta meminta kualitas tinggi; kisi banyak peserta memakai medium, dan peserta kecil di bawah fokus memakai low. Preview feed tetap adaptif dan tanpa suara. Video penonton dijeda ketika aplikasi/tab berada di latar.

Pengaturan ini meningkatkan sumber dan pilihan kualitas, tetapi hasil tetap mengikuti kamera, pencahayaan, upload host, koneksi penonton dan kapasitas SFU. Uji dua perangkat pada jaringan yang sama dan berbeda; bandingkan tampilan solo, dua peserta, kisi dan fokus. Rilis ini belum membuktikan kualitas pada VPS dan perangkat produksi.

Di Gambar & teks LIVE, pilih Edit pada gambar. Gunakan Ukuran gambar, Lebar/Tinggi atau Sebesar panggung. Pratinjau memakai posisi dan ukuran yang disimpan; gambar tetap ditampilkan utuh. Perubahan tersinkron ke penonton dan preview melalui state overlay server.

## Referensi resmi yang diperiksa

- https://developer.android.com/google/play/billing/security
- https://developer.android.com/google/play/billing/integrate
- https://developers.google.com/android-publisher/api-ref/rest/v3/purchases.productsv2
- https://developers.google.com/android-publisher/api-ref/rest/v3/purchases.products/consume
- https://developers.google.com/android-publisher/api-ref/rest/v3/purchases.voidedpurchases/list
- https://developers.google.com/android-publisher/getting_started
- https://developer.android.com/google/play/billing/test
- https://support.google.com/googleplay/android-developer/answer/1153481
- https://pub.dev/packages/in_app_purchase
- https://github.com/flutter/flutter/blob/3.38.10/CHANGELOG.md
- https://pub.dev/documentation/livekit_client/2.6.4/livekit_client/VideoPublishOptions-class.html
