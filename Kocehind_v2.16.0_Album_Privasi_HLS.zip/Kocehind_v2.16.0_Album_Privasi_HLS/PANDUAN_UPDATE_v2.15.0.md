# Panduan Kocehind 2.15.0

## 1. Update VPS backend dan web yang sudah terpasang

Akhiri semua LIVE terlebih dahulu karena API dan worker dimulai ulang. Upload ZIP pembaruan ke `/root`, lalu:

```bash
cd /root
unzip -o Kocehind_v2.15.0_MychaAI.zip
cd /root/Kocehind_v2.15.0_MychaAI
sha256sum -c SHA256SUMS.txt
/opt/kocehind/venv/bin/python UPDATE_BACKEND_WEB.py --check
/opt/kocehind/venv/bin/python UPDATE_BACKEND_WEB.py
systemctl is-active kocehind-api kocehind-mycha kocehind-email
/opt/kocehind/venv/bin/python DIAGNOSA_INTEGRASI.py
```

Updater memeriksa source, manifest web, Python backend 3.11+, dan Nginx. Alur existing mencadangkan database/media, menyiapkan virtualenv yang dapat dibaca user service, menjalankan migrasi tambahan, memeriksa versi kesehatan API dan menyediakan rollback kode bila backend gagal. Tabel baru ditambahkan tanpa reset saldo atau ledger. Cadangan runtime/kode dicetak oleh updater; pertahankan cadangan tersebut. Kegagalan bagian web setelah backend sukses dilaporkan sebagai belum selesai dan dapat dicoba ulang dari paket yang sama.

`UPDATE_BACKEND_WEB.py` untuk VPS existing. `BUILD_VPS_BARU.sh` adalah builder Android, bukan installer backend. Jangan mengganti Python sistem, JWT_SECRET, konfigurasi Kipay/Play, dokumen hukum aktif, atau keystore. Jangan hanya menjalankan UPDATE_UI_WEB.py untuk pembaruan ini karena endpoint backend baru diperlukan.

## 2. Pasang API key DattioAI di server

```bash
cd /root/Kocehind_v2.15.0_MychaAI
/opt/kocehind/venv/bin/python SETUP_MYCHAAI.py
/opt/kocehind/venv/bin/python SETUP_MYCHAAI.py --check
/opt/kocehind/venv/bin/python SETUP_MYCHAAI.py --test
systemctl is-active kocehind-api kocehind-mycha
```

API key diminta melalui input tersembunyi. Jangan kirim API key ke chat atau menaruhnya dalam Flutter/web. Base URL bawaan dari dokumentasi resmi DattioAI yang ditinjau 31 Oktober 2026 adalah `https://bandelbanget.xyz/v1`, protokol `/chat/completions`, header Bearer. Pilih model yang tersedia pada akun Anda; pilihan awal `glm-5.2` dapat diganti di prompt. Referensi: https://dattioai.com/docs.

Konfigurasi disimpan terpisah pada `/etc/kocehind/mycha.env`, root:kocehind 0640; cadangan 0600. API key memakai Base64 untuk menghindari karakter credential menjadi sintaks konfigurasi; Base64 **bukan enkripsi**. Konfigurasi lama backend.env dipertahankan. Setup memulai ulang API dan worker MychaAI. `--check` hanya memeriksa konfigurasi lokal; `--test` memakai kuota untuk satu uji pembelajaran kecil dan tidak mengirim data pengguna.

Tanpa key/model aktif atau saat provider gagal, pencarian video/akun/LIVE tetap berfungsi. Ringkasan yang belum berhasil dipelajari tidak ditampilkan. Periksa menu **MychaAI / Indeks pencarian** pada admin untuk status antrean, masalah konfigurasi, dan pelajari ulang. Pergantian key tidak mengharuskan build APK.

## 3. Cara kerja indeks dan popularitas

Worker meninjau ulang kandidat kreator setiap enam jam. Batas awal mengharuskan SEMUA syarat berikut:

| Sinyal | Batas awal |
|---|---:|
| Pengikut berbeda, bukan diri sendiri, akun tidak diblokir | 1.000 |
| Postingan publik, disetujui dan tidak disembunyikan | 5 |
| Pengguna berbeda yang memberi suka/komentar pada postingan publik 30 hari terakhir | 100 |
| Usia akun | 30 hari |

Penghitung view, centang biru, dan klaim bio saja tidak membuat kreator memenuhi syarat. Tabel suka lama tidak menyimpan waktu pemberian suka; jendela 30 hari mengacu pada tanggal postingan yang mendapat interaksi, bukan waktu suka yang tidak tersedia. Sinyal tersebut mengurangi indeks asal-asalan, tetapi bukan bukti keaslian setiap pengikut atau jaminan bebas manipulasi. Admin dapat menarik entri bila ditemukan penyalahgunaan.

Pengelola dapat mengubah `MYCHA_MIN_FOLLOWERS`, `MYCHA_MIN_POSTS`, `MYCHA_MIN_ENGAGED_USERS`, dan `MYCHA_MIN_ACCOUNT_DAYS` dalam backend.env, lalu memulai ulang API dan MychaAI. Batas minimum teknis mencegah konfigurasi nol mengindeks semua akun. Untuk pemindaian segera setelah perubahan konfigurasi, mulai ulang `kocehind-mycha`.

MychaAI mempelajari snapshot profil dan caption publik yang memenuhi syarat. DattioAI memilih fakta dari sumber yang diberikan; server hanya menerbitkan teks fakta tersebut, sehingga model tidak dapat menyisipkan biografi atau klaim bebas ke ringkasan. Ini pembelajaran ringkasan bersumber, bukan pelatihan ulang bobot model. Email, chat, transaksi, credential dan media privat tidak dikirim ke provider.

Indeks kreator harus lolos syarat popularitas dan pembelajaran sebelum tampil. Pemeriksaan saat pencarian kembali menolak akun diblokir/dihapus, blokir antar pengguna, konten yang menjadi privat/dihapus, atau snapshot yang sudah berubah. Snapshot baru dipelajari ulang pada pemindaian berikutnya. Pemilihan sumber tidak berarti memverifikasi pekerjaan, identitas nyata, atau hubungan komersial kreator.

Entri awal YouTube dan Google berisi fakta dari halaman resmi yang ditinjau, lalu tetap menunggu pembelajaran provider. Ini katalog terkurasi, bukan pencarian web tanpa batas. Untuk brand lain, admin menambahkan fakta bersumber dan aliasnya. Pertanyaan tanpa sumber cukup menampilkan keadaan kosong yang jujur di tab Tanya.

## 4. Menambahkan indeks manual di dashboard

Buka **Admin > MychaAI / Indeks pencarian > Tambah indeks**. Isi:

1. Nama brand atau topik serta alias pencarian.
2. Satu atau lebih fakta yang sudah diperiksa, URL HTTPS sumbernya, dan nama sumber.
3. Maksimal tiga URL gambar HTTPS atau unggah gambar JPG/PNG/WebP maksimal 5 MB.
4. Catatan peninjauan, lalu **Simpan & pelajari**.

Entri siap tampil setelah berhasil dipelajari. Edit sumber membuatnya kembali masuk antrean; ringkasan lama tidak tetap diterbitkan. **Tarik indeks** segera menghentikan penayangannya. **Tampilkan** dan **Pelajari ulang** menjadwalkan pembelajaran baru. Semua tindakan ini memeriksa peran admin pada server dan tercatat dalam audit.

Tautan tidak diambil otomatis oleh server; pengelola bertanggung jawab memasukkan fakta yang memang didukung sumber tersebut. Sumber manual perlu ditinjau ulang sebelum 90 hari. Gambar hasil upload tidak dibuka ke publik sebelum dirujuk oleh entri yang siap dan dipublikasikan. Indeks manual untuk subjek tambahan dapat dibuat sebagai topik dengan tautan sumber dan profil publik yang relevan.

## 5. Profil dan sematan

- Buka video milik sendiri, pilih **Bagikan > Sematkan di profil**. Maksimal tiga; copot salah satunya sebelum menambah yang keempat.
- **Copot sematkan** melepas sematan tanpa menghapus video. Foto tidak dapat disematkan.
- Video sematan diurutkan lebih dahulu pada profil. Pengunjung melihat label **Disematkan** pada video yang memang dapat diakses. Sematan tidak membuka konten Hanya Saya/Hanya Teman, konten moderasi, atau akun yang diblokir.
- Di **Edit profil**, isi maksimal dua judul/URL HTTPS. Judul boleh kosong; URL akan menjadi label. Hapus isi URL untuk menghapus tautan. Klien lama tidak menghapus tautan yang belum dikenalnya.

## 6. Pemeriksaan gambar LIVE

OpenNSFW2 dijalankan oleh `kocehind-moderation`; model visual gore/darah/kekerasan dijalankan oleh `kocehind-content-safety`, memakai runtime dan model existing. Aktifkan kebijakan moderasi serta `MULTI_MODERATION_ENABLED=1` dan `SAFETY_VISION_ENABLED=1`. Tidak ada unduhan/penggantian model besar otomatis oleh paket ini.

Setelah host memilih gambar galeri, aplikasi mengunggahnya secara privat dan meminta pemeriksaan. Gambar baru dapat ditempel di panggung setelah kedua pemeriksaan selesai tanpa temuan. Permintaan langsung ke endpoint overlay juga diperiksa server sehingga klien tidak dapat melewati persyaratan tersebut. Identitas pemilik, isi file, dan versi kebijakan terikat pada hasil pemeriksaan.

Temuan ketelanjangan atau gore/darah/kekerasan memindahkan LIVE ke status dihentikan, memblokir akses gambar/join, membuat Aktivitas moderasi dan alur banding, lalu menutup ruang SFU. Worker LIVE existing akan mengulang penutupan bila SFU sementara gagal. Kecepatan deteksi tetap mengikuti antrean dan kapasitas model, bukan jaminan nol detik. Gangguan model atau skor tidak valid menahan gambar; kegagalan pemeriksaan saja tidak menuduh host melanggar aturan.

Jika layar masih menunggu setelah satu menit, gambar belum ditayangkan. Periksa worker dan coba kembali. Model dapat salah menilai; gunakan Aktivitas > alasan/banding. Pergantian ambang/kebijakan mengharuskan pemeriksaan baru untuk unggahan berikutnya. Gambar yang sudah ada sebelum update tidak dipindai ulang otomatis hanya karena pemasangan paket.

## 7. Email pembelian

Pembelian yang berhasil diverifikasi dan dikredit mencatat konfirmasi/terima kasih pada outbox Mailjet dalam transaksi database yang sama. Pesan memuat jumlah koin, provider, referensi dan total pembayaran web yang telah diverifikasi. Untuk Google Play, nominal harga tidak ditebak dari klien; jumlah koin dan referensi terverifikasi tetap dicantumkan.

Pending, pembatalan sebelum kredit, pengiriman gift, dan operasi koin admin bukan pembelian berhasil. Retry webhook/verifikasi tidak menambahkan email konfirmasi baru untuk pembelian yang sama. Pembelian Google Play dapat dipulihkan worker tanpa harus membuka aplikasi untuk membuat email. Data pembelian sebelum pemasangan tidak dikirimi email massal ulang.

Pastikan konfigurasi Mailjet aktif dan `kocehind-email` berjalan. Pengiriman SMTP tidak digunakan. Gangguan Mailjet ditangani retry outbox. Pencatatan satu outbox per pembelian bukan jaminan pengiriman email exactly-once bila proses berhenti setelah provider menerima pesan tetapi sebelum status tersimpan.

## 8. Build Android dengan key lama

```bash
cd /root/Kocehind_v2.15.0_MychaAI
python3 PINDAH_KEY_LAMA.py build --check-only
bash BUILD_VPS_BARU.sh
```

Pakai VPS builder Android dan backup signing/Firebase existing. Dasar versi **2.15.0+41**; builder memilih nomor di atas riwayat lokal. Jika Play Console sudah memakai nomor lebih tinggi, tentukan nomor baru dengan:

```bash
python3 PINDAH_KEY_LAMA.py build --build-number NOMOR_YANG_BELUM_PERNAH_DIPAKAI
```

Build baru diperlukan untuk UI MychaAI, kontrol sematan, kolom tautan, dan pemeriksaan gambar galeri pada Android. APK lama tetap dapat mengakses fitur lama, tetapi unggahan gambar LIVE melalui UI lama dapat ditolak sampai aplikasi diperbarui karena server mewajibkan pemeriksaan baru. Key/package `id.web.kocehind` dipertahankan. Paket ini belum memuat APK/AAB release; jangan mengganti key lama.

## 9. Robots dan sitemap

SEO Video R1 sudah menyatu. Generator sitemap utama dan sitemap statis tetap dipertahankan. Sitemap video tambahan `https://kocehind.web.id/sitemaps/videos.xml`, metadata video, VideoObject, caption HTML, dan izin crawl `/media/` publik mengikuti perbaikan sebelumnya. Semua byte media tetap melalui otorisasi secure_media.

Robots main/web/admin mempertahankan perbaikan crawl; web/admin tetap noindex. Indeks MychaAI tidak otomatis dimasukkan ke sitemap dan tidak membuka API/admin/halaman privat untuk indexing.

```bash
curl -fsS https://kocehind.web.id/robots.txt
curl -fsS https://kocehind.web.id/sitemap.xml
curl -fsS https://kocehind.web.id/sitemaps/videos.xml
curl -fsS https://api.kocehind.web.id/robots.txt
```

Lakukan uji publik dari VPS setelah update, refresh cache browser, dan pengujian penerimaan dengan akun serta perangkat Anda. Status produksi, pembelian nyata, pengiriman email nyata, inferensi model nyata dan hasil indeks Google belum diuji dari lingkungan pembuatan paket ini.
