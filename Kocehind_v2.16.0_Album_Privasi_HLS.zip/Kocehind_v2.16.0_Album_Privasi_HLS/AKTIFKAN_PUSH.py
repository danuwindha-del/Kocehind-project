#!/usr/bin/env python3
"""Enable the existing FCM worker using the private server configuration."""
import argparse
from package_ops import require_root, source_tree, run_script


if __name__ == '__main__':
    try:
        argparse.ArgumentParser(description=__doc__).parse_args()
        require_root()
        with source_tree() as project:
            run_script(project, 'scripts/vps2_aktifkan_push.sh')
    except Exception as exc:
        raise SystemExit('BELUM SELESAI: ' + str(exc)) from None
