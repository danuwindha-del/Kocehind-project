# Kocehind 2.16.0 — Album Foto, Privasi Akun, HLS dan LIVE

Mulai dari **PANDUAN_UPDATE_v2.16.0.md**.

- Album hingga 20 foto, musik Kocehind, geser horizontal dan label Foto.
- Privat total atau privat hanya teman melalui Edit profil.
- HLS terotorisasi, enam riwayat pencarian, lima tag populer, pencarian inbox.
- LIVE kamera dengan target 720p/30 fps, bitrate lebih tinggi dan mirror dimatikan.

Backend/web existing: `python3 UPDATE_BACKEND_WEB.py --check`, lalu `python3 UPDATE_BACKEND_WEB.py`. Android: `python3 PINDAH_KEY_LAMA.py build --check-only`, lalu `bash BUILD_VPS_BARU.sh` pada VPS builder dengan key lama.

Paket ini berisi source dan alat pemasangan; belum dipasang di VPS dan tidak berisi APK/AAB release atau private key. Baca laporan pengujian dan uji perangkat sebelum distribusi.
