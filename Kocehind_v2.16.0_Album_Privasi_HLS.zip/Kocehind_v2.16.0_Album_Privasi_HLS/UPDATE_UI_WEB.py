#!/usr/bin/env python3
"""Atomic web-only deployment. Does not touch API, DB, env, nginx config or APK."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time


def verify(source, manifest):
    data = json.loads(manifest.read_text())
    expected = data['web_files']
    actual = {str(p.relative_to(source)) for p in source.rglob('*') if p.is_file()}
    if actual != set(expected):
        raise RuntimeError('Daftar file web berbeda dari manifest.')
    for name, checksum in expected.items():
        rel = Path(name)
        if rel.is_absolute() or '..' in rel.parts:
            raise RuntimeError('Path manifest tidak aman.')
        p = source / rel
        if p.is_symlink() or hashlib.sha256(p.read_bytes()).hexdigest() != checksum:
            raise RuntimeError('Checksum tidak cocok: ' + name)
    return data


def activate(base, target):
    temp = base / ('.current-ui-' + str(os.getpid()))
    try:
        temp.symlink_to(target)
        temp.replace(base / 'current')
    finally:
        if temp.is_symlink():
            temp.unlink()


def install(base, source, manifest, check_only=False):
    verify(source, manifest)
    current = base / 'current'
    if not current.is_symlink() or not current.resolve().is_dir():
        raise RuntimeError('Situs existing harus memakai releases/current symlink. Jangan pakai installer ini untuk instalasi baru.')
    old = current.resolve()
    # Preserve custom deployment assets, downloads remain outside this tree.
    for folder in ('web', 'main', 'admin', 'shared'):
        if not (old / folder).is_dir():
            raise RuntimeError('Layout web existing tidak dikenali: ' + folder)
    if check_only:
        print('PREFLIGHT OK: payload utuh; situs existing ditemukan. Belum ada perubahan.')
        return old
    target = base / 'releases' / ('ui-r1-' + str(time.time_ns()))
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(old, target, symlinks=True)
    try:
        for p in source.rglob('*'):
            rel = p.relative_to(source)
            dest = target / rel
            # Never follow an existing symlink while replacing a payload path.
            for parent in dest.parents:
                if parent == target:
                    break
                if parent.is_symlink():
                    raise RuntimeError('Symlink pada subdirektori target; dibatalkan.')
            if p.is_dir():
                dest.mkdir(exist_ok=True)
            else:
                if dest.is_symlink():
                    dest.unlink()
                shutil.copyfile(p, dest)
                dest.chmod(0o644)
        for p in target.rglob('*'):
            if p.is_dir() and not p.is_symlink():
                p.chmod(0o755)
        target.chmod(0o755)
        record = base / ('rollback-ui-r1-' + str(time.time_ns()) + '.json')
        record.write_text(json.dumps({'previous': str(old), 'release': str(target)}, indent=2))
        record.chmod(0o600)
        activate(base, target)
    except Exception:
        if current.resolve() != old:
            activate(base, old)
        shutil.rmtree(target)
        raise
    print('UI WEB R1 TERPASANG. API/database/env/APK tidak diubah. Tidak perlu restart API.')
    print('Rollback: sudo python3 UPDATE_UI_WEB.py --rollback ' + str(record))
    return target


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--rollback', type=Path)
    args = parser.parse_args()
    if os.geteuid() != 0:
        raise RuntimeError('Jalankan dengan sudo pada VPS backend/web existing.')
    base = Path('/var/www/kocehind-sites')
    if args.rollback:
        record = json.loads(args.rollback.read_text())
        previous = Path(record['previous']).resolve()
        releases = (base / 'releases').resolve()
        if not previous.is_relative_to(releases) or not previous.is_dir():
            raise RuntimeError('Target rollback tidak valid.')
        if (base / 'current').resolve() != Path(record['release']).resolve():
            raise RuntimeError('Current sudah berganti sejak update ini; rollback ditolak agar rilis baru tidak tertimpa.')
        activate(base, previous)
        print('Rollback UI selesai. API/database/env tidak diubah.')
        return
    subprocess.run(['nginx', '-t'], check=True)
    here = Path(__file__).resolve().parent
    install(base, here / 'websites', here / 'UI_MANIFEST.json', args.check)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        raise SystemExit('BELUM BERHASIL: ' + str(exc))
