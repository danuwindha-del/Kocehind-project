#!/usr/bin/env python3
"""Install/start the existing private LiveKit Egress + Studio recording pipeline."""
import argparse
from pathlib import Path
import re
import shutil
import subprocess
from package_ops import require_root, source_tree, run_script


def selected_image(explicit=None, config=Path('/etc/kocehind/egress.env')):
    if explicit:
        value = explicit
    else:
        match = re.search(r'(?m)^LIVEKIT_EGRESS_IMAGE=(livekit/egress@sha256:[0-9a-f]{64})\s*$',
                          config.read_text() if config.is_file() else '')
        if config.is_file() and not match:
            raise RuntimeError('Digest image existing pada egress.env tidak valid; periksa konfigurasi dahulu.')
        value = match[1] if match else 'livekit/egress:v1.15.0'
    if not re.fullmatch(r'livekit/egress(?:@sha256:[0-9a-f]{64}|:v[0-9]+\.[0-9]+\.[0-9]+)', value):
        raise RuntimeError('Gunakan image resmi livekit/egress dengan versi tetap atau digest SHA-256.')
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--image', help='Default: digest existing, atau livekit/egress:v1.15.0 untuk pemasangan pertama')
    args = parser.parse_args()
    require_root()
    for name in ('docker', 'ffmpeg', 'ffprobe'):
        if not shutil.which(name):
            raise RuntimeError('Kebutuhan belum tersedia: ' + name + '. Pasang Docker Engine dan FFmpeg dahulu.')
    for path in ('/etc/kocehind/backend.env', '/etc/kocehind/live/server.yaml'):
        if not Path(path).is_file():
            raise RuntimeError('Backend/LIVE belum dikonfigurasi: ' + path)
    image = selected_image(args.image)
    if args.check:
        print('PRASYARAT FILE/TOOL SIAP. Image: ' + image)
        print('Belum memasang atau memulai layanan. Akhiri semua LIVE sebelum menjalankan tanpa --check.')
        return
    # The project installer checks for active LIVE before pulling the pinned image.
    with source_tree() as project:
        if '@sha256:' not in image:
            # Check active sessions before the potentially large first download too.
            from package_ops import RUNTIME_PYTHON
            check = ("from dotenv import load_dotenv; load_dotenv('/etc/kocehind/backend.env',override=True); "
                     "from app.core import SessionLocal; from app.live_models import LiveRoom; "
                     "db=SessionLocal(); n=db.query(LiveRoom).filter(LiveRoom.status!='ended').count(); "
                     "db.close(); assert not n, 'Akhiri semua sesi LIVE sebelum mengaktifkan rekaman'")
            subprocess.run([str(RUNTIME_PYTHON), '-c', check], cwd='/opt/kocehind/backend', check=True)
            subprocess.run(['docker', 'pull', image], check=True)
            result = subprocess.run(['docker', 'image', 'inspect', '--format', '{{index .RepoDigests 0}}', image],
                                    capture_output=True, text=True, check=True)
            image = result.stdout.strip()
        if not re.fullmatch(r'livekit/egress@sha256:[0-9a-f]{64}', image):
            raise RuntimeError('Digest image resmi tidak ditemukan; konfigurasi belum diubah.')
        run_script(project, 'scripts/vps2_pasang_egress.sh', image)
    subprocess.run(['systemctl', 'restart', 'kocehind-egress', 'kocehind-studio-worker'], check=True)
    subprocess.run(['systemctl', 'is-active', 'kocehind-egress', 'kocehind-studio-worker'], check=True)
    print('Layanan dimulai. Uji LIVE baru sampai selesai dan periksa rekaman di Studio; sesi lama tidak direkam kembali.')


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        raise SystemExit('BELUM SELESAI: ' + str(exc)) from None
