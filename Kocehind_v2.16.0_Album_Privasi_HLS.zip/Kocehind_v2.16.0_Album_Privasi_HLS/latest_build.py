#!/usr/bin/env python3
"""Build APK + AAB from the bundled Kocehind v2.16.0 source and an EXISTING key.

Run: python3 /root/KOCEHIND_BUILD_TERBARU_KEY_LAMA_v2.16.0.pyz
The old project is read only: its Android runner, build settings and signing
credentials are reused in a NEW private build directory. No server is deployed.
"""
import argparse
import getpass
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shlex
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import urllib.request
import xml.etree.ElementTree as ET
import zipfile

import signing_core as signing

VERSION = '2.16.0'
BUILDER_REVISION = 19
MIN_BUILD = 42
ASSET = 'assets/kocehind_build_info.json'
ANDROID_NS = 'http://schemas.android.com/apk/res/android'
ENV_KEYS = ('API_BASE_URL', 'GOOGLE_WEB_CLIENT_ID', 'FIREBASE_API_KEY',
            'FIREBASE_APP_ID', 'FIREBASE_SENDER_ID', 'FIREBASE_PROJECT_ID')
DEFAULT_CONFIG = Path(__file__).with_name('build-defaults.json')
SKIP_DIRS = {'build', '.gradle', '.kotlin', '.dart_tool', '.git', 'node_modules',
             '.pub-cache', '.cache', 'android-sdk', 'sdk', 'test-venv', '.kocehind-builds'}


def say(message):
    print(message, flush=True)


def archive_payload():
    with zipfile.ZipFile(sys.argv[0]) as package:
        config = json.loads(package.read('package.json'))
        payload = package.read('source.zip')
    if config['version'] != VERSION or hashlib.sha256(payload).hexdigest() != config['source_sha256']:
        raise RuntimeError('Paket source tidak utuh. Unduh ulang paket build terbaru.')
    return payload, config


def native_gradle(project):
    paths = [project/'flutter/android/app/build.gradle.kts', project/'flutter/android/app/build.gradle']
    paths = [p for p in paths if p.is_file()]
    if len(paths) != 1:
        raise RuntimeError('Project lama harus memiliki satu build.gradle Android yang pernah dipakai build.')
    return paths[0]


def is_project(path):
    return (path/'flutter/pubspec.yaml').is_file() and any(
        (path/'flutter/android/app'/name).is_file() for name in ('build.gradle.kts', 'build.gradle'))


def find_project(explicit=None):
    if explicit:
        path = signing.project_at(explicit)
        native_gradle(path)
        return path
    cwd = Path.cwd().resolve()
    for path in (cwd, *cwd.parents, cwd/'kocehind_realtime_v2',
                 Path(sys.argv[0]).resolve().parent/'kocehind_realtime_v2',
                 Path.home()/'kocehind_realtime_v2'):
        if is_project(path): return path.resolve()
    candidates = set()
    for base, dirs, _ in os.walk(Path.home(), followlinks=False):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS and not Path(base, d).is_symlink()
                         and len(Path(base, d).relative_to(Path.home()).parts) <= 4)
        path = Path(base)
        if is_project(path):
            candidates.add(path.resolve())
            dirs[:] = []
    choices = sorted(candidates)
    if len(choices) == 1: return choices[0]
    if not choices:
        raise RuntimeError('Project Android lama tidak ditemukan. Jalankan pada VPS yang tadi berhasil menemukan keystore; atau tambahkan --project /lokasi/project/lama.')
    say('Ditemukan beberapa project lama. Pilih yang sebelumnya menghasilkan AAB:')
    for i, path in enumerate(choices, 1): say(str(i)+'. '+str(path))
    if sys.stdin.isatty():
        answer = input('Nomor project lama: ').strip()
        if answer.isdigit() and 1 <= int(answer) <= len(choices): return choices[int(answer)-1]
    raise RuntimeError('Project belum dipilih. Ulangi dengan --project diikuti folder project lama.')


def application_id(gradle):
    text = gradle.read_text(encoding='utf-8')
    # Recognize the ordinary generated Flutter runner; refuse dynamic/flavored
    # IDs rather than silently choose the default id.web.kocehind.
    text = re.sub(r'/\*.*?\*/|(?m:^[ \t]*//[^\n]*)', '', text, flags=re.S)
    ids = set(re.findall(r'''\bapplicationId\s*(?:=\s*)?["']([A-Za-z][A-Za-z0-9_.]*)["']''', text))
    if len(ids) != 1 or 'applicationIdSuffix' in text or re.search(r'\bproductFlavors\s*\{', text):
        raise RuntimeError('Package Android lama memakai konfigurasi khusus. Build dihentikan agar identitas aplikasi tidak berubah; kirim build.gradle tanpa password untuk diperiksa.')
    return next(iter(ids))


def select_key(project, explicit, expected):
    config = signing.properties(project/'flutter/android/key.properties')
    configured = None
    if config.get('storeFile'):
        configured = Path(config['storeFile']).expanduser()
        if not configured.is_absolute(): configured = project/'flutter/android/app'/configured
        configured = configured.resolve()
    paths = [explicit.expanduser().resolve()] if explicit else signing.discover(project, configured)
    if configured in paths:
        paths.remove(configured); paths.insert(0, configured)
    for path in paths:
        if not path.is_file(): continue
        say('Memeriksa keystore lama: '+str(path))
        password = config.get('storePassword') if path == configured else None
        if password is None and path.name == 'debug.keystore': password = 'android'
        entries = signing.inspect(path, password) if password is not None else None
        if entries is None and sys.stdin.isatty():
            password = getpass.getpass('Password keystore ini (Enter untuk lewati): ')
            if password: entries = signing.inspect(path, password)
        if not entries: continue
        for entry in entries:
            if entry['sha1'] != expected: continue
            if re.search(r'CN\s*=\s*Android Debug(?:\s*[,\n]|$)', entry['owner'], re.I): continue
            keypass = config.get('keyPassword') if path == configured and entry['alias'] == config.get('keyAlias') else None
            say('Kunci lama cocok: '+signing.fingerprint(entry['sha1']))
            return {**entry, 'path': path}, password, keypass
    raise RuntimeError('Keystore dengan SHA-1 lama belum ditemukan. Tidak ada kunci baru yang dibuat. Gunakan --keystore /lokasi/keystore/lama jika perlu.')


def read_env(path):
    result = {}
    if not path.is_file(): return result
    for line in path.read_text(encoding='utf-8', errors='replace').splitlines():
        match = re.match(r'^\s*(?:export\s+)?([A-Z_]+)\s*=\s*(.*?)\s*$', line)
        if not match or match[1] not in ENV_KEYS: continue
        try: parts = shlex.split(match[2], comments=True, posix=True)
        except ValueError: continue
        if len(parts) == 1 and '$' not in parts[0] and '`' not in parts[0] and parts[0]:
            result[match[1]] = parts[0]
    return result


def default_environment():
    if not DEFAULT_CONFIG.is_file():
        return {}
    values = json.loads(DEFAULT_CONFIG.read_text(encoding='utf-8'))
    required = set(ENV_KEYS) | {'REQUIRE_PUSH'}
    if (not isinstance(values, dict) or set(values) != required
            or any(not isinstance(v, str) or not v.strip() for v in values.values())
            or values['REQUIRE_PUSH'] != '1'
            or not re.fullmatch(r'[0-9]+-[A-Za-z0-9_-]+\.apps\.googleusercontent\.com', values['GOOGLE_WEB_CLIENT_ID'])
            or not values['API_BASE_URL'].startswith('https://')
            or not values['FIREBASE_SENDER_ID'].isdigit()
            or not values['FIREBASE_APP_ID'].startswith('1:'+values['FIREBASE_SENDER_ID']+':android:')):
        raise RuntimeError('Konfigurasi build bawaan tidak lengkap/valid. Ekstrak ulang paket terbaru.')
    return values


def build_environment(project, app_id, allow_fetch=True):
    settings = {}
    for path in (Path('/etc/kocehind/backend.env'), project/'backend/.env', project/'.env', project/'flutter/.env'):
        settings.update(read_env(path))
    saved = project.parent/'build-environment.json'
    if saved.is_file():
        values = json.loads(saved.read_text())
        settings.update({k:v for k,v in values.items() if k in ENV_KEYS and isinstance(v,str) and v})
    # Recover the exact Android Firebase project used in the previous runner.
    old = project/'flutter'
    xmls = [old/'build/app/generated/res/google-services/release/values/values.xml',
            old/'android/app/src/main/res/values/kocehind_firebase.xml',
            old/'android/app/src/main/res/values/strings.xml']
    mapping = {'google_api_key':'FIREBASE_API_KEY', 'google_app_id':'FIREBASE_APP_ID',
               'gcm_defaultSenderId':'FIREBASE_SENDER_ID', 'project_id':'FIREBASE_PROJECT_ID',
               'default_web_client_id':'GOOGLE_WEB_CLIENT_ID'}
    for path in xmls:
        if path.is_file():
            for node in ET.parse(path).getroot().findall('string'):
                key = mapping.get(node.get('name'))
                if key and node.text: settings[key] = node.text.strip()
    google = old/'android/app/google-services.json'
    if google.is_file():
        data = json.loads(google.read_text())
        clients = [c for c in data.get('client',[]) if c.get('client_info',{}).get('android_client_info',{}).get('package_name') == app_id]
        if len(clients) == 1:
            client = clients[0]; info = data.get('project_info',{})
            for key, value in {'FIREBASE_API_KEY':next((a.get('current_key') for a in client.get('api_key',[]) if a.get('current_key')),None),
                'FIREBASE_APP_ID':client.get('client_info',{}).get('mobilesdk_app_id'),
                'FIREBASE_SENDER_ID':info.get('project_number'), 'FIREBASE_PROJECT_ID':info.get('project_id'),
                'GOOGLE_WEB_CLIENT_ID':next((a.get('client_id') for a in client.get('oauth_client',[]) if a.get('client_type') == 3),None)}.items():
                if value: settings[key] = str(value)
    settings.update({k:os.environ[k].strip() for k in ENV_KEYS if os.getenv(k,'').strip()})
    # The owner's packaged settings win over stale values in the old runner,
    # migrated profile and SSH session. No per-build prompt/export is needed.
    settings.update(default_environment())
    settings.setdefault('API_BASE_URL', 'https://api.kocehind.web.id')
    if allow_fetch and not settings.get('GOOGLE_WEB_CLIENT_ID') and settings['API_BASE_URL'].startswith('https://'):
        try:
            with urllib.request.urlopen(settings['API_BASE_URL'].rstrip('/')+'/web/config', timeout=8) as response:
                value = json.loads(response.read(65536)).get('google_web_client_id','')
            if isinstance(value,str) and re.fullmatch(r'[\w.-]+\.apps\.googleusercontent\.com',value):
                settings['GOOGLE_WEB_CLIENT_ID'] = value
        except Exception:
            pass  # Offline builds can still use local configuration.
    firebase = [bool(settings.get(k)) for k in ENV_KEYS[2:]]
    if any(firebase) and not all(firebase):
        missing = ', '.join(k for k in ENV_KEYS[2:] if not settings.get(k))
        raise RuntimeError('Konfigurasi Firebase lama tidak lengkap. Isi environment berikut sebelum build: '+missing)
    return settings


def sdk_tool(name, project):
    if shutil.which(name): return shutil.which(name)
    roots = [os.getenv('ANDROID_SDK_ROOT'), os.getenv('ANDROID_HOME'),
             signing.properties(project/'flutter/android/local.properties').get('sdk.dir'),
             str(Path.home()/'android-sdk'), str(Path.home()/'Android/Sdk')]
    for root in roots:
        if not root: continue
        tools = Path(root).expanduser()/'build-tools'
        candidates = list(tools.glob('*/'+name)) if tools.is_dir() else []
        candidates.sort(key=lambda p: tuple(int(n) for n in re.findall(r'\d+',p.parent.name)), reverse=True)
        for path in candidates:
            if path.is_file() and os.access(path, os.X_OK): return str(path)
    raise RuntimeError(name+' belum tersedia pada Android SDK VPS. Pasang Android build-tools lalu ulangi.')


def parse_apk_badging(output):
    lines = [line for line in output.splitlines() if line.startswith('package:')]
    if len(lines) != 1:
        raise RuntimeError('Identitas/versi APK tidak dapat dibaca.')
    try:
        tokens = shlex.split(lines[0], posix=True)
    except ValueError:
        raise RuntimeError('Format identitas/versi APK tidak valid.') from None
    required = {'name','versionCode','versionName'}
    values = {}
    # Match whole keys. An unanchored regex also matched the "name" suffix in
    # compileSdkVersionCodename, replacing id.web.kocehind with e.g. "16".
    for token in tokens[1:]:
        key, separator, value = token.partition('=')
        if key not in required: continue
        if not separator or key in values:
            raise RuntimeError('Identitas/versi APK ganda atau tidak valid.')
        values[key] = value
    if (set(values) != required or not re.fullmatch(r'[0-9]+',values['versionCode'])
            or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_.]*',values['name'])):
        raise RuntimeError('Identitas/versi APK tidak dapat dibaca.')
    return values['name'], values['versionName'], int(values['versionCode'])


def apk_metadata(path, aapt):
    result = subprocess.run([aapt,'dump','badging',str(path)], capture_output=True, text=True, timeout=60, check=True)
    return parse_apk_badging(result.stdout)


def next_number(project, app_id, state_file, explicit=None):
    numbers = [MIN_BUILD-1]
    text = (project/'flutter/pubspec.yaml').read_text()
    match = re.search(r'(?m)^version:\s*\S+\+(\d+)\s*$', text)
    if match: numbers.append(int(match[1]))
    local = signing.properties(project/'flutter/android/local.properties').get('flutter.versionCode')
    if local and local.isdigit(): numbers.append(int(local))
    native = native_gradle(project).read_text()
    numbers.extend(int(n) for n in re.findall(r'(?m)^\s*versionCode\s*(?:=\s*)?(\d+)\s*;?\s*$',native))
    metadata = project/'flutter/build/app/outputs/apk/release/output-metadata.json'
    if metadata.is_file():
        data = json.loads(metadata.read_text())
        if data.get('applicationId') == app_id:
            numbers.extend(int(e['versionCode']) for e in data.get('elements',[]) if str(e.get('versionCode','')).isdigit())
    old_apk = project/'flutter/build/app/outputs/flutter-apk/app-release.apk'
    if old_apk.is_file():
        try:
            package, _, number = apk_metadata(old_apk,sdk_tool('aapt', project))
            if package != app_id:
                raise RuntimeError('Package APK lama: '+package+'; applicationId build.gradle: '+app_id+'. Keduanya memang berbeda. Kirim pesan lengkap ini agar identitas aplikasi dapat ditentukan tanpa mengubah key lama.')
            numbers.append(number)
        except subprocess.CalledProcessError:
            raise RuntimeError('APK lama tidak dapat dibaca. Pindahkan APK rusak dari folder build, lalu ulangi.')
    if state_file.is_file():
        data = json.loads(state_file.read_text())
        if data.get('application_id') == app_id: numbers.append(int(data['build_number']))
    value = max(numbers)+1 if explicit is None else explicit
    if value <= max(numbers) or value > 2_100_000_000:
        raise RuntimeError('Nomor build harus lebih besar dari semua nomor lokal yang terdeteksi dan tidak melebihi 2100000000.')
    return value


def extract_source(payload, build_root):
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        entries = archive.infolist()
        names = [e.filename for e in entries]
        if len(names) != len(set(names)): raise RuntimeError('ZIP source memuat nama file ganda.')
        for entry in entries:
            path = PurePosixPath(entry.filename)
            if path.is_absolute() or '..' in path.parts or '\\' in entry.filename or path.parts[0] != 'kocehind_realtime_v2':
                raise RuntimeError('Lokasi file pada ZIP source tidak valid.')
            if stat.S_ISLNK(entry.external_attr >> 16): raise RuntimeError('ZIP source memuat symlink.')
        archive.extractall(build_root)
    return build_root/'kocehind_realtime_v2'


def copy_native(project, target):
    origin = project/'flutter/android'
    # Symlinks in old runners can point at the old source or private data.
    # Refuse them in copied files rather than import a mutable external source.
    def ignore(base, names):
        result = {n for n in names if n in SKIP_DIRS or n in {'key.properties','local.properties'}}
        for name in names:
            if name in result: continue
            path = Path(base,name)
            if path.is_symlink():
                raise RuntimeError('Symlink Android perlu diperiksa agar source lama tidak terbawa: '+str(path))
        return result
    shutil.copytree(origin, target/'flutter/android', ignore=ignore)
    local = signing.properties(origin/'local.properties')
    sdk = os.getenv('ANDROID_SDK_ROOT') or os.getenv('ANDROID_HOME') or local.get('sdk.dir')
    flutter_sdk = local.get('flutter.sdk')
    values = {}
    if sdk: values['sdk.dir'] = sdk
    if flutter_sdk: values['flutter.sdk'] = flutter_sdk
    signing.write_private(target/'flutter/android/local.properties', ''.join(k+'='+signing.java_value(v)+'\n' for k,v in values.items()))
    return sdk, flutter_sdk


def validate_key(selected, password, keypass):
    # Check the private-key password BEFORE a potentially long Flutter build.
    # The real keystore stays read only; the small signed probe is temporary.
    with tempfile.TemporaryDirectory(prefix='kocehind-key-check-') as folder:
        probe = Path(folder)/'probe.jar'
        with zipfile.ZipFile(probe,'w') as archive:
            archive.writestr('META-INF/MANIFEST.MF','Manifest-Version: 1.0\r\n\r\n')
            archive.writestr('check.txt','Kocehind local signing check\n')
        env = os.environ.copy()
        env['KOCEHIND_CHECK_STOREPASS'] = password
        env['KOCEHIND_CHECK_KEYPASS'] = keypass
        result = subprocess.run(['jarsigner','-keystore',str(selected['path']),
            '-storepass:env','KOCEHIND_CHECK_STOREPASS','-keypass:env','KOCEHIND_CHECK_KEYPASS',
            str(probe),selected['alias']],env=env,capture_output=True,text=True,timeout=60)
        if result.returncode:
            raise RuntimeError('Password alias/kunci belum cocok, atau kunci tidak dapat digunakan untuk signing. Keystore lama tidak diubah; ulangi dengan password alias yang benar.')
        signing.verify_aab(probe,selected['sha1'])


def source_hashes(project):
    files = sorted((project/'flutter/lib').rglob('*.dart'))
    if not files: raise RuntimeError('Source Flutter terbaru tidak ditemukan.')
    return {str(path.relative_to(project)):hashlib.sha256(path.read_bytes()).hexdigest() for path in files}


def configure_build(project, selected, password, keypass, number, marker):
    gradle = native_gradle(project)
    kotlin = gradle.suffix == '.kts'
    updated = signing.patch_gradle(gradle.read_text(encoding='utf-8'), kotlin)
    # Add a final version override; custom old runners may hardcode an old
    # version instead of using flutter.versionName / flutter.versionCode.
    block = ('\n// BEGIN KOCEHIND PINNED VERSION\nandroid {\n    defaultConfig {\n'
             + (f'        versionName = "{VERSION}"\n        versionCode = {number}\n' if kotlin else
                f'        versionName "{VERSION}"\n        versionCode {number}\n')
             + '    }\n}\n// END KOCEHIND PINNED VERSION\n')
    updated = re.sub(r'\n// BEGIN KOCEHIND PINNED VERSION\n.*?// END KOCEHIND PINNED VERSION\n?', '',updated,flags=re.S)
    signing.write_private(gradle, updated+block)
    props = {'storeFile':str(selected['path']), 'storePassword':password,
             'keyAlias':selected['alias'], 'keyPassword':keypass}
    signing.write_private(project/'flutter/android/key.properties', ''.join(k+'='+signing.java_value(v)+'\n' for k,v in props.items()))
    pubspec = project/'flutter/pubspec.yaml'
    text, count = re.subn(r'(?m)^version:\s*[^\n]+$', 'version: '+VERSION+'+'+str(number),pubspec.read_text())
    if count != 1: raise RuntimeError('Nomor versi Flutter pada source tidak dikenali.')
    anchor = '    - assets/launcher_icon.png'
    if text.count(anchor) != 1: raise RuntimeError('Daftar aset source tidak dikenali.')
    text = text.replace(anchor,anchor+'\n    - '+ASSET)
    pubspec.write_text(text,encoding='utf-8')
    (project/'flutter'/ASSET).write_text(json.dumps(marker,sort_keys=True,indent=2)+'\n',encoding='utf-8')


def varint(data, offset):
    value = 0
    for shift in range(0,70,7):
        if offset >= len(data): break
        byte = data[offset]; offset += 1
        value |= (byte & 127) << shift
        if byte < 128: return value, offset
    raise RuntimeError('Manifest AAB memiliki protobuf terpotong/tidak valid.')


def fields(data):
    result = {}; offset = 0
    while offset < len(data):
        tag, offset = varint(data,offset); number, wire = tag >> 3, tag & 7
        if number == 0: raise RuntimeError('Nomor field manifest AAB tidak valid.')
        if wire == 0: value, offset = varint(data,offset)
        elif wire in (1,5):
            size = 8 if wire == 1 else 4
            value = data[offset:offset+size]; offset += size
            if len(value) != size: raise RuntimeError('Manifest AAB terpotong.')
        elif wire == 2:
            size, offset = varint(data,offset)
            value = data[offset:offset+size]; offset += size
            if len(value) != size: raise RuntimeError('Manifest AAB terpotong.')
        else: raise RuntimeError('Format protobuf manifest AAB tidak didukung.')
        result.setdefault(number,[]).append(value)
    return result


def one(data, number, default=None):
    values = data.get(number,[])
    if len(values) > 1: raise RuntimeError('Manifest AAB memiliki nilai identitas ganda.')
    return values[0] if values else default


def bundle_metadata(path):
    # Read AAPT2's published Resources.proto XmlNode/XmlAttribute schema.
    # https://android.googlesource.com/platform/frameworks/base/+/refs/heads/main/tools/aapt2/Resources.proto
    with zipfile.ZipFile(path) as archive:
        manifest = archive.read('base/manifest/AndroidManifest.xml')
    root = fields(one(fields(manifest),1,b''))
    if one(root,3,b'').decode() != 'manifest': raise RuntimeError('Manifest utama AAB tidak ditemukan.')
    values = {}
    for raw in root.get(4,[]):
        attr = fields(raw)
        ns = one(attr,1,b'').decode(); name = one(attr,2,b'').decode()
        if (ns,name) not in {('','package'),(ANDROID_NS,'versionName'),(ANDROID_NS,'versionCode')}: continue
        if name in values: raise RuntimeError('Identitas/versi ganda dalam manifest AAB.')
        value = one(attr,3,b'').decode()
        compiled = fields(one(attr,6,b''))
        if name == 'versionCode':
            primitive = fields(one(compiled,7,b''))
            actual = one(primitive,6,one(primitive,7))
            value = int(actual) if actual is not None else int(value)
        elif not value:
            raw_string = one(compiled,2,one(compiled,3,b''))
            value = one(fields(raw_string),1,b'').decode()
        values[name] = value
    if set(values) != {'package','versionName','versionCode'}:
        raise RuntimeError('Package/versi AAB tidak lengkap.')
    return values['package'], values['versionName'], values['versionCode']


def verify_apk(path, expected, apksigner):
    result = subprocess.run([apksigner,'verify','--print-certs',str(path)],
        text=True,capture_output=True,timeout=120)
    if result.returncode: raise RuntimeError('Tanda tangan APK tidak valid. Hasil belum dinyatakan selesai.')
    actual = re.findall(r'(?m)^Signer #\d+ certificate SHA-1 digest:\s*([0-9a-fA-F:]+)',result.stdout)
    if not actual or any(signing.normalized(value) != expected for value in actual):
        raise RuntimeError('APK tidak memakai sertifikat key lama yang diminta.')


def verify_outputs(project, expected, marker, started):
    flutter = project/'flutter'
    apk = flutter/'build/app/outputs/flutter-apk/app-release.apk'
    aab = flutter/'build/app/outputs/bundle/release/app-release.aab'
    for path in (apk,aab):
        if not path.is_file() or path.stat().st_mtime_ns < started:
            raise RuntimeError('Build belum menghasilkan APK dan AAB BARU. File lama tidak dianggap sukses.')
    verify_apk(apk, expected, sdk_tool('apksigner',project))
    signing.verify_aab(aab,expected)
    wanted = (marker['application_id'],VERSION,marker['build_number'])
    if apk_metadata(apk,sdk_tool('aapt',project)) != wanted or bundle_metadata(aab) != wanted:
        raise RuntimeError('Package/versi APK atau AAB tidak cocok dengan build terbaru yang diminta.')
    for path, prefix in ((apk,'assets/flutter_assets/'),(aab,'base/assets/flutter_assets/')):
        with zipfile.ZipFile(path) as archive:
            matches = [n for n in archive.namelist() if n == prefix+ASSET]
            if len(matches) != 1 or json.loads(archive.read(matches[0])) != marker:
                raise RuntimeError('Penanda source terbaru dalam APK/AAB tidak cocok. Jangan gunakan file tersebut.')
    return apk,aab


def execute(payload, config, old, selected, password, keypass, number, env, output_root):
    output_root.mkdir(mode=0o700,parents=True,exist_ok=True)
    root = Path(tempfile.mkdtemp(prefix='v'+VERSION+'-build'+str(number)+'-',dir=output_root))
    project = extract_source(payload,root)
    lib_hashes = source_hashes(project)
    combined = hashlib.sha256(json.dumps(lib_hashes,sort_keys=True).encode()).hexdigest()
    sdk, flutter_sdk = copy_native(old,project)
    marker = {'version':VERSION,'build_number':number,'application_id':application_id(native_gradle(old)),
              'source_sha256':config['source_sha256'],'dart_sources_sha256':combined,
              'signer_sha1':signing.fingerprint(selected['sha1'])}
    configure_build(project,selected,password,keypass,number,marker)
    signing.write_private(root/'build-environment.json',json.dumps(env,indent=2)+'\n')
    say('Source terbaru: Kocehind '+VERSION+'+'+str(number))
    say('Package tetap: '+marker['application_id'])
    say('Folder build baru: '+str(project))
    child = os.environ.copy(); child.update(env)
    child['KOCEHIND_REUSE_ANDROID_RUNNER'] = '1'
    if sdk: child['ANDROID_SDK_ROOT'] = sdk; child['ANDROID_HOME'] = sdk
    flutter_sdk = os.getenv('KOCEHIND_FLUTTER_ROOT') or flutter_sdk
    if flutter_sdk: child['PATH'] = str(Path(flutter_sdk)/'bin')+os.pathsep+child.get('PATH','')
    if source_hashes(project) != lib_hashes: raise RuntimeError('Source Flutter berubah sebelum build.')
    started = time.time_ns()
    subprocess.run(['bash',str(project/'scripts/vps1_build_apk_aab.sh')],cwd=project,env=child,check=True)
    if source_hashes(project) != lib_hashes: raise RuntimeError('Source Flutter berubah saat build. Hasil belum diterima.')
    # Tool lookup uses the exact SDK selected for this build.
    previous = {k:os.environ.get(k) for k in ('ANDROID_SDK_ROOT','ANDROID_HOME')}
    try:
        if sdk: os.environ['ANDROID_SDK_ROOT'] = sdk; os.environ['ANDROID_HOME'] = sdk
        apk,aab = verify_outputs(project,selected['sha1'],marker,started)
    finally:
        for key,value in previous.items():
            if value is None: os.environ.pop(key,None)
            else: os.environ[key] = value
    # Only expose user-facing output names after BOTH artifacts pass checks.
    result = root/'HASIL_TERVERIFIKASI'; result.mkdir(mode=0o700)
    final_apk = result/f'Kocehind-v{VERSION}-{number}.apk'
    final_aab = result/f'Kocehind-v{VERSION}-{number}.aab'
    shutil.copyfile(apk,final_apk); shutil.copyfile(aab,final_aab)
    report = {**marker,'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (final_apk,final_aab)},
              'old_project':str(old),'build_project':str(project)}
    signing.write_private(result/'HASIL_BUILD.json',json.dumps(report,indent=2)+'\n')
    signing.write_private(output_root/'latest-build.json',json.dumps(report,indent=2)+'\n')
    say('\nBUILD APK DAN AAB TERBARU SELESAI DAN TERVERIFIKASI')
    say('Versi: '+VERSION+' | Nomor build: '+str(number))
    say('SHA-1 key lama APK/AAB: '+signing.fingerprint(selected['sha1']))
    say('APK: '+str(final_apk))
    say('AAB: '+str(final_aab))
    say('AAB di atas ditandatangani upload key lama untuk diunggah ke Google Play.')
    say('APK lokal di atas juga memakai upload key lama. Untuk web dengan sertifikat Google Play, ambil Signed, universal APK tanpa Installer check yang mewajibkan Play, lalu gunakan PUBLIKASI_APK_PLAY.py di VPS backend.')
    say('Backend tidak dipasang ulang.')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project',type=Path,help='Opsional: project lama untuk mengambil konfigurasi Android dan key.')
    parser.add_argument('--keystore',type=Path,help='Opsional: lokasi key LAMA jika di luar folder pencarian.')
    parser.add_argument('--build-number',type=int,help='Opsional: nomor yang lebih tinggi jika nomor Play lebih besar dari yang terdeteksi lokal.')
    parser.add_argument('--output-dir',type=Path,default=Path.home()/'.kocehind-builds')
    parser.add_argument('--expected-sha1',help='Opsional: SHA-1 lengkap 20 byte; default memakai key lama yang sudah dilaporkan.')
    parser.add_argument('--check-only',action='store_true',help='Periksa source, konfigurasi dan sertifikat tanpa menulis/membangun.')
    parser.add_argument('--info',action='store_true',help='Tampilkan versi source bawaan tanpa memerlukan project/SDK.')
    args = parser.parse_args()
    os.umask(0o077)
    payload,config = archive_payload()
    expected = signing.normalized(args.expected_sha1) if args.expected_sha1 else signing.TARGET_SHA1
    if len(expected) != 40: raise RuntimeError('SHA-1 harus lengkap: 20 pasangan angka/huruf.')
    say('Paket build Kocehind TERBARU '+VERSION+' — APK + AAB, key lama (perbaikan build '+str(BUILDER_REVISION)+')')
    say('Target key lama: '+signing.fingerprint(expected))
    if args.info:
        say('SHA-256 snapshot source: '+config['source_sha256']); return
    java = Path(os.environ.get('JAVA_HOME','/usr/lib/jvm/java-17-openjdk-amd64'))/'bin'
    os.environ['PATH'] = str(java)+os.pathsep+os.environ.get('PATH','')
    for tool in ('keytool','jarsigner'):
        if not shutil.which(tool): raise RuntimeError('JDK pada VPS build belum lengkap: '+tool+' tidak ditemukan. Pasang openjdk-17-jdk lalu ulangi.')
    project = find_project(args.project)
    app_id = application_id(native_gradle(project))
    say('Konfigurasi Android diambil dari: '+str(project))
    say('Source aplikasi yang dibuild berasal dari paket terbaru, bukan folder lama ini.')
    selected,password,keypass = select_key(project,args.keystore,expected)
    env = build_environment(project,app_id,allow_fetch=not args.check_only)
    number = next_number(project,app_id,args.output_dir/'latest-build.json',args.build_number)
    if args.check_only:
        say('PEMERIKSAAN LULUS: source '+VERSION+', key lama cocok, package '+app_id+', calon nomor build '+str(number))
        return
    if keypass is None:
        if not sys.stdin.isatty(): raise RuntimeError('Jalankan dari terminal SSH interaktif untuk password alias.')
        keypass = getpass.getpass('Password alias/kunci (Enter jika sama dengan password keystore): ') or password
    validate_key(selected,password,keypass)
    if not env.get('GOOGLE_WEB_CLIENT_ID'):
        if sys.stdin.isatty():
            value = input('ID Web Google lama belum ditemukan. Tempel GOOGLE_WEB_CLIENT_ID (Enter jika tidak memakai Google Login): ').strip()
            if value: env['GOOGLE_WEB_CLIENT_ID'] = value
        if not env.get('GOOGLE_WEB_CLIENT_ID'): say('Google Login belum dikonfigurasi pada build ini.')
    if not env.get('FIREBASE_APP_ID'): say('Konfigurasi Firebase lama tidak ditemukan; push perangkat belum diaktifkan pada build ini.')
    execute(payload,config,project,selected,password,keypass,number,env,args.output_dir.expanduser().resolve())


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        say('\nDihentikan. Project dan keystore lama tetap tersedia.'); sys.exit(130)
    except Exception as exc:
        message = str(exc) if type(exc) is RuntimeError else ('Perintah build gagal; periksa error terminal di atas.'
            if isinstance(exc,subprocess.CalledProcessError) else 'Pemeriksaan/build gagal ('+type(exc).__name__+').')
        print('\nBELUM BERHASIL: '+message,file=sys.stderr)
        sys.exit(1)
