# Laporan Integrasi Kocehind UI R2

Tanggal: 30 Oktober 2026 (WIB).
Sumber utama: Kocehind_UI_R1.zip yang dikirim pengguna. Source aplikasi dan backend tetap 2.13.3; revisi integrasi paket R2, builder revision 16. Tidak ada desain lama yang disalin dari paket v2.12.6.

## Temuan dan perubahan

| Integrasi | Temuan | Hasil R2 |
|---|---|---|
| Pembelian koin web | Beranda/panduan memakai /coins tetapi router hanya menangani /wallet | /coins, /coins/ dan /wallet membuka komponen checkout Kipay yang sama; akses akun tetap diperiksa |
| Update backend/web | Paket utama hanya memiliki updater UI; jalur update backend tidak disertakan di tingkat paket | UPDATE_BACKEND_WEB.py dipulihkan dengan verifikasi source dan Python backend existing; situs R1 dibawa bersama backend |
| Kipay | Runtime KeyFix R1 sudah ada; alat setup/simulasi utama hilang | SETUP_KIPAY.py dan SIMULASI_KIPAY_SANDBOX.py dipulihkan; opaque credential, Base64 env aman, simulasi ditolak untuk production |
| Helper backend | Mailjet preflight tidak ikut disalin installer/updater | Mailjet preflight serta dua helper Kipay disalin ke runtime |
| Worker Studio/LIVE/email | Updater hanya melanjutkan worker yang sebelumnya aktif | Unit Studio dipasang dan maintenance dimulai; LIVE/email dipulihkan sesuai credential existing; Egress dimulai jika sebelumnya sudah dikonfigurasi |
| Rekaman pertama | Memerlukan pemasangan Egress terpisah | AKTIFKAN_REKAMAN_LIVE.py menyediakan check/setup dengan image resmi terkunci digest dan guard tanpa LIVE aktif |
| Notifikasi | Source Android dan FCM tetap ada | AKTIFKAN_PUSH.py dipulihkan; build --check-only juga mewajibkan konfigurasi Google/Firebase, REQUIRE_PUSH=1 diteruskan saat build |
| App Links | Helper publikasi sebelumnya dapat menggabungkan sertifikat dengan menghilangkan pernyataan lain | Merge mempertahankan aplikasi/relasi lama dan membawa aturan URL dinamis ke sertifikat yang ditambahkan; PERBAIKI_APP_LINKS.py memeriksa APK nyata dan dua host HTTPS |
| Unduhan APK | Wrapper publikasi Play tidak ada di paket utama | PUBLIKASI_APK_PLAY.py dipulihkan; kebijakan app signing existing tetap digunakan |
| File tambahan web | Pemasang penuh menyalin hanya source baru | Rilis berikutnya mempertahankan file deployment custom; overlay payload memeriksa symlink; pointer rilis diganti atomik |
| Dokumen hukum Kipay | Default source masih berisi kebijakan lama | Salinan versi 2 aktif dipulihkan dari API publik resmi; default hanya dipakai jika database belum mempunyai dokumen |
| Fixture pengujian sesi web | Import dependency dalam data URL terkunci pada query versi lama | Fixture menggunakan pencocokan versi generik; runtime API web tidak diubah untuk perbaikan fixture ini |

## Fitur yang sudah ada dan dipertahankan

- Backend Kipay QRIS, signed webhook, verifikasi ulang server, antrean rekonsiliasi tahan restart, kredit satu kali, invoice total/kode unik/biaya dan riwayat.
- Pesanan Tripay lama, perbaikan kolom ledger lama, wallet frozen, debt/refund, gift dan penarikan manual.
- Pembelian koin hanya di web; gift dan pendapatan di aplikasi; Google Play Billing tetap tidak diaktifkan.
- Ringkasan akhir LIVE berisi gift/koin/rupiah historis dan tiga pengirim teratas, dengan akses host/admin.
- Preview besar foto profil sendiri/orang lain; galeri dan teks LIVE, komentar gift, overlay video gift khusus.
- Model/worker moderasi, keputusan dan banding; layanan Mailjet; konfigurasi FCM dan Android App Links.
- Keystore lama, package id, konfigurasi Google/Firebase lama, pilihan nomor build otomatis dan pembatasan nomor yang pernah dipakai.

Keberadaan source dipisahkan dari aktivasi nyata: credential server, model lokal dan layanan yang belum dipasang tidak dibuat-buat oleh updater. Lihat diagnosis dan panduan aktivasi di README.

## Bukti mempertahankan desain

Perbandingan byte terhadap source dalam ZIP pengguna:

- 10 berkas CSS: identik.
- 55 berkas di flutter/lib: identik, termasuk main.dart, tema, widget dan semua layar.
- HTML web sosial hanya mengganti query cache app.js; struktur tampilan tetap.
- app.js hanya menambah alias route pembelian koin, tanpa mengganti komponen halaman.
- Source web di paket utama dan nested source disinkronkan agar jalur deploy/build memakai hasil yang sama.

Tidak ada klaim audit visual perangkat atau WCAG menyeluruh. Browser Chromium tidak dapat dipasang pada lingkungan ini karena unduhan runtime tidak tersedia; pengujian web memakai DOM dengan JavaScript nyata dan respons API sintetis.

## Pengujian aktual

- 174 tes backend lulus dalam satu run gabungan: Kipay/Tripay, wallet dan skema lama, gift/summary/canvas LIVE, Studio, Android setup/splash, akun/email, legal/migrasi serta helper integrasi baru.
- 115 tes web DOM/logika lulus, termasuk /coins dan /wallet sampai QRIS serta pembaruan saldo dengan provider sintetis, dan perlindungan /coins untuk tamu.
- 12 tes paket lulus: checksum dan path ZIP, penolakan symlink, pemilihan interpreter tanpa mengganti Python OS, pemilihan image rekaman, updater UI install/check/tamper/rollback.
- Sintaks Python, shell dan JavaScript yang diubah diperiksa. CRC ZIP dan semua manifest SHA-256 diperiksa saat packaging.

API/provider, systemctl dan signer memakai fixture/mocks pada tes helper. Pengujian pembayaran memakai database SQLite terisolasi; ini bukan bukti konkurensi PostgreSQL produksi atau transaksi uang nyata. Tes Android setup menjalankan pengubah XML/Kotlin/Gradle melalui Python, tanpa menjalankan Flutter SDK.

Belum dijalankan: deployment VPS pengguna, APK/AAB release, instalasi HP fisik, verifikasi default link di Android, pengiriman FCM nyata, deteksi model dengan data produksi atau rekaman Egress/SFU nyata. Tidak ada saldo/transaksi/credential pengguna yang diakses atau diubah dari lingkungan ini.

## Asal dokumen hukum

GET publik https://api.kocehind.web.id/legal/documents pada pekerjaan ini mengembalikan versi 2: privacy 25.657 karakter, updated_at 2026-10-28T10:46:34.744853Z; terms 28.650 karakter, updated_at 2026-10-28T10:47:20.442334Z. Isi disalin apa adanya, bukan ditulis ulang. seed_documents() tetap hanya menyisipkan dokumen yang belum ada dan tidak menimpa revisi admin.

## Referensi implementasi

- https://kipay.id/docs/security
- https://kipay.id/docs/guides/webhooks
- https://kipay.id/docs/concepts/sandbox
- https://kipay.id/docs/api/transactions/simulate
- https://developer.android.com/training/app-links/configure-assetlinks
- https://developer.android.com/training/app-links/troubleshoot
- https://docs.livekit.io/transport/self-hosting/egress/
- https://github.com/livekit/egress/releases/tag/v1.15.0
