# Pengujian source gabungan Kocehind 2.14.0

Pemeriksaan lokal 30 Oktober 2026 terhadap source yang telah digabung dari unggahan asli 2.14.0, Play Recovery R1 dan revisi katalog 1. Laporan v2.14.0 asli tetap disertakan sebagai riwayat; hasil Flutter dalam laporan lama bukan pengujian ulang pada paket ini.

## Hasil

| Pemeriksaan | Hasil |
| --- | --- |
| Regresi backend sinkron | 472 lulus, 9 dilewati; tidak ada kegagalan |
| Lima kasus backend async | 5 lulus, dijalankan terpisah dengan runner asyncio lokal |
| Alat paket dan diagnosis detail Google Play | 41 lulus |
| Sintaks Python pada paket dan source | Lulus |
| Sintaks shell installer/update/build terkait | Lulus dengan bash -n; tidak menjalankan deploy/build |
| Manifest SHA-256 source dan paket | Cocok dengan seluruh file terdaftar |
| CRC dan nama unik pada kedua ZIP | Lulus |
| package_ops.verify_bundle dan ekstraksi source_tree | Lulus menggunakan arsip source gabungan |
| Dasar build, riwayat dan larangan pakai ulang nomor | Dasar 40 cocok dengan metadata; riwayat 70 menghasilkan 71; nomor 70 ditolak |
| Perbandingan dengan source unggahan terbaru | 623 dari 634 file asli identik; 11 file diperbarui dan 4 file source ditambahkan |
| UI, web dan aset | File layar, widget dan aset Flutter serta seluruh websites identik dengan unggahan terbaru; web di paket luar dan source dalam cocok |

Total backend: **477 lulus, 9 dilewati** dari 486 kasus. Total alat paket/diagnosis: **41 lulus**.

Kasus yang dilewati memerlukan PostgreSQL uji terisolasi (5 kasus), SFU/RTC LiveKit nyata (3 kasus), atau runtime model OpenNSFW2 nyata (1 kasus). Tidak ada hasil uji tersebut yang diklaim lulus.

Lingkungan pengujian memakai Python 3.12 dan dependency backend pada virtualenv lokal, dengan NumPy dari runtime yang tersedia. Pengumpulan awal seluruh tes berhenti karena NumPy belum berada di jalur virtualenv; jalur NumPy kemudian disediakan. Lima tes async dijalankan terpisah dengan hook pytest yang mengeksekusi coroutine melalui asyncio.run karena pytest-asyncio tidak terpasang. Isi assertion dan fungsi tes tidak diubah. Peringatan deprecation FastAPI/Starlette dan marker asyncio tetap muncul.

## Perilaku pembelian yang diuji

- Tepat tujuh ID ditawarkan: 25/75/160/350/750/1600/3500.
- Satu unit menerima tepat jumlah paket, tanpa bonus tambahan; kuantitas dua menghasilkan dua kali jumlah paket.
- Token sama tidak menggandakan kredit; token baru dapat membeli paket sama lagi.
- Empat ID lama tetap dipulihkan worker tanpa ditawarkan pada katalog baru.
- Pending, penolakan identitas akun/SKU dan receipt tak lengkap tidak memberi kredit yang belum terverifikasi.
- Retry jaringan/Google, fallback receipt, konsumsi sesudah commit, refund, utang koin dan operasi admin diuji pada database terisolasi/respons pengganti.
- Katalog web dan tarif pendapatan host tidak berubah oleh pembaruan katalog Play.
- Penginstalan alat backend pada folder runtime sementara ikut menyalin diagnose_google_play.py dengan isi dan izin file yang benar.

## Batas verifikasi

Belum memasang paket pada VPS pengguna, belum membangun APK/AAB atau menjalankan Flutter analyze/test, dan belum menguji pada HP/browser produksi. Tidak membuat produk Play Console, mengirim transaksi Google nyata, mengonsumsi pembelian nyata, atau mengkredit saldo produksi.

Tidak mengklaim PostgreSQL concurrency, kualitas kamera perangkat, kemampuan model moderasi nyata, notifikasi HP atau rekaman SFU telah diuji ulang. Source integrasi fitur tersebut dipertahankan dari unggahan terbaru.

Konfigurasi privat VPS, credential, JWT_SECRET, harga Console dan tarif pendapatan host bukan bagian dari source ZIP. Ikuti UPDATE_GABUNGAN.md dan jalankan preflight pada VPS sebelum pemasangan.
