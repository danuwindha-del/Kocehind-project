#!/usr/bin/env python3
"""Check/repair website associations using the actual installed APK certificate."""
import subprocess
import sys
from package_ops import source_tree


if __name__ == '__main__':
    try:
        with source_tree() as project:
            result = subprocess.run([sys.executable, str(project / 'backend/deploy/repair_app_links.py'),
                                     *sys.argv[1:]])
            raise SystemExit(result.returncode)
    except Exception as exc:
        raise SystemExit('BELUM SELESAI: ' + str(exc)) from None
