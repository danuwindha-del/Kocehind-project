# Pengujian Kocehind 2.16.0

1 November 2026. Dasar: repositori `danuwindha-del/Kocehind-project`, HEAD `a746af2d478724f725e27dd278416adab2b1fb05`, paket source 2.15.0. Perubahan dibuat pada salinan terisolasi. Tidak ada pemasangan VPS produksi, perubahan signing key, transaksi nyata atau pengiriman pesan/email produksi.

## Hasil akhir

| Pemeriksaan | Hasil |
|---|---|
| Seluruh backend, Python 3.12.14, run serial terakhir | **529 lulus, 9 dilewati, 0 gagal** — 562,79 detik |
| Flutter 3.38.1 / Dart 3.10.0 `flutter analyze --no-pub` | **Tidak ada masalah** |
| Seluruh `flutter test --no-pub` | **129 lulus, 0 gagal** |
| Web/DOM/browser | **185 lulus, 1 dilewati, 0 gagal** dari 186 kasus |
| Alat paket, runtime Python dan diagnosis Play | **41 lulus** |
| Updater UI dan setup Android/App Links/permissions | **10 lulus** |
| Fitur backend 2.16 + stabilitas + regresi sosial terfokus | **27 lulus** |
| Sintaks Python/shell, checksum dan CRC ZIP | Diperiksa pada paket akhir |

Sembilan skip backend memerlukan PostgreSQL uji terisolasi, layanan RTC/LiveKit nyata, atau runtime model moderasi yang diaktifkan khusus. Tes tersebut tidak diubah menjadi seolah-olah lulus.

Satu skip web adalah **decode HLS H.264/AAC di browser uji**, karena Chromium Headless Shell yang tersedia tidak menyediakan decoder tersebut (`canPlayType` kosong). Tes tetap disertakan dan akan memeriksa pemutaran nyata pada browser yang mendukung codec. Browser uji yang berhasil dipakai adalah Chromium 134.0.6998.35, melalui Playwright 1.62.1 dengan override executable lokal; override tidak masuk ke kode aplikasi. Chrome stabil juga dicoba, tetapi tidak dapat dijalankan karena pembatasan socket pada lingkungan pengujian. Hasil ini bukan bukti pemutaran HLS di perangkat Android/Safari/Chrome produksi.

## Yang diverifikasi

- Unggahan nyata 20 foto: kepemilikan setiap file, urutan album, pembatasan ke-21, penolakan foto duplikat dalam payload, penolakan file akun lain dan akses foto tambahan. Foto lama tetap memiliki satu gambar. Penghapusan postingan membersihkan relasi album dan pekerjaan turunannya.
- Foto bermusik menggunakan sound yang ada. FFmpeg nyata menghasilkan video/audio sumber untuk uji integrasi, playlist VOD, segmen TS dan berkas AAC/M4A untuk album. Server benar-benar memberikan playlist/segmen/audio dan menolak URL lama setelah akun diprivat.
- HLS hanya diterbitkan setelah encoding siap. URL playlist membawa otorisasi ke playlist varian dan setiap segmen. Nama aset yang tidak diizinkan ditolak. Uji adapter web memeriksa awal pada varian rendah, fallback dan pelepasan pemutar.
- Dua mode akun privat: owner tetap dapat masuk/membuka akun, teman hanya mendapat akses pada mode teman, tamu/non-teman ditolak, pencarian dan Untuk Anda mengecualikan kedua mode termasuk cursor lama. Putus pertemanan mencabut akses. Halaman share/sitemap publik tidak membuka akun privat. Perubahan ke privat mengakhiri LIVE aktif.
- Migrasi dari tabel users existing yang belum memiliki kolom privasi, pembuatan tabel baru, pengulangan migrasi, pelestarian saldo dan pelestarian mode privat yang sudah dipilih.
- Enam riwayat pencarian terbaru, deduplikasi kapital/spasi, hapus satu/semua, pemisahan antar akun serta pembatasan guest pada penyimpanan lokal. Tag populer dibatasi lima dan tidak menghitung akun privat.
- Inbox search hanya mencari pasangan pesan yang melibatkan pengguna tersebut. Pesan dua akun lain, akun privat yang tidak boleh diakses, akun diblokir dan percakapan ditolak tidak dibuka melalui pencarian.
- Browser ponsel: carousel tiga foto, hitungan dan keyboard/geser, label Foto di baris username, batas 21, publikasi album dan sound, pilihan privasi, hapus riwayat, dan membuka hasil pencarian inbox. Tidak ada error halaman pada suite akhir.
- Widget Flutter: carousel horizontal, composer 20 foto dengan sound, penyimpanan pilihan privat total, dan refresh URL HLS. Seluruh regresi lama, termasuk feed, komentar, sesi, cache media, consent, Studio, billing dan LIVE, dijalankan.

Model moderasi pada uji album adalah pengganti terkontrol. Tes memeriksa bahwa temuan pada foto terakhir pun mencabut seluruh album; ini tidak mengukur akurasi model dunia nyata. Kamera/RTC pada tes widget dan API juga tidak menggantikan uji dua ponsel.

## Perbaikan yang ditemukan saat pengujian

- Jalur HTML profil/SEO yang memakai query khusus kini mengecualikan akun privat secara eksplisit.
- Import kebijakan akun disiapkan sebelum listener SQL berjalan, sehingga worker moderasi cold-start tidak memodifikasi daftar listener saat query sedang berlangsung. Semua kasus cold-start terkait kembali lulus.
- Web menunggu promise persiapan sumber video yang sama saat observer dan preload bersamaan. Ini memperbaiki timeout pemutaran setelah reload pada pengujian browser lama; kasus tersebut lulus pada suite akhir.
- Pemutar foto/HLS dilepas saat konten dicabut. Callback video juga dilepas sebelum elemen kontrol dibuang, sehingga event media yang terlambat tidak mengakses kontrol yang sudah hilang.
- Otorisasi berkas asli dan HLS memakai satu pekerjaan worker dengan session database yang ditutup sebelum pengiriman byte. Tes 24 transfer lambat dengan pool dua koneksi lulus pada run terfokus dan run serial lengkap terakhir.

Pada run suite paralel empat/dua proses, kasus 24 transfer tersebut pernah melewati batas waktu lima detik dan menghasilkan timeout pool satu detik. Assertion tidak dilonggarkan. Hasil serial terakhir lulus; variasi penjadwalan/resource lingkungan tetap berarti tes ini bukan jaminan throughput atau kapasitas VPS. Gunakan run serial untuk reproduksi dasar, lalu ukur beban di lingkungan staging sendiri.

Fixture lama yang mengganti import browser lewat `window.__deps` kini memuat helper produksi album/HLS/pencarian yang baru. URL modul cache mengikuti 2.16. Stub metode unggah Flutter menerima parameter album baru. Kasus lama yang menolak semua foto bersound diperbarui untuk memeriksa penolakan sumber sound yang sudah tidak boleh diakses; dukungan foto bersound diuji terpisah. Assertion akses, saldo dan consent dipertahankan.

## Reproduksi

Dari source lengkap:

```bash
cd backend
python3 -m venv .venv-test
.venv-test/bin/pip install -r requirements.txt -r requirements-test.txt
.venv-test/bin/python -m pytest -q
```

Tes memakai database/media sementara. Runtime model/RTC/PostgreSQL nyata memerlukan konfigurasi uji khusus; jangan arahkan fixture ke produksi.

```bash
cd flutter
flutter pub get
python3 scripts/fix_livekit_compat.py
flutter analyze --no-pub
flutter test --no-pub
```

Patch kompatibilitas LiveKit 2.6.4 yang sudah ada di builder tetap dipakai. Tidak ada upgrade SDK LiveKit atau pembaruan dependency massal pada aplikasi.

Dari root source:

```bash
npm ci
npx playwright install chromium
npm run test:web
python3 -m pytest tools/test_ui_installer.py flutter/scripts/tests -q
```

Untuk browser terpasang sendiri, opsi berikut hanya mengubah runner pengujian:

```bash
KOCEHIND_CHROMIUM_EXECUTABLE=/path/ke/chrome node --import ./tools/playwright-runtime.mjs --test --test-force-exit websites/web/test*.mjs
```

Dari folder paket luar: `python3 -m pytest tests -q` (dengan pytest dan dependency tes terpasang).

## Belum diverifikasi di produksi

Belum ada build native APK/AAB release, pemasangan pada HP, pasangan kamera/penonton LiveKit nyata, pengukuran delay end-to-end, fokus kamera, kualitas pada seluler, daya tahan/bandwidth perangkat, atau kapasitas encoding VPS. Pembuatan HLS dan akses server sudah diuji dengan FFmpeg dan HTTP nyata; decode HLS native/perangkat tetap perlu uji penerimaan setelah build. Tidak ada klaim loading atau delay nol.

Ikuti PANDUAN_UPDATE_v2.16.0.md untuk backup, migrasi, worker baru, routing Nginx, build memakai key lama dan uji penerimaan. Paket ini adalah source serta alat update/build, bukan bukti bahwa VPS atau APK pengguna sudah diperbarui.
