#!/usr/bin/env python3
"""Run the installed diagnosis without shell-sourcing backend.env."""
from pathlib import Path
import subprocess
import sys

python = Path('/opt/kocehind/venv/bin/python')
script = Path('/opt/kocehind/backend/diagnose_google_play.py')
if not python.is_file() or not script.is_file():
    raise SystemExit('Perbarui backend dari paket ini terlebih dahulu dengan UPDATE_BACKEND_WEB.py.')
raise SystemExit(subprocess.call([str(python), str(script), *sys.argv[1:]], cwd=script.parent))
