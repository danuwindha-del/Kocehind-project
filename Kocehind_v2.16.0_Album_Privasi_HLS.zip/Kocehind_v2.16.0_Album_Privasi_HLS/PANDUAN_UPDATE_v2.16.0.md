# Kocehind 2.16.0 — Album foto, privasi akun, HLS dan LIVE

Paket ini memperbarui source Android Flutter, backend FastAPI/PostgreSQL, web sosial dan alat pemasangan dari 2.15.0. Versi Android baru **2.16.0+42**; gunakan nomor lebih tinggi jika 42 sudah dipakai di Play Console. Application ID tetap `id.web.kocehind` dan build harus memakai signing key lama Anda.

## Perubahan

- Unggah **1–20 foto** dalam satu postingan. Urutan mengikuti pilihan/susunan pada composer; foto dapat dihapus dan dipindah sebelum publikasi. Album digeser horizontal di dalam feed vertikal. Indikator `1/20`, titik navigasi dan label **Foto di samping username** tersedia. Unggahan foto lama tetap terbaca.
- Foto dan album dapat memakai sound yang sudah tersedia di Kocehind. Pilih **Tambahkan musik dari Kocehind** di composer. Worker menyiapkan audio AAC tersendiri agar pemutaran musik tidak harus mengunduh seluruh video sumber. Saat belum siap, klien memakai sumber sound yang masih boleh diakses. Musik berhenti ketika album tidak aktif, aplikasi masuk latar, atau halaman lain dibuka. Browser dapat meminta ketukan untuk mengizinkan audio.
- **Edit profil > Privat akun**: Publik, **Privat total** (hanya pemilik), dan **Privat hanya teman** (saling mengikuti). Kedua mode privat tidak masuk Untuk Anda, hasil pencarian, tag populer, halaman eksplorasi tag/sound, MychaAI kreator otomatis atau sitemap publik. Teman mengakses akun privat-teman melalui profil/tautan langsung; tidak ada permintaan follow baru. Mengaktifkan privat mengakhiri LIVE yang sedang berjalan agar peserta lama tidak tetap menerima siaran.
- Video unggahan mendapat HLS `.m3u8`, segmen sekitar dua detik, profil 360p dan 720p sesuai resolusi sumber, H.264/AAC. Sumber kecil tidak diperbesar. HLS dibuat di worker; selama antrean/encoding, MP4 lama tetap dapat digunakan. Web memakai hls.js yang dibundel lokal; Android memakai video_player. Pemutar web menunggu persiapan sumber yang sama agar reload tidak memulai video sebelum sumber siap.
- Playlist, setiap segmen, audio foto, gambar tambahan dan avatar tetap memeriksa izin terkini. Mengubah privasi/blokir/pertemanan mencabut akses URL lama. HLS tidak disajikan sebagai folder statis terbuka. Autentikasi dan otorisasi media dijalankan dalam satu pekerjaan worker agar koneksi database tidak ditahan sambil menunggu giliran handler.
- Pencarian menampilkan **lima tag populer** dan **enam riwayat pencarian terakhir**. Riwayat bisa dibuka, dihapus satu per satu atau seluruhnya. Riwayat akun disimpan terpisah per akun; riwayat tamu hanya di perangkat/browser. Riwayat dicatat saat pencarian dikirim, bukan pada setiap huruf yang diketik.
- Inbox tab Pesan menyediakan pencarian isi pesan atau akun. Hanya pesan yang melibatkan pengguna tersebut yang ditelusuri; hasil membuka percakapan terkait.
- LIVE tetap menggunakan WebRTC/LiveKit. Kamera ditargetkan 720×1280, 30 fps, bitrate tertinggi sampai 3,5 Mbps, simulcast dan penyesuaian kualitas jaringan. Renderer Android dan web mematikan mirror. Ini tidak menjamin fokus kamera, bandwidth atau delay nol; kualitas sumber dan koneksi tetap menentukan.

## 1. Update backend dan web — VPS layanan

Sediakan ruang untuk backup database/media serta hasil HLS. Akhiri LIVE yang aktif. Ekstrak paket lengkap, lalu dari folder paket:

```bash
python3 UPDATE_BACKEND_WEB.py --check
python3 UPDATE_BACKEND_WEB.py
```

`--check` hanya preflight. Perintah kedua memakai jalur backup/update existing, migrasi tambahan `migrate_v2_16.py`, pemasangan web dan routing HLS Nginx. Konfigurasi environment, database, saldo, pesanan, dokumen hukum dan signing key tidak diganti dengan nilai contoh. Jangan memakai installer VPS kosong pada layanan existing.

Jika Nginx utama disimpan di lokasi khusus, tentukan path yang benar:

```bash
export KOCEHIND_NGINX_CONF=/etc/nginx/sites-available/kocehind
python3 UPDATE_BACKEND_WEB.py
```

Source lengkap juga dapat dipakai langsung:

```bash
unzip SOURCE_LENGKAP_v2.16.0.zip
cd kocehind_realtime_v2
sudo bash scripts/vps2_update_v216.sh
```

Migrasi dapat dijalankan ulang. Akun lama tetap **Publik**; foto lama tetap satu foto. Video lama dimasukkan ke antrean HLS tanpa mengubah file aslinya. Kolom/tabel ditambahkan; database tidak di-restore otomatis saat rollback kode.

## 2. Worker HLS dan pemeriksaan layanan

Worker baru **kocehind-streams** dipasang terpisah dari HTTP API dan berjalan dengan user layanan. Pekerjaan encoding dibatasi satu worker, memakai FFmpeg/FFprobe, prioritas CPU rendah dan batas memori 1 GB. Pastikan dependensi FFmpeg existing tersedia serta ruang disk cukup; hasil HLS membutuhkan ruang tambahan.

```bash
systemctl is-active kocehind-api kocehind-streams
journalctl -u kocehind-streams -n 80 --no-pager
curl -fsS http://127.0.0.1:8000/health
sudo nginx -t
```

Health harus menunjukkan **2.16.0**. `stream_status` pada data postingan memperlihatkan `queued`, `processing`, `retry` atau `ready`; `hls_url` baru terisi setelah hasil encoding tersedia. Gangguan encoding dicoba ulang dengan jeda; unggahan tetap dapat diputar lewat sumber lama. Album tanpa musik tidak membutuhkan pekerjaan audio.

Routing `/streams/` pada host API dan `/api/streams/` pada web harus tetap menuju FastAPI. Jangan menambahkan `alias` langsung ke folder HLS. Parameter otorisasi tidak ditulis ke access log pada lokasi HLS yang disediakan paket.

Model moderasi existing tetap dipakai. Kedua worker moderasi memeriksa seluruh foto album, bukan hanya sampul. Temuan pada salah satu foto mengikuti penghentian akses/banding existing untuk seluruh postingan. Paket tidak memasang atau mengunduh ulang model moderasi besar.

## 3. Build Android — VPS builder

Backend/web harus diperbarui sebelum distribusi Android baru. Dari folder paket di VPS builder:

```bash
python3 PINDAH_KEY_LAMA.py build --check-only
bash BUILD_VPS_BARU.sh
```

Gunakan backup signing/Google/Firebase existing sesuai alur builder lama. Paket tidak berisi private key, credential produksi atau APK/AAB yang sudah ditandatangani. Untuk nomor versi yang sudah terpakai:

```bash
python3 PINDAH_KEY_LAMA.py build --build-number NOMOR_BARU
```

Setelah build berhasil, uji APK di perangkat, lalu publikasikan menggunakan alat APK/Play existing. Jangan membuat signing key pengganti. Aplikasi lama hanya menampilkan sampul album dan belum menyediakan pilihan privasi akun atau pemutaran HLS baru.

## 4. Uji penerimaan di perangkat

1. Unggah 1, 2 dan 20 foto dengan sound; ubah urutan, hapus foto, lalu simpan/pulihkan draf. Pastikan pilihan ke-21 ditolak, geser horizontal mengganti foto dan geser vertikal mengganti postingan. Musik hanya berasal dari album yang aktif.
2. Dengan tiga akun A, B, C: buat A dan B saling mengikuti. Aktifkan privat-teman A; B dapat membuka profil/tautan A, C dan tamu mendapat tidak tersedia. Pastikan A dan kontennya tidak masuk Untuk Anda/pencarian, termasuk pada B. Putuskan pertemanan dan uji ulang URL media lama. Uji privat total: hanya A dapat mengakses. Kembalikan ke Publik.
3. Tunggu sebuah video berstatus ready. Pastikan web meminta master/variant `.m3u8` dan segmen `.ts`; uji jaringan cepat/lambat, pindah postingan, replay dan reload. Periksa juga MP4 saat HLS belum siap. Pengukuran waktu mulai, buffering dan kapasitas VPS memerlukan kondisi server/jaringan nyata.
4. Buat tujuh pencarian; pastikan hanya enam terakhir tersimpan dan urutannya berubah saat istilah lama dipakai lagi. Hapus satu/semua, kemudian periksa akun lain.
5. Di Inbox, cari potongan pesan dan username. Pastikan isi percakapan dua akun lain tidak muncul.
6. Siarkan kamera yang menghadap tulisan, lalu lihat dari perangkat kedua: tulisan harus terbaca tanpa mirror. Uji solo, tamu, flip kamera, Wi-Fi dan seluler. Periksa capture/bitrate dan koneksi UDP/LiveKit jika kualitas masih rendah.

## 5. Batas verifikasi

Hasil otomatis dan perintah reproduksi ada di **LAPORAN_PENGUJIAN_v2.16.0.md**. Pemasangan VPS produksi, APK/AAB release, transaksi nyata dan kualitas LIVE antarperangkat belum dijalankan dari lingkungan ini. HLS mengurangi ukuran unduhan awal dan memberi pilihan bitrate; hasil kecepatan tetap harus diukur setelah antrean encoding selesai pada VPS Anda.
