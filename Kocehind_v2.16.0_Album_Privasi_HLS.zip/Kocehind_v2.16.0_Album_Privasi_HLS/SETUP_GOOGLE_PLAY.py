#!/usr/bin/env python3
"""Configure the existing backend, without including credentials in this package."""
from pathlib import Path
import subprocess
import sys
from package_ops import require_root, source_tree, runtime_environment, install_backend_tools

require_root()
with source_tree() as project, runtime_environment() as environment:
    install_backend_tools(project)
    subprocess.run(['python3', '/opt/kocehind/backend/setup_google_play.py', *sys.argv[1:]], env=environment, check=True)
