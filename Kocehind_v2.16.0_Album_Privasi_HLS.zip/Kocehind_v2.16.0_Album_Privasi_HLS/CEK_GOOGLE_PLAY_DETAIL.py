#!/usr/bin/env python3
"""Read-only diagnosis: fresh OAuth, then the actual queued Play receipt.

No receipt tokens, access tokens, private keys or raw provider errors are printed.
No application files, services, balances or database rows are changed.
"""
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import sys
from urllib.parse import quote

PACKAGE = 'id.web.kocehind'
API = 'https://androidpublisher.googleapis.com/androidpublisher/v3/applications/' + PACKAGE
SCOPE = 'https://www.googleapis.com/auth/androidpublisher'
KNOWN = {
    'permissionDenied', 'insufficientPermissions', 'PERMISSION_DENIED', 'forbidden',
    'ACCESS_TOKEN_SCOPE_INSUFFICIENT', 'ACCESS_TOKEN_EXPIRED', 'UNAUTHENTICATED',
    'authError', 'invalidCredentials', 'accessNotConfigured', 'SERVICE_DISABLED',
    'API_DISABLED', 'notFound', 'purchaseTokenNotFound', 'invalid', 'badRequest',
    'quotaExceeded', 'rateLimitExceeded', 'RESOURCE_EXHAUSTED', 'backendError',
    'INTERNAL', 'UNAVAILABLE',
}


def analyse_response(status, data):
    error = data.get('error', {}) if isinstance(data, dict) else {}
    error = error if isinstance(error, dict) else {}
    reasons = set()
    for field in ('errors', 'details'):
        rows = error.get(field, [])
        if not isinstance(rows, list):
            continue
        for row in rows:
            if isinstance(row, dict) and isinstance(row.get('reason'), str) and row['reason'] in KNOWN:
                reasons.add(row['reason'])
    if isinstance(error.get('status'), str) and error['status'] in KNOWN:
        reasons.add(error['status'])
    message = error.get('message', '')
    # Match a known provider explanation, never copy the message into output.
    permission_message = isinstance(message, str) and 'insufficient permissions' in message.lower()
    if reasons & {'accessNotConfigured', 'SERVICE_DISABLED', 'API_DISABLED'}:
        code = 'PLAY_API_DISABLED'
    elif reasons & {'permissionDenied', 'insufficientPermissions', 'PERMISSION_DENIED', 'forbidden', 'ACCESS_TOKEN_SCOPE_INSUFFICIENT'} or status in (401, 403) and permission_message:
        code = 'PLAY_PERMISSION'
    elif status == 401:
        code = 'PLAY_AUTH_REJECTED'
    elif status == 403:
        code = 'PLAY_ACCESS_DENIED'
    elif status == 404:
        code = 'PLAY_NOT_FOUND'
    elif status == 400:
        code = 'PLAY_RECEIPT_REJECTED'
    elif status == 429:
        code = 'PLAY_QUOTA'
    elif status >= 500:
        code = 'PLAY_GOOGLE_UNAVAILABLE'
    elif 200 <= status < 300:
        code = 'OK'
    else:
        code = 'PLAY_RESPONSE_UNKNOWN'
    return code, ', '.join(sorted(reasons)) or 'tidak ada reason yang dikenali'


def oauth_failure(error):
    allowed = {'invalid_grant', 'invalid_client', 'unauthorized_client', 'access_denied', 'temporarily_unavailable'}
    code, description = 'OAUTH_ERROR', ''
    for item in getattr(error, 'args', ()):
        if isinstance(item, dict):
            if isinstance(item.get('error'), str) and item['error'] in allowed:
                code = item['error']
            if isinstance(item.get('error_description'), str):
                description = item['error_description'].lower()
    hint = 'Autentikasi Google belum berhasil; tidak menyimpulkan bahwa izin Play Console salah.'
    if any(term in description for term in ('short-lived', 'reasonable timeframe', 'iat and exp', 'used too early')):
        hint = 'Periksa jam VPS dengan timedatectl status.'
    elif 'signature' in description:
        hint = 'Google menolak tanda tangan JWT; periksa key yang dipakai dan status key di Google Cloud.'
    elif 'disabled' in description:
        hint = 'Periksa apakah akun layanan atau key dinonaktifkan di Google Cloud.'
    elif any(term in description for term in ('account not found', 'deleted')):
        hint = 'Periksa apakah akun layanan/key yang dipakai masih ada di Google Cloud.'
    elif type(error).__name__ in ('TransportError', 'Timeout', 'ConnectTimeout', 'ReadTimeout', 'ConnectionError'):
        code = 'OAUTH_NETWORK'
        hint = 'Koneksi OAuth gagal; periksa DNS dan koneksi keluar VPS.'
    return code, hint


def service_context():
    from dotenv import dotenv_values
    runtime = Path('/opt/kocehind/backend')
    if not runtime.is_dir():
        raise RuntimeError('RUNTIME_MISSING')
    if os.geteuid() == 0:
        import pwd
        config = dotenv_values('/etc/kocehind/backend.env', interpolate=False)
        if not all(isinstance(config.get(key), str) and config[key] for key in ('DATABASE_URL', 'JWT_SECRET', 'PLAY_SERVICE_ACCOUNT_FILE')):
            raise RuntimeError('CONFIG_MISSING')
        os.environ.update({key: value for key, value in config.items() if isinstance(value, str)})
        person = pwd.getpwnam('kocehind')
        os.chdir(runtime)
        os.initgroups(person.pw_name, person.pw_gid)
        os.setgid(person.pw_gid)
        os.setuid(person.pw_uid)
    else:
        os.chdir(runtime)
        if not all(os.environ.get(key) for key in ('DATABASE_URL', 'JWT_SECRET', 'PLAY_SERVICE_ACCOUNT_FILE')):
            raise RuntimeError('CONFIG_MISSING')
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(runtime))


def load_credentials():
    from google.oauth2 import service_account
    path = Path(os.environ['PLAY_SERVICE_ACCOUNT_FILE'])
    if path.stat().st_size > 1_000_000:
        raise ValueError('CREDENTIAL_SIZE')
    data = json.loads(path.read_text())
    if data.get('type') != 'service_account' or data.get('token_uri') != 'https://oauth2.googleapis.com/token':
        raise ValueError('CREDENTIAL_FORMAT')
    credentials = service_account.Credentials.from_service_account_info(data, scopes=[SCOPE])
    # Only explicitly non-secret configuration identifiers are displayed.
    email = data.get('client_email', '')
    project = data.get('project_id', '')
    email = email if isinstance(email, str) and re.fullmatch(r'[a-zA-Z0-9_.+\-]+@[a-zA-Z0-9.\-]+\.gserviceaccount\.com', email) else '(tidak tersedia)'
    project = project if isinstance(project, str) and re.fullmatch(r'[a-zA-Z0-9.\-:]+', project) else '(tidak tersedia)'
    return credentials, project, email


def fresh_oauth(credentials):
    from google.auth.transport.requests import Request
    request = Request()
    credentials.refresh(lambda *args, **kwargs: request(*args, **dict(kwargs, timeout=10)))


def read_sample():
    from sqlalchemy import inspect, text
    from cryptography.fernet import Fernet
    from app.core import engine, JWT_SECRET
    with engine.connect() as connection:
        if engine.dialect.name == 'postgresql':
            connection.exec_driver_sql('SET TRANSACTION READ ONLY')
        inspector = inspect(connection)
        row = None
        if inspector.has_table('google_play_verification_queue'):
            row = connection.execute(text("SELECT product_id, encrypted_token FROM google_play_verification_queue WHERE state != 'rejected' ORDER BY created_at DESC LIMIT 1")).mappings().first()
        if row is None and inspector.has_table('google_play_purchases'):
            row = connection.execute(text('SELECT product_id, encrypted_token FROM google_play_purchases ORDER BY created_at DESC LIMIT 1')).mappings().first()
        if row is None:
            return None
        encrypted = row['encrypted_token']
    key = base64.urlsafe_b64encode(hashlib.sha256(('kocehind-play-token-v1:' + JWT_SECRET).encode()).digest())
    try:
        token = Fernet(key).decrypt(encrypted.encode()).decode()
    except Exception:
        raise ValueError('TOKEN_DECRYPTION') from None
    if not 10 <= len(token) <= 4096 or any(ord(char) < 33 or ord(char) > 126 for char in token):
        raise ValueError('TOKEN_FORMAT')
    return token


def get_receipt(credentials, token):
    from google.auth.transport.requests import AuthorizedSession
    # A fresh OAuth token has already been obtained. Keep the original Publisher
    # HTTP status; automatic 401 retries must not obscure this diagnosis.
    with AuthorizedSession(credentials, refresh_status_codes=(), refresh_timeout=10) as session:
        with session.get(API + '/purchases/productsv2/tokens/' + quote(token, safe=''),
                         timeout=(5, 12), allow_redirects=False, stream=True) as response:
            raw = bytearray()
            for chunk in response.iter_content(8192):
                raw.extend(chunk)
                if len(raw) > 131072:
                    raise ValueError('RESPONSE_TOO_LARGE')
            try:
                data = json.loads(raw)
            except (ValueError, UnicodeError):
                data = {}
            return response.status_code, data


def check(*, load=load_credentials, oauth=fresh_oauth, sample=read_sample, request=get_receipt):
    print('Kocehind: pemeriksaan detail Google Play (hanya baca)')
    print('Package: ' + PACKAGE)
    try:
        credentials, project, email = load()
    except Exception:
        print('Konfigurasi: GAGAL dibaca/divalidasi sebagai pengguna service [LOCAL_CREDENTIAL]')
        return 2
    print('Project: ' + project)
    print('Service account yang benar-benar dipakai: ' + email)
    try:
        oauth(credentials)
    except Exception as error:
        code, hint = oauth_failure(error)
        print('OAuth: GAGAL [' + code + ']')
        print(hint)
        return 2
    print('OAuth: BERHASIL (Google menerima autentikasi key ini)')
    try:
        token = sample()
    except Exception as error:
        code = 'TOKEN_DECRYPTION' if error.args == ('TOKEN_DECRYPTION',) else 'LOCAL_RECEIPT'
        print('Receipt: belum dapat dibaca [' + code + ']')
        return 2
    if token is None:
        print('Receipt: belum ada di database. Tekan Periksa pembelian di aplikasi, lalu ulangi.')
        return 2
    try:
        status, data = request(credentials, token)
    except Exception:
        print('Google Publisher: belum mendapat respons [PUBLISHER_NETWORK_OR_RESPONSE]')
        return 2
    code, reason = analyse_response(status, data)
    print('Google Publisher HTTP: ' + str(status))
    print('Reason aman: ' + reason)
    print('Hasil: ' + code)
    if code == 'OK':
        context = data.get('purchaseStateContext') if isinstance(data, dict) else None
        state = context.get('purchaseState') if isinstance(context, dict) else None
        print('Status pembelian: ' + (state if state in ('PURCHASED', 'PENDING', 'CANCELLED') else 'BELUM DIKENALI'))
        print('Jalankan DIAGNOSA_GOOGLE_PLAY.py --google --retry untuk pemrosesan worker. Pemeriksaan ini tidak mengkredit koin.')
    elif code == 'PLAY_PERMISSION':
        print('Cocokkan email di atas dengan pengguna Play Console; periksa akses id.web.kocehind dan izin finansial serta pengelolaan pesanan.')
        print('Jika semuanya sudah tepat dan baru diubah, perubahan izin mungkin belum berlaku. Penolakan ini sendiri tidak membuktikan propagasi sebagai satu-satunya penyebab.')
    elif code == 'PLAY_API_DISABLED':
        print('Periksa aktivasi Google Play Android Developer API pada project service account di atas.')
    elif code in ('PLAY_AUTH_REJECTED', 'PLAY_ACCESS_DENIED'):
        print('OAuth berhasil tetapi akses Publisher ditolak; hasil ini tidak otomatis berarti file JSON rusak.')
    elif code == 'PLAY_NOT_FOUND':
        print('Google belum menemukan receipt untuk package ini; periksa aplikasi/produk dan status pesanan.')
    return 0 if code == 'OK' else 2


if __name__ == '__main__':
    try:
        service_context()
        raise SystemExit(check())
    except Exception:
        print('Pemeriksaan belum dapat dimulai [LOCAL_RUNTIME]. Gunakan Python virtualenv backend sebagai root; detail privat tidak dicetak.')
        raise SystemExit(2) from None
