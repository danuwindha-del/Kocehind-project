# Update web v2.13.3

Checkout baru: QRIS Kipay dengan QR melalui backend, total/kode unik/biaya,
verifikasi status, dan antrean webhook. Lihat ../PANDUAN_UPDATE_KIPAY_v2.13.3.md.
Catatan berikutnya menjelaskan riwayat fitur web yang tetap termasuk.

# Web Kocehind v2.12.7

Feed memulihkan cursor dan memakai cache sesi; preview LIVE memakai panggung bersama host/tamu, kamera cover dan avatar yang dapat diperbarui. Seluruh modul memakai versi cache yang sama. Ikuti `../PANDUAN_UPDATE_v2.12.7.md`.

## Riwayat

# Website v2.11.0

Update memakai `../scripts/vps2_update_v211.sh`. Centang biru SVG disediakan oleh `shared/api.js` dan `shared/base.css`; kartu inbox serta pengunjung profil berada di `web/app.js`. LIVE dapat dikirim ke inbox melalui `web/inbox-share.js`. Sitemap domain utama diproksikan ke backend, dengan HTML publik untuk video/profil/LIVE.

Panduan lengkap: `../PANDUAN_UPDATE_v2.11.0.md`. Riwayat komponen sebelumnya di bawah ini.

# Website Kocehind — pembaruan v2.7

Pengaturan menyediakan Kocehind Studio (analitik aktual, video, riwayat LIVE tujuh hari, replay privat, potong/bagikan klip) dan riwayat tontonan dengan hapus pilihan/semua. Privasi video Publik/Hanya Teman/Hanya Saya tersedia di composer dan menu Bagikan pemilik. Mention membuka profil, notifikasi komentar membuka thread dan komentar yang tepat, dan laporan LIVE masuk ke antrean admin. Tombol unduh yang siap menunjuk langsung ke `/downloads/Kocehind.apk`; file yang hilang memberi 404. Rincian implementasi dan pemeriksaan ada di `../docs/implementation/web-report.md`.

Tombol unduh APK ada pada landing page dan pintasan web sosial. File APK hasil build harus dipublikasikan pada VPS backend dengan `sudo bash scripts/vps2_pasang_apk.sh /root/app-release.apk`. Situs memeriksa file nyata dan menampilkan ketersediaan/ukuran/tanggal publikasi. Blokir akun, moderator LIVE dan pesan pembuka memakai backend v2.6. Perintah lengkap ada pada PANDUAN_UPDATE_v2.6.md di root paket.

# v2.4 LIVE

Aplikasi web memiliki /live, /live/new, /live/ID, SDK browser yang dibundel lokal, kamera/suara, solo/tamu, komentar, dan berbagi. Admin memiliki menu Moderasi LIVE. Baca `../PANDUAN_LIVE_v2.4.md` untuk domain, CSP, HTTPS, port dan hasil verifikasi.

# Website Kocehind

Tiga frontend buildless memakai API FastAPI yang sama. Gunakan skrip `scripts/vps2_pasang_website.sh` dari root project; tidak perlu npm build di VPS. Semua website harus dipasang setelah update backend v2.3. Lihat `PANDUAN_WEB_ADMIN_v2.3.md`.

- `main`: halaman utama / unduhan dan panduan.
- `web`: sosial browser dengan sesi cookie host-only.
- `admin`: Control Center, semua endpoint admin memeriksa peran di server.
- `shared`: logo, CSS dasar dan helper API/UI. Tidak ada token login yang disimpan dalam localStorage; hanya ID tamu untuk rekomendasi.

API browser diproksikan melalui `/api/` pada host web/admin. Aset diberi versi untuk pembaruan cache. CSS responsif untuk desktop/tablet/ponsel. Tidak ada data demo yang ditampilkan sebagai metrik pengguna sebenarnya.
