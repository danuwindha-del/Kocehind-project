import {api,esc,safeUrl,date} from '/shared/api.js?v=2.15.0';

export function mychaMarkup(item){
 return `<article class="mycha-answer"><h2>${esc(item.title)}</h2>${(item.images||[]).length?`<div class="mycha-images">${item.images.map(url=>`<img src="${esc(safeUrl(url))}" alt="${esc(item.title)}" loading="lazy" referrerpolicy="no-referrer">`).join('')}</div>`:''}<p class="mycha-summary">${esc(item.summary)}</p><div class="mycha-sources">${(item.sources||[]).map(s=>`<a href="${esc(safeUrl(s.url))}" target="_blank" rel="noopener noreferrer">${esc(s.label)} ↗</a>`).join('')}</div>${item.profile_url?`<a class="btn small" href="${esc(safeUrl(item.profile_url))}">Lihat profil Kocehind</a>`:''}<small>Dipelajari ${esc(date(item.studied_at))}</small></article>`;
}

export async function mountMycha(root,query,{isCurrent=()=>true,showEmpty=false}={}){
 if(!query.trim()){root.replaceChildren();return;}
 root.innerHTML='<section class="mycha-card"><div class="mycha-brand">✦ MychaAI <span>Ringkasan bersumber</span></div><p role="status">Memuat ringkasan…</p></section>';
 try{
  const result=await api('/search/mycha?q='+encodeURIComponent(query));
  if(!isCurrent()||!root.isConnected)return;
  if(!Array.isArray(result.items))throw new Error('Respons MychaAI tidak valid');
  if(!result.items.length&&!showEmpty){root.replaceChildren();return;}
  root.innerHTML=`<section class="mycha-card"><div class="mycha-brand">✦ MychaAI <span>Ringkasan bersumber</span></div>${result.items.length?result.items.map(mychaMarkup).join(''):`<p>${esc(result.message)}</p>`}${result.items.length?'<button class="text-btn mycha-expand" aria-expanded="false">Lebih banyak ⌄</button>':''}</section>`;
  const expand=root.querySelector('.mycha-expand');
  if(expand)expand.onclick=()=>{const card=root.querySelector('.mycha-card'),expanded=card.classList.toggle('expanded');expand.setAttribute('aria-expanded',String(expanded));expand.textContent=expanded?'Lebih sedikit ⌃':'Lebih banyak ⌄';};
 }catch{
  if(!isCurrent()||!root.isConnected)return;
  root.innerHTML='<section class="mycha-card"><div class="mycha-brand">✦ MychaAI</div><p>Ringkasan belum dapat dimuat.</p><button class="btn small" data-mycha-retry>Coba lagi</button></section>';
  root.querySelector('[data-mycha-retry]').onclick=()=>mountMycha(root,query,{isCurrent,showEmpty});
 }
}
