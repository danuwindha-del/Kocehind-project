import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
const {JSDOM}=createRequire(import.meta.url)('jsdom');
const settle=()=>new Promise(r=>setTimeout(r,35));
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

async function fixture(path,{guest=false}={}){
 const html=(await readFile(new URL('index.html',import.meta.url),'utf8')).replace(/<script[^>]*>.*?<\/script>/g,'');
 const dom=new JSDOM(html,{url:'https://web.kocehind.web.id'+path,runScripts:'outside-only'}),w=dom.window;
 const calls=[],user=guest?null:{id:'buyer',username:'buyer',name:'Pembeli',legal_required:false};
 let order=null,paid=false;
 w.setInterval=()=>0;w.clearInterval=()=>{};w.IntersectionObserver=class{observe(){}disconnect(){}};
 const api=async(path,options={})=>{
  calls.push({path,...options});
  if(path==='/wallet')return {coins:paid?100:0,earnings:0,held:0,earned_total:0,paid_total:0,minimum_withdrawal:50000,withdrawal_methods:{BRI:'Bank BRI'}};
  if(path==='/web/coins/packages')return {items:[{id:'coin_100',coins:100,price:10000}]};
  if(path==='/web/coins/channels')return {gateway:'kipay',mode:'sandbox',items:[{code:'QRIS',name:'QRIS · Kipay'}]};
  if(path==='/web/coins/orders'&&options.method==='POST'){
   assert.equal(options.body.method,'QRIS');assert.equal(options.body.package_id,'coin_100');
   assert.match(options.body.request_key,/^[a-f0-9-]{36}$/);
   order={id:'order-test',coins:100,price:10000,gateway:'kipay',payment_mode:'sandbox',unique_code:215,total_amount:10215,fee_amount:100,fee_bearer:'merchant',status:'unpaid',provider_reference:'SBX-20261030-TEST',created_at:'2026-10-30T01:00:00Z',expires_at:'2026-10-30 08:15:00'};
   return {...order};
  }
  if(path==='/web/coins/orders/order-test/refresh'){
   order={...order,status:paid?'paid':'unpaid',credited_at:paid?'2026-10-30T01:01:00Z':null};return {...order};
  }
  if(path==='/web/coins/orders')return {items:order?[{...order}]:[],next_offset:null};
  return {items:[],unread:0,next_offset:null,revision:'one'};
 };
 const openDialog=(title,html)=>{
  const d=w.document.createElement('dialog');d.innerHTML='<button class="close">Tutup</button><div class="dialog-body">'+html+'</div>';
  d.open=true;d.close=()=>{d.open=false;d.dispatchEvent(new w.Event('close'));d.remove();};
  d.querySelector('.close').onclick=()=>d.close();w.document.body.append(d);return d;
 };
 const errors=[];w.addEventListener('error',e=>errors.push(e.message));
 w.__deps={api,discovery:api,me:user,restoreError:null,restore:async()=>user,setMe:()=>{},logout:async()=>{},authDialog:async()=>false,requireAccount:async()=>!guest,requireLegalAcceptance:async()=>true,esc,safeUrl:v=>v,count:n=>String(n||0),date:v=>v||'',badge:()=>'',avatar:()=>'<span class="avatar">K</span>',icon:()=>'',toast:()=>{},openDialog,busy:()=>{},legalLinks:'',openProfilePhoto:()=>{},prepareSessionVideos:async()=>{},warmNextVideos:()=>{}};
 const wallet=(await readFile(new URL('wallet.js',import.meta.url),'utf8')).replace(/^import[^;]+;/gm,'').replaceAll('export ','');
 w.__deps.mountWallet=w.eval('(()=>{const {api,esc,date,toast,openDialog,safeUrl}=window.__deps;'+wallet+';return mountWallet;})()');
 const app=(await readFile(new URL('app.js',import.meta.url),'utf8')).replace(/^import\s+\{([^}]+)\}\s+from\s+[^;]+;/gm,'const {$1}=window.__deps;');
 w.eval(app);await settle();
 return {dom,w,calls,errors,setPaid:()=>{paid=true;}};
}

for(const path of ['/coins','/coins/','/wallet'])test(path+' opens the same QRIS checkout without losing Studio R1',async()=>{
 const {dom,w,calls,errors,setPaid}=await fixture(path);
 try{
  assert.equal(w.document.querySelector('#coin-form [type=submit]').disabled,false);
  assert(w.document.querySelector('link[href="/shared/studio-design.css?v=ui-r1"]'));
  w.document.querySelector('#coin-form').dispatchEvent(new w.Event('submit',{cancelable:true}));await settle();
  const dialog=w.document.querySelector('dialog');assert(dialog);
  assert.match(dialog.textContent,/10.215/);assert.match(dialog.textContent,/SANDBOX/);
  assert.equal(dialog.querySelector('.payment-qr').getAttribute('src'),'/api/web/coins/orders/order-test/qr');
  setPaid();dialog.querySelector('[data-verify-invoice]').click();await settle();
  assert.match(dialog.textContent,/Koin sudah diproses/);
  assert.equal(dialog.querySelector('.payment-qr'),null);
  assert.equal(w.document.querySelector('#wallet-balance .wallet-card strong').textContent,'100');
  assert.equal(calls.filter(c=>c.path==='/web/coins/orders'&&c.method==='POST').length,1);
  assert.deepEqual(errors,[]);
 }finally{dom.window.close();}
});

test('Guest /coins retains its destination and gates account access',async()=>{
 const {dom,w,calls,errors}=await fixture('/coins',{guest:true});
 try{
  assert(w.document.querySelector('#gate-login'));
  assert.equal(w.location.pathname,'/coins');
  assert(!calls.some(c=>c.path==='/web/coins/orders'||c.path==='/wallet'));
  assert.deepEqual(errors,[]);
 }finally{dom.window.close();}
});
