import {api,esc,date,toast,busy} from '/shared/api.js?v=2.15.0';

export const trustStatus = {removed:'Dihapus',appealed:'Banding ditinjau',restored:'Keputusan dibatalkan',upheld:'Keputusan dipertahankan',open:'Menunggu tim',waiting_user:'Menunggu balasan Anda',closed:'Ditutup',queued:'Antre pemeriksaan',processing:'Sedang diperiksa',error:'Pemeriksaan tertunda'};
const label=s=>trustStatus[s]||s;
const categories='<option value="account">Akun dan login</option><option value="upload">Unggahan</option><option value="live">LIVE</option><option value="moderation">Moderasi dan banding</option><option value="privacy">Privasi</option><option value="other">Lainnya</option>';

export async function mountHelp(root,path,navigate,isCurrent=()=>true){
 root.innerHTML='<h1>Pusat Bantuan</h1><p class="muted">Ceritakan kendala Anda. Balasan tim tersedia di tiket dan Inbox Aktivitas.</p><p><a href="/help" data-link>Tiket bantuan</a> · <a href="/moderation" data-link>Keputusan dan banding</a></p><div data-help></div>';
 const host=root.querySelector('[data-help]'),tid=path.split('/')[2];
 if(tid){
  const ticket=await api('/support/tickets/'+encodeURIComponent(tid));if(!isCurrent())return;
  host.innerHTML=`<h2>${esc(ticket.subject)}</h2><p>${esc(label(ticket.status))} · ${esc(ticket.category)}</p><div data-messages></div><button class="btn" data-older hidden>Pesan sebelumnya</button><form data-reply><label>Balasan<textarea name="message" required minlength="3" maxlength="3000" ${ticket.status==='closed'?'disabled':''}></textarea></label><button type="submit" class="btn primary" ${ticket.status==='closed'?'disabled':''}>Kirim</button></form><button class="btn" data-status>${ticket.status==='closed'?'Buka kembali tiket':'Tutup tiket'}</button>`;
  const messages=host.querySelector('[data-messages]'),older=host.querySelector('[data-older]');let before=ticket.next_before;
  const html=items=>items.map(m=>`<article class="settings-panel"><strong>${m.staff?'Tim Kocehind':'Anda'}</strong><p class="trust-text">${esc(m.body)}</p><small>${esc(date(m.created_at))}</small></article>`).join('');
  messages.innerHTML=html(ticket.messages);older.hidden=!before;
  older.onclick=async()=>{try{const page=await api(`/support/tickets/${encodeURIComponent(tid)}?before=${encodeURIComponent(before)}`);if(!isCurrent())return;messages.insertAdjacentHTML('afterbegin',html(page.messages));before=page.next_before;older.hidden=!before;}catch(e){toast(e.message);}};
  const form=host.querySelector('form');form.onsubmit=async e=>{e.preventDefault();busy(form,true);try{await api(`/support/tickets/${encodeURIComponent(tid)}/messages`,{method:'POST',body:{message:new FormData(form).get('message')}});await mountHelp(root,path,navigate,isCurrent);}catch(err){toast(err.message);}finally{busy(form,false);}};
  host.querySelector('[data-status]').onclick=async()=>{try{await api(`/support/tickets/${encodeURIComponent(tid)}/status`,{method:'PUT',body:{status:ticket.status==='closed'?'open':'closed'}});await mountHelp(root,path,navigate,isCurrent);}catch(e){toast(e.message);}};return;
 }
 host.innerHTML=`<section class="settings-panel"><h2>Buat tiket bantuan</h2><form data-new-ticket><label>Kategori<select name="category">${categories}</select></label><label>Judul<input name="subject" required minlength="5" maxlength="150"></label><label>Jelaskan kendala<textarea name="message" required minlength="3" maxlength="3000"></textarea></label><p class="muted">Jangan kirim kata sandi atau kode OTP. Maksimal lima tiket terbuka.</p><button type="submit" class="btn primary">Kirim tiket</button></form></section><h2>Tiket Anda</h2><div data-tickets></div><button class="btn" data-more hidden>Muat tiket berikutnya</button>`;
 const list=host.querySelector('[data-tickets]'),more=host.querySelector('[data-more]');let offset=0;
 async function load(){const data=await api('/support/tickets?offset='+offset);if(!isCurrent())return;list.insertAdjacentHTML('beforeend',data.items.map(t=>`<a class="settings-panel trust-card" href="/help/${esc(t.id)}" data-link><strong>${esc(t.subject)}</strong><p>${esc(label(t.status))} · ${esc(date(t.updated_at))}</p></a>`).join('')||(!offset?'<p>Belum ada tiket bantuan.</p>':''));offset=data.next_offset;more.hidden=offset===null;}
 more.onclick=()=>load().catch(e=>toast(e.message));await load();
 const form=host.querySelector('form');form.onsubmit=async e=>{e.preventDefault();busy(form,true);try{const result=await api('/support/tickets',{method:'POST',body:Object.fromEntries(new FormData(form))});navigate('/help/'+result.id);}catch(err){toast(err.message);}finally{busy(form,false);}};
}

export async function mountCases(root,path,navigate,isCurrent=()=>true){
 root.innerHTML='<h1>Keputusan dan banding</h1><p><a href="/help" data-link>Hubungi Pusat Bantuan</a></p><div data-cases></div>';
 const host=root.querySelector('[data-cases]'),cid=path.split('/')[2];
 if(cid){const row=await api('/moderation/cases/'+encodeURIComponent(cid));if(!isCurrent())return;
  host.innerHTML=`<section class="settings-panel"><h2>${row.target_type==='post'?(row.media_kind==='image'?'Foto dihapus':'Konten dihapus'):'LIVE dihentikan'}</h2><p>${esc(label(row.status))} · ${esc(date(row.created_at))}</p><h3>Alasan dan ketentuan</h3><p class="trust-text">${esc(row.rule)}</p><p>Aturan versi ${esc(row.policy_version)}. Batas banding: ${esc(date(row.appeal_deadline))}.</p>${row.resolution?`<h3>Hasil peninjauan</h3><p class="trust-text">${esc(row.resolution)}</p>`:''}${row.appeal_text?`<h3>Banding Anda</h3><p class="trust-text">${esc(row.appeal_text)}</p>`:''}${row.can_appeal?'<form><label>Alasan banding<textarea name="message" minlength="10" maxlength="3000" required placeholder="Jelaskan mengapa keputusan perlu ditinjau ulang"></textarea></label><button type="submit" class="btn primary">Ajukan banding</button></form>':'<p>Jika masih memerlukan bantuan, buka tiket di Pusat Bantuan.</p>'}</section>`;
  const form=host.querySelector('form');if(form)form.onsubmit=async e=>{e.preventDefault();busy(form,true);try{await api(`/moderation/cases/${encodeURIComponent(cid)}/appeal`,{method:'POST',body:{message:new FormData(form).get('message')}});await mountCases(root,path,navigate,isCurrent);toast('Banding dikirim untuk ditinjau admin.');}catch(err){toast(err.message);}finally{busy(form,false);}};return;
 }
 host.innerHTML='<p>Unggahan langsung terbit. Halaman ini hanya menampilkan keputusan jika ada konten yang dihapus atau LIVE yang dihentikan.</p><div data-list></div><button class="btn" data-more hidden>Keputusan berikutnya</button>';
 let offset=0;const more=host.querySelector('[data-more]');
 async function load(){const data=await api('/moderation/cases?offset='+offset);if(!isCurrent())return;host.querySelector('[data-list]').insertAdjacentHTML('beforeend',data.items.map(c=>`<a class="settings-panel trust-card" href="/moderation/${esc(c.id)}" data-link><strong>${c.target_type==='post'?(c.media_kind==='image'?'Foto':'Konten'):'LIVE'} · ${esc(label(c.status))}</strong><p>${esc(date(c.created_at))}</p></a>`).join('')||(!offset?'<p>Belum ada keputusan moderasi.</p>':''));offset=data.next_offset;more.hidden=offset===null;}
 more.onclick=()=>load().catch(e=>toast(e.message));await load();
}
