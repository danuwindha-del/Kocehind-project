import {api,esc,date,toast,openDialog,safeUrl} from '/shared/api.js?v=2.15.0';
export const money=n=>new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(Number(n)||0);
const stateName=s=>({pending:'Menunggu',processing:'Diproses',paid:'Dibayar',rejected:'Ditolak',unpaid:'Belum dibayar',creating:'Menyiapkan tagihan',unknown:'Perlu diperiksa',expired:'Kedaluwarsa',failed:'Gagal',refunded:'Dikembalikan'}[s]||s);
export function keyedAction(send,makeKey=()=>crypto.randomUUID()){
 let signature='',key='';return async payload=>{const next=JSON.stringify(payload);if(next!==signature){signature=next;key=makeKey();}const r=await send({...payload,request_key:key});if(!['unknown','creating'].includes(r?.status)){signature='';key='';}return r;};
}
export function kipayInvoiceHTML(o){
 const pending=o.status==='unpaid';
 return `<div class="kipay-invoice"><p>${o.payment_mode==='sandbox'?'<strong class="sandbox-notice">MODE SANDBOX · pembayaran uji coba</strong>':''}</p><p><strong>${esc(o.coins)} koin</strong></p><dl><div><dt>Harga paket</dt><dd>${money(o.price)}</dd></div><div><dt>Kode unik</dt><dd>${money(o.unique_code)}</dd></div><div><dt>Biaya layanan${o.fee_bearer==='merchant'?' (ditanggung merchant)':''}</dt><dd>${money(o.fee_amount)}</dd></div><div class="payable"><dt>Total yang dibayar</dt><dd>${money(o.total_amount)}</dd></div></dl><p role="status">${esc(stateName(o.status))}</p>${pending?`<p>Scan QRIS atau simpan gambar QR lalu buka aplikasi pembayaran yang mendukung QRIS. Bayar tepat sesuai total di atas.</p><img class="payment-qr" src="/api/web/coins/orders/${encodeURIComponent(o.id)}/qr" alt="QRIS pembayaran ${esc(o.coins)} koin"><p class="qr-error" role="alert" hidden>QR belum dapat dimuat. Tutup lalu buka lagi tagihan ini.</p><a class="btn" href="/api/web/coins/orders/${encodeURIComponent(o.id)}/qr" download="Kocehind-QRIS.png">Simpan QRIS</a><p class="muted">Berlaku hingga ${esc(o.expires_at||'lihat status tagihan')} (waktu dari Kipay).</p><button class="btn primary" data-verify-invoice="${esc(o.id)}">Saya sudah membayar · cek status</button>`:o.status==='paid'?'<p>Koin sudah diproses ke saldo akun Anda.</p>':'<p>QR tagihan ini sudah tidak berlaku. Buat tagihan baru jika ingin membeli koin.</p>'}<small>Pesanan ${esc(o.id)}<br>Referensi ${esc(o.provider_reference||'belum tersedia')}</small></div>`;
}
export async function mountWallet(root,{isCurrent=()=>true}={}){
 let stopped=false;const alive=()=>!stopped&&isCurrent();let timer,refreshing=null,automaticCursor=0,invoiceDialog=null,invoiceId=null,invoiceSignature="";
 const onVisible=()=>{if(document.visibilityState==='visible')refresh({verify:true,all:false});};
 const cleanup=()=>{stopped=true;if(invoiceDialog?.open)invoiceDialog.close();clearInterval(timer);document.removeEventListener('visibilitychange',onVisible);};
 root.innerHTML=`<div class="section-top"><div><span class="eyebrow">DOMPET KOCEHIND</span><h1>Koin dan pendapatan</h1><p class="muted">Dukung cerita favorit Anda melalui gift LIVE.</p></div><a class="btn" href="/settings" data-link>Kembali</a></div><p role="alert" id="wallet-error"></p><section id="wallet-balance" class="wallet-balances"></section><section class="settings-panel"><h2>Top up koin</h2><p class="muted">Pilih paket koin dan bayar melalui QRIS Kipay. Total tagihan mencakup kode unik serta biaya bila dibebankan kepada pembeli. Koin masuk setelah pembayaran terverifikasi.</p><p id="payment-mode" class="sandbox-notice" hidden></p><form id="coin-form"><div id="coin-packages" class="coin-packages">Memuat paket…</div><label>Metode pembayaran<select name="method" required disabled><option>Memuat metode…</option></select></label><p class="form-error" role="alert"></p><button class="btn primary" type="submit" disabled>Buat tagihan</button></form></section><section class="settings-panel"><div class="buttons"><h2>Riwayat top up</h2><button class="btn" id="orders-refresh">Periksa pembayaran</button></div><p id="coin-sync-status" class="muted" role="status"></p><div id="coin-orders"></div><button class="btn" id="coin-more" hidden>Muat lainnya</button></section><section class="settings-panel"><h2>Riwayat penarikan</h2><div id="withdrawal-list"></div><button class="btn" id="withdraw-more" hidden>Muat lainnya</button></section><section class="settings-panel"><h2>Aktivitas saldo</h2><div id="wallet-entries"></div><button class="btn" id="entries-more" hidden>Muat lainnya</button></section>`;
 const $=s=>root.querySelector(s);let balance,orders=[],withdrawals=[],entries=[],onext=null,wnext=null,enext=null;
 const err=e=>{if(alive())$('#wallet-error').textContent=e.message;};
 function drawBalance(){const b=balance;$('#wallet-balance').innerHTML=`<article class="wallet-card accent"><span>Saldo koin</span><strong>${b.coins}</strong><small>Koin untuk gift LIVE${b.coin_debt?'<br>Penyesuaian pengembalian: '+b.coin_debt+' koin':''}</small></article><article class="wallet-card"><span>Pendapatan tersedia</span><strong>${money(b.earnings)}</strong><button class="btn primary" id="withdraw" ${b.earnings<b.minimum_withdrawal?'disabled':''}>Tarik pendapatan</button><small>Minimum ${money(b.minimum_withdrawal)} · 1–2 hari kerja</small></article><article class="wallet-card"><span>Dalam proses penarikan</span><strong>${money(b.held)}</strong><small>Total pendapatan ${money(b.earned_total)}<br>Sudah dibayar ${money(b.paid_total)}</small></article>`;$('#withdraw').onclick=()=>withdrawDialog(balance,async()=>{await refresh();});}
 function drawOrders(){$('#coin-orders').innerHTML=orders.map(o=>`<article class="wallet-row"><div><strong>${o.coins} koin · ${money(o.price)}</strong><small>${esc(date(o.created_at))} · ${esc(stateName(o.status))} · ${esc(o.gateway==='kipay'?'Kipay QRIS':'Tripay')} ${o.payment_mode==='sandbox'?'· Sandbox':''}<br>${o.total_amount?`Total tagihan ${money(o.total_amount)}<br>`:''}${esc(o.id)}</small></div><div class="buttons">${o.status==='unpaid'&&o.gateway==='kipay'?`<button class="btn" data-invoice="${esc(o.id)}">Lihat QRIS</button>`:''}${o.status==='unpaid'&&o.checkout_url?`<a class="btn" href="${esc(safeUrl(o.checkout_url))}" target="_blank" rel="noopener noreferrer">Buka tagihan</a>`:''}${!o.credited_at&&o.provider_reference?`<button class="btn" data-check="${esc(o.id)}" ${refreshing?'disabled':''}>Cek status</button>`:''}${o.status==='unknown'?'<small>Tagihan sedang diperiksa pengelola. Hindari pembayaran ganda.</small>':''}</div></article>`).join('')||'<p>Belum ada top up.</p>';$('#coin-more').hidden=onext===null;
  root.querySelectorAll('[data-invoice]').forEach(b=>b.onclick=()=>showInvoice(orders.find(o=>o.id===b.dataset.invoice)));
  root.querySelectorAll('[data-check]').forEach(b=>b.onclick=()=>refresh({verify:true,ids:[b.dataset.check]}));
 }
 function renderInvoice(o){
  if(!invoiceDialog?.open||!o)return;
  const signature=JSON.stringify(o);if(signature===invoiceSignature)return;invoiceSignature=signature;
  invoiceDialog.querySelector('.kipay-dialog-body').innerHTML=kipayInvoiceHTML(o);
  const img=invoiceDialog.querySelector('.payment-qr');if(img)img.onerror=()=>{invoiceDialog.querySelector('.qr-error').hidden=false;};
  const check=invoiceDialog.querySelector('[data-verify-invoice]');if(check)check.onclick=()=>refresh({verify:true,ids:[o.id]});
 }
 function showInvoice(o){
  if(!o)return;invoiceDialog?.close();invoiceSignature='';invoiceId=o.id;
  invoiceDialog=openDialog('Pembayaran QRIS Kipay','<div class="kipay-dialog-body"></div>');renderInvoice(o);
 }
 function drawWithdrawals(){$('#withdrawal-list').innerHTML=withdrawals.map(w=>`<article class="wallet-row"><div><strong>${money(w.amount)} · ${esc(stateName(w.status))}</strong><small>${esc(w.method)} · ${esc(w.account_number)} · ${esc(w.account_name)}<br>${esc(date(w.created_at))}${w.note?'<br>'+esc(w.note):''}${w.payment_reference?'<br>Referensi: '+esc(w.payment_reference):''}</small></div></article>`).join('')||'<p>Belum ada penarikan.</p>';$('#withdraw-more').hidden=wnext===null;}
 function drawEntries(){$('#wallet-entries').innerHTML=entries.map(e=>{const known=e.unit!==null&&e.unit!==undefined&&e.delta!==null&&e.delta!==undefined;const amount=known?(e.unit==='IDR'?money(e.delta):e.delta+' koin'):'Detail saldo tidak tersedia untuk riwayat lama';return `<article class="wallet-row"><div><strong>${esc({topup_refund:'Pengembalian koin',refund_debt:'Penyesuaian pengembalian',debt_repaid:'Penyesuaian diselesaikan',topup_credit:'Koin masuk',gift_spend:'Gift terkirim',gift_income:'Pendapatan gift',withdrawal_hold:'Pengajuan penarikan',withdrawal_released:'Penarikan dikembalikan',withdrawal_paid:'Penarikan dibayar'}[e.kind]||e.kind)}</strong><small>${esc(date(e.created_at))}</small></div><strong>${esc(amount)}</strong></article>`}).join('')||'<p>Belum ada aktivitas.</p>';$('#entries-more').hidden=enext===null;}
 function pendingOrders(){return orders.filter(o=>!o.credited_at&&o.provider_reference&&['creating','unknown','unpaid'].includes(o.status));}
 function paint(){drawBalance();drawOrders();drawWithdrawals();drawEntries();if(invoiceDialog?.open)renderInvoice(orders.find(o=>o.id===invoiceId));}
 async function loadSnapshot(){
  const [b,o,w,e]=await Promise.all([api('/wallet'),api('/web/coins/orders'),api('/wallet/withdrawals'),api('/wallet/entries')]);
  if(!alive())return;
  balance=b;orders=o.items;withdrawals=w.items;entries=e.items;onext=o.next_offset;wnext=w.next_offset;enext=e.next_offset;
  paint();
 }
 function refresh({verify=false,all=true,ids=null}={}){
  if(!alive())return Promise.resolve();
  if(refreshing)return refreshing;
  const button=$('#orders-refresh');button.disabled=true;
  refreshing=(async()=>{
   try{
    // Paint the current wallet immediately, then verify pending invoices.
    // Reload balances only after successful payment commits, avoiding a stale
    // parallel wallet read when the invoice becomes PAID without a callback.
    await loadSnapshot();if(!alive())return;
    $('#wallet-error').textContent='';
    if(!verify)return;
    let candidates=pendingOrders();
    if(ids)candidates=ids.map(id=>({id}));
    else if(!all&&candidates.length)candidates=[candidates[automaticCursor++%candidates.length]];
    else candidates=candidates.slice(0,5);
    if(!candidates.length){$('#coin-sync-status').textContent='Status pembayaran sudah diperbarui.';return;}
    $('#coin-sync-status').textContent='Memeriksa pembayaran…';
    const failures=[];let at=0;
    const worker=async()=>{while(alive()&&at<candidates.length){const o=candidates[at++];try{await api('/web/coins/orders/'+encodeURIComponent(o.id)+'/refresh',{method:'POST'});}catch(error){failures.push(error);}}};
    await Promise.all(Array.from({length:Math.min(2,candidates.length)},worker));
    if(!alive())return;
    await loadSnapshot();if(!alive())return;
    if(failures.length){$('#coin-sync-status').textContent='Sebagian pembayaran belum dapat diperiksa.';err(failures[0]);}
    else $('#coin-sync-status').textContent='Pembayaran sudah diperiksa.';
   }catch(e){err(e);}finally{if(alive()){button.disabled=false;root.querySelectorAll('[data-check]').forEach(b=>b.disabled=false);}}
  })().finally(()=>{refreshing=null;});
  return refreshing;
 }
 for(const [id,path,which] of [['coin-more','/web/coins/orders','orders'],['withdraw-more','/wallet/withdrawals','withdrawals'],['entries-more','/wallet/entries','entries']])$("#"+id).onclick=async e=>{e.target.disabled=true;try{const r=await api(path+'?offset='+({orders:onext,withdrawals:wnext,entries:enext}[which]));if(!alive())return;if(which==='orders'){orders.push(...r.items);onext=r.next_offset;drawOrders();}else if(which==='withdrawals'){withdrawals.push(...r.items);wnext=r.next_offset;drawWithdrawals();}else{entries.push(...r.items);enext=r.next_offset;drawEntries();}}catch(e){err(e);}finally{e.target.disabled=false;}};
 $('#orders-refresh').onclick=()=>refresh({verify:true});
 const create=keyedAction(body=>api('/web/coins/orders',{method:'POST',body}));const form=$('#coin-form');
 form.onsubmit=async e=>{e.preventDefault();const b=form.querySelector('[type=submit]');b.disabled=true;try{const f=new FormData(form),order=await create({package_id:f.get('package'),method:f.get('method')});await refresh();if(!alive())return;if(order.gateway==='kipay'&&order.provider_reference){showInvoice(orders.find(o=>o.id===order.id)||order);}else if(order.checkout_url){const d=openDialog('Tagihan siap',`<p>Periksa rincian dan biaya layanan pada tagihan sebelum membayar.</p><a class="btn primary" href="${esc(safeUrl(order.checkout_url))}" target="_blank" rel="noopener noreferrer">Lanjut ke pembayaran</a>`);d.querySelector('a').onclick=()=>d.close();}else toast('Tagihan sedang disiapkan. Periksa riwayat top up.');}catch(error){form.querySelector('.form-error').textContent=error.message;await refresh();}finally{b.disabled=false;}};
 const initialRefresh=refresh({verify:true});
 const [p,c]=await Promise.allSettled([api('/web/coins/packages'),api('/web/coins/channels')]);
 if(alive()){
  if(p.status==='fulfilled')$('#coin-packages').innerHTML=p.value.items.map((p,i)=>`<label class="coin-package"><input type="radio" name="package" value="${esc(p.id)}" ${i?'':'checked'} required><strong>${p.coins} koin</strong><span>${money(p.price)}</span></label>`).join('')||'Paket belum tersedia.';
  else $('#coin-packages').textContent=p.reason.message;
  if(c.status==='fulfilled'){if(c.value.mode==='sandbox'){const notice=$('#payment-mode');notice.hidden=false;notice.textContent='Mode sandbox: transaksi ini untuk pengujian, tanpa pembayaran nyata.';}form.elements.method.innerHTML=c.value.items.map(c=>`<option value="${esc(c.code)}">${esc(c.name)}</option>`).join('');form.elements.method.disabled=!c.value.items.length;form.querySelector('[type=submit]').disabled=!(p.status==='fulfilled'&&p.value.items.length&&c.value.items.length);}else{form.elements.method.innerHTML='<option>Belum tersedia</option>';form.querySelector('.form-error').textContent=c.reason.message;}
  document.addEventListener('visibilitychange',onVisible);
  timer=setInterval(()=>{if(document.visibilityState==='visible')refresh({verify:true,all:false});},15000);
 }
 await initialRefresh;
 return cleanup;
}
function withdrawDialog(b,done){const d=openDialog('Tarik pendapatan',`<p>Tersedia ${money(b.earnings)}. Minimum ${money(b.minimum_withdrawal)}. Proses 1–2 hari kerja.</p><form><label>Nominal rupiah<input name="amount" type="number" min="${b.minimum_withdrawal}" max="${b.earnings}" step="1" required></label><label>Metode<select name="method">${Object.entries(b.withdrawal_methods).map(([id,n])=>`<option value="${esc(id)}">${esc(n)}</option>`).join('')}</select></label><label>Nama pemilik rekening<input name="account_name" minlength="2" maxlength="100" required></label><label>Nomor rekening / akun<input name="account_number" inputmode="numeric" pattern="[0-9]{8,30}" required></label><label><input type="checkbox" required> Saya sudah memeriksa tujuan dan nominal penarikan.</label><p class="form-error" role="alert"></p><button class="btn primary" type="submit">Ajukan penarikan</button></form>`),form=d.querySelector('form'),send=keyedAction(body=>api('/wallet/withdrawals',{method:'POST',body}));
 form.onsubmit=async e=>{e.preventDefault();const b=form.querySelector('[type=submit]');b.disabled=true;try{const f=new FormData(form);await send({amount:Number(f.get('amount')),method:f.get('method'),account_name:f.get('account_name').trim(),account_number:f.get('account_number').trim()});d.close();toast('Pengajuan diterima. Proses 1–2 hari kerja.');await done();}catch(error){form.querySelector('.form-error').textContent=error.message;}finally{b.disabled=false;}};
}
export async function giftHistory(rid){
 const d=openDialog('Riwayat gift LIVE',`<p id="gift-totals">Memuat…</p><div id="gift-history"></div><button class="btn" id="gift-history-more">Muat lainnya</button><a class="btn" href="/api/studio/live/${encodeURIComponent(rid)}/gifts/download" download>Unduh riwayat CSV</a>`);let cursor=0;
 async function load(){const b=d.querySelector('#gift-history-more');b.disabled=true;try{const r=await api('/studio/live/'+encodeURIComponent(rid)+'/gifts?after='+cursor);if(!d.open)return;d.querySelector('#gift-totals').textContent=`${r.total} gift · ${r.coins} koin · Pendapatan ${money(r.income)}`;d.querySelector('#gift-history').insertAdjacentHTML('beforeend',r.items.map(g=>`<p>@${esc(g.sender)} · ${esc(g.name)} · ${g.coins} koin<br><small>${esc(date(g.created_at))}</small></p>`).join(''));cursor=r.cursor;b.hidden=r.items.length<100;}catch(e){toast(e.message);}finally{b.disabled=false;}}
 d.querySelector('#gift-history-more').onclick=load;await load();
}
