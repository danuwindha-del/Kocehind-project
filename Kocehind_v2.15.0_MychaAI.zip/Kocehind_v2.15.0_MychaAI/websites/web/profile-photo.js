import {esc,safeUrl,openDialog} from '/shared/api.js?v=2.15.0';
export function openProfilePhoto(user){
 const source=user.avatar_url?safeUrl(user.avatar_url):'',name=user.username?'@'+user.username:user.name||'Pengguna';
 const html=source?`<div class="profile-photo-viewport"><img src="${esc(source)}" alt="${esc('Foto profil '+name)}"></div><p class="profile-photo-error" hidden>Foto belum dapat dimuat. Tutup preview dan coba kembali.</p>`:'<div class="profile-photo-empty">Belum ada foto profil</div>';
 const dialog=openDialog('Foto profil '+name,html,{wide:true});dialog.classList.add('profile-photo-dialog');
 dialog.querySelector('img')?.addEventListener('error',()=>{dialog.querySelector('img').hidden=true;dialog.querySelector('.profile-photo-error').hidden=false;});
 return dialog;
}
