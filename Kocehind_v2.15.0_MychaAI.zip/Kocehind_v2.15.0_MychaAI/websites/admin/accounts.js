import {api,esc,date,toast,openDialog,busy} from '/shared/api.js?v=2.15.0';

export async function mountAccountsAdmin(root,isCurrent) {
  const [status,campaigns,deletions,safety]=await Promise.all([
    api('/admin/email/status'),api('/admin/email/campaigns'),
    api('/admin/account-deletions'),api('/admin/content-safety/status')]);
  if(!isCurrent())return;
  const selected=new Map();
  root.innerHTML='<div class="page-heading"><div><h1>Email dan akun</h1>'+
    '<p class="muted">Mailjet HTTPS, pemulihan password dan permintaan penghapusan akun.</p></div></div>'+
    '<section class="panel"><div class="panel-body"><h2>Status email</h2>'+
    '<p>'+esc(status.transport)+' · port '+status.port+' · '+(status.configured?'Terkonfigurasi':'Belum dikonfigurasi')+
    '</p><p>Pengirim: '+esc(status.from_email||'Belum diisi')+'</p><p>'+esc(JSON.stringify(status.counts))+'</p></div></section>'+
    '<section class="panel"><div class="panel-body"><h2>Kirim email</h2>'+
    '<form id="email-campaign"><label>Kategori<select name="kind"><option value="information">Informasi</option>'+
    '<option value="promotion">Promosi</option><option value="update">Pembaruan</option><option value="event">Acara</option></select></label>'+
    '<label>Penerima<select name="audience"><option value="selected">Pilih pengguna</option><option value="all">Semua akun aktif dengan email terverifikasi</option></select></label>'+
    '<label>Subjek<input name="subject" minlength="3" maxlength="150" required></label>'+
    '<label>Isi email<textarea name="body" minlength="10" maxlength="20000" rows="6" required></textarea></label>'+
    '<p id="selected-users">Belum ada penerima dipilih.</p><p class="form-error" role="alert"></p>'+
    '<label><input type="checkbox" name="confirmed" required> Saya telah memeriksa isi dan penerima email.</label>'+
    '<button class="btn primary" type="submit">Antrekan pengiriman email</button></form></div></section>'+
    '<section class="panel"><div class="panel-body"><h2>Pilih pengguna / bantu pemulihan password</h2>'+
    '<form id="find-recipient"><label>Cari username atau email<input name="query" maxlength="100" required></label>'+
    '<button class="btn" type="submit">Cari akun</button></form><div id="recipient-results"></div></div></section>'+
    '<section class="panel"><div class="panel-body"><h2>Riwayat email</h2>'+campaigns.items.map(c=>
      '<article><strong>'+esc(c.subject)+'</strong><p>'+c.recipients+' penerima · '+esc(date(c.created_at))+
      '</p><p>'+esc(JSON.stringify(c.counts))+'</p></article>').join('')+'</div></section>'+
    '<section class="panel"><div class="panel-body"><h2>Permintaan penghapusan akun</h2>'+
    (deletions.items.map(d=>'<article><strong>'+esc(d.user_id)+'</strong><p>'+esc(d.reason)+'</p><p>Status: '+esc(d.status)+
      '</p><p>'+esc(d.resolution)+'</p>'+(['pending','reviewing'].includes(d.status)?'<button class="btn" data-review="'+esc(d.id)+
      '">Tinjau</button> <button class="btn danger" data-reject="'+esc(d.id)+'">Tolak dengan alasan</button>':'')+'</article>').join('')||
      '<p>Belum ada permintaan.</p>')+'</div></section>'+
    '<section class="panel"><div class="panel-body"><h2>Deteksi gore, darah, kekerasan dan ujaran kebencian</h2>'+
    '<p>'+esc(safety.message)+'</p><pre>'+esc(JSON.stringify(safety,null,2))+'</pre></div></section>';
  const form=root.querySelector('#email-campaign');
  let requestKey=crypto.randomUUID();
  form.onsubmit=async event=>{
    event.preventDefault();busy(form,true);
    try{
      const values=Object.fromEntries(new FormData(form));
      const result=await api('/admin/email/campaigns',{method:'POST',body:{
        kind:values.kind,subject:values.subject,body:values.body,audience:values.audience,
        user_ids:values.audience==='selected'?[...selected.keys()]:[],request_key:requestKey}});
      toast('Email diantrekan untuk '+result.recipients+' penerima.');
      requestKey=crypto.randomUUID();form.reset();selected.clear();
      root.querySelector('#selected-users').textContent='Belum ada penerima dipilih.';
    }catch(error){form.querySelector('.form-error').textContent=error.message;}
    finally{busy(form,false);}
  };
  root.querySelector('#find-recipient').onsubmit=async event=>{
    event.preventDefault();
    try{
      const r=await api('/admin/users?limit=30&q='+encodeURIComponent(new FormData(event.target).get('query')));
      if(!isCurrent())return;
      const results=root.querySelector('#recipient-results');
      results.innerHTML=r.items.map(u=>'<div class="user-row"><label><input type="checkbox" data-select="'+esc(u.id)+
        '" '+(selected.has(u.id)?'checked':'')+'> @'+esc(u.username)+' · '+esc(u.email)+'</label>'+
        '<button class="btn small" data-reset="'+esc(u.id)+'">Kirim pemulihan password</button></div>').join('')||'<p>Akun tidak ditemukan.</p>';
      results.querySelectorAll('[data-select]').forEach(b=>b.onchange=()=>{
        const user=r.items.find(x=>x.id===b.dataset.select);
        if(b.checked)selected.set(user.id,user.username);else selected.delete(user.id);
        root.querySelector('#selected-users').textContent='Dipilih: '+([...selected.values()].join(', ')||'belum ada');
      });
      results.querySelectorAll('[data-reset]').forEach(b=>b.onclick=()=>reasonAction('Bantu pemulihan password',
        'Kode dan tautan akan dikirim ke email pemilik akun. Admin tidak dapat melihat kode atau menetapkan password.',
        reason=>api('/admin/users/'+encodeURIComponent(b.dataset.reset)+'/password-reset',{method:'POST',body:{reason}})));
    }catch(error){toast(error.message);}
  };
  for(const [key,action] of [['review','review'],['reject','reject']])
    root.querySelectorAll('[data-'+key+']').forEach(b=>b.onclick=()=>reasonAction('Tinjau permintaan penghapusan',
      'Peninjauan tidak otomatis memusnahkan data. Pemrosesan hak pengguna dilakukan sesuai prosedur penghapusan.',
      reason=>api('/admin/account-deletions/'+encodeURIComponent(b.dataset[key])+'/decision',
        {method:'POST',body:{action,reason}})));
}

function reasonAction(title,description,action) {
  const d=openDialog(title,'<p>'+esc(description)+'</p><form><label>Alasan/catatan<textarea name="reason" minlength="3" maxlength="2000" required></textarea></label>'+
    '<p class="form-error" role="alert"></p><button class="btn primary" type="submit">Konfirmasi</button></form>');
  const f=d.querySelector('form');
  f.onsubmit=async event=>{event.preventDefault();busy(f,true);
    try{await action(new FormData(f).get('reason'));d.close();toast('Permintaan diproses. Muat ulang halaman untuk status terbaru.');}
    catch(error){f.querySelector('.form-error').textContent=error.message;}
    finally{busy(f,false);}
  };
}
