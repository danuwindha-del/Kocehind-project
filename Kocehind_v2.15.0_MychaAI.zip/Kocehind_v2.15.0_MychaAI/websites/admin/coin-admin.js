import {api,esc,toast,openDialog} from '/shared/api.js?v=2.15.0';

export async function mountCoinAdmin(root,isCurrent=()=>true){
 let query='',offset=0,next=null,generation=0;
 root.innerHTML=`<section class="panel"><div class="panel-head"><h2>Koin pengguna</h2></div><div class="panel-body"><p>Tambah atau kirim koin ke pengguna, kurangi saldo, atau pindahkan koin antar akun. Semua perubahan tercatat di riwayat tindakan admin.</p><form data-coin-search class="toolbar"><label>Cari nama, username, atau ID<input name="q" maxlength="100" autocomplete="off"></label><button class="btn" type="submit">Cari pengguna</button></form><p data-coin-error role="alert"></p><div data-coin-users></div><div class="pagination"><button class="btn" data-coin-prev>Sebelumnya</button><button class="btn" data-coin-next>Berikutnya</button></div></div></section>`;
 const $=s=>root.querySelector(s);
 async function load(){
  const current=++generation;try{
   const response=await api(`/admin/wallet/users?q=${encodeURIComponent(query)}&offset=${offset}`);
   if(!isCurrent()||current!==generation)return;
   next=response.next_offset;$('[data-coin-error]').textContent='';
   $('[data-coin-users]').innerHTML=`<div class="table-scroll"><table><thead><tr><th>Pengguna</th><th>Saldo koin</th><th>Penyesuaian refund</th><th>Tindakan</th></tr></thead><tbody>${response.items.map(user=>`<tr><td><strong>@${esc(user.username)}</strong><br>${esc(user.name)}${user.is_banned?' · Diblokir':''}</td><td>${esc(user.coins)}</td><td>${esc(user.coin_debt)}</td><td><button class="btn small" data-coin-user="${esc(user.id)}" ${user.is_banned?'disabled':''}>Kelola koin</button></td></tr>`).join('')||'<tr><td colspan="4">Pengguna tidak ditemukan.</td></tr>'}</tbody></table></div>`;
   $('[data-coin-prev]').disabled=offset===0;$('[data-coin-next]').disabled=next===null;
   root.querySelectorAll('[data-coin-user]').forEach(button=>button.onclick=()=>edit(response.items.find(user=>user.id===button.dataset.coinUser)));
  }catch(error){if(isCurrent()&&current===generation)$('[data-coin-error]').textContent=error.message;}
 }
 function edit(user){
  const dialog=openDialog('Kelola koin pengguna',`<p>Penerima / akun tujuan: <strong>@${esc(user.username)}</strong> · ${esc(user.name)}<br>Saldo saat dibuka: ${esc(user.coins)} koin.</p><form><label>Tindakan<select name="action"><option value="credit">Tambah / kirim koin dari admin</option><option value="debit">Kurangi koin pengguna</option><option value="transfer">Pindahkan dari pengguna lain</option></select></label><label data-source hidden>Username pengirim<input name="source_username" maxlength="24" autocomplete="off" placeholder="username pengirim"></label><label>Jumlah koin<input name="amount" type="number" min="1" max="1000000000" step="1" required></label><label>Alasan<textarea name="reason" minlength="3" maxlength="500" required></textarea></label><p>Penambahan akan menyelesaikan penyesuaian refund terlebih dahulu bila ada.</p><p class="form-error" role="alert"></p><button class="btn primary" type="submit">Simpan perubahan koin</button></form>`);
  const form=dialog.querySelector('form');let requestKey=crypto.randomUUID(),previous='',busy=false;
  form.elements.action.onchange=()=>{const transfer=form.elements.action.value==='transfer';form.querySelector('[data-source]').hidden=!transfer;form.elements.source_username.required=transfer;};
  form.onsubmit=async event=>{
   event.preventDefault();if(busy)return;busy=true;const button=form.querySelector('[type=submit]');button.disabled=true;
   try{
    const fields=new FormData(form),action=fields.get('action');
    const body={action,target_user_id:user.id,amount:Number(fields.get('amount')),reason:String(fields.get('reason')).trim()};
    if(action==='transfer'){
     const username=String(fields.get('source_username')).trim().replace(/^@/,'').toLowerCase();
     const matches=await api('/admin/wallet/users?exact=true&q='+encodeURIComponent(username));
     const source=matches.items.find(item=>item.username.toLowerCase()===username);
     if(!source)throw new Error('Username pengirim tidak ditemukan. Periksa kembali.');
     body.source_user_id=source.id;
    }
    const signature=JSON.stringify(body);if(previous&&previous!==signature)requestKey=crypto.randomUUID();previous=signature;
    await api('/admin/wallet/coins',{method:'POST',body:{...body,request_key:requestKey}});
    dialog.close();toast('Perubahan koin tersimpan dan tercatat di audit.');await load();
   }catch(error){form.querySelector('.form-error').textContent=error.message;}finally{busy=false;button.disabled=false;}
  };
 }
 $('[data-coin-search]').onsubmit=event=>{event.preventDefault();query=String(new FormData(event.target).get('q')).trim();offset=0;load();};
 $('[data-coin-prev]').onclick=()=>{offset=Math.max(0,offset-30);load();};
 $('[data-coin-next]').onclick=()=>{if(next!==null){offset=next;load();}};
 await load();
}
