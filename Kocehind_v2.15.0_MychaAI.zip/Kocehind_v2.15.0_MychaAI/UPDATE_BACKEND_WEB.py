#!/usr/bin/env python3
"""Restore backend/web integration while deploying the bundled Studio R1 design."""
import argparse
from pathlib import Path
import subprocess
from package_ops import require_root, source_tree, runtime_environment, install_backend_tools
from UPDATE_UI_WEB import verify


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='Preflight tanpa perubahan pada VPS')
    args = parser.parse_args()
    require_root()
    if not Path('/etc/kocehind/backend.env').is_file():
        raise RuntimeError('Backend existing belum ditemukan. Updater ini bukan installer VPS kosong.')
    with source_tree() as project, runtime_environment() as env:
        verify(project / 'websites', project / 'UI_MANIFEST.json')
        subprocess.run(['nginx', '-t'], check=True)
        if args.check:
            print('PREFLIGHT OK: source, web Studio R1, Python backend dan Nginx siap. Belum ada perubahan.')
            print('Update akan mencadangkan database/media dan memulai ulang API/worker; akhiri LIVE dahulu.')
            return
        subprocess.run(['bash', str(project / 'scripts/vps2_update_v215.sh')],
                       cwd=project, env=env, check=True)
        install_backend_tools(project)
    print('KOCEHIND 2.15.0 TERPASANG dengan desain Studio R1. Env, saldo, pesanan dan dokumen hukum aktif dipertahankan.')
    print('Periksa worker: /opt/kocehind/venv/bin/python DIAGNOSA_INTEGRASI.py')


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        raise SystemExit('BELUM SELESAI: ' + str(exc)) from None
