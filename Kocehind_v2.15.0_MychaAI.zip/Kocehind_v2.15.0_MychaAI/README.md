# Kocehind 2.15.0 — MychaAI dan profil kreator

Pembaruan lengkap dari source gabungan 2.14.0. Termasuk Play Recovery R1, tujuh paket koin tanpa bonus, Kipay, SEO Video R1, robots.txt dan sitemap yang telah diperbaiki.

Fitur baru:

- **MychaAI** di bagian atas pencarian dan tab **Tanya**, memakai API DattioAI di backend. Ringkasan memuat sumber dan dapat diperluas.
- Indeks kreator otomatis dengan syarat popularitas berlapis. Data publik dipelajari dahulu; indeks yang belum siap tidak ditampilkan. Admin dapat menambah fakta, tautan dan gambar, mengedit, mempelajari ulang, atau menarik indeks.
- **Bagikan > Sematkan di profil / Copot sematkan**, maksimal tiga video. Video yang disematkan tampil lebih dahulu, termasuk untuk pengunjung, dengan tetap mematuhi privasi dan moderasi.
- **Edit profil > Tambahkan tautan**, maksimal dua tautan HTTPS, ditampilkan di bawah bio.
- Gambar galeri untuk LIVE diperiksa sebelum ditayangkan oleh OpenNSFW2 dan model visual gore/darah/kekerasan yang sudah dipasang. Temuan menghentikan LIVE dan masuk Aktivitas beserta alasan/banding. Model gagal/belum siap tidak mengizinkan gambar tampil.
- Email konfirmasi dan terima kasih untuk pembelian koin yang telah diverifikasi melalui Kipay, Google Play, dan penyelesaian pesanan Tripay lama.

Mulai dari **PANDUAN_UPDATE_v2.15.0.md**. Baca **LAPORAN_PENGUJIAN_v2.15.0.md** untuk hasil dan batas pengujian.

Ini paket source dan alat update/build. Belum dipasang di VPS Anda; tidak menyertakan APK/AAB release, keystore, credential server, atau API key DattioAI. API key diinput tersembunyi pada VPS melalui **SETUP_MYCHAAI.py**.
