# Kocehind 2.14.0

Pembaruan dari UI Integrasi R2: pembelian koin Android dengan Google Play, kontrol koin admin, kualitas video LIVE, pembesaran gambar, dan pemulihan halaman aktivitas Kocehind.

Mulai dari **PANDUAN_GOOGLE_PLAY_v2.14.0.md** untuk pemasangan backend/web, pembuatan produk Play Console, service account, build Android dengan key lama dan uji dua akun. **LAPORAN_PENGUJIAN_v2.14.0.md** mencatat hasil pengujian dan batas verifikasi.

Paket ini mencakup hotfix launcher Python updater: virtualenv baru menggunakan interpreter yang tetap, sehingga preflight pengguna service tidak bergantung pada direktori sementara privat.

- Backend: 2.14.0; migrasi tambahan tanpa reset saldo.
- Android: 2.14.0+39, nomor build otomatis meningkat sesuai riwayat.
- Web sosial, landing page dan admin: source tersinkron di paket ini dan SOURCE_LENGKAP_v2.14.0.zip.
- Google Play memerlukan aktivasi produk, harga dan credential privat milik pemilik. Flag default nonaktif; kode saja tidak mengaktifkan akun Play Console.
- BUILD_VPS_BARU.sh khusus builder Android. UPDATE_BACKEND_WEB.py khusus VPS backend/web existing.
- Pembelian web Kipay dan pemenuhan pesanan Tripay lama tetap berjalan.

Di VPS backend, akhiri LIVE lalu jalankan:

```bash
cd /root/Kocehind_v2.14.0
sha256sum -c SHA256SUMS.txt
/opt/kocehind/venv/bin/python UPDATE_BACKEND_WEB.py --check
/opt/kocehind/venv/bin/python UPDATE_BACKEND_WEB.py
```

Di builder Android, gunakan key lama dan Flutter 3.38.10, lalu bangun APK/AAB baru. Jangan memakai ulang nomor build yang pernah diunggah ke Play.

Catatan operasional versi sebelumnya ada di README_INTEGRASI_R2.md dan source lengkap. Dokumen hukum aktif tidak diganti otomatis; kaji pembaruan penjelasan pembayaran Google Play dan terbitkan lewat Admin > Dokumen hukum.
