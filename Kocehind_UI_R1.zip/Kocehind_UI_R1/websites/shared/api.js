import {LegalConsent} from './legal-state.js?v=2.13.3';
import {networkFetch,OFFLINE_MESSAGE} from './network.js?v=2.13.3';
export class ApiError extends Error { constructor(message,status) { super(message); this.status=status; } }
let refreshTask,signingOut=false;
export let me=null,restoreError=null;
let restoreTask;
export const setMe=(user)=>{restoreError=null;me=user;window.dispatchEvent(new CustomEvent('sessionchange',{detail:user}));};
let guest;
try{guest=localStorage.getItem('kocehind_guest');}catch{}
if(!guest){guest=typeof crypto.randomUUID==='function'?crypto.randomUUID():Array.from(crypto.getRandomValues(new Uint8Array(24)),n=>n.toString(16).padStart(2,'0')).join('');try{localStorage.setItem('kocehind_guest',guest);}catch{}}
export async function api(path,{method='GET',body,refresh=true,legalRetry=true,...options}={}) {
  if(me?.legal_required&&!['GET','HEAD','OPTIONS'].includes(method.toUpperCase())&&!path.startsWith('/web/auth/')&&!['/legal/accept','/legal/requests'].includes(path)&&!await requireLegalAcceptance())throw new ApiError('Persetujuan dokumen terbaru diperlukan untuk melanjutkan.',428);
  const headers={'X-Guest-ID':guest,...options.headers};
  if(body!==undefined&&!(body instanceof FormData))headers['Content-Type']='application/json';
  const res=await networkFetch('/api'+path,{...options,method,credentials:'same-origin',headers,body:body instanceof FormData?body:body===undefined?undefined:JSON.stringify(body)});
  if(res.status===401&&refresh&&!signingOut&&!path.startsWith('/web/auth/')) {
    refreshTask??=api('/web/auth/refresh',{method:'POST',refresh:false}).then(r=>setMe(r.user)).finally(()=>refreshTask=null);
    try { await refreshTask; } catch(error) { if([401,403].includes(error.status))setMe(null);throw error; }
    // A later action error must retain the refreshed session and its consent state.
    if(me)return await api(path,{method,body,...options,refresh:false,legalRetry});
  }
  const data=await res.json().catch(()=>({detail:'Server tidak merespons dengan benar'}));
  if(res.status===428&&me){
    setMe({...me,legal_required:true});
    // A rejected mutation has not run. Retry once only, after fresh explicit consent.
    if(legalRetry&&!path.startsWith('/web/auth/')&&path!=='/legal/accept'&&await requireLegalAcceptance())return await api(path,{method,body,...options,refresh,legalRetry:false});
  }
  if(!res.ok)throw new ApiError(typeof data.detail==='string'?data.detail:typeof data.detail?.message==='string'?data.detail.message:'Periksa isian Anda dan coba lagi',res.status);
  return data;
}
export async function discovery(path){
 try{return await api(path);}catch(error){
  const url=new URL(path,location.origin);
  if(error.status!==400||!['/feed','/live/discover'].includes(url.pathname)||!url.searchParams.has('cursor'))throw error;
  url.searchParams.delete('cursor');return api(url.pathname+'?'+url.searchParams.toString());
 }
}
export function restore(){return restoreTask??=(async()=>{try{const user=await api('/users/me');restoreError=null;setMe(user);}catch(error){if([401,403].includes(error.status)){restoreError=null;setMe(null);}else restoreError=error;}window.dispatchEvent(new Event('sessionrestore'));return me;})().finally(()=>{restoreTask=null;});}
export async function logout(){signingOut=true;try{if(refreshTask)await refreshTask.catch(()=>{});await api('/web/auth/logout',{method:'POST',refresh:false});setMe(null);}finally{signingOut=false;}}
export const esc=(v)=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const safeUrl=v=>{try{const u=new URL(v,location.origin);return ['https:','http:'].includes(u.protocol)?u.href:'';}catch{return '';}};
export const count=n=>new Intl.NumberFormat('id-ID',{notation:Number(n)>9999?'compact':'standard',maximumFractionDigits:1}).format(Number(n)||0);
export const date=v=>{const d=new Date(v);return Number.isNaN(d.getTime())?'':new Intl.DateTimeFormat('id-ID',{dateStyle:'medium',timeStyle:'short'}).format(d);};
export const badge=u=>u?.is_verified?'<span class="verified" title="Akun terverifikasi" role="img" aria-label="Akun terverifikasi"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="m23 12-2.44-2.79.34-3.69-3.61-.82L15.4 1.5 12 2.96 8.6 1.5 6.71 4.69l-3.61.81.34 3.7L1 12l2.44 2.79-.34 3.7 3.61.82 1.89 3.19 3.4-1.47 3.4 1.46 1.89-3.19 3.61-.82-.34-3.69L23 12Z"/><path fill="#fff" d="m10.09 16.72-4.5-4.5L7 10.81l3.09 3.08 6.9-6.9 1.42 1.42-8.32 8.31Z"/></svg></span>':'';
export const avatar=u=>u?.avatar_url?`<img class="avatar" src="${esc(safeUrl(u.avatar_url))}" alt="" loading="lazy">`:`<span class="avatar letter">${esc((u?.name||u?.username||'K')[0].toUpperCase())}</span>`;
export function toast(message){let el=document.querySelector('#toast');if(!el){el=document.createElement('div');el.id='toast';el.role='status';document.body.append(el);}el.textContent=message;el.classList.add('show');clearTimeout(el.timer);el.timer=setTimeout(()=>el.classList.remove('show'),5000);}
export function icon(name){const shapes={lock:'<rect x="5" y="10" width="14" height="12" rx="2"/><path d="M8 10V6a4 4 0 0 1 8 0v4"/><circle cx="12" cy="16" r="1"/>',history:'<path d="M3 10a9 9 0 1 1 0 5M3 3v7h7M12 7v6l4 2"/>',home:'<path d="m3 10 9-7 9 7v10H14v-7h-4v7H3z"/>',search:'<circle cx="10" cy="10" r="6"/><path d="m15 15 6 6"/>',heart:'<path d="M20 5c-3-3-6-1-8 1C6-1-3 6 5 14l7 7 7-7c4-4 4-7 1-9Z"/>',comment:'<path d="M21 11a9 9 0 0 1-9 9H3l2-5a9 9 0 1 1 16-4Z"/>',save:'<path d="M5 3h14v19l-7-5-7 5Z"/>',share:'<path d="m14 3 8 8-8 7v-5C8 12 4 15 2 19c0-9 5-13 12-13Z"/>',users:'<circle cx="9" cy="7" r="4"/><path d="M1 22v-4a8 8 0 0 1 16 0v4M17 3a4 4 0 0 1 0 8m2 3a7 7 0 0 1 4 7"/>',user:'<circle cx="12" cy="7" r="4"/><path d="M4 22v-3a8 8 0 0 1 16 0v3"/>',inbox:'<rect x="2" y="4" width="20" height="17" rx="3"/><path d="M2 13h6l2 3h4l2-3h6"/>',plus:'<path d="M12 3v18M3 12h18"/>',refresh:'<path d="M21 10a9 9 0 1 0-1 8M21 3v7h-7"/>',settings:'<path d="m9 2-1 3-3 1-3 4 2 2-1 3 3 4 3-1 3 4 3-2h3l3-5-2-3 1-3-4-4-3 1Z"/><circle cx="12" cy="12" r="3"/>',logout:'<path d="M9 3H3v18h6m6-16 7 7-7 7M7 12h15"/>',shield:'<path d="m12 2 9 4v7c0 5-9 9-9 9s-9-4-9-9V6Z"/><path d="m7 12 3 3 7-7"/>',chart:'<path d="M3 3v18h19M7 17v-5m5 5V7m5 10V4"/>',video:'<rect x="2" y="5" width="14" height="14" rx="3"/><path d="m16 10 6-4v13l-6-4"/>',flag:'<path d="M4 22V2m0 2c5-5 10 5 16 0v11c-6 5-11-5-16 0"/>',check:'<path d="m4 12 5 5L21 5"/>',close:'<path d="m5 5 14 14M19 5 5 19"/>',arrow:'<path d="M3 12h18m-7-7 7 7-7 7"/>',download:'<path d="M12 2v14m-5-5 5 5 5-5M3 16v6h18v-6"/>',music:'<path d="M9 18V4l12-2v14M9 8l12-2"/><ellipse cx="6" cy="19" rx="3" ry="2"/><ellipse cx="18" cy="17" rx="3" ry="2"/>',bell:'<path d="M4 18h16l-2-4V9A6 6 0 0 0 6 9v5Zm5 3h6"/>'};return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${shapes[name]||shapes.home}</svg>`;}
export function openDialog(title,html,{wide=false,onClose}={}) {
 const dialog=document.createElement('dialog');dialog.className=wide?'modal wide':'modal';dialog.innerHTML=`<header><h2>${esc(title)}</h2><button class="icon-btn close" aria-label="Tutup">${icon('close')}</button></header><div class="dialog-body">${html}</div>`;
 document.body.append(dialog);dialog.querySelector('.close').onclick=()=>dialog.close();dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close();});dialog.addEventListener('close',()=>{onClose?.();dialog.remove();});dialog.showModal();return dialog;
}
export function busy(form,value){form.querySelectorAll('button[type="submit"]').forEach(b=>b.disabled=value);}
export const legalLinks='<a href="https://kocehind.web.id/privasi" target="_blank" rel="noopener">Kebijakan Privasi ↗</a><a href="https://kocehind.web.id/ketentuan" target="_blank" rel="noopener">Ketentuan Penggunaan ↗</a>';
export function legalConsentMarkup(){return `<section class="legal-consent"><div class="legal-doc-links"><button class="text-btn" type="button" data-read-legal="privacy">Baca Kebijakan Privasi</button><button class="text-btn" type="button" data-read-legal="terms">Baca Ketentuan Penggunaan</button></div><p class="muted" data-legal-status role="status">Memuat versi dokumen terbaru…</p><label class="legal-check"><input type="checkbox" name="legal_consent" required disabled><span>Saya telah membaca dan menyetujui Kebijakan Privasi dan Ketentuan Penggunaan versi yang ditampilkan di atas.</span></label><button class="text-btn" type="button" data-retry-legal hidden>Muat ulang dokumen</button></section>`;}
export function readLegalDocument(doc){return openDialog(doc.title,`<p class="muted">Versi ${esc(doc.version)}${doc.updated_at?' · Diperbarui '+esc(date(doc.updated_at)):''}</p><div class="legal-document-content" tabindex="0">${esc(doc.content)}</div>`,{wide:true});}
function consentControls(root,onChange=()=>{}){
 const state=new LegalConsent(),checkbox=root.querySelector('[name="legal_consent"]'),status=root.querySelector('[data-legal-status]'),retry=root.querySelector('[data-retry-legal]');
 const changed=()=>{checkbox.checked=state.checked;onChange(state);};
 checkbox.onchange=()=>{state.choose(checkbox.checked);changed();};
 root.querySelectorAll('[data-read-legal]').forEach(button=>button.onclick=()=>{const doc=state.documents?.[button.dataset.readLegal];if(doc)readLegalDocument(doc);});
 const refresh=async()=>{state.choose(false);checkbox.disabled=true;changed();status.textContent='Memuat versi dokumen terbaru…';retry.hidden=true;try{state.replace(await api('/legal/documents'));if(!root.isConnected)return;checkbox.disabled=false;status.textContent=`Kebijakan Privasi v${state.documents.privacy.version} · Ketentuan Penggunaan v${state.documents.terms.version}`;}catch(error){state.documents=null;status.textContent=error.message;retry.hidden=false;}finally{changed();}};
 retry.onclick=refresh;const ready=refresh();return {state,refresh,ready,acceptance:()=>state.acceptance()};
}
let legalTask;
export function requireLegalAcceptance(){
 if(!me?.legal_required)return Promise.resolve(Boolean(me));
 return legalTask??=new Promise(resolve=>{
  const userID=me.id;let done=false;
  const d=openDialog('Persetujuan dokumen terbaru',`<p class="muted">Kebijakan Privasi atau Ketentuan Penggunaan telah diperbarui. Baca versi terbaru dan berikan persetujuan sebelum melanjutkan aktivitas akun. Anda tetap dapat membaca dokumen atau keluar akun.</p><form>${legalConsentMarkup()}<p class="form-error" role="alert"></p><button class="btn primary" type="submit">Setujui dan lanjutkan</button></form><button class="text-btn" id="legal-logout">Keluar akun</button>`),form=d.querySelector('form'),controls=consentControls(form);
  form.onsubmit=async event=>{event.preventDefault();if(done)return;busy(form,true);try{if(me?.id!==userID)throw new Error('Sesi akun berubah. Masuk kembali untuk melanjutkan.');const response=await api('/legal/accept',{method:'POST',body:controls.acceptance()});setMe({...me,...response});if(response.legal_required!==false)throw new ApiError('Dokumen telah diperbarui. Baca dan setujui versi terbaru.',428);done=true;d.close();resolve(true);}catch(error){form.querySelector('.form-error').textContent=error.message;if(error.status===428)await controls.refresh();}finally{busy(form,false);}};
  d.querySelector('#legal-logout').onclick=async()=>{try{await logout();d.close();}catch(error){form.querySelector('.form-error').textContent=error.message;}};
  d.addEventListener('close',()=>{if(!done)resolve(false);});
 }).finally(()=>{legalTask=null;});
}
export function authDialog({admin=false}={}){
 return new Promise(resolve=>{
  let mode='login',done=false,revision=0;
  const d=openDialog(admin?'Masuk ke Control Center':'Selamat datang di Kocehind','');
  const draw=()=>{const rev=++revision;let signing=false,googleConfig=null;
   d.querySelector('.dialog-body').innerHTML=`<p class="muted">${admin?'Gunakan akun yang telah diberi peran administrator.':'Masuk untuk ikut ngobrol, mengikuti kreator, dan menyimpan cerita favorit.'}</p><form id="auth-form">${mode==='register'?'<label>Nama<input name="name" required maxlength="100" autocomplete="name"></label><label>Username<input name="username" required minlength="3" maxlength="24" pattern="[a-z0-9_.]+" autocomplete="username"></label>':''}<label>${mode==='register'?'Email':'Username atau email'}<input type="${mode==='register'?'email':'text'}" name="email" required autocomplete="username" maxlength="254"></label><label>Password<input type="password" name="password" required ${mode==='register'?'minlength="10"':''} autocomplete="${mode==='register'?'new-password':'current-password'}"></label>${legalConsentMarkup()}<p class="form-error" role="alert"></p><button class="btn primary" type="submit">${mode==='register'?'Buat akun':'Masuk'}</button></form><button class="text-btn" id="forgot-password">Lupa password?</button>${!admin?`<button class="text-btn switch-auth">${mode==='login'?'Belum punya akun? Daftar':'Sudah punya akun? Masuk'}</button><div id="google-button" aria-live="polite"></div>`:''}`;
   const form=d.querySelector('form');let controls;
   const showError=async error=>{form.querySelector('.form-error').textContent=error.message;if(error.status===428)await controls.refresh();};
   const finish=async response=>{if(response.verification_required){response=await (await import('./accounts.js?v=2.13.3')).verifyEmailDialog(response.challenge);if(!response)return;}setMe(response.user);if(admin){try{await api('/admin/me');}catch(error){await logout();throw error;}}done=true;d.close();resolve(true);};
   const google=async()=>{const target=d.querySelector('#google-button');if(!target||rev!==revision||!d.open)return;target.replaceChildren();if(!controls?.state.checked||signing){target.textContent='Setujui dokumen di atas untuk melanjutkan dengan Google.';return;}if(!googleConfig?.google_web_client_id)return;try{await loadGoogle();if(!controls.state.checked||rev!==revision||!d.open)return;window.google.accounts.id.initialize({client_id:googleConfig.google_web_client_id,callback:async response=>{if(signing||rev!==revision||!d.open)return;try{const acceptance=controls.acceptance();signing=true;busy(form,true);await finish(await api('/web/auth/google',{method:'POST',body:{id_token:response.credential,legal_acceptance:acceptance}}));}catch(error){await showError(error);}finally{signing=false;busy(form,false);google();}}});window.google.accounts.id.renderButton(target,{theme:'outline',size:'large',text:'continue_with'});}catch{target.textContent='Google belum dapat dimuat. Silakan masuk dengan email.';}};
   controls=consentControls(form,()=>google());
   form.onsubmit=async event=>{event.preventDefault();if(signing)return;signing=true;busy(form,true);try{const fields=Object.fromEntries(new FormData(form));delete fields.legal_consent;await finish(await api('/web/auth/'+mode,{method:'POST',body:{...fields,legal_acceptance:controls.acceptance()}}));}catch(error){await showError(error);}finally{signing=false;busy(form,false);google();}};
   d.querySelector('#forgot-password').onclick=async()=> (await import('./accounts.js?v=2.13.3')).passwordResetDialog();
   d.querySelector('.switch-auth')?.addEventListener('click',()=>{if(signing)return;mode=mode==='login'?'register':'login';draw();});
   if(!admin)api('/web/config').then(config=>{googleConfig=config;google();}).catch(()=>{});
  };draw();d.addEventListener('close',()=>{if(!done)resolve(false);});
 });
}
let googleTask;
function loadGoogle(){return googleTask??=new Promise((resolve,reject)=>{if(window.google?.accounts)return resolve();const s=document.createElement('script');s.src='https://accounts.google.com/gsi/client';s.async=true;s.onload=resolve;s.onerror=reject;document.head.append(s);});}
export async function requireAccount(){if(!me&&!await authDialog())return false;return requireLegalAcceptance();}

window.addEventListener('offline',()=>toast(OFFLINE_MESSAGE));
window.addEventListener('online',()=>{toast('Koneksi kembali tersedia. Silakan coba lagi.');if(restoreError)restore();});
