async function giftHistory(...args){const {giftHistory}=await import('./wallet.js?v=2.13.3');return giftHistory(...args);}
// Pure API behavior is kept separate from rendering for dependency-free browser/Node checks.
const escapeHTML=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function createPlaybackSignals(makeId=()=>globalThis.crypto.randomUUID?.()||Array.from(globalThis.crypto.getRandomValues(new Uint8Array(16)),n=>n.toString(16).padStart(2,'0')).join('')){
 const playback_id=makeId();return metrics=>({...metrics,playback_id});
}
export const visibilityNames={public:'Publik',friends:'Hanya Teman',private:'Hanya Saya'};
export function visibilityOptions(value='public'){
 return Object.entries(visibilityNames).map(([id,label])=>`<option value="${id}" ${value===id?'selected':''}>${label}</option>`).join('');
}
export function richText(text,mentions=[]){
 const source=String(text??''),known=new Map(mentions.map(m=>[String(m.username).toLowerCase(),String(m.username)]));
 let html='',last=0;
 for(const match of source.matchAll(/([@#])([\p{L}\p{N}_.]+)/gu)){
  const [token,kind,rawName]=match,index=match.index,name=kind==='@'?rawName.replace(/\.+$/,''):rawName,suffix=rawName.slice(name.length);
  if(index&&/[\p{L}\p{N}_@.]/u.test(source[index-1]))continue;
  const mention=kind==='@'&&known.has(name.toLowerCase());
  if(!mention&&kind!=='#')continue;
  html+=escapeHTML(source.slice(last,index));
  html+=mention?`<a class="mention" href="/@${encodeURIComponent(known.get(name.toLowerCase()))}" data-link>${escapeHTML('@'+name)}</a>${escapeHTML(suffix)}`:`<a href="/hashtag/${encodeURIComponent(name)}" data-link>${escapeHTML(token)}</a>`;
  last=index+token.length;
 }
 return html+escapeHTML(source.slice(last));
}
export function createHistoryController(api){
 const state={items:[],selected:new Set(),next:null,nextCursor:null,total:0,
  async load(append=false){
   const path=append&&state.nextCursor?'/users/me/history?cursor='+encodeURIComponent(state.nextCursor)+'&limit=30':'/users/me/history?offset='+(append?(state.next??0):0)+'&limit=30';
   const r=await api(path);
   const merged=append?[...state.items,...r.items]:r.items,seen=new Set();
   state.items=merged.filter(item=>{if(seen.has(item.post.id))return false;seen.add(item.post.id);return true;});state.next=r.next_offset;state.nextCursor=r.next_cursor??null;state.total=r.total;
   if(!append)state.selected.clear();return state;
  },
  async remove(all=false){
   if(!all&&!state.selected.size)return {deleted:0};
   const ids=[...state.selected];
   const result=await api('/users/me/history',{method:'DELETE',body:all?{all:true}:{ids,all:false}});
   state.items=all?[]:state.items.filter(item=>!state.selected.has(item.post.id));
   state.total=Math.max(0,state.total-result.deleted);state.selected.clear();
   // Deletion changes offsets. Re-read before asking for the next page.
   state.next=state.items.length<state.total?state.items.length:null;
   state.nextCursor=null;
   return result;
  }
 };return state;
}
export async function loadCommentTarget(api,postId,commentId){
 try{return await api(`/posts/${encodeURIComponent(postId)}/comments/target/${encodeURIComponent(commentId)}`);}
 catch(error){if(error.status===404)return null;throw error;}
}
export function recordingAvailable(recording,now=Date.now()){
 return Boolean(recording&&['ready','available','completed'].includes(recording.status)&&(!recording.expires_at||Date.parse(recording.expires_at)>now));
}
export async function queueClip(api,roomId,recording,start,end){
 const duration=Number(recording?.duration_seconds);
 if(!recordingAvailable(recording))throw Error('Rekaman tidak tersedia atau sudah kedaluwarsa.');
 if(!Number.isFinite(start)||!Number.isFinite(end)||start<0||end<=start||!Number.isFinite(duration)||end>duration||end-start>600)throw Error('Pilih awal dan akhir di dalam durasi rekaman. Akhir harus lebih besar dari awal. Klip maksimal 10 menit.');
 return api(`/studio/live/${encodeURIComponent(roomId)}/clips`,{method:'POST',body:{start_seconds:start,end_seconds:end}});
}
export async function publishClip(api,clip,caption,visibility){
 if(clip.status!=='ready'||!clip.media_url)throw Error('Tunggu klip selesai diproses.');
 if(!Object.hasOwn(visibilityNames,visibility))throw Error('Pilih privasi video.');
 return api('/posts',{method:'POST',body:{kind:'video',media_url:clip.media_url,thumbnail_url:clip.thumbnail_url||'',caption,visibility}});
}
export function watchClips(api,paint,clock=globalThis,onError=()=>{}){
 let timer=null,stopped=false,loading=false,rerun=false;
 const clear=()=>{if(timer!==null)clock.clearInterval(timer);timer=null;};
 const refresh=async()=>{
  if(stopped)return;if(loading){rerun=true;return;}loading=true;
  try{
   const r=await api('/studio/clips');if(stopped)return;
   paint(r.items);
   if(r.items.some(c=>['queued','processing'].includes(c.status))){if(timer===null)timer=clock.setInterval(()=>refresh().catch(onError),5000);}else clear();
  }finally{loading=false;if(rerun&&!stopped){rerun=false;await refresh();}}
 };
 const stop=()=>{stopped=true;clear();};stop.refresh=refresh;return stop;
}

export async function mountWatchHistory(root,ctx){
 const {api,esc,safeUrl,date,toast,openDialog}=ctx,history=createHistoryController(api);
 let stopped=false,loading=false;const alive=()=>!stopped&&ctx.isCurrent?.()!==false;ctx.register?.(()=>{stopped=true;});
 const draw=()=>{
  if(!alive())return;
  const collectionKey=ctx.historyCollection?.(history)||'';
  root.innerHTML=`<div class="section-top"><div><h1>Riwayat tontonan</h1><p class="muted">${history.total} video ditonton. Menghapus riwayat tidak mengubah tayangan video.</p></div><a class="btn" href="/settings" data-link>Kembali</a></div><div class="history-actions"><label><input type="checkbox" id="history-select-all"> Pilih semua yang dimuat</label><button class="btn danger" id="history-delete" disabled>Hapus pilihan</button><button class="btn" id="history-delete-all" ${history.total?'':'disabled'}>Hapus semua riwayat</button></div><p id="history-status" role="status"></p><div class="history-list">${history.items.map(item=>`<article class="history-row"><input type="checkbox" data-history-id="${esc(item.post.id)}" aria-label="Pilih video ${esc(item.post.caption||'@'+item.post.author.username)}"><a href="/video/${encodeURIComponent(item.post.id)}" data-link${collectionKey?` data-collection="${collectionKey}"`:""}><img src="${esc(safeUrl(item.post.thumbnail_url))}" alt="" loading="lazy"><span><strong>${esc(item.post.caption||'Video @'+item.post.author.username)}</strong><small>@${esc(item.post.author.username)} · ${esc(date(item.watched_at))}</small></span></a></article>`).join('')||'<div class="empty">Belum ada riwayat tontonan.</div>'}</div>${history.next!==null?'<button class="btn load-more" id="history-more">Muat lainnya</button>':''}`;
  const update=()=>{root.querySelector('#history-delete').disabled=!history.selected.size;root.querySelector('#history-delete').textContent='Hapus pilihan'+(history.selected.size?' ('+history.selected.size+')':'');};
  root.querySelectorAll('[data-history-id]').forEach(box=>box.onchange=()=>{if(box.checked)history.selected.add(box.dataset.historyId);else history.selected.delete(box.dataset.historyId);update();});
  root.querySelector('#history-select-all').onchange=e=>{root.querySelectorAll('[data-history-id]').forEach(box=>{box.checked=e.target.checked;if(box.checked)history.selected.add(box.dataset.historyId);else history.selected.delete(box.dataset.historyId);});update();};
  const remove=all=>{
   const d=openDialog(all?'Hapus semua riwayat?':'Hapus riwayat pilihan?','<p>Video tetap tersedia pada profil kreator. Tayangan dan analitik tidak berubah.</p><p class="form-error" role="alert"></p><button class="btn danger" data-confirm>Hapus riwayat</button>');
   d.querySelector('[data-confirm]').onclick=async e=>{e.target.disabled=true;try{const r=await history.remove(all);d.close();toast(r.deleted+' riwayat dihapus');if(alive()){await history.load();draw();}}catch(error){d.querySelector('.form-error').textContent=error.message;e.target.disabled=false;}};
  };
  root.querySelector('#history-delete').onclick=()=>remove(false);
  root.querySelector('#history-delete-all').onclick=()=>remove(true);
  root.querySelector('#history-more')?.addEventListener('click',async e=>{if(loading)return;loading=true;e.target.disabled=true;try{await history.load(true);draw();}catch(error){toast(error.message);e.target.disabled=false;}finally{loading=false;}});
 };
 await history.load();draw();return ()=>{stopped=true;};
}

export async function mountStudio(root,ctx){
 const {api,esc,safeUrl,count,date,toast,openDialog,busy,navigate}=ctx;
 let stopped=false;const alive=()=>!stopped&&ctx.isCurrent?.()!==false;let days=7,videoNext=null,videoItems=[],videoLoading=false,overviewGeneration=0;
 root.innerHTML=`<div class="section-top"><div><h1>Kocehind Studio</h1><p class="muted">Analitik akun, video, dan LIVE Anda.</p></div><a class="btn" href="/settings" data-link>Kembali</a></div><div class="studio-toolbar"><label>Rentang analitik<select id="studio-days"><option value="7">7 hari</option><option value="30">30 hari</option><option value="90">90 hari</option></select></label><button class="btn" id="studio-refresh">Muat ulang</button></div><section id="studio-overview" aria-live="polite"><p>Memuat analitik…</p></section><section class="studio-section"><h2>Video Anda</h2><div id="studio-videos">Memuat video…</div><button class="btn load-more" id="studio-videos-more" hidden>Muat video lainnya</button></section><section class="studio-section"><h2>Riwayat LIVE · 7 hari terakhir</h2><p class="muted">Rekaman hanya dapat diputar oleh Anda dan kedaluwarsa setelah 7 hari. Siaran lama tanpa rekaman tidak dapat diputar. Siaran mendatang direkam jika perekam server sudah dikonfigurasi.</p><div id="studio-live">Memuat riwayat LIVE…</div></section><section class="studio-section"><div class="studio-toolbar"><h2>Klip LIVE</h2><button class="btn" id="studio-clips-refresh">Periksa status klip</button></div><p class="muted">Klip selesai dapat diunduh atau dibagikan sebagai video. Klip antrean diperiksa otomatis setiap 5 detik.</p><div id="studio-clips" aria-live="polite">Memuat klip…</div></section>`;
 const el=id=>root.querySelector('#'+id);
 const metric=(label,value)=>`<article class="studio-metric"><span>${esc(label)}</span><strong>${count(value)}</strong></article>`;
 const fail=(id,error)=>{if(alive())el(id).innerHTML=`<p class="form-error" role="alert">${esc(error.message)}. Gunakan Muat ulang untuk mencoba lagi.</p>`;};
 async function overview(){
  const epoch=++overviewGeneration,r=await api('/studio/overview?days='+days);if(!alive()||epoch!==overviewGeneration)return;
  el('studio-overview').innerHTML=`<p class="muted">Metrik baru dilacak sejak ${esc(date(r.tracking_since))||'belum tersedia'}. Pertumbuhan sebelum tanggal ini belum dilacak.</p><h2>Akun saat ini</h2><div class="studio-metrics">${[['Pengikut',r.account.followers],['Mengikuti',r.account.following],['Video',r.account.posts],['Total tayangan',r.account.views],['Total suka',r.account.likes],['Total komentar',r.account.comments],['Perubahan pengikut ('+r.days+' hari)',r.account.follower_change]].map(v=>metric(...v)).join('')}</div><h2>Aktivitas video · ${r.days} hari</h2><div class="studio-metrics">${[['Tayangan',r.video.views],['Suka',r.video.likes],['Komentar',r.video.comments],['Waktu tonton (menit)',Math.round(r.video.watch_ms/60000)],['Selesai ditonton',r.video.completed]].map(v=>metric(...v)).join('')}</div><h2>Aktivitas LIVE · ${r.days} hari</h2><div class="studio-metrics">${[['Sesi',r.live.sessions],['Penonton',r.live.viewers],['Suka',r.live.likes],['Durasi (menit)',Math.round(r.live.duration_seconds/60)]].map(v=>metric(...v)).join('')}</div><h2>Pertumbuhan harian</h2><div class="studio-table-scroll"><table class="studio-table"><thead><tr><th>Tanggal</th><th>Tayangan</th><th>Suka</th><th>Komentar</th><th>Pengikut</th><th>Pengikut baru</th><th>Tayangan LIVE</th></tr></thead><tbody>${r.daily.map(d=>`<tr><th scope="row">${esc(d.date)}</th>${[d.views,d.likes,d.comments,d.followers,d.new_followers,d.live_views].map(n=>`<td>${n===null||n===undefined?'Belum dilacak':count(n)}</td>`).join('')}</tr>`).join('')||'<tr><td colspan="7">Belum ada metrik harian yang dilacak.</td></tr>'}</tbody></table></div>`;
 }
 async function videos(append=false){
  if(videoLoading)return;videoLoading=true;
  try{const r=await api('/studio/videos?offset='+(append?(videoNext??0):0)+'&limit=30');if(!alive())return;videoItems=append?[...videoItems,...r.items]:r.items;videoNext=r.next_offset;
   el('studio-videos').innerHTML=videoItems.map(p=>`<article class="studio-video"><a href="/video/${encodeURIComponent(p.id)}" data-link><img src="${esc(safeUrl(p.thumbnail_url))}" alt="" loading="lazy"><span><strong>${esc(p.caption||'Video tanpa keterangan')}</strong><small>${esc(visibilityNames[p.visibility]||'Publik')} · ${esc(date(p.created_at))}</small></span></a><p>${count(p.metrics.views)} tayangan · ${count(p.metrics.likes)} suka · ${count(p.metrics.comments)} komentar<br>${count(Math.round(p.metrics.watch_ms/60000))} menit ditonton · ${count(p.metrics.completed)} selesai</p></article>`).join('')||'<div class="empty">Belum ada video.</div>';el('studio-videos-more').hidden=videoNext===null;
  }finally{videoLoading=false;}
 }
 const clipWatcher=watchClips(api,clips=>{
  if(!alive())return;
  el('studio-clips').innerHTML=clips.map(c=>`<article class="studio-clip"><div><strong>${esc({queued:'Dalam antrean',processing:'Sedang diproses',ready:'Siap dibagikan',failed:'Gagal diproses',expired:'Kedaluwarsa'}[c.status]||c.status)}</strong><p>${c.start_seconds}–${c.end_seconds} detik${c.error?' · '+esc(c.error):''}</p></div>${c.status==='ready'?`<div class="buttons"><a class="btn" href="/api/studio/clips/${encodeURIComponent(c.id)}/download" download>Unduh klip</a><button class="btn primary" data-publish-clip="${esc(c.id)}">Bagikan video</button></div>`:''}</article>`).join('')||'<p class="muted">Belum ada klip LIVE.</p>';
  el('studio-clips').querySelectorAll('[data-publish-clip]').forEach(button=>button.onclick=()=>{
   const clip=clips.find(c=>c.id===button.dataset.publishClip),d=openDialog('Bagikan klip LIVE',`<form><label>Keterangan<textarea name="caption" maxlength="2000"></textarea></label><label>Siapa yang dapat menonton?<select name="visibility">${visibilityOptions()}</select></label><p class="form-error" role="alert"></p><button class="btn primary" type="submit">Bagikan video</button></form>`),form=d.querySelector('form');
   form.onsubmit=async event=>{event.preventDefault();busy(form,true);try{const data=new FormData(form),p=await publishClip(api,clip,data.get('caption'),data.get('visibility'));d.close();toast('Klip berhasil dibagikan');navigate('/video/'+p.id);}catch(error){form.querySelector('.form-error').textContent=error.message;}finally{busy(form,false);}};
  });
 },globalThis,error=>{if(alive())toast('Status klip belum dapat diperiksa: '+error.message);});
 async function live(){
  const r=await api('/studio/live?days=7');if(!alive())return;
  el('studio-live').innerHTML=r.items.map(l=>{
   const recording=l.recording,available=recordingAvailable(recording)&&recording.playback_url;
   return `<article class="studio-live-recording"><h3>${esc(l.title)}</h3><div class="buttons"><button class="btn" data-gift-history="${esc(l.id)}">Riwayat gift</button>${l.recording?.download_url?`<a class="btn" href="${esc(safeUrl(l.recording.download_url))}" download>Unduh rekaman dengan gift</a>`:""}</div><p>${l.gift_count||0} gift · ${l.gift_coins||0} koin · Rp ${l.gift_income||0}</p><p>${esc(date(l.started_at))} · ${esc(l.status)} · ${count(l.views)} penonton · ${count(l.peak_viewers)} puncak · ${count(l.likes)} suka · ${count(Math.round(l.duration_seconds/60))} menit</p>${available?`<video controls playsinline preload="none" src="${esc(safeUrl(recording.playback_url))}" aria-label="Rekaman privat ${esc(l.title)}"></video><p class="muted">Rekaman privat · kedaluwarsa ${esc(date(recording.expires_at))}</p><form class="studio-clip-form" data-clip-room="${esc(l.id)}"><p class="muted">Pilih rentang maksimal 10 menit.</p><label>Awal (detik)<input name="start" type="number" min="0" max="${Number(recording.duration_seconds)}" step="0.1" value="0" required></label><label>Akhir (detik)<input name="end" type="number" min="0.1" max="${Number(recording.duration_seconds)}" step="0.1" value="${Math.min(30,Number(recording.duration_seconds))}" required></label><button class="btn" type="submit">Buat klip</button><p class="form-error" role="alert"></p></form>`:`<p class="muted">${recording&&['queued','recording','processing','pending','starting','finalizing','processing_gifts','gift_failed'].includes(recording.status)?'Rekaman sedang disiapkan. Muat ulang untuk memeriksa status.':recording?.status==='expired'||(recording?.expires_at&&Date.parse(recording.expires_at)<=Date.now())?'Rekaman telah kedaluwarsa.':'Rekaman tidak tersedia untuk siaran ini.'}</p>`}</article>`;
  }).join('')||'<p class="muted">Belum ada LIVE dalam 7 hari terakhir.</p>';
  el('studio-live').querySelectorAll('[data-gift-history]').forEach(b=>b.onclick=()=>giftHistory(b.dataset.giftHistory).catch(e=>toast(e.message)));
  el('studio-live').querySelectorAll('[data-clip-room]').forEach(form=>form.onsubmit=async event=>{event.preventDefault();busy(form,true);const error=form.querySelector('.form-error');error.textContent='';try{const data=new FormData(form),room=r.items.find(l=>l.id===form.dataset.clipRoom);await queueClip(api,room.id,room.recording,Number(data.get('start')),Number(data.get('end')));toast('Klip masuk antrean pemrosesan');await clipWatcher.refresh();}catch(err){error.textContent=err.message;}finally{busy(form,false);}});
 }
 async function refresh(){await Promise.allSettled([overview().catch(e=>fail('studio-overview',e)),videos().catch(e=>fail('studio-videos',e)),live().catch(e=>fail('studio-live',e)),clipWatcher.refresh().catch(e=>fail('studio-clips',e))]);}
 el('studio-days').onchange=e=>{days=Number(e.target.value);overview().catch(error=>fail('studio-overview',error));};
 el('studio-refresh').onclick=async e=>{e.target.disabled=true;try{await refresh();}finally{e.target.disabled=false;}};
 el('studio-clips-refresh').onclick=()=>clipWatcher.refresh().catch(e=>fail('studio-clips',e));
 el('studio-videos-more').onclick=async e=>{e.target.disabled=true;try{await videos(true);}catch(error){toast(error.message);}finally{e.target.disabled=false;}};
 const cleanup=()=>{if(stopped)return;stopped=true;clipWatcher();root.querySelectorAll('video').forEach(v=>v.pause());};ctx.register?.(cleanup);await refresh();return cleanup;
}
