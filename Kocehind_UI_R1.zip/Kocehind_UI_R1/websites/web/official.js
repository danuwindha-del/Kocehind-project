import {badge,api,esc,date,toast} from '/shared/api.js?v=2.13.3';
import {officialBlocksHTML,officialCategories,bindOfficialMedia} from '/shared/official-content.js?v=2.13.3';
export async function mountOfficial(root,activityId,navigate,isCurrent=()=>true,register=()=>{}){
 const go=id=>navigate('/inbox?tab=official'+(id?'&activity='+encodeURIComponent(id):''));
 if(activityId){
  const item=await api('/official/activities/'+encodeURIComponent(activityId));if(!isCurrent())return;
  root.innerHTML=`<article class="official-detail"><button class="text-btn" data-back>← Dari Kocehind</button><div class="official-byline"><span class="avatar letter">K</span><div><strong>Kocehind ${badge({is_verified:true})}</strong><small>${esc(officialCategories[item.category]||item.category)} · ${esc(date(item.published_at))}</small></div></div><h1>${esc(item.title)}</h1><p class="muted">${esc(item.summary)}</p><div class="official-blocks">${officialBlocksHTML(item.blocks)}</div></article>`;
  const cleanup=bindOfficialMedia(root,{isCurrent,refresh:()=>api('/official/activities/'+encodeURIComponent(activityId))});register(cleanup);
  root.querySelector('[data-back]').onclick=()=>go();
  await api('/official/activities/'+encodeURIComponent(item.id)+'/read',{method:'POST'});
  if(isCurrent())window.dispatchEvent(new Event('officialread'));return cleanup;
 }
 let items=[],next=0,loading=false;
 async function load(){
  if(loading||next===null)return;loading=true;
  try{
   const result=await api('/official/activities?offset='+next+'&limit=30');if(!isCurrent())return;
   const seen=new Set(items.map(r=>r.id));items.push(...result.items.filter(r=>!seen.has(r.id)));next=result.next_offset;
   root.innerHTML=`<div class="official-intro"><span class="avatar letter">K</span><div><h2>Dari Kocehind</h2><p class="muted">Promosi, pengumuman, dan informasi resmi. ${result.unread?result.unread+' belum dibaca.':''}</p></div></div><div class="activity-list">${items.map(item=>`<button class="activity official-item" data-official="${esc(item.id)}"><span class="official-category">${esc(officialCategories[item.category]||item.category)}</span><span class="activity-content"><strong>${esc(item.title)}</strong><p>${esc(item.summary)}</p><small>${esc(date(item.published_at))}</small></span>${!item.read?'<span class="unread" aria-label="Belum dibaca"></span>':''}</button>`).join('')||'<p class="empty">Belum ada kabar dari Kocehind.</p>'}</div>${next!==null?'<button class="btn load-more" data-more>Muat lainnya</button>':''}`;
   root.querySelectorAll('[data-official]').forEach(b=>b.onclick=()=>go(b.dataset.official));
   root.querySelector('[data-more]')?.addEventListener('click',()=>load().catch(e=>toast(e.message)));
  }finally{loading=false;}
 }
 await load();
}
