import {api,esc,badge} from '/shared/api.js?v=2.13.3';
import {renderLiveStage} from './live-stage.js?v=2.13.3';
let claimTail=Promise.resolve();
function claim(fn){const result=claimTail.then(fn);claimTail=result.catch(()=>{});return result;}
export function previewHTML(r){return `<article class="live-preview-card" data-live="${esc(r.id)}"><div class="live-preview-media"><div class="live-preview-video live-stage"></div></div><a class="live-preview-open" href="/live/${encodeURIComponent(r.id)}" data-link aria-label="Tonton LIVE @${esc(r.host.username)}"><div class="live-preview-caption"><span class="live-tag">LIVE · ${r.viewers||0} menonton</span><h2>@${esc(r.host.username)}${badge(r.host)}</h2><p>${esc(r.title)}</p><strong>Ketuk untuk masuk LIVE →</strong><small data-preview-status>Pratinjau tanpa suara</small></div></a></article>`;}
export function bindPreviews(root,rows){
 const byId=new Map(rows.map(r=>[r.id,r])),clean=[];
 root.querySelectorAll('.live-preview-card:not([data-preview-bound])').forEach(card=>{
  card.dataset.previewBound='1';const row=byId.get(card.dataset.live);if(!row)return;
  let room=null,lease=null,timer=null,visible=false,disposed=false,busy=false,resync=false,version=0,watched=0,tickBusy=false,info={...row};
  const base='/live/rooms/'+row.id,stage=card.querySelector('.live-preview-video');
  const report=()=>watched?api(base+'/signal',{method:'POST',body:{watch_ms:Math.min(3600000,Math.round(watched))}}).catch(()=>{}):Promise.resolve();
  const desired=()=>visible&&!document.hidden&&!disposed;
  const status=text=>{if(!disposed)card.querySelector('[data-preview-status]').textContent=text;};
  function draw(){
   if(disposed)return;
   const members=[...(info.members||[{...info.host,role:'host'}])];
   for(const p of room?.remoteParticipants?.values()||[]){
    if(members.some(m=>m.id===p.identity))continue;
    if(![...p.videoTrackPublications.values()].some(pub=>pub.track&&!pub.isMuted))continue;
    try{const m=JSON.parse(p.metadata||'{}');if(['host','speaker'].includes(m.role))members.push({...m,id:p.identity,name:p.name||m.username});}catch{}
   }
   card.classList.toggle('together',Boolean(info.together));
   renderLiveStage(stage,{...info,members},room);
  }
  async function stop(){
   version++;clearInterval(timer);timer=null;const r=room,id=lease;room=lease=null;
   report();if(r)await r.disconnect().catch(()=>{});
   if(id)await api(base+'/preview/leave',{method:'POST',body:{lease_id:id}}).catch(()=>{});
   if(!disposed){stage.replaceChildren();draw();}
  }
  async function start(){
   if(!desired())return stop();if(busy){resync=true;return;}if(room)return;
   busy=true;resync=false;const ticket=++version;
   try{
    const sdk=await import('/shared/livekit.js?v=2.13.3');
    if(!desired()||ticket!==version)return;
    const grant=await claim(async()=>{
     if(!desired()||ticket!==version)return null;
     const g=await api(base+'/preview',{method:'POST',body:{}});
     if(!desired()||ticket!==version){await api(base+'/preview/leave',{method:'POST',body:{lease_id:g.lease_id}}).catch(()=>{});return null;}return g;
    });
    if(!grant||!desired()||ticket!==version)return;
    lease=grant.lease_id;info={...row,...grant.room};
    const r=new sdk.Room({adaptiveStream:true,dynacast:true});room=r;
    const subscribe=()=>{
     if(disposed||room!==r)return;
     for(const p of r.remoteParticipants.values())for(const pub of p.videoTrackPublications.values())if(!pub.isSubscribed)pub.setSubscribed(true);
     draw();
    };
    for(const event of [sdk.RoomEvent.ParticipantConnected,sdk.RoomEvent.ParticipantDisconnected,sdk.RoomEvent.TrackPublished,sdk.RoomEvent.TrackSubscribed,sdk.RoomEvent.TrackUnsubscribed,sdk.RoomEvent.TrackMuted,sdk.RoomEvent.TrackUnmuted])if(event)r.on(event,subscribe);
    // Deliberately no audio subscriptions, camera or microphone permission calls.
    await r.connect(grant.url,grant.token,{autoSubscribe:false});
    if(!desired()||ticket!==version){await r.disconnect();return;}
    subscribe();status(info.mode==='audio'?'LIVE obrolan suara':'Pratinjau tanpa suara');
    let ticks=0,last=performance.now();
    timer=setInterval(async()=>{
     if(!desired()||room!==r||tickBusy)return;tickBusy=true;
     try{
      const now=performance.now(),hasVideo=[...stage.querySelectorAll('video')].some(v=>!v.paused&&v.readyState>=2);
      if(hasVideo||info.mode==='audio')watched+=Math.min(1500,now-last);last=now;subscribe();
      if(++ticks%5===0){const update=await api(base+'/preview',{method:'POST',body:{lease_id:lease}});if(ticket!==version||room!==r)return;info={...row,...update.room};draw();await report();}
     }catch(error){status(navigator.onLine===false||error?.status===0?'Anda sedang Offline periksa jaringan Anda':'Siaran selesai atau koneksi terputus');await stop();}
     finally{tickBusy=false;}
    },1000);
   }catch(error){status(navigator.onLine===false||error?.status===0?'Anda sedang Offline periksa jaringan Anda':'Pratinjau belum tersambung · ketuk untuk masuk');await stop();}
   finally{busy=false;if(resync&&desired()&&!room)start();}
  }
  draw();const resize=new ResizeObserver(draw);resize.observe(stage);
  const observer=new IntersectionObserver(entries=>{for(const e of entries){visible=e.isIntersecting&&e.intersectionRatio>=.65;if(desired())start();else stop();}},{root:root.classList.contains('feed-scroll')?root:null,threshold:[0,.65]});
  observer.observe(card);
  const hide=()=>desired()?start():stop();document.addEventListener('visibilitychange',hide);
  card.querySelector('a').addEventListener('click',()=>{visible=false;stop();api(base+'/signal',{method:'POST',body:{joined:true}}).catch(()=>{});});
  clean.push(()=>{disposed=true;observer.disconnect();resize.disconnect();document.removeEventListener('visibilitychange',hide);stop();});
 });
 return ()=>clean.forEach(fn=>fn());
}
