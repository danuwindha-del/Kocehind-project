let registration,signature='',session=crypto.randomUUID();
async function worker(){
 if(!('serviceWorker' in navigator))return null;
 registration??=navigator.serviceWorker.register('/video-session-worker.js?v=2.13.3',{scope:'/'});
 const registered=await registration;await navigator.serviceWorker.ready;
 return navigator.serviceWorker.controller||registered.active;
}
export async function prepareSessionVideos(){
 const w=await worker();if(!w)return;
 w.postMessage({type:'init',session});
 if(!navigator.serviceWorker.controller)await new Promise(resolve=>{
  const done=()=>{clearTimeout(timer);navigator.serviceWorker.removeEventListener('controllerchange',done);resolve();};
  const timer=setTimeout(done,1500);navigator.serviceWorker.addEventListener('controllerchange',done,{once:true});
 });
}
export function warmNextVideos(card){
 const urls=[];let next=card.nextElementSibling;
 while(next&&urls.length<3){const v=next.querySelector('video');if(v)urls.push(v.dataset.source||v.currentSrc||v.src);next=next.nextElementSibling;}
 const key=urls.join('|');if(key===signature)return;signature=key;
 worker().then(w=>w?.postMessage({type:'warm',session,urls})).catch(()=>{});
}
export function clearSessionVideos(){signature='';worker().then(w=>w?.postMessage({type:'clear'})).catch(()=>{});session=crypto.randomUUID();}
window.addEventListener('pagehide',clearSessionVideos);
let owner;
window.addEventListener('sessionchange',event=>{const next=event.detail?.id||null;if(owner!==undefined&&owner!==next)clearSessionVideos();owner=next;});
