import {documentSections} from './legal-content.js?v=2.13.3';
const title=document.querySelector('#legal-title'),meta=document.querySelector('#legal-meta'),content=document.querySelector('#legal-content'),toc=document.querySelector('#toc'),article=document.querySelector('#document'),retry=document.querySelector('#legal-retry');
const kind=document.body.dataset.document;
async function load(){article.setAttribute('aria-busy','true');retry.hidden=true;meta.textContent='Mengambil dokumen terbaru…';content.replaceChildren();toc.replaceChildren();try{
 const response=await fetch('/api/legal/documents/'+kind,{cache:'no-store',credentials:'omit'});if(!response.ok)throw new Error('Dokumen belum dapat diambil');
 const doc=await response.json();if(!doc.content||!doc.version)throw new Error('Dokumen belum tersedia');title.textContent=doc.title;document.title=doc.title+' | Kocehind';
 const timestamp=new Date(doc.updated_at);meta.textContent='Versi '+doc.version+' · Diperbarui '+(Number.isNaN(timestamp.getTime())?doc.updated_at:new Intl.DateTimeFormat('id-ID',{dateStyle:'long',timeStyle:'short',timeZone:'Asia/Jakarta'}).format(timestamp)+' WIB');
 for(const [i,section]of documentSections(doc.content).entries()){const node=document.createElement(section.heading?'h2':'p');node.textContent=section.text;if(section.heading){node.id='bagian-'+i;const link=document.createElement('a');link.href='#'+node.id;link.textContent=section.text;toc.append(link);}content.append(node);}
 }catch{meta.textContent='Dokumen terbaru belum dapat dimuat. Periksa koneksi lalu coba lagi sebelum menyetujui kebijakan.';retry.hidden=false;}finally{article.setAttribute('aria-busy','false');}}
retry.addEventListener('click',load);load();
