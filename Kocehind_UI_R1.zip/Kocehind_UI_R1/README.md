# Kocehind UI Studio R1

Pembaruan lapisan presentasi di atas source 2.13.3-kipay + runtime KeyFix R1.
Ini bukan penggantian backend dan bukan penambahan fitur rekomendasi baru.

## Cakupan
- Web sosial: navigasi desktop/mobile, feed, profil, grid, form, komentar, chat,
  aktivitas, dompet dan panel Studio melalui stylesheet bersama.
- Situs publik: beranda, tentang, bantuan, komunitas, pembayaran, kontak, legal.
- Admin: tema, navigasi, kontrol, tabel dan panel melalui stylesheet bersama.
- Flutter: token warna/kontras, tipografi aplikasi, tab/list/form serta target
  sentuh dan label aksesibilitas tombol unggah. Layar khusus tetap memakai
  implementasi dan geometri sebelumnya. Ini fondasi desain lintas layar,
  bukan klaim setiap layar telah dirancang ulang secara individual.
- Tidak mengubah backend/app, endpoint, database, env atau aturan pembayaran.

## Instalasi web pada VPS existing
Upload ZIP dari workspace, kemudian:

```sh
cd /root
unzip Kocehind_UI_R1.zip
cd Kocehind_UI_R1
sha256sum -c SHA256SUMS.txt
sudo python3 UPDATE_UI_WEB.py --check
sudo python3 UPDATE_UI_WEB.py
curl -fsS http://127.0.0.1:8000/health
curl -fsSI https://web.kocehind.web.id/shared/studio-design.css?v=ui-r1
```

Memerlukan situs existing /var/www/kocehind-sites/current berupa symlink ke rilis
berisi web/main/admin/shared dan Nginx yang sudah melayaninya. Jika layout berbeda,
installer berhenti; jangan paksa. Nginx config, TLS dan APK publik tidak disentuh.
API tidak direstart; LIVE tidak dihentikan oleh updater ini. Uji di staging dahulu.
Tutup/buka ulang tab atau hard refresh agar HTML mengambil CSS baru.
Updater mempertahankan file custom existing dan rilis lama. Jangan menghapusnya.
Rollback memakai command yang dicetak updater:

```sh
sudo python3 UPDATE_UI_WEB.py --rollback /var/www/kocehind-sites/rollback-ui-r1-TIMESTAMP.json
```

## Build Android: profil key lama sudah diimpor
Di VPS builder yang sebelumnya memakai paket v11 dan ~/.kocehind-portable:

```sh
cd /root/Kocehind_UI_R1
sha256sum -c SHA256SUMS.txt
python3 PINDAH_KEY_LAMA.py build --check-only
bash BUILD_VPS_BARU.sh
```

Tanpa --build-number builder memilih nomor di atas nomor lokal/profil yang
terdeteksi. Bila Play Console memiliki nomor lebih tinggi, gunakan:
`bash BUILD_VPS_BARU.sh --build-number NOMOR_YANG_LEBIH_TINGGI`.
Jangan gunakan nomor yang sudah terunggah ke Play.
Versi nama tetap 2.13.3, revisi UI dibedakan nomor build.
Untuk builder baru, gunakan backup key terenkripsi milik Anda sesuai panduan v11;
jangan membuat keystore pengganti. Firebase/Google diambil dari profil/build lama,
bukan credential dummy dalam paket. Tidak ada build-defaults.json berisi key.
APK/AAB hasil build ada di output ~/.kocehind-builds yang dicetak builder.
Tidak ada APK/AAB bertanda tangan dalam paket ini.

Source penuh: SOURCE_LENGKAP_v2.13.3.zip. Untuk pengembangan ekstrak ke direktori
baru. Jangan mengekstrak source ke runtime API produksi sebagai cara update UI.

## Verifikasi aktual
- Flutter analyze: No issues found.
- Flutter tests: 118 passed.
- Web suite penuh: 137 passed, 13 failed; nama 13 kegagalan sama dengan baseline
  sebelum UI berubah. Tidak ada kegagalan baru. Suite penuh belum hijau.
- Suite checkout Kipay/Tripay, wallet/admin, profil, summary, canvas/loves/legal
  terpilih: 23 passed.
- Installer: 3 tes filesystem terisolasi lulus (install+rollback, tamper, preflight).
- Preview browser 390x844 dan 1440x900: feed/explore/profil/settings/publik/admin
  yang diperiksa tidak overflow horizontal; API menggunakan mock.
- Backend/app identik dengan baseline git lokal (sudah memuat KeyFix R1).

Belum diverifikasi: deploy VPS asli, APK/AAB release, perangkat Android fisik,
SFU LIVE nyata, pembayaran merchant, audit screen reader dan WCAG menyeluruh.
Screenshot preview memakai data sintetis, bukan hasil penggunaan produksi.
Tidak ada jaminan kesetaraan kualitas TikTok atau peningkatan retensi terukur.

Berkas utama: websites/shared/studio-design.css, websites/main/public-design.css,
flutter/lib/main.dart, flutter/lib/widgets/ui.dart, UPDATE_UI_WEB.py.
