# Pengujian Kocehind 2.18.0+47

## Hasil verifikasi

| Lingkup | Hasil |
|---|---:|
| Flutter analyze | Tidak ada masalah |
| Flutter, seluruh tes aplikasi | 155 lulus |
| Web, seluruh suite termasuk Chromium | 209 lulus |
| Backend, regresi terpilih | 110 lulus |
| Alat paket update/build | 44 lulus |

## Cakupan

- Sampul: pengambilan frame dari video WebM sungguhan di Chromium, pilihan waktu, pengiriman JPEG, impor galeri, pemisahan `cover_url` dari thumbnail otomatis, kepemilikan gambar, moderasi sampul, dan sampul saat video memakai sound.
- Android: format/static analysis seluruh aplikasi, 155 tes, pemetaan waktu cuplikan ke channel lokal, generasi bridge Kotlin dua kali pada runner existing tanpa mengganti plugin lain atau referensi signing. Pengambilan frame Android fisik belum diuji.
- Profil: header tampil sebelum respons yang ditunda, request bersamaan digabung, satu endpoint identitas/video, cache terpisah antar akun/revisi privasi, pagination, blokir dan pembatasan video private.
- Pesan: tepat sebelum/saat batas 24 jam, satu permintaan baru, pesan kedua masih ditahan, serta blokir akun.
- Email: email lama tidak berubah sebelum OTP, kode salah/expired/replay/akun berbeda ditolak, cooldown resend, pengecekan duplikasi saat request dan konfirmasi, pembuktian mailbox lama untuk akun Google tanpa password, tautan Google tetap bisa login, sesi lama dicabut dan cookie web HttpOnly diperbarui tanpa memaparkan JWT.
- Migrasi: dijalankan dua kali dari database lama; akun existing tetap utuh. Template dua email OTP baru memakai escaping dan tautan pengaturan.
- Regresi: aktivitas/notifikasi, privasi, sesi, LIVE, push diagnostics, media lambat dan preflight deployment. Uji beban mempertahankan 24 transfer serentak dengan pool dua koneksi. Pemeriksaan sesi realtime memakai satu sesi DB singkat.
- Paket: checksum source dan seluruh web, struktur arsip, alat update/build, Python runtime, diagnosis, serta validasi signing existing.

## Menjalankan ulang

```bash
# Dari root source, dengan dependency backend terpasang:
python -m pytest backend/tests/test_v2180.py backend/tests/test_video_cover_bridge_v2180.py backend/tests/test_social.py backend/tests/test_email_sessions_v2121.py backend/tests/test_v212.py backend/tests/test_privacy_v27.py backend/tests/test_guest_read_v2125.py backend/tests/test_v2171_gallery_time.py backend/tests/test_v2171_push.py backend/tests/test_runtime_live_stability.py backend/tests/test_backend_stability.py backend/tests/test_deploy_preflight_r2.py -q
npm ci
npm run test:web
cd flutter
flutter pub get
flutter analyze
flutter test
```

Suite web memerlukan browser Chromium Playwright. Jika memakai Chromium yang telah disediakan, gunakan bootstrap `tools/playwright-runtime.mjs` serta `KOCEHIND_CHROMIUM_EXECUTABLE` seperti workflow existing.

## Batas hasil

Paket ini belum dideploy ke VPS, belum menghasilkan APK/AAB signed, dan belum diuji pada Android fisik. Pengiriman email produksi, OTP ke mailbox nyata, FCM sampai bilah HP, kondisi jaringan pengguna, dan latensi server produksi belum diverifikasi. Respons profil pertama tetap memerlukan jaringan. Integrasi SMTP/Mailjet, Firebase, signing key dan konfigurasi VPS existing dipertahankan.
