# Kocehind 2.18.0 — Sampul video, profil cepat, permintaan pesan dan email

Android **2.18.0+47**. Baca **PANDUAN_UPDATE_v2.18.0.md** dan **LAPORAN_PENGUJIAN_v2.18.0.md**.

- Ubah sampul sebelum unggah melalui strip cuplikan video atau impor gambar dari galeri. Pilihan sampul ikut tersimpan di draf aplikasi.
- Profil mengambil identitas dan 24 video awal dalam satu permintaan. Header yang sudah dikenal tampil segera; daftar video diperiksa ulang terhadap privasi.
- Permintaan pesan yang ditolak dapat diajukan ulang setelah tepat 24 jam. Tetap satu pesan sampai permintaan diterima.
- Pengaturan memiliki Ubah email. Email baru menerima kode enam digit; email lama tetap aktif sampai berhasil diverifikasi.

Update backend/web dahulu dengan `python3 UPDATE_BACKEND_WEB.py --check`, lalu `python3 UPDATE_BACKEND_WEB.py`. Bangun aplikasi dengan key lama melalui `python3 PINDAH_KEY_LAMA.py build --check-only`, lalu `python3 PINDAH_KEY_LAMA.py build`.

Paket berisi source dan alat update/build. Belum dipasang ke VPS dan tidak berisi APK/AAB bertanda tangan.
