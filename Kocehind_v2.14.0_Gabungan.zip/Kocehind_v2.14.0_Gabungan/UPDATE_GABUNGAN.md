# Update source gabungan Kocehind 2.14.0

## Isi penggabungan

Source lengkap dari unggahan terbaru 2.14.0 digabung dengan:

1. Play Recovery R1: receipt dikirim ke antrean server sebelum verifikasi Google; retry worker, kredit satu kali, konsumsi sesudah kredit dan penanganan refund.
2. Pemulihan Flutter: gangguan secure storage tidak menghentikan pengiriman receipt ke server; timer retry tetap hidup; pesan kesalahan membedakan pembelian milik akun lain dari gangguan izin layanan.
3. Katalog tujuh paket tanpa bonus; ID lama tetap dikenali untuk transaksi historis.
4. Alat diagnosis Google Play umum dan detail yang sebelumnya diberikan terpisah.
5. Panduan produk baru dan builder dengan dasar build 40. Versi API tetap 2.14.0.

Tampilan halaman, komponen UI, web dan aset identik dengan unggahan terbaru. Penggabungan ini tidak memilih ulang konfigurasi VPS atau mengubah tarif pendapatan host.

## Produk pada Play Console

| Product ID | Total koin satu unit | Harga target Indonesia |
| --- | ---: | ---: |
| `kocehind_coin_25` | 25 | Rp1.000 |
| `kocehind_coin_75` | 75 | Rp3.000 |
| `kocehind_coin_160` | 160 | Rp6.000 |
| `kocehind_coin_350` | 350 | Rp12.000 |
| `kocehind_coin_750` | 750 | Rp25.000 |
| `kocehind_coin_1600` | 1.600 | Rp50.000 |
| `kocehind_coin_3500` | 3.500 | Rp100.000 |

Semua jumlah sudah final, tanpa bonus tambahan. Produk konsumabel dapat dibeli ulang. Buat dan aktifkan tujuh ID tersebut, beserta opsi pembelian dan ketersediaan negara, pada aplikasi id.web.kocehind. Harga dan batas harga mengikuti Play Console; aplikasi menampilkan harga dari Google Play. Backend tidak membuat produk/harga di Console.

Produk lama kocehind_coin_100/500/1000/5000 tetap dikenali untuk verifikasi, pemulihan dan refund, tanpa ditawarkan di katalog baru. Jangan menghapus pemetaan historis pada backend.

## Update backend dan web existing

Selesaikan LIVE terlebih dahulu. Upload ZIP gabungan ke /root VPS backend, lalu:

```bash
cd /root
unzip -o Kocehind_v2.14.0_Gabungan.zip
cd /root/Kocehind_v2.14.0_Gabungan
sha256sum -c SHA256SUMS.txt
/opt/kocehind/venv/bin/python UPDATE_BACKEND_WEB.py --check
/opt/kocehind/venv/bin/python UPDATE_BACKEND_WEB.py
systemctl is-active kocehind-api kocehind-play
/opt/kocehind/venv/bin/python DIAGNOSA_INTEGRASI.py
```

Ini updater VPS existing dengan Python backend 3.11+, bukan instalasi VPS kosong. Database/media dicadangkan oleh alur installer, migrasi menambah struktur yang diperlukan, dan konfigurasi backend.env beserta saldo/pesanan existing dipertahankan. Gunakan interpreter virtualenv tersebut; jangan mengganti Python sistem Ubuntu. Jangan mengganti JWT_SECRET: receipt antrean dan email memakai kunci yang diturunkan darinya.

Jika Google Play sebelumnya sudah berhasil, pertahankan credential dan akses yang aktif; tidak perlu menjalankan SETUP_GOOGLE_PLAY.py lagi. Periksa status dua service di atas. Apabila worker gagal hidup, gunakan diagnosis di bawah sebelum mengubah credential.

Untuk VPS yang sudah memasang Recovery R1 dan hanya perlu mengganti katalog, gunakan jalur kecil berikut sebagai pengganti update backend/web lengkap:

```bash
cd /root/Kocehind_v2.14.0_Gabungan/PERBAIKAN_BACKEND/Kocehind_Backend_Paket_Koin
/opt/kocehind/venv/bin/python UPDATE_PAKET_KOIN.py --check
/opt/kocehind/venv/bin/python UPDATE_PAKET_KOIN.py
```

Jalur kecil hanya memperbarui modul katalog runtime yang dikenal, dengan backup, preflight sebagai pengguna service dan rollback kode. Tidak perlu menjalankan TERAPKAN_SOURCE.py pada paket gabungan ini: perubahan sudah menyatu dalam SOURCE_LENGKAP_v2.14.0.zip.

## Build APK dan AAB

Jalankan di VPS builder Android yang sudah memiliki SDK, Flutter 3.38.10/Dart 3.10 dan key lama. BUILD_VPS_BARU.sh khusus builder Android.

```bash
cd /root/Kocehind_v2.14.0_Gabungan
python3 PINDAH_KEY_LAMA.py build --check-only
bash BUILD_VPS_BARU.sh
```

Builder menggunakan source gabungan yang disertakan, runner/key lama, serta profil signing existing. Build dasar 40, dan otomatis lebih tinggi bila riwayat lokal memerlukannya. Jika Play Console sudah memakai nomor yang lebih tinggi dari yang terdeteksi lokal, berikan nomor baru secara eksplisit melalui `python3 PINDAH_KEY_LAMA.py build --build-number NOMOR_BARU`.

Katalog baru dapat dipakai APK 2.14.0 yang sudah ada dengan menekan **Muat paket**, tanpa build ulang. Build APK baru diperlukan untuk memasukkan perbaikan Flutter pemulihan pembelian dari paket gabungan ini. Source bukan APK/AAB yang sudah ditandatangani.

Untuk mengekstrak source secara manual:

```bash
cd /root/Kocehind_v2.14.0_Gabungan
unzip -o SOURCE_LENGKAP_v2.14.0.zip -d /root/kocehind-source-gabungan
```

Folder source menjadi /root/kocehind-source-gabungan/kocehind_realtime_v2. Saat build berikutnya, gunakan paket/source gabungan ini agar source lama tidak mengembalikan katalog sebelumnya.

## Diagnosis bila pembelian tertunda

Di aplikasi akun pembeli, tekan Periksa pembelian agar receipt yang masih di perangkat dikirim ke server. Kemudian bila perlu:

```bash
cd /root/Kocehind_v2.14.0_Gabungan
/opt/kocehind/venv/bin/python DIAGNOSA_GOOGLE_PLAY.py --google
/opt/kocehind/venv/bin/python CEK_GOOGLE_PLAY_DETAIL.py
```

Pemeriksaan detail bersifat baca saja, tidak mengkredit koin atau mengonsumsi pembelian. Recovery manual `DIAGNOSA_GOOGLE_PLAY.py --google --retry` hanya untuk menjadwalkan ulang antrean yang tertunda. Pembelian normal tetap diverifikasi dan diproses worker otomatis setelah Google menyatakan PURCHASED; pembayaran pending belum menambah koin.

## Pengaturan pendapatan host

Katalog tanpa bonus mempertahankan tarif pendapatan host yang aktif. Periksa Admin > Gift dan penarikan > Pengaturan pendapatan. Jika tarif masih Rp50/koin, 3.500 koin yang dijadikan gift mencatat Rp175.000 pendapatan host, sedangkan harga target belinya Rp100.000, sebelum biaya Google Play. Paket ini tidak mengubah tarif tersebut atau pendapatan yang sudah dicatat. Paket koin web Kipay juga tetap mengikuti pengaturan admin.

## Batas verifikasi

Lihat LAPORAN_PENGUJIAN_GABUNGAN.md di paket luar. Paket sudah diperiksa secara lokal, tetapi belum dipasang pada VPS Anda. Tidak ada build Flutter, transaksi Google nyata atau pembuatan produk Play Console yang dilakukan dalam penyusunan paket ini.
