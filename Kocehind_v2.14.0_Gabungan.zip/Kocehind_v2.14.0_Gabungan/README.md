# Kocehind 2.14.0 — source lengkap gabungan perbaikan

Paket ini berasal dari unggahan terbaru Kocehind_v2.14.0 Anda, digabung dengan perbaikan pembelian Google Play Recovery R1 dan tujuh paket koin tanpa bonus. Backend, Flutter, web sosial, landing page, admin, aset dan alat build disertakan. UI Studio R1 dan aset dari unggahan terbaru dipertahankan.

Mulai dari **UPDATE_GABUNGAN.md** untuk perintah update VPS dan build. **PANDUAN_GOOGLE_PLAY_v2.14.0.md** sudah memakai tujuh produk baru. **LAPORAN_PENGUJIAN_GABUNGAN.md** mencatat pengujian paket ini dan batas verifikasinya. Laporan versi sebelumnya tetap tersedia sebagai riwayat.

- API tetap 2.14.0; Play Recovery R1 dan revisi katalog 1 sudah menyatu di source.
- Android dasar 2.14.0+40; builder memilih nomor lebih tinggi berdasarkan riwayat lokal. Pilih nomor yang belum pernah diunggah ke Play Console.
- Paket Play: 25, 75, 160, 350, 750, 1.600 dan 3.500 koin. Jumlah akhir tanpa tambahan bonus.
- Empat ID Play lama tetap dapat dipulihkan dan direfund; katalog aplikasi menawarkan tujuh ID baru.
- Konfigurasi pembayaran Google Play yang sudah berhasil tidak perlu di-setup ulang. Harga dan ketersediaan produk diatur oleh pemilik pada Play Console.
- Pembelian web Kipay, admin koin, LIVE, preview foto profil, notifikasi, moderasi dan rekaman tetap mengikuti integrasi source terbaru.
- Source tidak menyertakan credential privat server, keystore atau APK/AAB baru.

Update pada VPS backend existing setelah LIVE selesai:

```bash
cd /root
unzip -o Kocehind_v2.14.0_Gabungan.zip
cd /root/Kocehind_v2.14.0_Gabungan
sha256sum -c SHA256SUMS.txt
/opt/kocehind/venv/bin/python UPDATE_BACKEND_WEB.py --check
/opt/kocehind/venv/bin/python UPDATE_BACKEND_WEB.py
systemctl is-active kocehind-api kocehind-play
```

Updater lengkap memakai alur backup/migrasi/rollback dari source versi terbaru. Folder **PERBAIKAN_BACKEND/Kocehind_Backend_Paket_Koin** juga menyediakan updater katalog kecil untuk VPS yang sudah memasang Recovery R1. Pilih satu jalur yang sesuai; keduanya memakai modul katalog yang sama. Baca UPDATE_GABUNGAN.md.
