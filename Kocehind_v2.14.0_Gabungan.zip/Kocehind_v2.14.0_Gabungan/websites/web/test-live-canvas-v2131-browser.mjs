import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {createRequire} from 'node:module';
const {chromium}=createRequire(import.meta.url)('playwright');
const sites=resolve(new URL('..',import.meta.url).pathname);
const viewer={id:'v',username:'viewer',name:'Viewer',legal_required:false};
const creator={id:'c',username:'creator',name:'Creator'};
const host={id:'h',username:'host',name:'Host',legal_required:false};
const people=[host,...Array.from({length:8},(_,i)=>({id:'g'+i,username:'guest'+i,name:'Guest '+i}))].map((m,i)=>({...m,role:i?'speaker':'host',connected:true}));
const sdk=`
export const RoomEvent={TrackSubscribed:'track',TrackUnsubscribed:'untrack',Disconnected:'disconnect',Reconnecting:'reconnecting',Reconnected:'connected'};
function participant(id){const track={attach(){const v=document.createElement('video');v.dataset.track=id;return v;},detach(v){return v?[v]:[];}};return {identity:id,isSpeaking:false,videoTrackPublications:new Map([['camera',{track,trackSid:id,isMuted:false}]]),async setCameraEnabled(){window.cameraCalls=(window.cameraCalls||0)+1;},async setMicrophoneEnabled(){},async unpublishTrack(){}};}
export class Room{constructor(){this.state='connected';this.localParticipant=participant(window.fixtureUser);this.remoteParticipants=new Map(${JSON.stringify(people)}.filter(p=>p.id!==window.fixtureUser).map(p=>[p.id,participant(p.id)]));}on(){return this;}async connect(){window.rtcConnects=(window.rtcConnects||0)+1;}async disconnect(){}async startAudio(){}}
`;

async function fixture(handle){
 const server=createServer(async(req,res)=>{
  try{
   const url=new URL(req.url,'http://fixture');
   if(url.pathname==='/shared/livekit.js'){res.writeHead(200,{'content-type':'text/javascript'});res.end(sdk);return;}
   if(url.pathname.startsWith('/api/')){
    let text='';for await(const part of req)text+=part;
    const result=await handle({path:url.pathname.slice(4),query:url.searchParams,method:req.method,body:text&&!req.headers['content-type']?.includes('multipart/')?JSON.parse(text):null,user:req.headers['x-fixture-user']||'v'});
    res.writeHead(Number.isInteger(result?.status)?result.status:200,{'content-type':'application/json'});res.end(JSON.stringify(result?.data??result??{}));return;
   }
   if(url.pathname.endsWith('.mp4')){res.writeHead(200,{'content-type':'video/mp4'});res.end();return;}
   const relative=url.pathname.startsWith('/shared/')?url.pathname.slice(1):/\.(js|css)$/.test(url.pathname)?'web'+url.pathname:'web/index.html';
   const path=resolve(sites,relative);if(!path.startsWith(sites+'/'))throw Error('path');
   const bytes=await readFile(path);res.writeHead(200,{'content-type':({'.js':'text/javascript','.css':'text/css','.html':'text/html'}[extname(path)]||'application/octet-stream')});res.end(bytes);
  }catch(e){res.writeHead(404);res.end('missing');}
 });
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 return {url:'http://127.0.0.1:'+server.address().port,close:()=>new Promise(r=>server.close(r))};
}
const launch=()=>chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE,args:['--no-sandbox']});


const pixel=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4z8DwHwAFgAI/ScLbtAAAAABJRU5ErkJggg==','base64');
test('Phone host adds gallery and background text, drags it, and viewer receives the same canvas and gift comments',async()=>{
 let state={version:0,items:[]},feed=[],giftList=[];const updates=[];
 const info={id:'room',title:'LIVE Canvas',mode:'camera',together:false,seats:9,status:'active',host,members:[people[0]],layout:{version:0,slots:['h']},likes:0};
 const f=await fixture(r=>{
  const own=r.user==='h'?host:viewer,room=()=>({...info,overlays:structuredClone(state),role:r.user==='h'?'host':'viewer',capabilities:{}});
  if(r.path==='/users/me')return own;
  if(r.path.endsWith('/join'))return {url:'wss://fixture',token:'fixture',role:r.user==='h'?'host':'viewer',room:room()};
  if(r.path.endsWith('/heartbeat')||r.path==='/live/rooms/room')return room();
  if(r.path.endsWith('/comments'))return {items:feed.filter(c=>c.sequence>Number(r.query.get('after'))),cursor:feed.length};
  if(r.path.endsWith('/gifts'))return r.query.has('initialize')?{items:[],cursor:giftList.length}:{items:giftList.slice(Number(r.query.get('after'))),cursor:giftList.length};
  if(r.path==='/media/upload')return {media_url:'http://fixture/media/owned.png'};
  if(r.path.endsWith('/overlays')&&r.method==='PUT'){
   assert.equal(r.user,'h');assert.equal(r.body.version,state.version);updates.push(r.body);
   state={version:state.version+1,items:r.body.items.map(i=>{const {media_url,...item}=i;return item.kind==='image'?{...item,image_url:'/fixture.png'}:item;})};return state;
  }
  if(r.path==='/users/me/privacy')return {revision:'fixed'};
  return {items:[],next_cursor:null,next_offset:null};
 });
 const browser=await launch(),page=await browser.newPage({viewport:{width:412,height:915}}),watch=await browser.newPage({viewport:{width:390,height:844}}),errors=[];
 for(const [p,id] of [[page,'h'],[watch,'v']]){p.setDefaultTimeout(7000);await p.setExtraHTTPHeaders({'x-fixture-user':id});await p.addInitScript(id=>window.fixtureUser=id,id);p.on('pageerror',e=>errors.push(e.message));await p.route('**/fixture.png',r=>r.fulfill({body:pixel,contentType:'image/png'}));}
 try{
  await page.goto(f.url+'/live/room');await page.locator('#live-overlays:not([hidden])').waitFor();
  await watch.goto(f.url+'/live/room');await watch.locator('.live-tile').waitFor();assert(await watch.locator('#live-overlays').isHidden());
  await page.locator('#live-overlays').click();await page.locator('dialog [data-add-text]').click();
  const form=page.locator('dialog:has(textarea[name=text])');await form.locator('textarea').fill('Promo malam ini');
  await form.locator('[name=style]').selectOption('background');await form.locator('[name=background]').fill('#2563eb');await form.locator('[type=submit]').click();
  await page.locator('dialog [data-items]').getByText('Promo malam ini',{exact:true}).waitFor();
  await page.locator('dialog [data-image]').setInputFiles({name:'galeri.png',mimeType:'image/png',buffer:pixel});
  await page.locator('dialog [data-items]').getByText('Gambar galeri',{exact:true}).waitFor();
  await page.locator('dialog .live-overlay-row').filter({hasText:'Gambar galeri'}).locator('[data-edit]').click();
  const imageEditor=page.locator('dialog:has([name=image_size])');
  await imageEditor.locator('[data-fill-stage]').click();
  await imageEditor.locator('[type=submit]').click();
  assert.equal(state.items.find(i=>i.kind==='image').width,1);
  assert.equal(state.items.find(i=>i.kind==='image').height,1);
  await page.locator('dialog .live-overlay-row').filter({hasText:'Promo malam ini'}).locator('[data-front]').click();
  await page.waitForFunction(()=>!document.querySelector('dialog [data-drag]').disabled);
  await page.locator('dialog [data-drag]').click();await page.locator('.live-canvas.editing').waitFor();
  assert.equal(await page.locator('.live-canvas-item').count(),2);
  const text=page.locator('.live-canvas-item.is-text'),box=await text.boundingBox();
  await page.mouse.move(box.x+box.width/2,box.y+box.height/2);await page.mouse.down();await page.mouse.move(box.x+box.width/2+35,box.y+box.height/2+30,{steps:5});await page.mouse.up();
  await page.waitForFunction(()=>document.querySelector('.live-canvas.editing')&&!document.querySelector('#live-overlay-done').disabled);
  assert(state.items.find(i=>i.kind==='text').x>.15);await page.locator('#live-overlay-done').click();
  await watch.waitForFunction(()=>document.querySelectorAll('.live-canvas-item').length===2);
  const hostPosition=await text.evaluate(e=>[e.style.left,e.style.top]);
  await watch.waitForFunction(expected=>JSON.stringify([document.querySelector('.live-canvas-item.is-text')?.style.left,document.querySelector('.live-canvas-item.is-text')?.style.top])===JSON.stringify(expected),hostPosition);
  assert.equal(await watch.locator('.live-canvas-item.is-text span').evaluate(e=>e.style.backgroundColor),'rgb(37, 99, 235)');
  assert.equal(await watch.locator('.live-canvas.editing').count(),0);
  const gift={id:'ordinary-gift',sequence:1,sender:'viewer',name:'Mawar',image_url:'/fixture.png',video_url:null,exclusive_video:false,display_mode:'comment',duration_seconds:0};
  giftList=[gift];feed=[{id:'ordinary-gift',sequence:1,kind:'gift',body:'mengirim Mawar ×1',gift,author:viewer}];
  await watch.locator('#live-comments .gift-comment').waitFor();await page.locator('#live-comments .gift-comment').waitFor();assert.equal(await watch.locator('.live-gift-card').count(),0);
  await page.screenshot({path:'/workspace/scratch/789ef136df3a/live-canvas-host.png'});
  await watch.screenshot({path:'/workspace/scratch/789ef136df3a/live-canvas-viewer.png'});
  assert(updates.length>=3);assert.deepEqual(errors,[]);
 }finally{await browser.close();await f.close();}
});
