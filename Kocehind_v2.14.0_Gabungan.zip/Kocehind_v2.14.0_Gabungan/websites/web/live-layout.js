import {api,me,esc,openDialog,toast} from '/shared/api.js?v=2.14.0';

export function stageSlots(info){
 const capacity=info.together?(info.seats||9):1;
 const members=(info.members||[]).filter(m=>m.role==='host'||m.role==='speaker');
 const byId=new Map(members.map(m=>[m.id,m])),seen=new Set(),slots=Array(capacity).fill(null);
 for(let i=0;i<capacity;i++){const id=info.layout?.slots?.[i];if(byId.has(id)&&!seen.has(id)){slots[i]=byId.get(id);seen.add(id);}}
 for(const m of members)if(!seen.has(m.id)){const i=slots.indexOf(null);if(i<0)break;slots[i]=m;seen.add(m.id);}
 return slots;
}

export function stageCells(count,focus,width,height){
 const columns=count===1?1:count===2?(width>height*1.2?2:1):3;
 if(focus<0||count===1)return {columns,rows:`repeat(${Math.ceil(count/columns)},minmax(0,1fr))`,
   cells:Array.from({length:count},(_,i)=>({row:Math.floor(i/columns)+1,column:i%columns+1}))};
 const cols=count===2?1:4,cells=[];let next=0;
 for(let i=0;i<count;i++)cells.push(i===focus?{row:1,column:'1 / -1'}:{row:2+Math.floor(next/cols),column:(next++)%cols+1});
 return {columns:cols,rows:`3fr repeat(${Math.ceil((count-1)/cols)},minmax(0,1fr))`,cells};
}

export function openLiveLayout(info,base,updated){
 const people=(info.members||[]).filter(m=>m.role==='host'||m.role==='speaker');
 const capacity=info.seats||9;
 const host=me?.id===info.host?.id;
 const d=openDialog('Atur layar',`<label>Pilih peserta<select name="layout-person">${people.map(m=>`<option value="${esc(m.id)}">@${esc(m.username)}${m.role==='host'?' · Host':''}</option>`).join('')}</select></label>
 ${host&&info.mode==='camera'?`<p>Jumlah tamu kamera</p><div class="buttons"><button class="btn" data-capacity="1" ${capacity===2?'disabled':''}>Host + 1 tamu</button><button class="btn" data-capacity="8" ${capacity===9?'disabled':''}>Host + 8 tamu</button></div>`:''}
 <div class="buttons layout-focus"><button class="btn primary" data-focus ${people.length?'':'disabled'}>Perbesar peserta terpilih</button><button class="btn" data-unfocus>Kembalikan ukuran semua</button></div>
 <p>Pindahkan ke tempat (bertukar dengan penghuni tempat itu)</p><div class="live-slot-picker" style="--slot-cols:${capacity===2?2:3}">${Array.from({length:capacity},(_,i)=>`<button class="btn" data-slot="${i}" ${people.length?'':'disabled'}>Tempat ${i+1}</button>`).join('')}</div>
 <button class="text-btn" data-reset>Susun otomatis</button><p class="form-error" role="alert"></p>`);
 let busy=false;
 const person=()=>d.querySelector('[name=layout-person]').value;
 async function save(endpoint,body){
  if(busy)return;busy=true;d.querySelectorAll('button').forEach(b=>b.disabled=true);
  try{const next=await api(base+'/'+endpoint,{method:'PUT',body:{version:info.layout?.version||0,...body}});updated(next);d.close();}
  catch(e){if(d.open)d.querySelector('.form-error').textContent=e.message;else toast(e.message);}
  finally{busy=false;d.querySelectorAll('button').forEach(b=>b.disabled=false);}
 }
 d.querySelector('[data-focus]').onclick=()=>save('layout',{action:'focus',user_id:person()});
 d.querySelector('[data-unfocus]').onclick=()=>save('layout',{action:'focus',user_id:null});
 d.querySelector('[data-reset]').onclick=()=>save('layout',{action:'reset'});
 d.querySelectorAll('[data-slot]').forEach(b=>b.onclick=()=>save('layout',{action:'swap',user_id:person(),slot:Number(b.dataset.slot)}));
 d.querySelectorAll('[data-capacity]').forEach(b=>b.onclick=async()=>{
  const limit=Number(b.dataset.capacity),guests=people.filter(m=>m.role==='speaker'),kept=guests.find(m=>m.id===person())||guests[0];
  if(limit===1&&guests.length>1){
   const confirm=openDialog('Gunakan satu tamu?',`<p>@${esc(kept.username)} tetap di kamera. Tamu lainnya kembali menjadi penonton dan dapat meminta kursi lagi.</p><button class="btn primary" data-confirm>Gunakan 1 tamu</button>`);
   const yes=await new Promise(resolve=>{confirm.querySelector('[data-confirm]').onclick=()=>{resolve(true);confirm.close();};confirm.addEventListener('close',()=>resolve(false),{once:true});});
   if(!yes)return;
  }
  await save('camera-seats',{guest_limit:limit,...(limit===1&&kept?{keep_user_id:kept.id}:{})});
 });
 return d;
}
