#!/usr/bin/env bash
# Bootstrap Ubuntu/Debian x86_64, restore OLD key, then build bundled 2.14.0.
set -Eeuo pipefail
umask 077
TASK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[[ "$(uname -m)" == 'x86_64' ]] || {
  echo 'Paket build ini memerlukan VPS Ubuntu/Debian x86_64 (amd64).' >&2
  exit 1
}
command -v apt-get >/dev/null || {
  echo 'Gunakan VPS Ubuntu/Debian yang menyediakan apt-get.' >&2
  exit 1
}
TASK_SUDO=()
if [[ "${EUID}" -ne 0 ]]; then
  command -v sudo >/dev/null || { echo 'Jalankan sebagai root atau pengguna sudo.' >&2; exit 1; }
  TASK_SUDO=(sudo)
fi
# Check backup presence before downloading SDKs or installing packages.
if [[ ! -d "${HOME}/.kocehind-portable" && ! -f "${HOME}/KOCEHIND_KEY_LAMA.enc" ]]; then
  echo 'Upload KOCEHIND_KEY_LAMA.enc hasil ekspor VPS lama ke folder home (untuk root: /root/).' >&2
  exit 1
fi
echo 'Menyiapkan Java 17, OpenSSL dan kebutuhan build pada VPS baru...'
"${TASK_SUDO[@]}" apt-get update
"${TASK_SUDO[@]}" env DEBIAN_FRONTEND=noninteractive apt-get install -y \
  python3 openssl ca-certificates curl git unzip xz-utils zip libglu1-mesa openjdk-17-jdk
export JAVA_HOME="${JAVA_HOME:-/usr/lib/jvm/java-17-openjdk-amd64}"
export PATH="${JAVA_HOME}/bin:/opt/flutter/bin:${HOME}/flutter/bin:${PATH}"
export ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-${HOME}/android-sdk}"
export ANDROID_HOME="${ANDROID_SDK_ROOT}"
export FLUTTER_VERSION="${FLUTTER_VERSION:-3.38.10}"
if [[ ! -d "${HOME}/.kocehind-portable" ]]; then
  python3 "${TASK_DIR}/PINDAH_KEY_LAMA.py" impor
fi
exec python3 "${TASK_DIR}/PINDAH_KEY_LAMA.py" build "$@"
