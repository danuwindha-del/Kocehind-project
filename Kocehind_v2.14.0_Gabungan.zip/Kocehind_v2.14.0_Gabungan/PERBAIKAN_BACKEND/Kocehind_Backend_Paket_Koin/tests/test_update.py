import importlib.util
from pathlib import Path
import shutil
from types import SimpleNamespace
import pytest

HERE = Path(__file__).resolve().parents[1]


@pytest.fixture
def updater(tmp_path, monkeypatch):
    spec = importlib.util.spec_from_file_location('catalog_updater', HERE / 'UPDATE_PAKET_KOIN.py')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    bundle, runtime = tmp_path / 'bundle', tmp_path / 'runtime'
    shutil.copytree(HERE, bundle, ignore=shutil.ignore_patterns('__pycache__', '.pytest_cache'))
    shutil.copytree(HERE / 'tests/fixtures/runtime', runtime)
    (runtime / 'app/main.py').write_text('app = None\n')
    config = tmp_path / 'backend.env'
    config.write_text('DATABASE_URL=sqlite:///not-used.db\nJWT_SECRET=test-private-value\nPLAY_BILLING_ENABLED=1\n')
    for key, value in {'HERE': bundle, 'RUNTIME': runtime, 'PYTHON': Path(__import__('sys').executable),
                       'ENV': config, 'STAGING': tmp_path / 'staging', 'BACKUPS': tmp_path / 'backups'}.items():
        monkeypatch.setattr(mod, key, value)
    monkeypatch.setattr(mod.os, 'geteuid', lambda: 0)
    monkeypatch.setattr(mod.pwd, 'getpwnam', lambda user: SimpleNamespace())
    monkeypatch.setattr(mod, 'active', lambda unit: True)
    monkeypatch.setattr(mod.subprocess, 'run', lambda *a, **kw: SimpleNamespace(returncode=0, stdout='', stderr=''))
    monkeypatch.setattr(mod, 'preflight', lambda *a: None)
    monkeypatch.setattr(mod.sys, 'argv', ['UPDATE_PAKET_KOIN.py'])
    return mod


def test_unknown_runtime_is_rejected_before_restart(updater):
    (updater.RUNTIME / 'app/play_billing.py').write_text('custom change\n')
    with pytest.raises(RuntimeError, match='custom'):
        updater.verify()


def test_tampered_payload_is_rejected(updater):
    (updater.HERE / 'backend/app/play_billing.py').write_text('bad payload\n')
    with pytest.raises(RuntimeError, match='hash'):
        updater.verify()


def test_preflight_only_does_not_change_code_or_restart_services(updater, monkeypatch):
    before = (updater.RUNTIME / 'app/play_billing.py').read_bytes()
    calls = []
    monkeypatch.setattr(updater, 'run', lambda args, **kw: calls.append(args))
    monkeypatch.setattr(updater.sys, 'argv', ['update', '--check'])
    updater.main()
    assert before == (updater.RUNTIME / 'app/play_billing.py').read_bytes()
    assert calls == []
    assert not list(updater.STAGING.iterdir())


def test_restart_failure_restores_old_module_and_preserves_environment(updater, monkeypatch):
    before = (updater.RUNTIME / 'app/play_billing.py').read_bytes()
    environment = updater.ENV.read_bytes()
    worker = (updater.RUNTIME / 'app/play_worker.py').read_bytes()
    def fail_on_restart(args, **kwargs):
        if args == ['systemctl', 'start', 'kocehind-api']:
            raise RuntimeError('test-restart-failure')
    monkeypatch.setattr(updater, 'run', fail_on_restart)
    with pytest.raises(RuntimeError, match='test-restart-failure'):
        updater.main()
    assert (updater.RUNTIME / 'app/play_billing.py').read_bytes() == before
    assert (updater.RUNTIME / 'app/play_worker.py').read_bytes() == worker
    assert updater.ENV.read_bytes() == environment
    assert not list(updater.STAGING.iterdir())


def test_success_updates_only_the_catalogue_module(updater, monkeypatch):
    environment = updater.ENV.read_bytes()
    worker = (updater.RUNTIME / 'app/play_worker.py').read_bytes()
    monkeypatch.setattr(updater, 'run', lambda *a, **kw: None)
    monkeypatch.setattr(updater, 'wait_for_health', lambda: None)
    updater.main()
    assert (updater.RUNTIME / 'app/play_billing.py').read_bytes() == (updater.HERE / 'backend/app/play_billing.py').read_bytes()
    assert (updater.RUNTIME / 'app/play_worker.py').read_bytes() == worker
    assert updater.ENV.read_bytes() == environment


def test_repeated_install_does_not_restart_services(updater, monkeypatch):
    (updater.RUNTIME / 'app/play_billing.py').write_bytes((updater.HERE / 'backend/app/play_billing.py').read_bytes())
    calls = []
    monkeypatch.setattr(updater, 'run', lambda args, **kw: calls.append(args))
    updater.main()
    assert calls == []


def test_preflight_reads_income_setting_without_disclosing_raw_output(updater, monkeypatch, capsys):
    # Exercise the preflight result parser separately from service execution.
    spec = importlib.util.spec_from_file_location('catalog_preflight_parser', HERE / 'UPDATE_PAKET_KOIN.py')
    original = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(original)
    monkeypatch.setattr(original, 'run', lambda *a, **kw: SimpleNamespace(stdout='private-unrelated-output\nCATALOG_PREFLIGHT={"ok":true,"income_per_coin":17}\n'))
    original.preflight(Path('/not-used'), {})
    output = capsys.readouterr().out
    assert 'Rp17' in output and 'private-unrelated-output' not in output
