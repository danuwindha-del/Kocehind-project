"""Google-verified consumable coins. Tokens never determine their own value."""
import base64
import hashlib
import hmac
import os
from datetime import timedelta
from urllib.parse import quote
from cryptography.fernet import Fernet
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy import BigInteger, DateTime, ForeignKey, Integer, String, Text, select
from sqlalchemy.orm import Mapped, mapped_column
from .core import Base, JWT_SECRET, current_user, db_session, utcnow
from .coin_admin import credit_coins
from .wallet import lock_users, wallet, entry

router = APIRouter()
PACKAGE = 'id.web.kocehind'
PRODUCTS = {f'kocehind_coin_{n}': n for n in (100, 500, 1000, 5000)}
API = f'https://androidpublisher.googleapis.com/androidpublisher/v3/applications/{PACKAGE}'

class PlayPurchase(Base):
    __tablename__ = 'google_play_purchases'
    token_hash: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    product_id: Mapped[str] = mapped_column(String(100))
    encrypted_token: Mapped[str] = mapped_column(Text)
    coins_per_unit: Mapped[int] = mapped_column(Integer)
    quantity: Mapped[int] = mapped_column(Integer)
    refunded_quantity: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(20), default='pending')
    order_id: Mapped[str] = mapped_column(String(200), default='')
    credited_at: Mapped[object | None] = mapped_column(DateTime, nullable=True)
    consumed_at: Mapped[object | None] = mapped_column(DateTime, nullable=True)
    next_check_at: Mapped[object] = mapped_column(DateTime, default=utcnow, index=True)
    lease_until: Mapped[object | None] = mapped_column(DateTime, nullable=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[object] = mapped_column(DateTime, default=utcnow)

def account_id(uid):
    return hashlib.sha256(('kocehind-play-v1:' + uid).encode()).hexdigest()

def token_digest(token):
    return hashlib.sha256(token.encode()).hexdigest()

def token_cipher():
    return Fernet(base64.urlsafe_b64encode(hashlib.sha256(('kocehind-play-token-v1:' + JWT_SECRET).encode()).digest()))

def enabled():
    return os.getenv('PLAY_BILLING_ENABLED', '0').lower() in ('1', 'true', 'yes')

def publisher_request(method, path, **kwargs):
    if not enabled() or not os.getenv('PLAY_SERVICE_ACCOUNT_FILE'):
        raise HTTPException(503, 'Pembelian Google Play belum diaktifkan oleh pengelola')
    from google.oauth2 import service_account
    from google.auth.transport.requests import AuthorizedSession
    try:
        credentials = service_account.Credentials.from_service_account_file(
            os.environ['PLAY_SERVICE_ACCOUNT_FILE'], scopes=['https://www.googleapis.com/auth/androidpublisher'])
        with AuthorizedSession(credentials) as session:
            response = session.request(method, API + path, timeout=(5, 20), allow_redirects=False, **kwargs)
        if response.status_code == 404:
            raise HTTPException(422, 'Pembelian belum ditemukan di Google Play. Coba periksa kembali.')
        if not 200 <= response.status_code < 300:
            raise HTTPException(503, 'Google Play belum dapat memverifikasi pembayaran. Coba lagi.')
        return response.json() if response.content else {}
    except HTTPException:
        raise
    except Exception:
        # Provider exceptions can contain a token-bearing URL or private-key data.
        raise HTTPException(503, 'Layanan verifikasi Google Play belum tersedia. Coba lagi.') from None

def retrieve(token):
    return publisher_request('GET', '/purchases/productsv2/tokens/' + quote(token, safe=''))

def consume(product, token):
    publisher_request('POST', '/purchases/products/' + quote(product, safe='') + '/tokens/' + quote(token, safe='') + ':consume')

class VerifyPurchase(BaseModel):
    model_config = ConfigDict(extra='forbid')
    product_id: str = Field(min_length=1, max_length=100)
    purchase_token: str = Field(min_length=10, max_length=4096)

    @field_validator('purchase_token')
    @classmethod
    def opaque_token(cls, value):
        if any(ord(ch) < 33 or ord(ch) > 126 for ch in value):
            raise ValueError('Token pembelian tidak valid')
        return value

def receipt_details(data, uid, product):
    if not isinstance(data, dict) or not hmac.compare_digest(str(data.get('obfuscatedExternalAccountId', '')), account_id(uid)):
        raise HTTPException(403, 'Pembelian ini terkait dengan akun Kocehind yang berbeda')
    lines = data.get('productLineItem')
    if not isinstance(lines, list) or len(lines) != 1 or not isinstance(lines[0], dict) or lines[0].get('productId') != product:
        raise HTTPException(409, 'Produk pada bukti Google Play tidak cocok')
    context = data.get('purchaseStateContext')
    details = lines[0].get('productOfferDetails')
    if not isinstance(context, dict) or not isinstance(details, dict):
        raise HTTPException(502, 'Respons Google Play tidak valid')
    state = context.get('purchaseState')
    quantity = details.get('quantity', 1 if state != 'PURCHASED' else None)
    remaining = details.get('refundableQuantity', quantity if state != 'PURCHASED' else None)
    if state not in ('PURCHASED', 'PENDING', 'CANCELLED') or type(quantity) is not int or not 1 <= quantity <= 1000:
        raise HTTPException(502, 'Status atau jumlah pembelian Google Play tidak valid')
    if state == 'CANCELLED':
        remaining = 0
    if type(remaining) is not int or not 0 <= remaining <= quantity or details.get('rentOfferDetails') is not None:
        raise HTTPException(502, 'Jumlah koin Google Play belum dapat diverifikasi')
    consumption = details.get('consumptionState')
    if state == 'PURCHASED' and consumption not in ('CONSUMPTION_STATE_YET_TO_BE_CONSUMED', 'CONSUMPTION_STATE_CONSUMED'):
        raise HTTPException(502, 'Status penggunaan pembelian Google Play tidak valid')
    return state, quantity, remaining, consumption == 'CONSUMPTION_STATE_CONSUMED'

def apply_receipt(db, uid, product, token, data):
    state, quantity, remaining, consumed = receipt_details(data, uid, product)
    digest = token_digest(token)
    lock_users(db, uid)
    row = db.scalar(select(PlayPurchase).where(PlayPurchase.token_hash == digest)
                    .with_for_update().execution_options(populate_existing=True))
    if row and state == 'CANCELLED' and 'quantity' not in data['productLineItem'][0]['productOfferDetails']:
        quantity = row.quantity
    if row and (row.user_id != uid or row.product_id != product or row.credited_at and row.quantity != quantity):
        raise HTTPException(409, 'Bukti pembelian sudah digunakan untuk transaksi lain')
    if row and row.status == 'cancelled':
        return row  # A delayed response may never resurrect a cancelled token.
    if row is None:
        if consumed:
            raise HTTPException(409, 'Pembelian sudah dipakai. Hubungi bantuan bila saldo belum tercatat.')
        row = PlayPurchase(token_hash=digest, user_id=uid, product_id=product, quantity=quantity,
                           coins_per_unit=PRODUCTS[product], encrypted_token=token_cipher().encrypt(token.encode()).decode())
        db.add(row)
        db.flush()
    if row.credited_at is None:
        row.quantity = quantity
    w = wallet(db, uid)
    if state == 'PURCHASED' and row.credited_at is None:
        # Record the full entitlement and any already-refunded quantity atomically.
        credit_coins(db, w, row.coins_per_unit * quantity, 'play_credit', digest)
        row.credited_at = utcnow()
    refund_units = quantity - remaining if row.credited_at else 0
    if refund_units > row.refunded_quantity:
        coins = (refund_units - row.refunded_quantity) * row.coins_per_unit
        removed = min(w.coins, coins)
        w.coins -= removed
        w.coin_debt += coins - removed
        reference = digest + ':' + str(refund_units)
        entry(db, w, 'play_refund', reference, 'coins', -removed)
        if coins > removed:
            entry(db, w, 'refund_debt', reference, 'debt', coins - removed)
        row.refunded_quantity = refund_units
    row.order_id = str(data.get('orderId', ''))[:200]
    if consumed and row.credited_at:
        row.consumed_at = row.consumed_at or utcnow()
    row.status = 'refunded' if row.credited_at and row.refunded_quantity == quantity else 'credited' if row.credited_at else state.lower()
    row.next_check_at = utcnow() + timedelta(seconds=30 if state == 'PENDING' or row.credited_at and not row.consumed_at else 86400)
    row.attempts = 0
    db.commit()
    return row

def finish_consumption(db, row, token):
    if row.credited_at and not row.consumed_at and row.status == 'credited':
        digest = row.token_hash
        db.commit()  # Never keep money locks during a provider request.
        consume(row.product_id, token)
        row = db.scalar(select(PlayPurchase).where(PlayPurchase.token_hash == digest).with_for_update())
        row.consumed_at = utcnow()
        row.next_check_at = utcnow() + timedelta(days=1)
        db.commit()

def response(db, row):
    w = wallet(db, row.user_id)
    return {'status': row.status, 'coins': w.coins, 'coin_debt': w.coin_debt,
            'credited_coins': row.coins_per_unit * row.quantity if row.credited_at else 0,
            'consumed': row.consumed_at is not None}

@router.get('/wallet/google-play/products')
def products(me=Depends(current_user)):
    return {'enabled': enabled(), 'account_id': account_id(me.id),
            'items': [{'product_id': product, 'coins': coins} for product, coins in PRODUCTS.items()]}

@router.post('/wallet/google-play/verify')
def verify(payload: VerifyPurchase, me=Depends(current_user), db=Depends(db_session)):
    if not enabled():
        raise HTTPException(503, 'Pembelian Google Play belum diaktifkan oleh pengelola')
    if payload.product_id not in PRODUCTS:
        raise HTTPException(422, 'Paket koin Google Play tidak dikenal')
    from .security import throttle
    from .events import user_event
    uid = me.id
    throttle(db, 'play-verify:' + uid, 120, 3600)
    data = retrieve(payload.purchase_token)
    row = apply_receipt(db, uid, payload.product_id, payload.purchase_token, data)
    try:
        finish_consumption(db, row, payload.purchase_token)
    except HTTPException:
        db.rollback()  # The committed entitlement and retry schedule survive.
    user_event(uid, 'wallet_updated')
    return response(db, row)
