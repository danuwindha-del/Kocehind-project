"""Add Play receipts and admin coin operations without rewriting balances."""
from app.core import engine
from app.coin_admin import AdminCoinOperation
from app.play_billing import PlayPurchase
from app.play_worker import PlayRefundScan

def migrate():
    for model in (AdminCoinOperation, PlayPurchase, PlayRefundScan):
        model.__table__.create(engine, checkfirst=True)

if __name__ == '__main__':
    migrate()
    print('Migrasi 2.14.0 selesai; saldo dan ledger sebelumnya dipertahankan.')
