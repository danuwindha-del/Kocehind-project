"""Google-verified consumable coins. Tokens never determine their own value."""
import base64
import hashlib
import hmac
import os
import logging
from copy import deepcopy
from datetime import timedelta
from urllib.parse import quote
from cryptography.fernet import Fernet
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy import BigInteger, DateTime, ForeignKey, Integer, String, Text, select
from sqlalchemy.orm import Mapped, mapped_column
from .core import Base, JWT_SECRET, current_user, db_session, utcnow
from .coin_admin import credit_coins
from .wallet import lock_users, wallet, entry

router = APIRouter()
PACKAGE = 'id.web.kocehind'
PRODUCTS = {f'kocehind_coin_{n}': n for n in (100, 500, 1000, 5000)}
API = f'https://androidpublisher.googleapis.com/androidpublisher/v3/applications/{PACKAGE}'
log = logging.getLogger('kocehind.play')

ERRORS = {
    'PLAY_CONFIG': 'Pembelian Google Play belum dikonfigurasi pada backend.',
    'PLAY_CREDENTIALS': 'Credential backend Google Play tidak valid atau tidak dapat dibaca. Pengelola perlu memeriksa service account.',
    'PLAY_PERMISSION': 'Service account backend belum memiliki izin verifikasi pesanan Kocehind di Play Console.',
    'PLAY_API_DISABLED': 'Google Play Android Developer API belum aktif pada project service account backend.',
    'PLAY_NOT_FOUND': 'Bukti pembelian belum ditemukan Google Play. Transaksi tersimpan dan akan diperiksa kembali.',
    'PLAY_GOOGLE_UNAVAILABLE': 'Verifikasi Google Play sementara gagal. Transaksi tersimpan dan akan diperiksa kembali.',
    'PLAY_RECEIPT_INCOMPLETE': 'Data pembayaran dari Google Play belum lengkap. Transaksi tersimpan untuk pemeriksaan ulang.',
    'PLAY_ACCOUNT': 'Pembelian ini terkait dengan akun Kocehind yang berbeda.',
    'PLAY_REJECTED': 'Bukti pembelian tidak sesuai dengan akun atau paket yang dipilih.',
}

def play_error(code, status=503):
    error = HTTPException(status, '[' + code + '] ' + ERRORS[code])
    error.play_code = code
    return error


class PlayVerification(Base):
    """Unverified claims have a separate queue and never reserve a paid token."""
    __tablename__ = 'google_play_verification_queue'
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    product_id: Mapped[str] = mapped_column(String(100))
    encrypted_token: Mapped[str] = mapped_column(Text)
    state: Mapped[str] = mapped_column(String(20), default='queued')
    last_code: Mapped[str] = mapped_column(String(40), default='')
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    next_check_at: Mapped[object] = mapped_column(DateTime, default=utcnow, index=True)
    lease_until: Mapped[object | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[object] = mapped_column(DateTime, default=utcnow)

class PlayPurchase(Base):
    __tablename__ = 'google_play_purchases'
    token_hash: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    product_id: Mapped[str] = mapped_column(String(100))
    encrypted_token: Mapped[str] = mapped_column(Text)
    coins_per_unit: Mapped[int] = mapped_column(Integer)
    quantity: Mapped[int] = mapped_column(Integer)
    refunded_quantity: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(20), default='pending')
    order_id: Mapped[str] = mapped_column(String(200), default='')
    credited_at: Mapped[object | None] = mapped_column(DateTime, nullable=True)
    consumed_at: Mapped[object | None] = mapped_column(DateTime, nullable=True)
    next_check_at: Mapped[object] = mapped_column(DateTime, default=utcnow, index=True)
    lease_until: Mapped[object | None] = mapped_column(DateTime, nullable=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[object] = mapped_column(DateTime, default=utcnow)

def account_id(uid):
    return hashlib.sha256(('kocehind-play-v1:' + uid).encode()).hexdigest()

def token_digest(token):
    return hashlib.sha256(token.encode()).hexdigest()

def token_cipher():
    return Fernet(base64.urlsafe_b64encode(hashlib.sha256(('kocehind-play-token-v1:' + JWT_SECRET).encode()).digest()))

def enabled():
    return os.getenv('PLAY_BILLING_ENABLED', '0').lower() in ('1', 'true', 'yes')

def publisher_request(method, path, **kwargs):
    if not enabled() or not os.getenv('PLAY_SERVICE_ACCOUNT_FILE'):
        raise play_error('PLAY_CONFIG')
    from google.oauth2 import service_account
    from google.auth.transport.requests import AuthorizedSession
    from google.auth.exceptions import GoogleAuthError
    try:
        credentials = service_account.Credentials.from_service_account_file(
            os.environ['PLAY_SERVICE_ACCOUNT_FILE'], scopes=['https://www.googleapis.com/auth/androidpublisher'])
    except Exception:
        raise play_error('PLAY_CREDENTIALS') from None
    try:
        with AuthorizedSession(credentials, refresh_timeout=10) as session:
            response = session.request(method, API + path, timeout=(5, 12), allow_redirects=False, **kwargs)
        if response.status_code in (401, 403):
            code = 'PLAY_CREDENTIALS' if response.status_code == 401 else 'PLAY_PERMISSION'
            try:
                error = response.json().get('error', {})
                reasons = {item.get('reason') for item in error.get('errors', []) if isinstance(item, dict)}
                reasons.update(item.get('reason') for item in error.get('details', []) if isinstance(item, dict))
                if reasons & {'accessNotConfigured', 'SERVICE_DISABLED', 'API_DISABLED'}:
                    code = 'PLAY_API_DISABLED'
            except Exception:
                pass
            raise play_error(code)
        if response.status_code == 404:
            raise play_error('PLAY_NOT_FOUND')
        if not 200 <= response.status_code < 300:
            raise play_error('PLAY_GOOGLE_UNAVAILABLE')
        return response.json() if response.content else {}
    except HTTPException:
        raise
    except GoogleAuthError:
        raise play_error('PLAY_CREDENTIALS') from None
    except Exception:
        # Provider exceptions can contain a token-bearing URL or private-key data.
        raise play_error('PLAY_GOOGLE_UNAVAILABLE') from None

def retrieve(token):
    return publisher_request('GET', '/purchases/productsv2/tokens/' + quote(token, safe=''))

def consume(product, token):
    publisher_request('POST', '/purchases/products/' + quote(product, safe='') + '/tokens/' + quote(token, safe='') + ':consume')

class VerifyPurchase(BaseModel):
    model_config = ConfigDict(extra='forbid')
    product_id: str = Field(min_length=1, max_length=100)
    purchase_token: str = Field(min_length=10, max_length=4096)

    @field_validator('purchase_token')
    @classmethod
    def opaque_token(cls, value):
        if any(ord(ch) < 33 or ord(ch) > 126 for ch in value):
            raise ValueError('Token pembelian tidak valid')
        return value

def receipt_details(data, uid, product):
    if not isinstance(data, dict) or not hmac.compare_digest(str(data.get('obfuscatedExternalAccountId', '')), account_id(uid)):
        raise HTTPException(403, 'Pembelian ini terkait dengan akun Kocehind yang berbeda')
    lines = data.get('productLineItem')
    if not isinstance(lines, list) or len(lines) != 1 or not isinstance(lines[0], dict) or lines[0].get('productId') != product:
        raise HTTPException(409, 'Produk pada bukti Google Play tidak cocok')
    context = data.get('purchaseStateContext')
    details = lines[0].get('productOfferDetails')
    if not isinstance(context, dict) or not isinstance(details, dict):
        raise HTTPException(502, 'Respons Google Play tidak valid')
    state = context.get('purchaseState')
    quantity = details.get('quantity', 1 if state != 'PURCHASED' else None)
    remaining = details.get('refundableQuantity', quantity if state != 'PURCHASED' else None)
    if state not in ('PURCHASED', 'PENDING', 'CANCELLED') or type(quantity) is not int or not 1 <= quantity <= 1000:
        raise HTTPException(502, 'Status atau jumlah pembelian Google Play tidak valid')
    if state == 'CANCELLED':
        remaining = 0
    if type(remaining) is not int or not 0 <= remaining <= quantity or details.get('rentOfferDetails') is not None:
        raise HTTPException(502, 'Jumlah koin Google Play belum dapat diverifikasi')
    consumption = details.get('consumptionState')
    if state == 'PURCHASED' and consumption not in ('CONSUMPTION_STATE_YET_TO_BE_CONSUMED', 'CONSUMPTION_STATE_CONSUMED'):
        raise HTTPException(502, 'Status penggunaan pembelian Google Play tidak valid')
    return state, quantity, remaining, consumption == 'CONSUMPTION_STATE_CONSUMED'


def read_receipt(uid, product, token):
    data = retrieve(token)
    # Validate identity and product before attempting compatibility recovery.
    if not isinstance(data, dict) or not hmac.compare_digest(str(data.get('obfuscatedExternalAccountId', '')), account_id(uid)):
        raise play_error('PLAY_ACCOUNT', 403)
    lines = data.get('productLineItem')
    if not isinstance(lines, list) or len(lines) != 1 or not isinstance(lines[0], dict) or lines[0].get('productId') != product:
        raise play_error('PLAY_REJECTED', 409)
    context, details = data.get('purchaseStateContext'), lines[0].get('productOfferDetails')
    if isinstance(context, dict) and context.get('purchaseState') == 'PURCHASED' and isinstance(details, dict):
        if any(key not in details for key in ('quantity', 'refundableQuantity', 'consumptionState')):
            # Do not guess a paid entitlement from incomplete v2 data. The older
            # official endpoint explicitly defines an omitted quantity as one.
            legacy = publisher_request('GET', '/purchases/products/' + quote(product, safe='') + '/tokens/' + quote(token, safe=''))
            if not isinstance(legacy, dict):
                raise play_error('PLAY_RECEIPT_INCOMPLETE')
            if not hmac.compare_digest(str(legacy.get('obfuscatedExternalAccountId', '')), account_id(uid)):
                raise play_error('PLAY_ACCOUNT', 403)
            if legacy.get('productId', product) != product:
                raise play_error('PLAY_REJECTED', 409)
            if type(legacy.get('purchaseState')) is not int or legacy['purchaseState'] != 0:
                raise play_error('PLAY_RECEIPT_INCOMPLETE')
            quantity = legacy.get('quantity', 1)
            remaining = legacy.get('refundableQuantity')
            consumed = legacy.get('consumptionState')
            if type(quantity) is not int or type(remaining) is not int or type(consumed) is not int or consumed not in (0, 1):
                raise play_error('PLAY_RECEIPT_INCOMPLETE')
            if 'quantity' in details and details['quantity'] != quantity:
                raise play_error('PLAY_RECEIPT_INCOMPLETE')
            if 'refundableQuantity' in details and type(details['refundableQuantity']) is not int:
                raise play_error('PLAY_RECEIPT_INCOMPLETE')
            data = deepcopy(data)
            offer = data['productLineItem'][0]['productOfferDetails']
            offer.setdefault('quantity', quantity)
            # A later refund may reduce the refundable quantity between reads.
            offer['refundableQuantity'] = min(offer.get('refundableQuantity', remaining), remaining)
            offer['consumptionState'] = ('CONSUMPTION_STATE_YET_TO_BE_CONSUMED', 'CONSUMPTION_STATE_CONSUMED')[consumed]
    receipt_details(data, uid, product)
    return data


def verification_id(uid, product, token):
    return hashlib.sha256((uid + '\0' + product + '\0' + token_digest(token)).encode()).hexdigest()


def queue_verification(db, uid, product, token):
    lock_users(db, uid)
    key = verification_id(uid, product, token)
    job = db.get(PlayVerification, key)
    if job is None:
        job = PlayVerification(id=key, user_id=uid, product_id=product,
            encrypted_token=token_cipher().encrypt(token.encode()).decode())
        db.add(job)
    db.commit()  # Durable before contacting Google; no wallet/row lock on network.
    return key


def record_verification(db, key, *, error=None, complete=False):
    job = db.get(PlayVerification, key)
    if job is None:
        return
    job.lease_until = None
    if error is None:
        job.state = 'verified' if complete else 'retry'
        job.last_code = ''
        job.attempts = 0
        job.next_check_at = utcnow() + timedelta(seconds=30)
    else:
        code = getattr(error, 'play_code', None)
        if not code:
            code = 'PLAY_ACCOUNT' if isinstance(error, HTTPException) and error.status_code == 403 else 'PLAY_REJECTED' if isinstance(error, HTTPException) and error.status_code in (409, 422) else 'PLAY_GOOGLE_UNAVAILABLE'
        job.last_code = code
        job.state = 'rejected' if isinstance(error, HTTPException) and error.status_code in (403, 409, 422) else 'retry'
        job.attempts += 1
        job.next_check_at = utcnow() + timedelta(seconds=min(900, 15 * 2 ** min(job.attempts, 6)))
        log.warning('play_verification code=%s job=%s', code, key[:12])
    db.commit()

def apply_receipt(db, uid, product, token, data):
    state, quantity, remaining, consumed = receipt_details(data, uid, product)
    digest = token_digest(token)
    lock_users(db, uid)
    row = db.scalar(select(PlayPurchase).where(PlayPurchase.token_hash == digest)
                    .with_for_update().execution_options(populate_existing=True))
    if row and state == 'CANCELLED' and 'quantity' not in data['productLineItem'][0]['productOfferDetails']:
        quantity = row.quantity
    if row and (row.user_id != uid or row.product_id != product or row.credited_at and row.quantity != quantity):
        raise HTTPException(409, 'Bukti pembelian sudah digunakan untuk transaksi lain')
    if row and row.status == 'cancelled':
        return row  # A delayed response may never resurrect a cancelled token.
    if row is None:
        if consumed:
            raise HTTPException(409, 'Pembelian sudah dipakai. Hubungi bantuan bila saldo belum tercatat.')
        row = PlayPurchase(token_hash=digest, user_id=uid, product_id=product, quantity=quantity,
                           coins_per_unit=PRODUCTS[product], encrypted_token=token_cipher().encrypt(token.encode()).decode())
        db.add(row)
        db.flush()
    if row.credited_at is None:
        row.quantity = quantity
    w = wallet(db, uid)
    if state == 'PURCHASED' and row.credited_at is None:
        # Record the full entitlement and any already-refunded quantity atomically.
        credit_coins(db, w, row.coins_per_unit * quantity, 'play_credit', digest)
        row.credited_at = utcnow()
    refund_units = quantity - remaining if row.credited_at else 0
    if refund_units > row.refunded_quantity:
        coins = (refund_units - row.refunded_quantity) * row.coins_per_unit
        removed = min(w.coins, coins)
        w.coins -= removed
        w.coin_debt += coins - removed
        reference = digest + ':' + str(refund_units)
        entry(db, w, 'play_refund', reference, 'coins', -removed)
        if coins > removed:
            entry(db, w, 'refund_debt', reference, 'debt', coins - removed)
        row.refunded_quantity = refund_units
    row.order_id = str(data.get('orderId', ''))[:200]
    if consumed and row.credited_at:
        row.consumed_at = row.consumed_at or utcnow()
    row.status = 'refunded' if row.credited_at and row.refunded_quantity == quantity else 'credited' if row.credited_at else state.lower()
    row.next_check_at = utcnow() + timedelta(seconds=30 if state == 'PENDING' or row.credited_at and not row.consumed_at else 86400)
    row.attempts = 0
    db.commit()
    return row

def finish_consumption(db, row, token, *, purchased=True):
    if purchased and row.credited_at and not row.consumed_at and row.status == 'credited':
        digest = row.token_hash
        db.commit()  # Never keep money locks during a provider request.
        consume(row.product_id, token)
        row = db.scalar(select(PlayPurchase).where(PlayPurchase.token_hash == digest).with_for_update())
        row.consumed_at = utcnow()
        row.next_check_at = utcnow() + timedelta(days=1)
        db.commit()

def response(db, row):
    w = wallet(db, row.user_id)
    return {'status': row.status, 'coins': w.coins, 'coin_debt': w.coin_debt,
            'credited_coins': row.coins_per_unit * row.quantity if row.credited_at else 0,
            'consumed': row.consumed_at is not None}

@router.get('/wallet/google-play/products')
def products(me=Depends(current_user)):
    return {'enabled': enabled(), 'account_id': account_id(me.id),
            'items': [{'product_id': product, 'coins': coins} for product, coins in PRODUCTS.items()]}

@router.post('/wallet/google-play/verify')
def verify(payload: VerifyPurchase, me=Depends(current_user), db=Depends(db_session)):
    if not enabled():
        raise HTTPException(503, 'Pembelian Google Play belum diaktifkan oleh pengelola')
    if payload.product_id not in PRODUCTS:
        raise HTTPException(422, 'Paket koin Google Play tidak dikenal')
    from .security import throttle
    from .events import user_event
    uid = me.id
    throttle(db, 'play-verify:' + uid, 120, 3600)
    key = queue_verification(db, uid, payload.product_id, payload.purchase_token)
    try:
        data = read_receipt(uid, payload.product_id, payload.purchase_token)
        row = apply_receipt(db, uid, payload.product_id, payload.purchase_token, data)
        try:
            finish_consumption(db, row, payload.purchase_token,
                purchased=data['purchaseStateContext']['purchaseState'] == 'PURCHASED')
        except HTTPException as error:
            db.rollback()  # The committed entitlement and retry schedule survive.
            record_verification(db, key, error=error)
        else:
            record_verification(db, key, complete=row.consumed_at is not None or row.status in ('cancelled', 'refunded'))
    except Exception as error:
        db.rollback()
        record_verification(db, key, error=error)
        raise
    user_event(uid, 'wallet_updated')
    return response(db, row)
