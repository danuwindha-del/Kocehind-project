import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import zipfile
import pytest

HERE = Path(__file__).resolve().parents[1]


def helper():
    spec = importlib.util.spec_from_file_location('catalog_source', HERE / 'TERAPKAN_SOURCE.py')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def source(tmp_path):
    target = tmp_path / 'kocehind_realtime_v2'
    shutil.copytree(HERE / 'tests/fixtures/source', target)
    (target / 'backend/app/main.py').write_text('main-unchanged\n')
    (target / 'websites').mkdir()
    (target / 'websites/design.css').write_bytes(b'current-design')
    (target / 'flutter').mkdir()
    (target / 'flutter/pubspec.yaml').write_bytes(b'version: 2.14.0+39\n')
    (target / 'MANIFEST_SHA256.txt').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest() + '  ' + str(f.relative_to(target)) + '\n' for f in sorted(target.rglob('*')) if f.is_file()))
    return target


def test_original_source_gains_recovery_and_catalogue_without_ui_changes(tmp_path):
    target = source(tmp_path)
    helper().apply(target)
    assert (target / 'websites/design.css').read_bytes() == b'current-design'
    assert (target / 'flutter/pubspec.yaml').read_bytes() == b'version: 2.14.0+39\n'
    assert 'OFFERED_PRODUCTS' in (target / 'backend/app/play_billing.py').read_text()
    assert 'run_queued_one' in (target / 'backend/app/play_worker.py').read_text()
    helper().apply(target)
    for line in (target / 'MANIFEST_SHA256.txt').read_text().splitlines():
        sha, name = line.split('  ', 1)
        assert hashlib.sha256((target / name).read_bytes()).hexdigest() == sha


def test_recovery_r1_source_is_accepted(tmp_path):
    target = source(tmp_path)
    for path in (HERE / 'tests/fixtures/runtime/app').glob('*.py'):
        shutil.copy2(path, target / 'backend/app'/path.name)
    helper().apply(target)
    assert 'OFFERED_PRODUCTS' in (target / 'backend/app/play_billing.py').read_text()


def test_nested_package_hashes_are_updated_without_android_build_change(tmp_path):
    tree = source(tmp_path)
    package = tmp_path / 'Kocehind_v2.14.0'
    package.mkdir()
    archive = package / 'SOURCE_LENGKAP_v2.14.0.zip'
    with zipfile.ZipFile(archive, 'w') as z:
        for f in tree.rglob('*'):
            if f.is_file():
                z.write(f, 'kocehind_realtime_v2/' + str(f.relative_to(tree)))
    (package / 'package.json').write_text(json.dumps({'version': '2.14.0', 'min_build': 39}))
    (package / 'SHA256SUMS.txt').write_text('unused  package.json\nunused  '+archive.name+'\n')
    helper().apply(package)
    data = json.loads((package / 'package.json').read_text())
    assert data['min_build'] == 39 and data['play_coin_catalog_revision'] == 1
    assert data['source_sha256'] == hashlib.sha256(archive.read_bytes()).hexdigest()
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert z.read('kocehind_realtime_v2/flutter/pubspec.yaml') == b'version: 2.14.0+39\n'
    for line in (package / 'SHA256SUMS.txt').read_text().splitlines():
        sha, name = line.split('  ', 1)
        assert hashlib.sha256((package / name).read_bytes()).hexdigest() == sha


def test_custom_module_is_not_overwritten(tmp_path):
    target = source(tmp_path)
    (target / 'backend/app/play_billing.py').write_bytes(b'custom-code')
    with pytest.raises(RuntimeError, match='custom'):
        helper().apply(target)
    assert (target / 'backend/app/play_billing.py').read_bytes() == b'custom-code'


def test_zip_path_traversal_is_rejected(tmp_path):
    archive = tmp_path / 'SOURCE_LENGKAP_v2.14.0.zip'
    with zipfile.ZipFile(archive, 'w') as z:
        z.writestr('../invalid', 'invalid')
    with pytest.raises(RuntimeError, match='Struktur'):
        helper().apply(tmp_path)
