# Pengujian katalog Google Play tanpa bonus — 30 Oktober 2026

Dasar perubahan: source Kocehind 2.14.0 yang diunggah pengguna, ditambah Play Recovery R1 yang telah dipasang pengguna. Jumlah koin dipertahankan sesuai pilihan pengguna: 25, 75, 160, 350, 750, 1.600, 3.500. Setiap angka adalah total akhir per satu unit.

| Pemeriksaan | Hasil |
| --- | --- |
| Suite backend katalog baru, Play Billing, pemulihan R1, koin admin, dompet/schema/ledger lama, dan Kipay | 107 lulus |
| Installer dan helper source | 12 lulus |
| Helper source pada salinan paket lengkap Kocehind_v2.14.0.zip asli | Lulus; 630 file source yang tidak diubah tetap identik byte per byte |
| Nomor build Android dan file UI Flutter/web setelah penyimpanan ke source | Tidak berubah |
| Pemeriksaan sintaks Python, manifest SHA-256 dan CRC ZIP | Lulus |

Tes katalog baru lebih dahulu dijalankan pada implementasi lama: 10 gagal dan 4 lulus. Kegagalan mencakup daftar tujuh SKU baru dan penambahan jumlah koin yang diminta. Setelah perubahan, seluruh kasus tersebut lulus. Kasus tambahan membuktikan pembelian berikutnya dengan token baru untuk paket yang sama dapat menambah saldo lagi.

Pengujian memakai HTTP FastAPI dan transaksi database SQLite terisolasi. Hanya respons Google yang diganti. Kredit setiap paket tepat sesuai nominal, percobaan ulang token yang sama tidak menambah dua kali, klaim bonus dari klien ditolak, quantity dua menggandakan jumlah paket tanpa tambahan bonus, dan empat SKU lama tetap dapat pulih dari pending ke paid. Nilai pendapatan host dan paket web juga diperiksa tetap sama.

Tes installer menggunakan systemd pengganti dan path sementara untuk memeriksa penolakan payload/source custom, preflight tanpa pergantian kode, rollback ketika restart gagal, pemasangan yang hanya mengganti modul katalog, dan pemasangan ulang tanpa restart yang tidak perlu. Test helper memeriksa source original/R1, hash arsip/paket, pengulangan, penolakan source custom dan path traversal.

Installer belum dijalankan pada VPS produksi pengguna. Tidak ada produk/harga yang dibuat di Play Console dalam pengujian ini, tidak ada transaksi pembayaran nyata, dan tidak ada APK/AAB yang dibangun. Harga aplikasi berasal dari Google Play sehingga validasi produk, negara dan harga tetap dilakukan pada akun Play Console pemilik.
