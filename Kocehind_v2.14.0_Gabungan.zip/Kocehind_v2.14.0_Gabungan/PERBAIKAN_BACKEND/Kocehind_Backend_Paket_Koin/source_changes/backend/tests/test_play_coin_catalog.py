"""The displayed Play catalogue and actual credits use the same exact totals."""
from copy import deepcopy
from uuid import uuid4
from sqlalchemy import select
import pytest
from test_play_billing_v214 import client, setup_purchase, verify
from v210_db import isolated_v210_db
from app.core import SessionLocal, utcnow
from app.wallet_models import WalletConfig

NEW = {f'kocehind_coin_{n}': n for n in (25, 75, 160, 350, 750, 1600, 3500)}


def test_only_the_seven_new_packages_are_offered(client, monkeypatch):
    play, headers, uid, body, receipt = setup_purchase(client, monkeypatch)
    response = client.get('/wallet/google-play/products', headers=headers)
    assert response.status_code == 200
    assert {row['product_id']: row['coins'] for row in response.json()['items']} == NEW
    assert len(response.json()['items']) == 7
    assert client.get('/wallet/google-play/products').status_code == 401


@pytest.mark.parametrize('product,coins', list(NEW.items()))
def test_each_package_credits_the_exact_total_once_without_extra_bonus(client, monkeypatch, product, coins):
    play, headers, uid, body, receipt = setup_purchase(client, monkeypatch)
    body['product_id'] = product
    receipt['productLineItem'][0]['productId'] = product
    response = verify(client, headers, body)
    assert response.status_code == 200, response.text
    assert response.json()['coins'] == coins
    assert response.json()['credited_coins'] == coins
    assert verify(client, headers, body).json()['coins'] == coins
    assert verify(client, headers, {**body, 'bonus': 1000}).status_code == 422


@pytest.mark.parametrize('coins', [100, 500, 1000, 5000])
def test_legacy_pending_purchases_remain_recoverable_without_being_listed(client, monkeypatch, coins):
    play, headers, uid, body, receipt = setup_purchase(client, monkeypatch, state='PENDING')
    product = f'kocehind_coin_{coins}'
    body['product_id'] = product
    receipt['productLineItem'][0]['productId'] = product
    assert verify(client, headers, body).json()['coins'] == 0
    receipt['purchaseStateContext']['purchaseState'] = 'PURCHASED'
    with SessionLocal() as db:
        job = db.scalar(select(play.PlayVerification))
        job.next_check_at = utcnow()
        db.commit()
    from app.play_worker import run_one
    assert run_one()
    assert client.get('/wallet', headers=headers).json()['coins'] == coins


def test_web_prices_and_gift_income_setting_are_preserved(client, monkeypatch):
    play, headers, uid, body, receipt = setup_purchase(client, monkeypatch)
    with SessionLocal() as db:
        db.get(WalletConfig, 'main').income_per_coin = 17
        db.commit()
    web_before = client.get('/public/coins/packages').json()
    body['product_id'] = 'kocehind_coin_350'
    receipt['productLineItem'][0]['productId'] = body['product_id']
    response = verify(client, headers, body)
    assert response.status_code == 200, response.text
    assert response.json()['coins'] == 350
    assert client.get('/public/coins/packages').json() == web_before
    with SessionLocal() as db:
        assert db.get(WalletConfig, 'main').income_per_coin == 17


def test_quantity_multiplies_the_package_total_without_bonus(client, monkeypatch):
    play, headers, uid, body, receipt = setup_purchase(client, monkeypatch, quantity=2)
    body['product_id'] = 'kocehind_coin_350'
    receipt['productLineItem'][0]['productId'] = body['product_id']
    response = verify(client, headers, body)
    assert response.status_code == 200, response.text
    assert response.json()['coins'] == 700


def test_a_new_purchase_of_the_same_package_can_be_credited_again(client, monkeypatch):
    play, headers, uid, body, receipt = setup_purchase(client, monkeypatch)
    body['product_id'] = 'kocehind_coin_25'
    receipt['productLineItem'][0]['productId'] = body['product_id']
    assert verify(client, headers, body).json()['coins'] == 25
    body['purchase_token'] = 'test-token-' + uuid4().hex
    receipt['orderId'] = 'GPA.second-purchase'
    assert verify(client, headers, body).json()['coins'] == 50
