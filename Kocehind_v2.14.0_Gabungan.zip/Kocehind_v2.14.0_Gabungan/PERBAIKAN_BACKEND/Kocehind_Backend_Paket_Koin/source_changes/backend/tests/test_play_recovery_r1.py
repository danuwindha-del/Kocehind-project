"""Real HTTP/database regression checks; Google alone is substituted."""
from copy import deepcopy
from datetime import timedelta
from unittest.mock import Mock
import pytest
from fastapi import HTTPException
from sqlalchemy import select, func
from test_play_billing_v214 import client, setup_purchase, verify
from v210_db import isolated_v210_db
from app.core import SessionLocal, utcnow
from app.wallet_models import WalletEntry


def test_first_google_outage_is_queued_and_recovers_without_the_phone(client, monkeypatch):
    play, headers, uid, body, receipt = setup_purchase(client, monkeypatch)
    def unavailable(token):
        raise HTTPException(503, 'Google sementara tidak tersedia')
    monkeypatch.setattr(play, 'retrieve', unavailable)
    assert verify(client, headers, body).status_code == 503
    with SessionLocal() as db:
        job = db.scalar(select(play.PlayVerification))
        assert job.user_id == uid and job.state == 'retry'
        assert body['purchase_token'] not in job.encrypted_token
        job.next_check_at = utcnow() - timedelta(seconds=1)
        db.commit()
    monkeypatch.setattr(play, 'retrieve', lambda token: deepcopy(receipt))
    from app.play_worker import run_one
    assert run_one()
    assert client.get('/wallet', headers=headers).json()['coins'] == 100
    assert verify(client, headers, body).json()['coins'] == 100
    with SessionLocal() as db:
        assert db.scalar(select(func.count()).select_from(WalletEntry).where(WalletEntry.kind == 'play_credit')) == 1
        assert db.scalar(select(play.PlayVerification)).state == 'verified'


def test_google_permission_error_has_an_actionable_secret_free_code(client, monkeypatch):
    from app import play_billing as play
    from google.oauth2 import service_account
    from google.auth.transport import requests
    monkeypatch.setattr(service_account.Credentials, 'from_service_account_file', Mock(return_value=object()))
    response = Mock(status_code=403)
    response.json.return_value = {'error': {'message': 'SECRET-DO-NOT-PRINT', 'errors': [{'reason': 'insufficientPermissions'}]}}
    session = Mock()
    session.__enter__ = Mock(return_value=session)
    session.__exit__ = Mock(return_value=False)
    session.request.return_value = response
    monkeypatch.setattr(requests, 'AuthorizedSession', Mock(return_value=session))
    with pytest.raises(HTTPException) as caught:
        play.retrieve('private-purchase-token')
    assert caught.value.status_code == 503
    assert '[PLAY_PERMISSION]' in caught.value.detail
    assert 'SECRET' not in caught.value.detail and 'private-purchase-token' not in caught.value.detail


def test_incomplete_v2_is_completed_only_from_a_matching_google_receipt(client, monkeypatch):
    play, h, uid, body, receipt = setup_purchase(client, monkeypatch)
    del receipt['productLineItem'][0]['productOfferDetails']['quantity']
    legacy = {'purchaseState': 0, 'consumptionState': 0, 'refundableQuantity': 1,
              'productId': body['product_id'], 'obfuscatedExternalAccountId': play.account_id(uid)}
    paths = []
    def publisher(method, path, **kwargs):
        paths.append(path)
        return deepcopy(legacy)
    monkeypatch.setattr(play, 'publisher_request', publisher)
    assert verify(client, h, body).json()['coins'] == 100
    assert any('/purchases/products/' in p for p in paths)


def test_legacy_fallback_never_accepts_another_account(client, monkeypatch):
    play, h, uid, body, receipt = setup_purchase(client, monkeypatch)
    del receipt['productLineItem'][0]['productOfferDetails']['quantity']
    monkeypatch.setattr(play, 'publisher_request', lambda *a, **k: {
        'purchaseState': 0, 'consumptionState': 0, 'quantity': 1, 'refundableQuantity': 1,
        'productId': body['product_id'], 'obfuscatedExternalAccountId': 'another-account'})
    assert verify(client, h, body).status_code == 403
    assert client.get('/wallet', headers=h).json()['coins'] == 0


def test_a_forged_initial_claim_never_reserves_the_real_buyers_token(client, monkeypatch):
    from test_social import account
    play, h, uid, body, receipt = setup_purchase(client, monkeypatch)
    _, thief, _ = account(client, 'wrongclaim')
    assert verify(client, thief, body).status_code == 403
    assert verify(client, h, body).json()['coins'] == 100


def test_receipt_state_is_rechecked_before_consume_after_an_earlier_credit(client, monkeypatch):
    play, h, uid, body, receipt = setup_purchase(client, monkeypatch)
    monkeypatch.setattr(play, 'consume', Mock(side_effect=HTTPException(503, 'retry')))
    assert verify(client, h, body).json()['coins'] == 100
    receipt['purchaseStateContext']['purchaseState'] = 'PENDING'
    consume = Mock()
    monkeypatch.setattr(play, 'consume', consume)
    assert verify(client, h, body).status_code == 200
    consume.assert_not_called()


@pytest.mark.parametrize('field', ['quantity', 'refundableQuantity', 'consumptionState'])
def test_missing_v2_field_never_credits_when_fallback_is_unavailable(client, monkeypatch, field):
    play, h, uid, body, receipt = setup_purchase(client, monkeypatch)
    del receipt['productLineItem'][0]['productOfferDetails'][field]
    def unavailable(*args, **kwargs):
        raise play.play_error('PLAY_PERMISSION')
    monkeypatch.setattr(play, 'publisher_request', unavailable)
    assert verify(client, h, body).status_code == 503
    assert client.get('/wallet', headers=h).json()['coins'] == 0
    with SessionLocal() as db:
        job = db.scalar(select(play.PlayVerification))
        assert job.state == 'retry' and job.last_code == 'PLAY_PERMISSION'


def test_queued_pending_payment_does_not_credit_then_recovers_once_paid(client, monkeypatch):
    play, h, uid, body, receipt = setup_purchase(client, monkeypatch, state='PENDING')
    assert verify(client, h, body).json()['status'] == 'pending'
    from app.play_worker import run_one
    for state in ('PENDING', 'PURCHASED'):
        receipt['purchaseStateContext']['purchaseState'] = state
        with SessionLocal() as db:
            job = db.scalar(select(play.PlayVerification))
            job.next_check_at = utcnow()
            db.commit()
        assert run_one()
        assert client.get('/wallet', headers=h).json()['coins'] == (100 if state == 'PURCHASED' else 0)


def test_google_api_disabled_is_different_from_a_wrong_app_account(client, monkeypatch):
    from app import play_billing as play
    from google.oauth2 import service_account
    from google.auth.transport import requests
    monkeypatch.setattr(service_account.Credentials, 'from_service_account_file', Mock(return_value=object()))
    response = Mock(status_code=403)
    response.json.return_value = {'error': {'details': [{'reason': 'SERVICE_DISABLED'}]}}
    session = Mock()
    session.__enter__ = Mock(return_value=session)
    session.__exit__ = Mock(return_value=False)
    session.request.return_value = response
    monkeypatch.setattr(requests, 'AuthorizedSession', Mock(return_value=session))
    with pytest.raises(HTTPException) as caught:
        play.retrieve('do-not-display-this-token')
    assert '[PLAY_API_DISABLED]' in caught.value.detail
    assert caught.value.status_code == 503


@pytest.mark.parametrize('remaining', [None, '1'])
def test_invalid_existing_refund_count_is_not_guessed_during_compatibility_recovery(client, monkeypatch, remaining):
    play, h, uid, body, receipt = setup_purchase(client, monkeypatch)
    details = receipt['productLineItem'][0]['productOfferDetails']
    del details['quantity']
    details['refundableQuantity'] = remaining
    monkeypatch.setattr(play, 'publisher_request', lambda *a, **k: {
        'purchaseState': 0, 'consumptionState': 0, 'quantity': 1, 'refundableQuantity': 1,
        'productId': body['product_id'], 'obfuscatedExternalAccountId': play.account_id(uid)})
    assert verify(client, h, body).status_code == 503
    assert client.get('/wallet', headers=h).json()['coins'] == 0
