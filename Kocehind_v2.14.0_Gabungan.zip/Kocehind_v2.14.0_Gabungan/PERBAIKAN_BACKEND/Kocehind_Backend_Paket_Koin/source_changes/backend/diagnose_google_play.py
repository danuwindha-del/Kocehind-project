#!/usr/bin/env python3
"""Secret-free Play checks; --retry only schedules already submitted receipts."""
import argparse
import os
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--google', action='store_true', help='Check backend catalog API access, without a payment')
    parser.add_argument('--retry', action='store_true', help='Reschedule existing unfinished verification jobs')
    args = parser.parse_args()
    runtime = Path('/opt/kocehind/backend')
    if os.geteuid() == 0:
        from dotenv import dotenv_values
        import pwd
        config = dotenv_values('/etc/kocehind/backend.env', interpolate=False)
        os.environ.update({k: v for k, v in config.items() if isinstance(v, str)})
        person = pwd.getpwnam('kocehind')
        os.initgroups(person.pw_name, person.pw_gid)
        os.setgid(person.pw_gid)
        os.setuid(person.pw_uid)
    if runtime.is_dir():
        os.chdir(runtime)
        sys.path.insert(0, str(runtime))
    from sqlalchemy import func, inspect, select
    from app.core import SessionLocal, engine, utcnow
    from app import play_billing as play
    print('Google Play recovery R1')
    problems = not play.enabled()
    for service in ('kocehind-api', 'kocehind-play'):
        result = subprocess.run(['systemctl', 'is-active', service], capture_output=True, text=True, timeout=10)
        print(service + ': ' + (result.stdout.strip() or 'tidak ditemukan'))
        if result.returncode and (service == 'kocehind-api' or play.enabled()):
            problems = True
    print('PLAY_BILLING_ENABLED: ' + ('aktif' if play.enabled() else 'NONAKTIF'))
    credential = Path(os.getenv('PLAY_SERVICE_ACCOUNT_FILE', '/nonexistent'))
    try:
        import json
        from google.oauth2 import service_account
        data = json.loads(credential.read_text())
        if data.get('type') != 'service_account' or data.get('token_uri') != 'https://oauth2.googleapis.com/token':
            raise ValueError()
        credentials = service_account.Credentials.from_service_account_info(data,
            scopes=['https://www.googleapis.com/auth/androidpublisher'])
        print('Credential: dapat dibaca pengguna service; format valid')
    except Exception:
        problems = True
        print('Credential: GAGAL dibaca/divalidasi oleh pengguna service [PLAY_CREDENTIALS]')
    if play.PlayVerification.__tablename__ not in inspect(engine).get_table_names():
        print('Tabel antrean: belum terpasang; jalankan PASANG_PERBAIKAN.py')
        return 2
    with SessionLocal() as db:
        if args.retry:
            from sqlalchemy import or_
            jobs = db.scalars(select(play.PlayVerification).where(
                play.PlayVerification.state.in_(('queued', 'retry'))).with_for_update()).all()
            for job in jobs:
                job.next_check_at = utcnow()
                # Do not steal a live worker's lease.
            receipts = db.scalars(select(play.PlayPurchase).where(
                play.PlayPurchase.status.in_(('pending', 'credited')),
                or_(play.PlayPurchase.credited_at.is_(None), play.PlayPurchase.consumed_at.is_(None)))
                .with_for_update()).all()
            for row in receipts:
                row.next_check_at = utcnow()
            db.commit()
            print('Dijadwalkan ulang: %d antrean dan %d receipt belum selesai; tidak mengubah saldo.' % (len(jobs), len(receipts)))
        for state, count in db.execute(select(play.PlayVerification.state, func.count()).group_by(play.PlayVerification.state)):
            print('Antrean ' + state + ': ' + str(count))
        for status, count in db.execute(select(play.PlayPurchase.status, func.count()).group_by(play.PlayPurchase.status)):
            print('Receipt ' + status + ': ' + str(count))
        for job in db.scalars(select(play.PlayVerification).order_by(play.PlayVerification.created_at.desc()).limit(5)):
            print('Job ' + job.id[:12] + ': ' + job.state + ' code=' + (job.last_code or 'OK') + ' retry=' + str(job.attempts))
        if db.scalar(select(func.count()).select_from(play.PlayVerification)) == 0:
            print('Belum ada token yang diterima antrean ini. Di aplikasi akun pembeli, tekan Periksa pembelian.')
        candidate = db.scalar(select(play.PlayVerification).where(play.PlayVerification.state != 'rejected')
            .order_by(play.PlayVerification.created_at.desc()).limit(1))
        if candidate is None:
            candidate = db.scalar(select(play.PlayPurchase).order_by(play.PlayPurchase.created_at.desc()).limit(1))
        sample = (candidate.user_id, candidate.product_id, candidate.encrypted_token) if candidate else None
    if args.google:
        try:
            if sample:
                uid, product, encrypted = sample
                token = play.token_cipher().decrypt(encrypted.encode()).decode()
                receipt = play.read_receipt(uid, product, token)
                print('Google API receipt terbaru: berhasil; status=' + receipt['purchaseStateContext']['purchaseState'] + '. Diagnosis tidak menambah saldo; worker memproses antrean.')
            else:
                from google.auth.transport.requests import Request
                class BoundedRequest(Request):
                    def __call__(self, *args, **kwargs):
                        kwargs['timeout'] = 10
                        return super().__call__(*args, **kwargs)
                if problems:
                    print('Perbaiki service/configuration di atas terlebih dahulu.')
                    return 2
                credentials.refresh(BoundedRequest())
                print('OAuth Google: berhasil. Belum ada token untuk menguji izin pesanan. Tekan Periksa pembelian di HP, lalu ulangi diagnosis.')
        except Exception as error:
            code = getattr(error, 'play_code', 'PLAY_GOOGLE_UNAVAILABLE')
            print('Google API: [' + code + '] ' + play.ERRORS.get(code, 'Belum dapat diperiksa.'))
            return 2
    print('Laporan tidak menampilkan purchase token, key, email credential, order ID atau identitas pengguna.')
    return 2 if problems else 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        print('Diagnosis belum selesai: ' + type(error).__name__ + '. Jangan kirim backend.env atau key JSON.')
        raise SystemExit(2) from None
