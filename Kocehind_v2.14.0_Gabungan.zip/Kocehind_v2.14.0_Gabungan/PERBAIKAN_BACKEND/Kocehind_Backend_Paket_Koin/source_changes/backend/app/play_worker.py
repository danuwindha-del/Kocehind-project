"""Recover pending purchases, consume credited coins, and reconcile Play refunds."""
import logging
import time
from datetime import timedelta
from sqlalchemy import DateTime, String, Text, or_, select
from sqlalchemy.orm import Mapped, mapped_column
from .core import Base, SessionLocal, utcnow
from . import play_billing as play

log = logging.getLogger('kocehind.play')

class PlayRefundScan(Base):
    __tablename__ = 'google_play_refund_scan'
    id: Mapped[str] = mapped_column(String(20), primary_key=True)
    next_at: Mapped[object] = mapped_column(DateTime, default=utcnow)
    page_token: Mapped[str] = mapped_column(Text, default='')

def run_queued_one():
    with SessionLocal() as db:
        now = utcnow()
        job = db.scalar(select(play.PlayVerification).where(
            play.PlayVerification.state.in_(('queued', 'retry')),
            play.PlayVerification.next_check_at <= now,
            or_(play.PlayVerification.lease_until.is_(None), play.PlayVerification.lease_until <= now))
            .order_by(play.PlayVerification.next_check_at).with_for_update(skip_locked=True).limit(1))
        if job is None:
            return False
        key, uid, product, encrypted = job.id, job.user_id, job.product_id, job.encrypted_token
        job.lease_until = now + timedelta(seconds=120)
        db.commit()
        try:
            token = play.token_cipher().decrypt(encrypted.encode()).decode()
            data = play.read_receipt(uid, product, token)
            row = play.apply_receipt(db, uid, product, token, data)
            play.finish_consumption(db, row, token,
                purchased=data['purchaseStateContext']['purchaseState'] == 'PURCHASED')
            play.record_verification(db, key, complete=row.consumed_at is not None or row.status in ('cancelled', 'refunded'))
            from .events import user_event
            user_event(uid, 'wallet_updated')
        except Exception as error:
            db.rollback()
            play.record_verification(db, key, error=error)
        return True


def run_one():
    if run_queued_one():
        return True
    with SessionLocal() as db:
        now = utcnow()
        row = db.scalar(select(play.PlayPurchase).where(
            play.PlayPurchase.status.in_(('pending', 'credited')),
            play.PlayPurchase.next_check_at <= now,
            or_(play.PlayPurchase.lease_until.is_(None), play.PlayPurchase.lease_until <= now))
            .order_by(play.PlayPurchase.next_check_at).with_for_update(skip_locked=True).limit(1))
        if row is None:
            return False
        digest, uid, product = row.token_hash, row.user_id, row.product_id
        row.lease_until = now + timedelta(seconds=120)
        encrypted = row.encrypted_token
        db.commit()
        try:
            token = play.token_cipher().decrypt(encrypted.encode()).decode()
            receipt = play.read_receipt(uid, product, token)
            row = play.apply_receipt(db, uid, product, token, receipt)
            play.finish_consumption(db, row, token,
                purchased=receipt['purchaseStateContext']['purchaseState'] == 'PURCHASED')
            row.lease_until = None
            db.commit()
            from .events import user_event
            user_event(uid, 'wallet_updated')
        except Exception as error:
            db.rollback()
            row = db.get(play.PlayPurchase, digest)
            row.lease_until = None
            row.attempts += 1
            row.next_check_at = utcnow() + timedelta(seconds=min(3600, 15 * 2 ** min(row.attempts, 8)))
            db.commit()
            log.warning('Verifikasi Play tertunda; receipt=%s code=%s', digest[:12],
                        getattr(error, 'play_code', 'PLAY_GOOGLE_UNAVAILABLE'))
        return True

def scan_refunds():
    """Persist pagination; rescan the provider's 30-day voided window every hour.

    A void notice only locates our receipt. The current Google purchase response
    supplies cumulative refundableQuantity, so duplicate partial notices cannot
    remove coins twice. Unknown tokens never create wallets or purchases.
    """
    with SessionLocal() as db:
        scan = db.get(PlayRefundScan, 'main')
        if scan is None:
            scan = PlayRefundScan(id='main')
            db.add(scan)
            db.commit()
        if scan.next_at > utcnow():
            return False
        params = {'maxResults': 1000, 'type': 0, 'includeQuantityBasedPartialRefund': 'true'}
        if scan.page_token:
            params['token'] = scan.page_token
        db.commit()
        data = play.publisher_request('GET', '/purchases/voidedpurchases', params=params)
        for notice in data.get('voidedPurchases', []):
            token = notice.get('purchaseToken')
            if not isinstance(token, str):
                continue
            row = db.get(play.PlayPurchase, play.token_digest(token))
            if row is None:
                continue
            uid, product = row.user_id, row.product_id
            db.commit()
            play.apply_receipt(db, uid, product, token, play.read_receipt(uid, product, token))
            from .events import user_event
            user_event(uid, 'wallet_updated')
        scan = db.get(PlayRefundScan, 'main')
        scan.page_token = data.get('tokenPagination', {}).get('nextPageToken', '')
        scan.next_at = utcnow() + timedelta(seconds=1 if scan.page_token else 3600)
        db.commit()
        return True

def main():
    logging.basicConfig(level=logging.INFO)
    while True:
        if play.enabled():
            try:
                run_one()
                scan_refunds()
            except Exception:
                log.warning('Sinkronisasi Google Play belum selesai; akan dicoba kembali')
        time.sleep(5)

if __name__ == '__main__':
    main()
