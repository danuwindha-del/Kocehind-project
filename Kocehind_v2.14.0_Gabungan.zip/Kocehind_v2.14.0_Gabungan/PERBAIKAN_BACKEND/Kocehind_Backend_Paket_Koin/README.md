# Kocehind — backend tujuh paket Google Play tanpa bonus

Pembaruan untuk backend existing **Kocehind 2.14.0 dengan Play Recovery R1**, seperti VPS yang sudah berhasil menerima pembelian 100 koin Anda. Paket ini memperbarui modul katalog pembayaran pada backend tersebut. Ini bukan installer VPS kosong atau pengganti seluruh source aplikasi.

Jumlah akhir dipertahankan sesuai pilihan Anda: **25, 75, 160, 350, 750, 1.600, dan 3.500 koin**. Setiap pembelian satu unit menerima tepat jumlah itu, tanpa penambahan bonus. Semua paket adalah konsumabel dan dapat dibeli berulang setelah konfirmasi konsumsi selesai; paket 25 koin tidak diberi pembatasan sekali per akun.

## 1. Siapkan produk di Play Console terlebih dahulu

Pada aplikasi **id.web.kocehind**, buka **Monetisasi dengan Google Play > Produk > Produk sekali beli**, lalu buat/aktifkan produk berikut dengan Product ID **persis** sama.

| Product ID | Koin masuk per satu unit | Harga target Indonesia |
| --- | ---: | ---: |
| `kocehind_coin_25` | 25 | Rp1.000 |
| `kocehind_coin_75` | 75 | Rp3.000 |
| `kocehind_coin_160` | 160 | Rp6.000 |
| `kocehind_coin_350` | 350 | Rp12.000 |
| `kocehind_coin_750` | 750 | Rp25.000 |
| `kocehind_coin_1600` | 1.600 | Rp50.000 |
| `kocehind_coin_3500` | 3.500 | Rp100.000 |

Harga di atas adalah target yang Anda tentukan. Harga, mata uang, negara penjualan dan validasi rentang harga diatur pada **Play Console**. Aplikasi menampilkan harga yang dikirim Google Play. Backend menentukan jumlah koin dari Product ID yang telah diverifikasi, dan tidak mengatur harga checkout Google.

Aktifkan opsi pembelian yang tersedia untuk pengguna Indonesia. Gunakan produk sekali beli biasa untuk koin. Setelah tujuh produk siap, pasang backend di langkah 2. Sebab katalog aplikasi akan berganti ke tujuh ID baru, produk yang belum aktif/tersedia di Play dapat tidak muncul.

ID lama `kocehind_coin_100`, `kocehind_coin_500`, `kocehind_coin_1000`, dan `kocehind_coin_5000` tetap diterima untuk verifikasi, pemulihan pembayaran dan refund. Backend tidak menawarkan keempat ID itu dalam daftar baru. Jika ingin menghentikan penjualan produk lama sepenuhnya, kelola ketersediaannya di Play Console; pemetaan verifikasi historis pada server tetap dipertahankan.

## 2. Pasang pada VPS backend yang sedang berjalan

Upload Kocehind_Backend_Paket_Koin.zip ke /root VPS backend. Updater melakukan restart singkat pada API dan worker Google Play; pilih waktu yang sesuai untuk layanan Anda.

```bash
cd /root
unzip -o Kocehind_Backend_Paket_Koin.zip
cd /root/Kocehind_Backend_Paket_Koin
sha256sum -c SHA256SUMS.txt
/opt/kocehind/venv/bin/python UPDATE_PAKET_KOIN.py --check
/opt/kocehind/venv/bin/python UPDATE_PAKET_KOIN.py
systemctl is-active kocehind-api kocehind-play
```

Updater memeriksa kecocokan source R1, melakukan import sebagai pengguna service dengan akses database baca saja, mencadangkan modul lama, mengganti **app/play_billing.py** secara atomik, lalu memulai ulang service. Jika pergantian/restart/health gagal, modul lama dipulihkan. Source custom yang tidak dikenali akan ditolak agar tidak tertimpa.

Saldo, receipt, antrean Google Play, database, key, JWT_SECRET, credential, konfigurasi Kipay/web, konfigurasi pendapatan host, worker lain, UI/UX dan aset tidak diganti. Tidak ada migrasi database atau pemasangan dependency baru. Versi API tetap **2.14.0**, dengan revisi katalog paket 1 di metadata paket ini.

## 3. Muat paket di aplikasi

Buka **Koin dan pendapatan > Muat paket**. Katalog dasar menggunakan APK 2.14.0 yang sudah terpasang; **tidak perlu build APK baru** untuk perubahan daftar ini. Aplikasi memuat daftar Product ID dari server dan harga dari Google Play. Apabila hanya sebagian paket terlihat, periksa aktivasi, negara penjualan, opsi pembelian dan kecocokan ID produk tersebut di Play Console.

Pembelian berhasil tetap diverifikasi Google di backend dan dikredit satu kali. Pending belum dikredit; koneksi gagal dipulihkan melalui antrean R1. Gunakan Periksa pembelian bila perlu memulihkan receipt yang belum terkirim. Pembelian baru dengan token baru dapat menambah jumlah paket yang sama lagi.

## 4. Simpan juga pada source untuk update berikutnya

Untuk folder paket utama Anda:

```bash
cd /root/Kocehind_Backend_Paket_Koin
/opt/kocehind/venv/bin/python TERAPKAN_SOURCE.py /root/Kocehind_v2.14.0
```

Sesuaikan path jika folder utama berada di lokasi lain. Helper menerima folder paket yang berisi SOURCE_LENGKAP_v2.14.0.zip, atau folder source kocehind_realtime_v2 langsung. Source original 2.14.0 maupun source yang sudah diberi R1 dapat digunakan. Katalog baru dan perbaikan backend Recovery R1 disimpan bersama ke source; hash arsip/paket diperbarui. Nomor build Android dan file Flutter/web tetap mengikuti source Anda. Berkas sebelum perubahan dicadangkan dengan akhiran .before-coin-catalog-v1.

Perintah ini memperbarui source, bukan backend berjalan. Jalankan langkah 2 untuk pemasangan backend. Menggunakan ulang source lama tanpa pembaruan ini pada update berikutnya dapat mengembalikan katalog lama.

## Pengaturan pendapatan host

Menghilangkan bonus tidak mengubah tarif rupiah pendapatan host. Updater menampilkan tarif aktif saat preflight dan mempertahankan nilai pengaturan admin tersebut. Jika masih Rp50 per koin, pemakaian 3.500 koin menjadi gift mencatat Rp175.000 pendapatan host, sedangkan harga target paketnya Rp100.000. Tinjau perhitungan tarif tersebut pada **Admin > Gift dan penarikan > Pengaturan pendapatan**, termasuk biaya layanan Google Play. Paket ini tidak memilih atau mengubah tarif pendapatan host atas nama Anda.

Paket pembelian web Kipay juga tetap mengikuti pengaturan paket koin web di admin.

## Verifikasi

Lihat HASIL_PENGUJIAN.md. Pengujian menggunakan database terisolasi dan respons Google pengganti. Produk Play Console belum dibuat atau diaktifkan oleh paket ini, dan updater belum dijalankan pada VPS Anda. Tidak ada APK/AAB baru atau transaksi pembayaran nyata dalam pengujian lokal.

Referensi:

- https://developer.android.com/google/play/billing/integrate
- https://developers.google.com/android-publisher/api-ref/rest/v3/purchases.productsv2
- https://support.google.com/googleplay/android-developer/answer/112622
