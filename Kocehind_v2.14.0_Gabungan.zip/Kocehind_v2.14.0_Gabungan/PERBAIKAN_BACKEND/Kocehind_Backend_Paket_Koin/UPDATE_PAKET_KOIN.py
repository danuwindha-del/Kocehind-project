#!/usr/bin/env python3
"""Update the Play coin catalogue on an existing Kocehind 2.14.0 + Recovery R1."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import pwd
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request

HERE = Path(__file__).resolve().parent
RUNTIME = Path('/opt/kocehind/backend')
PYTHON = Path('/opt/kocehind/venv/bin/python')
ENV = Path('/etc/kocehind/backend.env')
STAGING = Path('/opt/kocehind/staging')
BACKUPS = Path('/opt/kocehind/code-backups')
EXPECTED = {f'kocehind_coin_{n}': n for n in (25, 75, 160, 350, 750, 1600, 3500)}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify():
    metadata = json.loads((HERE / 'PACKAGE.json').read_text())
    if metadata['offered_products'] != EXPECTED:
        raise RuntimeError('Katalog paket tidak sesuai.')
    source = HERE / 'backend/app/play_billing.py'
    if source.is_symlink() or not source.is_file() or digest(source) != metadata['module_sha256']:
        raise RuntimeError('Source paket rusak atau hash tidak cocok.')
    for relative, hashes in metadata['compatible_runtime'].items():
        path = RUNTIME / relative
        if path.is_symlink() or not path.is_file() or digest(path) not in hashes:
            raise RuntimeError('Source backend berbeda/custom pada ' + relative + '. Paket ini memerlukan Kocehind 2.14.0 dengan Play Recovery R1 yang sudah terpasang.')
    return metadata


def run(args, *, env=None, cwd=None):
    completed = subprocess.run([str(value) for value in args], env=env, cwd=cwd,
                               capture_output=True, text=True, timeout=60)
    if completed.returncode:
        code = 'SERVICE_ACCESS' if 'Permission denied' in completed.stderr else 'UPDATE_STEP'
        for line in completed.stdout.splitlines():
            if line.startswith('CATALOG_ERROR='):
                value = line.partition('=')[2]
                if value in ('IMPORT', 'SCHEMA', 'DATABASE', 'CATALOG'):
                    code = value
        raise RuntimeError('[' + code + '] Langkah ' + Path(str(args[0])).name + ' gagal (exit ' + str(completed.returncode) + '). Detail privat tidak dicetak.')
    return completed


def active(unit):
    return subprocess.run(['systemctl', 'is-active', '--quiet', unit],
                          capture_output=True, timeout=10).returncode == 0


def replace_file(source, target):
    original = target.stat()
    fd, name = tempfile.mkstemp(prefix='.coin-catalog-', dir=target.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(source.read_bytes())
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(name, original.st_mode & 0o777)
        os.chown(name, original.st_uid, original.st_gid)
        os.replace(name, target)
    finally:
        Path(name).unlink(missing_ok=True)


def preflight(stage, environment):
    code = '''
try:
    from app.main import app
    from app import play_billing as play
    from app.core import engine
    from sqlalchemy import inspect, text
    import json
except Exception:
    print('CATALOG_ERROR=IMPORT')
    raise SystemExit(2) from None
expected = {f'kocehind_coin_{n}': n for n in (25,75,160,350,750,1600,3500)}
if app.version != '2.14.0' or play.OFFERED_PRODUCTS != expected or any(play.PRODUCTS.get(f'kocehind_coin_{n}') != n for n in (100,500,1000,5000)):
    print('CATALOG_ERROR=CATALOG')
    raise SystemExit(2)
try:
    with engine.connect() as connection:
        if engine.dialect.name == 'postgresql':
            connection.exec_driver_sql('SET TRANSACTION READ ONLY')
        inspector = inspect(connection)
        if not all(inspector.has_table(name) for name in ('google_play_purchases','google_play_verification_queue','wallet_config')):
            print('CATALOG_ERROR=SCHEMA')
            raise SystemExit(2)
        income = connection.execute(text("SELECT income_per_coin FROM wallet_config WHERE id='main'")).scalar()
except Exception:
    print('CATALOG_ERROR=DATABASE')
    raise SystemExit(2) from None
print('CATALOG_PREFLIGHT=' + json.dumps({'ok':True,'income_per_coin':income}))
'''
    result = run(['runuser', '-u', 'kocehind', '--', PYTHON, '-c', code], env=environment, cwd=stage)
    line = next((row for row in result.stdout.splitlines() if row.startswith('CATALOG_PREFLIGHT=')), '')
    payload = json.loads(line.partition('=')[2])
    if payload.get('ok') is not True:
        raise RuntimeError('Hasil preflight tidak valid.')
    print('PREFLIGHT OK: katalog tujuh paket, verifikasi paket lama, pengguna service dan schema Recovery R1 cocok.')
    income = payload.get('income_per_coin')
    if isinstance(income, int):
        print('Info: pendapatan host saat ini Rp' + str(income) + ' per koin; pengaturan ini tidak diubah.')


def wait_for_health():
    for _ in range(20):
        try:
            with urllib.request.urlopen('http://127.0.0.1:8000/health', timeout=2) as response:
                result = json.load(response)
            if result.get('status') == 'ok' and result.get('version') == '2.14.0':
                return
        except Exception:
            pass
        time.sleep(.5)
    raise RuntimeError('Health backend belum siap.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    if os.geteuid() != 0:
        raise RuntimeError('Jalankan sebagai root pada VPS backend.')
    if sys.version_info < (3, 11):
        raise RuntimeError('Gunakan /opt/kocehind/venv/bin/python.')
    if not ENV.is_file() or not PYTHON.is_file():
        raise RuntimeError('Backend existing belum ditemukan.')
    from dotenv import dotenv_values
    config = dotenv_values(ENV, interpolate=False)
    if not all(config.get(key) for key in ('DATABASE_URL', 'JWT_SECRET')):
        raise RuntimeError('Konfigurasi backend tidak lengkap.')
    environment = {**os.environ, **{key: value for key, value in config.items() if isinstance(value, str)},
                   'PYTHONDONTWRITEBYTECODE': '1'}
    metadata = verify()
    pwd.getpwnam('kocehind')
    STAGING.mkdir(parents=True, exist_ok=True, mode=0o755)
    stage = Path(tempfile.mkdtemp(prefix='coin-catalog-', dir=STAGING))
    stage.chmod(0o755)
    try:
        if any(path.is_symlink() for path in (RUNTIME / 'app').rglob('*')):
            raise RuntimeError('Preflight menolak symlink di dalam app.')
        shutil.copytree(RUNTIME / 'app', stage / 'app', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
        shutil.copyfile(HERE / 'backend/app/play_billing.py', stage / 'app/play_billing.py')
        for path in stage.rglob('*'):
            path.chmod(0o755 if path.is_dir() else 0o644)
        preflight(stage, environment)
        if args.check:
            print('Pemeriksaan selesai. Belum mengganti kode atau me-restart service.')
            return
        target = RUNTIME / 'app/play_billing.py'
        if digest(target) == metadata['module_sha256']:
            print('Katalog ini sudah terpasang. Tidak ada pergantian kode.')
            return
        stamp = time.strftime('%Y%m%d-%H%M%S') + '-' + str(os.getpid())
        backup = BACKUPS / ('coin-catalog-' + stamp)
        backup.mkdir(parents=True, mode=0o700)
        shutil.copy2(target, backup / 'play_billing.py')
        was_api, was_play = active('kocehind-api'), active('kocehind-play')
        try:
            run(['systemctl', 'stop', 'kocehind-api'])
            if was_play:
                run(['systemctl', 'stop', 'kocehind-play'])
            replace_file(HERE / 'backend/app/play_billing.py', target)
            run(['systemctl', 'start', 'kocehind-api'])
            if str(config.get('PLAY_BILLING_ENABLED', '0')).lower() in ('1', 'true', 'yes'):
                run(['systemctl', 'restart', 'kocehind-play'])
            wait_for_health()
        except Exception:
            subprocess.run(['systemctl', 'stop', 'kocehind-api', 'kocehind-play'], capture_output=True, timeout=30)
            replace_file(backup / 'play_billing.py', target)
            for unit, before in [('kocehind-api', was_api), ('kocehind-play', was_play)]:
                if before:
                    subprocess.run(['systemctl', 'start', unit], capture_output=True, timeout=30)
            print('Kode sebelum update dipulihkan. Saldo, antrean dan pengaturan pendapatan tetap tersimpan.')
            raise
        print('BERHASIL: tujuh paket Google Play tanpa bonus sudah dikonfigurasi di backend.')
        print('Backup kode: ' + str(backup))
        print('Aktifkan Product ID yang sama di Play Console, lalu tekan Muat paket di aplikasi.')
    finally:
        shutil.rmtree(stage, ignore_errors=True)


if __name__ == '__main__':
    try:
        main()
    except RuntimeError as error:
        raise SystemExit('BELUM SELESAI: ' + str(error)) from None
    except Exception as error:
        raise SystemExit('BELUM SELESAI: ' + type(error).__name__ + '. Konfigurasi privat tidak dicetak.') from None
