#!/usr/bin/env python3
"""Preserve the Play catalogue and Recovery R1 in the existing source package."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import os
import tempfile
import zipfile

HERE = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def atomic(path, data):
    fd, name = tempfile.mkstemp(prefix='.play-source-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as out:
            out.write(data)
            out.flush()
            os.fsync(out.fileno())
        os.chmod(name, (path.stat().st_mode & 0o777) if path.exists() else 0o644)
        os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)


def patched(files):
    specification = json.loads((HERE / 'SOURCE_PATCH.json').read_text())
    for relative, hashes in specification.items():
        replacement = (HERE / 'source_changes' / relative).read_bytes()
        if sha(replacement) != hashes['patched']:
            raise RuntimeError('Source patch rusak: ' + relative)
        existing = files.get(relative)
        if (sha(existing) if existing is not None else None) not in [hashes['base'], hashes['patched'], *hashes.get('previous', [])]:
            raise RuntimeError('Source berbeda/custom pada ' + relative + '; belum ada perubahan.')
        files[relative] = replacement
    files['MANIFEST_SHA256.txt'] = ''.join(sha(data) + '  ' + name + '\n' for name, data in sorted(files.items())
        if name != 'MANIFEST_SHA256.txt').encode()
    return files


def apply(target):
    archive = target / 'SOURCE_LENGKAP_v2.14.0.zip'
    updates = {}
    if archive.is_file():
        files = {}
        with zipfile.ZipFile(archive) as source:
            if sum(item.file_size for item in source.infolist()) > 300_000_000:
                raise RuntimeError('Source ZIP terlalu besar.')
            for item in source.infolist():
                path = Path(item.filename)
                if path.is_absolute() or '..' in path.parts or path.parts[0] != 'kocehind_realtime_v2':
                    raise RuntimeError('Struktur ZIP tidak cocok.')
                if not item.is_dir():
                    files[str(Path(*path.parts[1:]))] = source.read(item)
        patched(files)
        output = io.BytesIO()
        with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as out:
            for relative, data in sorted(files.items()):
                out.writestr('kocehind_realtime_v2/' + relative, data)
        updates[archive] = output.getvalue()
        metadata_path = target / 'package.json'
        metadata = json.loads(metadata_path.read_text())
        metadata['source_sha256'] = sha(updates[archive])
        metadata['play_recovery_revision'] = 1
        metadata['play_coin_catalog_revision'] = 1
        updates[metadata_path] = (json.dumps(metadata, indent=2) + '\n').encode()
        sums = target / 'SHA256SUMS.txt'
        records = []
        for line in sums.read_text().splitlines():
            name = line.split('  ', 1)[1]
            path = target / name
            if Path(name).is_absolute() or '..' in Path(name).parts:
                raise RuntimeError('Manifest paket tidak valid.')
            records.append(sha(updates[path] if path in updates else path.read_bytes()) + '  ' + name + '\n')
        updates[sums] = ''.join(records).encode()
    else:
        if (target / 'kocehind_realtime_v2/backend/app/main.py').is_file():
            target = target / 'kocehind_realtime_v2'
        if not (target / 'backend/app/main.py').is_file():
            raise RuntimeError('Pilih folder Kocehind_v2.14.0 atau folder source kocehind_realtime_v2.')
        specification = json.loads((HERE / 'SOURCE_PATCH.json').read_text())
        names = set(specification) | {'MANIFEST_SHA256.txt'}
        files = {relative: (target / relative).read_bytes() for relative in names if (target / relative).is_file()}
        # Preserve the existing manifest's entries for unchanged files.
        for line in files.get('MANIFEST_SHA256.txt', b'').decode().splitlines():
            relative = line.split('  ', 1)[1]
            if Path(relative).is_absolute() or '..' in Path(relative).parts:
                raise RuntimeError('Manifest source tidak valid.')
            files.setdefault(relative, (target / relative).read_bytes())
        patched(files)
        updates = {target / relative: files[relative] for relative in names}
    backups = {path: path.read_bytes() if path.exists() else None for path in updates}
    for path, content in backups.items():
        if content is not None:
            backup = path.with_name(path.name + '.before-coin-catalog-v1')
            if not backup.exists():
                atomic(backup, content)
    written = []
    try:
        for path, content in updates.items():
            path.parent.mkdir(parents=True, exist_ok=True)
            atomic(path, content)
            written.append(path)
    except Exception:
        for path in reversed(written):
            if backups[path] is None:
                path.unlink(missing_ok=True)
            else:
                atomic(path, backups[path])
        raise
    print('Source 2.14.0 diperbarui dengan tujuh paket tanpa bonus dan Recovery R1. Build Android tetap. Perintah ini hanya memperbarui source.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('folder', type=Path)
    args = parser.parse_args()
    try:
        apply(args.folder.resolve())
    except Exception as error:
        raise SystemExit('BELUM SELESAI: ' + str(error)) from None
