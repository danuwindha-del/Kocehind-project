#!/usr/bin/env python3
"""Read-only integration report. Never prints environment values or secrets."""
import argparse
import json
from pathlib import Path
import subprocess
import urllib.request
from dotenv import dotenv_values


def configured(values, *keys):
    return all(bool(values.get(key)) for key in keys)


def main():
    argparse.ArgumentParser(description=__doc__).parse_args()
    env_file = Path('/etc/kocehind/backend.env')
    if not env_file.is_file():
        raise RuntimeError('backend.env belum ditemukan.')
    values = dotenv_values(env_file, interpolate=False)
    rows = {
        'kocehind-api': True,
        'kocehind-play': str(values.get('PLAY_BILLING_ENABLED', '0')).lower() in ('true', '1', 'yes'),
        'kocehind-studio-worker': True,
        'kocehind-live': configured(values, 'LIVEKIT_URL', 'LIVEKIT_API_KEY', 'LIVEKIT_API_SECRET'),
        'kocehind-live-worker': configured(values, 'LIVEKIT_URL', 'LIVEKIT_API_KEY', 'LIVEKIT_API_SECRET'),
        'kocehind-egress': str(values.get('LIVE_RECORDING_ENABLED', '')).lower() in ('true', '1', 'yes'),
        'kocehind-payments': configured(values, 'KIPAY_API_KEY', 'KIPAY_WEBHOOK_SECRET'),
        'kocehind-email': configured(values, 'MAILJET_API_KEY', 'MAILJET_SECRET_KEY', 'MAILJET_FROM_EMAIL'),
        'kocehind-push': configured(values, 'FCM_PROJECT_ID', 'FCM_CREDENTIALS_FILE'),
        'kocehind-moderation': Path('/opt/kocehind/moderation-venv/bin/python').is_file(),
        'kocehind-live-safety': Path('/opt/kocehind/moderation-venv/bin/python').is_file(),
        'kocehind-content-safety': str(values.get('MULTI_MODERATION_ENABLED', '')).lower() in ('true', '1', 'yes'),
        'kocehind-live-content-safety': str(values.get('MULTI_MODERATION_ENABLED', '')).lower() in ('true', '1', 'yes'),
    }
    missing = []
    for service, expected in rows.items():
        result = subprocess.run(['systemctl', 'is-active', service], capture_output=True,
                                text=True, timeout=15)
        status = result.stdout.strip() or 'tidak ditemukan'
        print(service + ': ' + status + (' [perlu aktif]' if expected else ' [opsional/belum dikonfigurasi]'))
        if expected and result.returncode:
            missing.append(service)
    for label, url in (
        ('API', 'http://127.0.0.1:8000/health'),
        ('LIVE', 'http://127.0.0.1:8000/health/live'),
        ('Katalog koin', 'http://127.0.0.1:8000/public/coins/packages'),
    ):
        try:
            with urllib.request.urlopen(url, timeout=10) as response:
                raw = response.read(262145)
                if response.status != 200 or len(raw) > 262144:
                    raise ValueError('response')
                payload = json.loads(raw)
            version = payload.get('version') if label == 'API' and isinstance(payload, dict) else None
            print(label + ': HTTP 200 JSON' + (' versi ' + str(version) if version else ''))
        except Exception:
            print(label + ': belum dapat diperiksa')
            missing.append(label)
    print('Laporan ini tidak menguji dana nyata, pengiriman FCM ke HP, hasil model, atau hasil rekaman.')
    if missing:
        raise SystemExit(2)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        raise SystemExit('BELUM SELESAI: ' + str(exc)) from None
