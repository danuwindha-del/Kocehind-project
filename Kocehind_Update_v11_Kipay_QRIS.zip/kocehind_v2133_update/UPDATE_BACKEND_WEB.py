#!/usr/bin/env python3
"""Apply the bundled backend stability hotfix to the existing backend/web."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

import latest_build as builder


def main():
    if os.geteuid() != 0 or not Path('/etc/kocehind/backend.env').is_file():
        raise RuntimeError('Jalankan dengan sudo pada VPS backend/web yang sudah terpasang.')
    here = Path(__file__).resolve().parent
    payload = (here/f'SOURCE_LENGKAP_v{builder.VERSION}.zip').read_bytes()
    config = json.loads((here/'package.json').read_text())
    if config['version'] != builder.VERSION or hashlib.sha256(payload).hexdigest() != config['source_sha256']:
        raise RuntimeError('Source paket tidak utuh. Ekstrak ulang ZIP terbaru.')
    print('Update backend/web '+config.get('backend_version', builder.VERSION)+'. Semua LIVE harus sudah diakhiri. Checkout baru menggunakan Kipay setelah SETUP_KIPAY.py. Tidak perlu rebuild APK untuk perubahan gateway ini.', flush=True)
    with tempfile.TemporaryDirectory(prefix='kocehind-update-') as folder:
        project = builder.extract_source(payload, Path(folder))
        env = os.environ.copy()
        runtime_bin = Path('/opt/kocehind/venv/bin')
        if (runtime_bin/'python3').is_file():
            subprocess.run([str(runtime_bin/'python3'), '-c', 'import sys; assert sys.version_info >= (3,11)'], check=True)
            env['PATH'] = str(runtime_bin) + os.pathsep + env.get('PATH', '')
        subprocess.run(['bash', str(project/'scripts/vps2_update_v213.sh')], check=True, env=env)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, ValueError, subprocess.SubprocessError) as exc:
        message = str(exc) if isinstance(exc, RuntimeError) else 'Update belum selesai; periksa pesan terminal di atas.'
        print('BELUM BERHASIL: '+message, file=sys.stderr)
        sys.exit(1)
