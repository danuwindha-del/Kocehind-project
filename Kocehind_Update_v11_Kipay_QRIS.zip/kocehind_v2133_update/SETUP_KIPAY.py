#!/usr/bin/env python3
"""Configure KiPay privately on an already updated backend VPS."""
import argparse
import getpass
import grp
import os
from pathlib import Path
import re
import shutil
import subprocess
import time
from dotenv import set_key


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode',required=True,choices=('sandbox','production'))
    args=parser.parse_args()
    env=Path('/etc/kocehind/backend.env')
    if os.geteuid()!=0 or not env.is_file() or not Path('/opt/kocehind/backend/app/kipay.py').is_file():
        raise RuntimeError('Jalankan di VPS backend setelah UPDATE_BACKEND_WEB.py berhasil.')
    key=getpass.getpass('API key project Kipay (input tersembunyi): ').strip()
    secret=getpass.getpass('Webhook secret project yang sama (input tersembunyi): ').strip()
    if not re.fullmatch(r'apg_[A-Za-z0-9_-]{4,252}',key):
        raise RuntimeError('Format API key tidak valid; gunakan API key project dari dashboard Kipay.')
    if not re.fullmatch(r'whsec_[A-Za-z0-9_-]{16,256}',secret):
        raise RuntimeError('Format webhook secret tidak valid; salin secret dari pengaturan webhook Kipay.')
    backups=Path('/etc/kocehind/private-backups');backups.mkdir(mode=0o700,exist_ok=True)
    backup=backups/('backend.env-before-kipay-'+str(time.time_ns()))
    shutil.copyfile(env,backup);backup.chmod(0o600)
    for name,value in {'COIN_PAYMENT_GATEWAY':'kipay','KIPAY_MODE':args.mode,
                       'KIPAY_API_KEY':key,'KIPAY_WEBHOOK_SECRET':secret}.items():
        set_key(str(env),name,value,quote_mode='always')
    os.chown(env,0,grp.getgrnam('kocehind').gr_gid);env.chmod(0o640)
    subprocess.run(['systemctl','daemon-reload'],check=True)
    subprocess.run(['systemctl','restart','kocehind-api','kocehind-payments'],check=True)
    subprocess.run(['systemctl','enable','kocehind-payments'],check=True)
    print('Konfigurasi tersimpan. Mode: '+args.mode+'. API key dan secret tidak dicetak.')
    print('Webhook URL: https://api.kocehind.web.id/payments/kipay/callback')
    print('Lanjutkan Tes webhook di dashboard Kipay dan satu transaksi uji di web.')
    print('Nilai TRIPAY_* tetap disimpan untuk menyelesaikan tagihan lama.')


if __name__=='__main__':
    try:main()
    except (RuntimeError,OSError,ValueError,subprocess.SubprocessError) as exc:
        print('BELUM SELESAI: '+(str(exc) if isinstance(exc,RuntimeError) else 'Periksa layanan API/payment dan pengaturan VPS.'))
        raise SystemExit(1)
