#!/usr/bin/env python3
"""Publish the original Signed, universal APK on the existing backend VPS."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

import latest_build as builder


def main():
    if os.geteuid() != 0 or not Path('/etc/kocehind/backend.env').is_file():
        raise RuntimeError('Jalankan dengan sudo pada VPS backend/web, tempat /etc/kocehind/backend.env berada.')
    if len(sys.argv) < 2:
        raise RuntimeError('Pemakaian: sudo python3 PUBLIKASI_APK_PLAY.py /root/Kocehind-Play.apk [SHA1_APP_SIGNING_PLAY]')
    apk = Path(sys.argv[1]).expanduser().resolve()
    if not apk.is_file():
        raise RuntimeError('Upload Signed, universal APK dari Play Console ke VPS backend terlebih dahulu.')
    here = Path(__file__).resolve().parent
    config = json.loads((here/'package.json').read_text())
    payload = (here/f'SOURCE_LENGKAP_v{builder.VERSION}.zip').read_bytes()
    if hashlib.sha256(payload).hexdigest() != config['source_sha256']:
        raise RuntimeError('Source paket tidak utuh. Ekstrak ulang ZIP terbaru.')
    print('APK web harus berasal dari rilis Play tanpa Installer check yang mewajibkan pemasangan dari Play.', flush=True)
    print('Pemeriksaan sertifikat di bawah tidak memastikan status Automatic protection; uji APK melalui unduhan web setelah publikasi.', flush=True)
    with tempfile.TemporaryDirectory(prefix='kocehind-apk-play-') as folder:
        source = builder.extract_source(payload, Path(folder))
        subprocess.run(['bash', str(source/'scripts/vps2_pasang_apk_play.sh'), str(apk), *sys.argv[2:]],
                       check=True)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, ValueError, subprocess.SubprocessError) as exc:
        message = str(exc) if isinstance(exc, RuntimeError) else 'Publikasi belum terverifikasi; periksa pesan perintah di atas.'
        print('BELUM BERHASIL: '+message, file=sys.stderr)
        sys.exit(1)
