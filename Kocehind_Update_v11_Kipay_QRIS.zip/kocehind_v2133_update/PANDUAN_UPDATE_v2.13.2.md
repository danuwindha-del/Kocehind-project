# Kocehind update v10 — 2.13.2

Backend: **2.13.2-live**. Android: **2.13.2+33**, atau build lebih tinggi jika
riwayat keystore lama memerlukannya. Melanjutkan paket v9 2.13.1.

## Perubahan

- Homepage https://kocehind.web.id/ menjadi halaman publik berisi penjelasan
  layanan video/LIVE, produk koin digital, contoh gift, harga paket aktif dari
  database, cara membeli, konfirmasi/pengiriman saldo dan bantuan pembayaran.
  Tambahan /kontak dan /pembayaran dengan informasi pengembalian dana.
  Halaman privasi/ketentuan tetap memakai dokumen yang dipublikasikan admin.
- Ringkasan akhir LIVE untuk host/admin: total gift, total koin, pendapatan
  rupiah sesi, dan Top 3 pemberi gift berdasarkan total koin per akun.
  Seri diurutkan dari gift pertama. Pendapatan memakai nilai historis receipt,
  bukan dikalikan kurs terbaru. Retry transaksi tidak menambah hitungan.
  Penonton/anonim tidak menerima ringkasan keuangan host.
- Ketuk foto profil sendiri atau orang lain untuk membuka preview besar.
  Android mendukung pinch zoom, tombol tutup dan tombol kembali. Web memakai
  dialog besar dengan penanganan foto kosong/gagal. Edit foto tetap terpisah.
- Pemantau ukuran panggung web dilepas ketika LIVE berakhir sehingga tidak
  membaca elemen yang sudah ditutup. Cache aset web diperbarui ke 2.13.2.

## Update VPS backend yang sudah berjalan

Akhiri semua LIVE aktif. Upload ZIP ke /root dan jalankan sebagai root:

```bash
unzip -o /root/Kocehind_Update_v10_Homepage_Ringkasan_Profil.zip -d /root
cd /root/kocehind_v2132_update
sha256sum -c SHA256SUMS.txt &&
/opt/kocehind/venv/bin/python UPDATE_BACKEND_WEB.py
curl -fsS --max-time 15 http://127.0.0.1:8000/health
```

Health harus menunjukkan **2.13.2-live**. Updater memilih runtime Python dari
virtualenv API yang sudah berfungsi; sesuai VPS Ubuntu 22.04 dengan Python
3.12 berdampingan. Python sistem tidak diganti. Alur backup database/media,
migrasi aditif, preflight user service, dan rollback kode tetap dipakai.

Tidak ada tabel/kolom baru khusus v10. Database, saldo, receipt gift,
backend.env, konfigurasi TriPay/Mailjet/Firebase, TLS, model moderasi lokal,
dan identitas signing dipertahankan. Worker yang sudah aktif dijalankan
kembali oleh updater. Tidak perlu memasang ulang model atau membuat key baru.

Periksa setelah update:

```bash
systemctl is-active kocehind-api kocehind-email \
  kocehind-moderation kocehind-live-safety \
  kocehind-content-safety kocehind-live-content-safety kocehind-live-worker
# Jika push sudah dikonfigurasi sebelumnya:
systemctl is-active kocehind-push
```

Jika suatu service belum aktif, periksa log service itu. Jangan mengganti
backend.env dengan file contoh atau mengaktifkan service tanpa model/key.

## Build dan pasang Android

Ringkasan dan preview foto pada Android memerlukan APK baru. Di VPS build,
upload dan ekstrak ZIP yang sama, lalu gunakan keystore lama serta konfigurasi
Google/Firebase yang sama. Untuk alur key portabel yang dipakai pada v9:

```bash
cd /root/kocehind_v2132_update
bash BUILD_VPS_BARU.sh
```

Builder minimum build 33, atau lebih tinggi bila riwayat key memerlukannya.
Paket ini berisi source dan builder, bukan APK/AAB produksi bertanda tangan.
Untuk VPS build baru, siapkan KOCEHIND_KEY_LAMA.enc milik Anda sesuai panduan
portabilitas yang disertakan. Jangan membuat key pengganti aplikasi lama.

## Pengajuan ulang merchant TriPay

Pakai URL **https://kocehind.web.id/** pada data website merchant.
Contoh deskripsi tersedia di DESKRIPSI_MERCHANT_TRIPAY.txt.

Periksa tanpa login bahwa homepage, /about, /kontak, /pembayaran, /privasi dan
/ketentuan dapat dibuka. Harga harus sesuai paket aktif produksi; checkout,
konfirmasi pembayaran dan penanganan tiket harus berfungsi. Gunakan data
badan usaha dan kontak yang benar jika diminta TriPay. Paket ini tidak
merekayasa nama perusahaan, alamat, email, izin atau klaim persetujuan.

Perubahan menjawab alasan penolakan pada gambar: website perlu keterangan
produk/layanan yang jelas dan homepage. Persetujuan tetap hasil penilaian
TriPay. Mode sandbox tidak diubah menjadi production otomatis.

## Uji di VPS dan HP

1. Buka domain utama tanpa login: tetap pada homepage; paket/harga berasal dari
   katalog aktif yang sama dengan pembelian. Coba semua tautan informasi.
2. Kirim gift dari beberapa akun uji, lalu akhiri LIVE. Bandingkan total dengan
   riwayat gift Studio. Satu akun digabung walaupun mengirim beberapa jenis gift.
3. LIVE tanpa gift harus menampilkan 0; penonton tidak menerima pendapatan host.
4. Uji ketuk foto sendiri dan profil orang lain, foto kosong, tutup/kembali,
   dan perbesaran pada APK baru. Uji web di HP dan desktop.
5. Periksa moderasi dan push yang sudah diaktifkan sebelumnya.

Hasil uji lokal dan batas pengujian ada di PENGUJIAN_v2.13.2.md.
