# Kocehind v11 — v2.13.3 Kipay QRIS

Paket ini meneruskan v10/v2.13.2. Pembelian koin baru di web memakai Kipay QRIS.
Ringkasan gift LIVE, tiga pengirim teratas, preview foto profil, perbaikan dompet,
moderasi, dan notifikasi dari versi sebelumnya tetap termasuk.
Tidak perlu rebuild atau mengganti APK 2.13.2+37 hanya untuk perubahan gateway.
Google Play Billing tetap tidak diaktifkan; gift dan pendapatan tetap di aplikasi.

## 1. Update VPS backend/web yang sudah berjalan

Akhiri LIVE aktif. Upload ZIP ke /root lalu jalankan sebagai root:

```bash
unzip -o /root/Kocehind_Update_v11_Kipay_QRIS.zip -d /root
cd /root/kocehind_v2133_update
sha256sum -c SHA256SUMS.txt &&
/opt/kocehind/venv/bin/python UPDATE_BACKEND_WEB.py
curl -fsS http://127.0.0.1:8000/health
```

Health harus menyebut `2.13.3-kipay`. Updater memakai Python 3.11+ pada venv
backend yang sudah ada; tidak mengganti Python sistem. Jalur backup database,
media, preflight, dan rollback kode dari v10 tetap dipakai. Model moderasi tidak
diunduh ulang; credential Firebase/Mailjet/LiveKit dan konfigurasi TLS dipertahankan.

Migrasi hanya menambahkan kolom informasi Kipay pada `coin_orders` dan tabel antrean
`kipay_payment_checks`. Semua pesanan lama ditandai `tripay` secara default.
Saldo, histori gift, penarikan, dan transaksi lama tidak dikonversi/dihapus.

## 2. Konfigurasi project Kipay

Buka https://kipay.id/dashboard/projects. Siapkan project pada mode yang sesuai,
API key project, dan QRIS merchant yang diminta Kipay. Isi Webhook URL:

```
https://api.kocehind.web.id/payments/kipay/callback
```

Simpan webhook secret yang ditampilkan oleh Kipay saat pengaturan webhook.
API key dan secret harus berasal dari project yang sama. Secret hanya ditampilkan
sekali; jika sudah hilang gunakan fitur buat ulang secret pada project tersebut.
Jangan mengirim API key atau webhook secret ke chat/source/browser.

Untuk transaksi uji, jalankan:

```bash
cd /root/kocehind_v2133_update
/opt/kocehind/venv/bin/python SETUP_KIPAY.py --mode sandbox
```

Masukkan API key dan webhook secret saat diminta. Input tersembunyi dan tidak
masuk shell history. Skrip menyimpan backup env privat, memperbarui empat variabel
saja, dan memulai ulang API serta worker pembayaran:

```
COIN_PAYMENT_GATEWAY=kipay
KIPAY_MODE=sandbox
KIPAY_API_KEY=<diisi lewat prompt>
KIPAY_WEBHOOK_SECRET=<diisi lewat prompt>
```

`KIPAY_MODE` harus sama dengan mode project. Mode ditentukan Kipay melalui project,
bukan flag pada request create. Kode memeriksa `mode` dan prefiks SBX/QRIS.
Mode sandbox menggunakan saldo akun Kocehind yang sama: gunakan akun uji khusus,
jangan memberi koin simulasi kepada pembeli sungguhan.

Jangan menghapus `TRIPAY_*` dahulu. Pesanan Tripay lama tetap diverifikasi ke
Tripay melalui refresh, callback lama, atau menu rekonsiliasi admin; pesanan Kipay
selalu diverifikasi ke Kipay. Tidak ada fallback diam-diam ke Tripay jika Kipay gagal.

## 3. Uji satu transaksi sandbox

- Jalankan **Tes webhook** dari project Kipay; hasil endpoint harus HTTP 200.
- Masuk ke https://web.kocehind.web.id/coins dengan akun uji.
- Pilih paket, pilih QRIS Kipay, dan tekan Buat tagihan. Web menampilkan mode
  sandbox, harga paket, kode unik, biaya beserta pihak penanggungnya, total akhir,
  referensi SBX, QRIS, dan batas waktu dari penyedia.
- Untuk simulasi tanpa mengekspos key, salin referensi SBX dari riwayat web:

```bash
cd /root/kocehind_v2133_update
/opt/kocehind/venv/bin/python SIMULASI_KIPAY_SANDBOX.py SBX-ID-DARI-RIWAYAT
```

Ganti argumen terakhir dengan ID transaksi yang sebenarnya. Script menolak
mode production dan tidak dipasang sebagai endpoint publik/admin web.

Kembali ke web, klik **Saya sudah membayar · cek status** / **Periksa pembayaran**.
Saldo harus bertambah sesuai jumlah koin paket, satu kali saja. Refresh dan webhook
ulang tidak menambah lagi. QR menghilang saat paid/expired. Tombol Simpan QRIS
memungkinkan pengguna HP membuka gambar tersebut di aplikasi pembayaran yang
mendukung pembacaan QR dari galeri.

Worker memeriksa antrean setiap lima detik, satu transaksi per putaran; tagihan
pending dijadwalkan ulang sekitar satu menit. Kegagalan sementara dicoba ulang
dengan jeda, maksimal lima menit. Polling web setiap 15 detik dan tombol cek status
memakai verifikasi server yang sama. Webhook di-ACK setelah antrean tersimpan;
penerimaan webhook saja tidak menambahkan saldo.

## 4. Aktifkan production

Selesaikan pemeriksaan transaksi sandbox terlebih dahulu. Pakai project/API key
dan secret production dari Kipay; pastikan QRIS merchant serta akses production
sudah diaktifkan di akun Kipay. Project sandbox tidak menerima uang nyata.
Selesaikan tagihan pending sebelum mengganti credential/mode; credential baru
mungkin tidak dapat membaca transaksi milik project lama.

```bash
cd /root/kocehind_v2133_update
/opt/kocehind/venv/bin/python SETUP_KIPAY.py --mode production
systemctl is-active kocehind-api kocehind-payments
curl -fsS http://127.0.0.1:8000/health
```

Masukkan API key/secret production saat prompt. Lakukan Tes webhook pada project
production, kemudian satu pembayaran QRIS kecil yang benar-benar dibayar; periksa
saldo dan riwayat. Nominal harus tepat sesuai total final, termasuk kode unik.
Aktivasi akun/merchant tetap mengikuti proses Kipay. Paket ini belum diuji dengan
credential atau uang nyata milik Anda.

## 5. Jika pembayaran belum masuk

```bash
systemctl status kocehind-payments --no-pager -l
journalctl -u kocehind-payments -n 60 --no-pager
```

- Mode/ID tidak cocok: periksa mode project dan `KIPAY_MODE`.
- Signature gagal: periksa webhook secret project yang benar dan sinkronisasi jam VPS.
- Tagihan `unknown`: periksa dashboard Kipay berdasarkan note berupa ID pesanan
  Kocehind. Gunakan Admin > Dompet > Verifikasi pembayaran dengan trx_id terkait.
  Backend mengambil ulang detail API dan mencocokkan note, nominal, mode, dan ID.
- Jangan membuat tagihan kedua saat hasil create belum pasti; request key yang sama
  tidak membuat invoice provider kedua. Endpoint Kipay tidak mendokumentasikan
  idempotency key/list-by-note, sehingga timeout tanpa trx_id perlu callback atau
  penelusuran dashboard/admin. Fitur penutupan admin hanya untuk tagihan yang sudah
  diperiksa tidak punya pembayaran/tagihan aktif.
- Kesalahan konfigurasi/data provider tidak menambah koin; jangan menambahkan saldo
  manual hanya berdasarkan bukti screenshot pembayaran.

Kipay memberikan timestamp API berupa string tanpa offset pada contoh dokumentasi.
Karena zona waktu string tersebut belum ditentukan di kontrak publik yang dibaca,
web menampilkan nilai asli dengan label "waktu dari Kipay", tanpa mengasumsikan WIB
atau UTC dan tanpa menghitung kedaluwarsa sendiri. Status expired dari API yang
menutup checkout. Sesuaikan tampilan zona waktu setelah penyedia mengonfirmasinya.

## 6. Build Android opsional

APK yang sudah berjalan tetap dapat dipakai. Jika ingin membangun paket source
versi ini, gunakan VPS builder dengan keystore dan Firebase lama:

```bash
cd /root/kocehind_v2133_update
bash BUILD_VPS_BARU.sh --build-number 38
```

Nomor harus lebih tinggi dari versi Play/build lokal yang sudah ada. Build 37
sudah dipakai pada versi sebelumnya. Tidak ada APK/AAB bertanda tangan atau key
privat dalam paket ini; build Android tidak dijalankan dalam pekerjaan update web ini.

## Referensi kontrak yang dipakai

Dokumentasi resmi dibaca 28 Oktober 2026:

- https://kipay.id/docs/api/transactions/create
- https://kipay.id/docs/api/transactions/retrieve
- https://kipay.id/docs/api/transactions/qr
- https://kipay.id/docs/guides/webhooks
- https://kipay.id/docs/api/webhooks
- https://kipay.id/docs/security
- https://kipay.id/docs/concepts/sandbox
- https://kipay.id/docs/api/transactions/simulate

URL OpenAPI yang ditautkan penyedia tidak dapat diakses pada lingkungan pengujian.
Implementasi memakai kontrak rinci halaman dokumentasi, bukan endpoint hasil tebakan.
