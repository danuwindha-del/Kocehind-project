#!/usr/bin/env python3
"""Ekspor key/config pada VPS lama; impor/build source 2.12.7 pada VPS baru."""
import argparse
import getpass
import hashlib
import hmac
import io
import json
import os
from pathlib import Path, PurePosixPath
import secrets
import shutil
import subprocess
import sys
import tarfile
import tempfile

import latest_build as builder

HERE = Path(__file__).resolve().parent
MAGIC = b'KOCEHIND-KEY-v1\n'
ITERATIONS = 200_000
LIMIT = 200 * 1024 * 1024
SKIP_FILES = {'key.properties', 'local.properties'}
SKIP_SUFFIXES = {'.jks', '.keystore', '.p12', '.pfx', '.pem', '.key', '.log'}


def private_write(path, content):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    if isinstance(content, str):
        builder.signing.write_private(path, content)
    else:
        with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as f:
            pending = Path(f.name)
            try:
                f.write(content)
                f.flush()
                pending.chmod(0o600)
                os.replace(pending, path)
            finally:
                pending.unlink(missing_ok=True)


def request_phrase(confirm=False):
    if not sys.stdin.isatty():
        raise RuntimeError('Jalankan dari terminal SSH interaktif untuk memasukkan sandi backup.')
    phrase = getpass.getpass('Sandi backup pemindahan key: ')
    if len(phrase) < 12:
        raise RuntimeError('Gunakan sandi backup minimal 12 karakter. Ini boleh berbeda dari password keystore.')
    if confirm and getpass.getpass('Ulangi sandi backup: ') != phrase:
        raise RuntimeError('Sandi backup tidak sama. Ulangi ekspor.')
    return phrase


def openssl_crypt(data, phrase, decrypt=False):
    env = os.environ.copy()
    env['KOCEHIND_BACKUP_PASSPHRASE'] = phrase
    command = ['openssl', 'enc', '-aes-256-cbc', '-pbkdf2', '-iter', str(ITERATIONS),
               '-md', 'sha256', '-pass', 'env:KOCEHIND_BACKUP_PASSPHRASE']
    if decrypt:
        command.append('-d')
    else:
        command.append('-salt')
    result = subprocess.run(command, input=data, env=env, capture_output=True, timeout=120)
    if result.returncode:
        raise RuntimeError('Enkripsi/dekripsi backup gagal. Periksa OpenSSL dan sandi backup.')
    return result.stdout


def encrypt(data, phrase):
    salt = secrets.token_bytes(16)
    encrypted = openssl_crypt(data, phrase)
    content = MAGIC + salt + encrypted
    key = hashlib.pbkdf2_hmac('sha256', phrase.encode('utf-8'), salt, ITERATIONS)
    return content + hmac.new(key, content, hashlib.sha256).digest()


def decrypt(data, phrase):
    if len(data) > LIMIT or len(data) < len(MAGIC) + 16 + 32 + 16 or not data.startswith(MAGIC):
        raise RuntimeError('Format backup key tidak valid atau ukurannya terlalu besar.')
    content, tag = data[:-32], data[-32:]
    salt = content[len(MAGIC):len(MAGIC)+16]
    key = hashlib.pbkdf2_hmac('sha256', phrase.encode('utf-8'), salt, ITERATIONS)
    if not hmac.compare_digest(hmac.new(key, content, hashlib.sha256).digest(), tag):
        raise RuntimeError('Sandi backup salah atau berkas backup telah berubah. Belum ada key yang diimpor.')
    return openssl_crypt(content[len(MAGIC)+16:], phrase, decrypt=True)


def runner_files(project):
    android = project/'flutter/android'
    for base, dirs, files in os.walk(android, followlinks=False):
        dirs[:] = sorted(n for n in dirs if n not in builder.SKIP_DIRS)
        for name in dirs:
            if Path(base, name).is_symlink():
                raise RuntimeError('Runner Android memuat symlink; periksa project lama sebelum ekspor.')
        for name in sorted(files):
            if (name in SKIP_FILES or '.before-' in name or name.endswith(('.bak', '.backup'))
                    or Path(name).suffix.lower() in SKIP_SUFFIXES):
                continue
            path = Path(base, name)
            if path.is_symlink() or not path.is_file():
                raise RuntimeError('Runner Android memuat file khusus; ekspor dihentikan.')
            yield path, 'old_project/flutter/android/' + path.relative_to(android).as_posix()


def pack_profile(project, selected, password, keypass, env, previous_number):
    files = {name: (path.read_bytes(), bool(path.stat().st_mode & 0o111))
             for path, name in runner_files(project)}
    required = ('old_project/flutter/android/gradlew',
                'old_project/flutter/android/app/src/main/AndroidManifest.xml')
    if not all(name in files for name in required):
        raise RuntimeError('Runner Android lama belum lengkap. gradlew atau AndroidManifest.xml tidak tersedia.')
    files['signing/upload-keystore.jks'] = (selected['path'].read_bytes(), False)
    # Passwords travel only inside the encrypted backup, never in the source ZIP.
    creds = {'storePassword': password, 'keyPassword': keypass, 'keyAlias': selected['alias']}
    files['credentials.json'] = (json.dumps(creds).encode(), False)
    metadata = {'schema': 1, 'sha1': selected['sha1'],
                'application_id': builder.application_id(builder.native_gradle(project)),
                'previous_build_number': previous_number,
                'source_version': builder.VERSION}
    files['portable.json'] = (json.dumps(metadata, indent=2).encode(), False)
    files['build-environment.json'] = (json.dumps(env, indent=2).encode(), False)
    files['old_project/flutter/pubspec.yaml'] = (
        ('name: kocehind\nversion: '+builder.VERSION+'+'+str(previous_number)+'\n').encode(), False)
    hashes = {name: hashlib.sha256(value[0]).hexdigest() for name, value in files.items()}
    files['TRANSFER_SHA256.json'] = (json.dumps(hashes, sort_keys=True).encode(), False)
    result = io.BytesIO()
    with tarfile.open(fileobj=result, mode='w:gz') as archive:
        for name, (data, executable) in sorted(files.items()):
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            entry.mode = 0o700 if executable else 0o600
            archive.addfile(entry, io.BytesIO(data))
    if len(result.getvalue()) > LIMIT:
        raise RuntimeError('Backup terlalu besar. Periksa folder Android lama; folder build/SDK tidak diperlukan.')
    return result.getvalue(), metadata


def unpack_profile(data, destination):
    # Validate all paths, entry types, sizes and hashes before writing any file.
    files = {}
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
        members = archive.getmembers()
        total = 0
        for entry in members:
            name = PurePosixPath(entry.name)
            if (not entry.isfile() or name.is_absolute() or '..' in name.parts
                    or '\\' in entry.name or entry.name in files or str(name) != entry.name
                    or len(members) > 10_000):
                raise RuntimeError('Isi backup key tidak valid. Tidak ada file yang diimpor.')
            total += entry.size
            if total > LIMIT:
                raise RuntimeError('Isi backup terlalu besar.')
            files[entry.name] = (archive.extractfile(entry).read(), bool(entry.mode & 0o111))
    expected = json.loads(files['TRANSFER_SHA256.json'][0])
    if set(expected) != set(files) - {'TRANSFER_SHA256.json'}:
        raise RuntimeError('Daftar file backup tidak cocok.')
    for name, digest in expected.items():
        if hashlib.sha256(files[name][0]).hexdigest() != digest:
            raise RuntimeError('Isi backup key tidak utuh.')
    for name, (value, executable) in files.items():
        private_write(destination/name, value)
        if executable:
            (destination/name).chmod(0o700)
    return json.loads(files['portable.json'][0])


def validate_profile(profile):
    info = json.loads((profile/'portable.json').read_text())
    if info.get('schema') != 1 or info.get('sha1') != builder.signing.TARGET_SHA1:
        raise RuntimeError('Backup ini tidak memakai SHA-1 key lama Kocehind yang diminta.')
    if not isinstance(info.get('previous_build_number'), int) or not 0 < info['previous_build_number'] < 2_100_000_000:
        raise RuntimeError('Nomor build dalam backup tidak valid.')
    project = profile/'old_project'
    if builder.application_id(builder.native_gradle(project)) != info['application_id']:
        raise RuntimeError('Package Android backup tidak cocok.')
    creds = json.loads((profile/'credentials.json').read_text())
    key = profile/'signing/upload-keystore.jks'
    entries = builder.signing.inspect(key, creds['storePassword']) or []
    selected = next((dict(e, path=key) for e in entries
                     if e['sha1'] == info['sha1'] and e['alias'] == creds['keyAlias']), None)
    if not selected:
        raise RuntimeError('Key lama atau password pada backup tidak cocok.')
    builder.validate_key(selected, creds['storePassword'], creds['keyPassword'])
    return project, info, creds


def finalize_profile(profile):
    project, info, creds = validate_profile(profile)
    key = profile/'signing/upload-keystore.jks'
    props = dict(storeFile=str(key), **creds)
    builder.signing.write_private(project/'flutter/android/key.properties',
        ''.join(k+'='+builder.signing.java_value(v)+'\n' for k, v in props.items()))
    # Discard SDK/Flutter absolute paths from the previous VPS.
    sdk = os.getenv('ANDROID_SDK_ROOT') or os.getenv('ANDROID_HOME') or str(Path.home()/'android-sdk')
    builder.signing.write_private(project/'flutter/android/local.properties',
        'sdk.dir='+builder.signing.java_value(sdk)+'\nflutter.versionCode='+str(info['previous_build_number'])+'\n')
    return project, info


def export_backup(args):
    project = builder.find_project(args.project)
    selected, password, keypass = builder.select_key(project, args.keystore, builder.signing.TARGET_SHA1)
    if keypass is None:
        keypass = getpass.getpass('Password alias/kunci (Enter jika sama dengan password keystore): ') or password
    builder.validate_key(selected, password, keypass)
    app_id = builder.application_id(builder.native_gradle(project))
    env = builder.build_environment(project, app_id)
    number = builder.next_number(project, app_id, Path.home()/'.kocehind-builds/latest-build.json') - 1
    payload, info = pack_profile(project, selected, password, keypass, env, number)
    if args.output.exists():
        raise RuntimeError('File backup tujuan sudah ada. Pindahkan dahulu atau gunakan --output nama-baru.enc.')
    private_write(args.output, encrypt(payload, request_phrase(confirm=True)))
    print('\nEKSPOR KEY LAMA SELESAI')
    print('Package: '+info['application_id'])
    print('SHA-1: '+builder.signing.fingerprint(info['sha1']))
    print('Nomor build terakhir terdeteksi: '+str(number))
    print('Pindahkan ke VPS baru: '+str(args.output))
    print('Simpan sandi backup. Berkas ini berisi key privat dan konfigurasi; jangan bagikan ke publik.')
    for key in ('GOOGLE_WEB_CLIENT_ID', 'FIREBASE_APP_ID'):
        if not env.get(key):
            print('Catatan: '+key+' tidak ditemukan di VPS lama; konfigurasi fitur tersebut perlu dilengkapi sebelum build.')


def import_backup(args):
    if args.profile.exists():
        raise RuntimeError('Profil signing sudah ada. Untuk build ulang gunakan perintah build; untuk impor lain pilih --profile folder-baru.')
    if not args.backup.is_file() or args.backup.stat().st_size > LIMIT:
        raise RuntimeError('Backup key belum ditemukan atau terlalu besar. Upload KOCEHIND_KEY_LAMA.enc dari VPS lama.')
    data = decrypt(args.backup.read_bytes(), request_phrase())
    args.profile.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    staged = Path(tempfile.mkdtemp(prefix='.kocehind-import-', dir=args.profile.parent))
    try:
        unpack_profile(data, staged)
        validate_profile(staged)
        os.rename(staged, args.profile)
        _, info = finalize_profile(args.profile)
    finally:
        if staged.exists():
            shutil.rmtree(staged)
    print('IMPOR KEY LAMA SELESAI: '+builder.signing.fingerprint(info['sha1']))
    return args.profile


def build_new(args):
    project, info = finalize_profile(args.profile)
    source = HERE/f'SOURCE_LENGKAP_v{builder.VERSION}.zip'
    config = json.loads((HERE/'package.json').read_text())
    payload = source.read_bytes()
    if config.get('version') != builder.VERSION or hashlib.sha256(payload).hexdigest() != config['source_sha256']:
        raise RuntimeError('Source terbaru tidak utuh. Ekstrak ulang ZIP paket build.')
    selected, password, keypass = builder.select_key(project, None, builder.signing.TARGET_SHA1)
    env = builder.build_environment(project, info['application_id'], allow_fetch=False)
    number = builder.next_number(project, info['application_id'], args.output_dir/'latest-build.json', args.build_number)
    if args.check_only:
        print('PEMERIKSAAN VPS BARU LULUS: source '+builder.VERSION+', key lama cocok, package '+info['application_id']+', calon nomor build '+str(number))
        return
    if not env.get('GOOGLE_WEB_CLIENT_ID'):
        raise RuntimeError('GOOGLE_WEB_CLIENT_ID belum terbawa dari VPS lama. Lengkapi environment ini agar Google Login tidak hilang pada build baru.')
    if not env.get('FIREBASE_APP_ID'):
        raise RuntimeError('Konfigurasi Firebase belum terbawa. Lengkapi FIREBASE_API_KEY, FIREBASE_APP_ID, FIREBASE_SENDER_ID, FIREBASE_PROJECT_ID agar push tetap berfungsi.')
    print('Konfigurasi Google/Firebase otomatis aktif; REQUIRE_PUSH='+env.get('REQUIRE_PUSH','0'))
    builder.execute(payload, config, project, selected, password, keypass, number, env, args.output_dir)


def main():
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    export = commands.add_parser('ekspor', help='Jalankan pada VPS lama yang menyimpan key asli.')
    export.add_argument('--project', type=Path)
    export.add_argument('--keystore', type=Path)
    export.add_argument('--output', type=Path, default=Path.home()/'KOCEHIND_KEY_LAMA.enc')
    imported = commands.add_parser('impor', help='Jalankan sekali pada VPS baru.')
    imported.add_argument('--backup', type=Path, default=Path.home()/'KOCEHIND_KEY_LAMA.enc')
    imported.add_argument('--profile', type=Path, default=Path.home()/'.kocehind-portable')
    build = commands.add_parser('build', help='Bangun APK+AAB terbaru menggunakan profil key yang sudah diimpor.')
    build.add_argument('--profile', type=Path, default=Path.home()/'.kocehind-portable')
    build.add_argument('--output-dir', type=Path, default=Path.home()/'.kocehind-builds')
    build.add_argument('--build-number', type=int)
    build.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    for key, value in vars(args).items():
        if isinstance(value, Path):
            setattr(args, key, value.expanduser().resolve())
    if args.command == 'ekspor':
        export_backup(args)
    elif args.command == 'impor':
        import_backup(args)
    else:
        if not args.profile.is_dir():
            raise RuntimeError('Key lama belum diimpor. Jalankan BUILD_VPS_BARU.sh setelah upload backup dari VPS lama.')
        build_new(args)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\nDihentikan. Key asli tidak diubah.', file=sys.stderr)
        sys.exit(130)
    except Exception as exc:
        message = str(exc) if isinstance(exc, RuntimeError) else 'Pemeriksaan/pemindahan/build gagal ('+type(exc).__name__+'); periksa error perintah di atas.'
        print('BELUM BERHASIL: '+message, file=sys.stderr)
        sys.exit(1)
