# Hasil pengujian Kocehind v2.13.1

Verifikasi selesai pada 28 Oktober 2026.

| Pemeriksaan | Hasil |
|---|---|
| Backend Python / SQLite, 9 berkas tes | 82 lulus |
| Web: unit DOM dan browser Chromium, 5 berkas tes | 20 lulus |
| Flutter: 4 berkas tes unit/widget | 19 lulus |
| Flutter analyzer pada 9 berkas terkait | Tidak ada issue |
| Pemeriksaan sintaks Python / JavaScript / shell dan whitespace diff | Lulus |

## Skenario penting

- Sembilan jenis gift membuat tepat satu komentar per receipt. Retry kunci
  transaksi yang sama tidak menggandakan receipt, komentar, atau saldo.
- Kekurangan koin tidak membuat komentar. Gangguan saat penyimpanan komentar
  membatalkan transaksi gift, ledger, dan perubahan saldo.
- Hanya Mahkota, Mobil, dan Istana membawa metadata video eksklusif. Gift biasa
  tidak dimasukkan ke antrean animasi web/Flutter.
- Boundary profil diuji satu mikrodetik sebelum dan tepat pada hari ke-7 dan
  ke-30. Perubahan nama tidak membuka username dan sebaliknya; bio tetap dapat
  disimpan saat kedua field terkunci.
- Host dapat menyimpan, memindah, mengubah warna/ukuran, menghapus, dan menyusun
  gambar/teks. Viewer ditolak saat mencoba mengubah state. Versi state lama
  ditolak dengan konflik, tanpa menimpa state terbaru.
- Field kosong, warna tidak valid, angka tak hingga, posisi melewati layar,
  ID ganda, dan jumlah elemen melebihi 12 ditolak.
- Gambar milik pengguna lain dan URL eksternal ditolak. Salinan siaran dapat
  dilihat penonton, sedangkan unggahan asli tetap privat. Penghapusan elemen,
  berakhirnya LIVE, dan pemblokiran global host menghentikan akses salinan.
- Browser dengan dua sesi membuktikan penambahan galeri/teks, warna background,
  posisi setelah drag, urutan depan/belakang, dan komentar gift sama pada host
  serta penonton. Media host tidak disambungkan ulang saat mengatur layar.
- Widget Flutter memeriksa drag host, batas posisi, mode viewer yang tidak
  dapat menggeser, dua versi teks, serta pemilihan warna background.
- Regresi Tripay, dompet skema VPS/frozen v8, ledger, migrasi, susunan LIVE,
  preview feed, dan alur membuat LIVE ikut diuji.

## Menjalankan ulang

Dari root source, gunakan environment Python dengan `backend/requirements.txt`,
`pytest`, `httpx`, dan FFmpeg/FFprobe:

```bash
python -m pytest -q backend/tests/test_live_canvas_v2131.py \
  backend/tests/test_wallet_v213.py backend/tests/test_wallet_vps_schema_v213.py \
  backend/tests/test_wallet_legacy_accounts_v213.py \
  backend/tests/test_wallet_legacy_ledger_v213.py \
  backend/tests/test_tripay_sync_v213.py backend/tests/test_migration_v213_import_order.py \
  backend/tests/test_live_layout_v2126.py backend/tests/test_live.py
```

Dengan dependensi npm dan Chromium Playwright tersedia:

```bash
node --test --test-force-exit \
  websites/web/test-live-canvas-v2131.mjs \
  websites/web/test-feed-preview-v2127.mjs \
  websites/web/test-live-canvas-v2131-browser.mjs \
  websites/web/test-feed-live-v2126-browser.mjs \
  websites/web/test-wallet-v213-browser.mjs
```

Dari folder `flutter`, dengan Flutter 3.35.5 / Dart 3.9.2:

```bash
flutter pub get
flutter analyze lib/widgets/live_canvas.dart lib/screens/live_overlay_editor.dart \
  lib/widgets/live_gifts.dart lib/widgets/live_stage.dart lib/screens/live_screens.dart \
  lib/screens/live_preview.dart lib/screens/interaction_screens.dart lib/widgets/ui.dart \
  test/live_canvas_v2131_test.dart
flutter test test/live_canvas_v2131_test.dart test/live_preview_v2127_test.dart \
  test/feed_live_v2126_test.dart test/creation_live_test.dart
```

Lockfile Flutter telah diselaraskan dengan SDK 3.35.5 yang diuji; batas dependensi
aplikasi tetap sama. Builder VPS baru menggunakan patch SDK ini secara default.

## Batas verifikasi

Tes backend memakai SQLite dan provider pembayaran tiruan. Tes browser memakai
SDK media tiruan serta dua sesi pada browser sungguhan; tes Flutter memakai
widget test. Ini belum merupakan uji pada VPS/PostgreSQL/LiveKit/merchant
produksi, perangkat Android fisik, atau build APK/AAB bertanda tangan. Tidak ada
layanan pengguna yang di-deploy dari sesi pengerjaan ini. Panduan menyediakan
langkah update dan uji dua akun setelah pemasangan. Gambar/teks LIVE tambahan
belum dibakar ke rekaman Studio; fitur ini menyinkronkan layar klien saat LIVE.
