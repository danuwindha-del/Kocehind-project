#!/usr/bin/env python3
"""Collect read-only backend diagnostics from the bundled source."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

import latest_build as builder


def main():
    if os.geteuid() != 0 or not Path('/etc/kocehind/backend.env').is_file():
        raise RuntimeError('Jalankan dengan sudo pada VPS backend/web yang sudah terpasang.')
    here = Path(__file__).resolve().parent
    payload = (here/f'SOURCE_LENGKAP_v{builder.VERSION}.zip').read_bytes()
    config = json.loads((here/'package.json').read_text())
    if config['version'] != builder.VERSION or hashlib.sha256(payload).hexdigest() != config['source_sha256']:
        raise RuntimeError('Source paket tidak utuh. Ekstrak ulang ZIP terbaru.')
    print('Mengumpulkan diagnosis backend tanpa restart atau mengubah konfigurasi.', flush=True)
    with tempfile.TemporaryDirectory(prefix='kocehind-update-') as folder:
        project = builder.extract_source(payload, Path(folder))
        subprocess.run(['bash', str(project/'scripts/vps2_diagnosa_backend.sh')], check=True)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, ValueError, subprocess.SubprocessError) as exc:
        message = str(exc) if isinstance(exc, RuntimeError) else 'Diagnosis belum selesai; periksa pesan terminal di atas.'
        print('BELUM BERHASIL: '+message, file=sys.stderr)
        sys.exit(1)
