# Hotfix v5 — sinkronisasi pembayaran Tripay

Paket ini memakai **Kocehind_Hotfix_v4_migrasi_wallet_entries.zip** yang Anda kirim sebagai dasar. Backend menjadi **2.13.0-tripay1**. Android tetap 2.13.0+31 dan APK yang sekarang dapat digunakan.

## Masalah dan perubahan

Sebelumnya tombol **Periksa pembayaran** hanya membaca database Kocehind. Jika perubahan status di sandbox belum diterima lewat callback, refresh halaman tetap memperlihatkan status lama. Pemeriksaan satu tagihan juga hanya membaca detail tanpa meminta penyegaran status provider.

Sekarang halaman dompet melakukan pemeriksaan saat dibuka, saat Periksa pembayaran ditekan, saat tab kembali aktif, serta berkala pada tab yang terlihat. Tombol Cek status memeriksa satu tagihan. Pemeriksaan latar dibatasi satu tagihan per interval, sedangkan tombol utama memeriksa hingga lima tagihan terbaru dengan maksimal dua permintaan bersamaan.

Backend memanggil `transaction/check-status`, lalu mengambil `transaction/detail` dari mode Tripay yang dikonfigurasi. Respons check-status resmi dapat berisi success/message tanpa data; format ini sudah ditangani. Status tidak ditebak dari teks pesan. Invoice, referensi provider, metode dan nominal tetap harus cocok sebelum koin dikreditkan. Perubahan saldo dan bukti kredit dicatat dalam transaksi yang sama, sehingga refresh/callback berulang tidak menggandakan koin.

Saldo web dibaca lagi setelah verifikasi pembayaran selesai. Jika provider gagal dihubungi atau data tidak cocok, halaman menampilkan kesalahan untuk dicoba kembali. Pemeriksaan admin menggunakan alur verifikasi yang sama.

Perbaikan skema dan constraint v4, saldo koin lama, serta tampilan riwayat lama tetap dipertahankan. Hotfix ini tidak memerlukan migrasi baru di luar migrasi v4 yang sudah disertakan.

## Memasang pada backend/web aktif

Upload `Kocehind_Hotfix_v5_Tripay_sync.zip` ke `/root`, akhiri LIVE yang sedang berjalan, lalu jalankan sebagai root:

```bash
cd /root
unzip -o Kocehind_Hotfix_v5_Tripay_sync.zip -d /root
cd /root/kocehind_v2130_vps_baru
sha256sum -c SHA256SUMS.txt
```

Setelah semua checksum OK:

```bash
python3 /root/kocehind_v2130_vps_baru/UPDATE_BACKEND_WEB.py
curl -fsS http://127.0.0.1:8000/health
```

Health harus menunjukkan `2.13.0-tripay1`. Updater tetap menjalankan backup, preflight, migrasi v4 dan pemasangan web melalui alur yang sudah ada. Konfigurasi Tripay dibaca dari `/etc/kocehind/backend.env` pada server.

## Memeriksa tagihan yang sudah terlanjur dibayar

1. Buka halaman `/wallet` di Kocehind Web. Muat ulang dengan Ctrl+Shift+R agar modul hotfix dimuat.
2. Tekan **Periksa pembayaran**, atau **Cek status** pada invoice yang sudah ditandai PAID di sandbox.
3. Tunggu keterangan pemeriksaan selesai. Bila detail API Tripay menyatakan PAID dan cocok, status berubah menjadi Dibayar dan koin masuk. Gunakan tagihan yang sudah ada; tidak perlu membeli ulang.
4. Buka kembali saldo di aplikasi untuk melihat koin yang sama.

Mode `TRIPAY_MODE` dan tiga kredensial harus berasal dari merchant/mode yang dipakai saat tagihan dibuat. Jika detail API Tripay sendiri masih UNPAID, hotfix akan menampilkan UNPAID sampai provider melaporkan PAID. Jika muncul pesan kesalahan, kirim teks kesalahan tersebut untuk diagnosis; API Key dan Private Key tetap disimpan di server.

## Pengujian aktual

- 29 tes server lulus: sepuluh skenario sinkronisasi Tripay, sepuluh tes dompet/gift/penarikan, dan sembilan tes migrasi v4.
- Enam tes browser dompet/gift/admin lulus. Tiga skenario baru membuktikan pemulihan PAID tanpa callback pada reload, pemeriksaan tombol dengan retry setelah error, dan pemeriksaan saat tab kembali aktif.
- 41 tes DOM/session/Studio lulus.
- Hasil preflight dan verifikasi paket tercatat pada bagian akhir dokumen ini.

Kasus tambahan yang diuji meliputi penolakan invoice/referensi/metode/nominal yang salah, larangan memeriksa invoice akun lain, pesan PAID tanpa receipt PAID, timeout provider, serta callback yang datang di tengah refresh. Saldo dan jumlah entri kredit diverifikasi agar tidak bertambah dua kali.

Pengujian memakai SQLite dan API/callback Tripay tiruan. Belum ada akses ke merchant sandbox atau VPS pengguna, sehingga hotfix belum dipasang atau diuji langsung pada transaksi pengguna. Pemeriksaan konkurensi PostgreSQL lintas proses belum dijalankan. Source Android dipertahankan dari v4 dan tidak memerlukan build ulang untuk perbaikan ini.

Dokumentasi primer: https://tripay.co.id/developer (Cek Status Transaksi, Detail Transaksi, Callback).

Verifikasi akhir: **7 tes preflight lulus**, termasuk startup API dua worker dan readiness versi hotfix. Hash seluruh berkas Flutter, model dompet, serta migrasi v4 dibandingkan dengan ZIP dasar dan tetap sama. Paket diperiksa dengan CRC ZIP, SHA-256 dan uji ekstraksi menggunakan helper builder.
