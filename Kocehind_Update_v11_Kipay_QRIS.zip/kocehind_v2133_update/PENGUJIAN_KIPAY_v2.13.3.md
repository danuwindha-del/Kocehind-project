# Pengujian v11 / v2.13.3 Kipay

Dilakukan 28 Oktober 2026. Hasil akhir: 115 pengujian backend dan 23 pengujian web lulus.

## Backend

Lingkungan: Python 3.11+, FastAPI/SQLAlchemy; database SQLite terisolasi per pengujian.
Semua respons Kipay/Tripay dan layanan eksternal diganti fixture, tanpa credential
atau transaksi nyata. Suite legacy gift memakai FFmpeg untuk fixture rendering.

Command dari root source, dengan dependency requirements dan pytest tersedia:

```bash
python -m pytest -q backend/tests/test_kipay_v2133.py backend/tests/test_wallet_v213.py backend/tests/test_tripay_sync_v213.py backend/tests/test_wallet_legacy_accounts_v213.py backend/tests/test_wallet_legacy_ledger_v213.py backend/tests/test_wallet_vps_schema_v213.py backend/tests/test_migration_v213_import_order.py backend/tests/test_live_summary_v2132.py backend/tests/test_live_canvas_v2131.py backend/tests/test_live.py
```

Cakupan: request create/retrieve/QR sesuai kontrak; key tidak masuk respons browser;
akses QR dibatasi pemilik; status paid memerlukan GET terverifikasi; HMAC raw body,
replay window 5 menit, pembatasan JSON dan ukuran; antrean commit sebelum ACK;
webhook ganda dan polling tidak menggandakan kredit; timeout create tidak mengirim
invoice kedua; callback/admin dapat memulihkan trx_id; retry worker tersimpan;
nominal/mode/ref/note/biaya yang berbeda ditolak; sandbox dan production tidak dicampur;
redirect HTTP tidak diikuti; path berisi key direduksi di log HTTP; kredit membayar
coin_debt dengan pembukuan lama; migrasi aditif dan pemisahan Tripay/Kipay;
regresi frozen/ledger/account lama, gift, recap IDR, top 3, dan kanvas LIVE.

## Web

23 pengujian lulus: 14 skenario Chromium nyata dan 9 cek modul/DOM Node.
Tidak ada error JavaScript pada skenario browser yang dijalankan.

```bash
CHROMIUM_EXECUTABLE=/path/to/chromium node --test websites/web/test-kipay-v2133-browser.mjs websites/web/test-wallet-v213-browser.mjs websites/web/test-v2132-browser.mjs websites/web/test-summary-profile-v2132.mjs websites/web/test-live-canvas-v2131.mjs websites/web/test-live-loves.mjs websites/main/test-legal-content.mjs
```

Termasuk QRIS/tagihan pada lebar 360 dan 1440, total Rp10.215 dari fixture,
label sandbox, biaya merchant, simpan QR, pembaruan dialog saat paid/expired,
buka ulang pesanan, kegagalan gambar/konfigurasi, saldo setelah verifikasi,
checkout Tripay lama, penarikan, admin, homepage, foto profil, dan ringkasan LIVE.
Gambar QR fixture browser adalah PNG sintetis; bukan QRIS pembayaran yang diuji scan.

Python AST, bash -n skrip deploy yang diubah, dan node --check modul produksi yang
diubah lulus. ZIP dan hash manifest source/wrapper diverifikasi saat pengemasan.

## Batas verifikasi

Belum melakukan pembayaran Kipay sandbox/production dengan akun merchant Anda,
uji scan QR melalui aplikasi pembayaran, deploy ke VPS Anda, uji konkruensi dengan
PostgreSQL produksi, atau build/install APK/AAB baru. Tidak ada jaminan aktivasi
merchant berdasarkan unit test. Lanjutkan satu transaksi sandbox dan production
sesuai panduan setelah mengisi credential langsung di VPS.

SDK Flutter tidak dijalankan untuk pembaruan backend/web ini. APK lama tetap dapat
digunakan; builder disertakan untuk kebutuhan build berikutnya.
