# Catatan dokumen Kocehind siap ditempel

Diperbarui 25 Oktober 2026. Kedua berkas teks sudah berisi tanggal, identitas dan kontak yang diberikan pengelola. Tidak ada kolom pengganti yang harus diisi manual.

## Isi yang sudah dimasukkan

- Pengelola: PT MychaDaf Tecno Indonesia.
- Email privasi, bantuan dan pengaduan: mychadaftecnoindonesia@gmail.com.
- WhatsApp: +6285182631819, dengan tautan https://wa.me/6285182631819.
- Tanggal berlaku: 25 Oktober 2026.
- Infrastruktur: VPS sewa. Nama penyedia, alamat perusahaan atau negara penempatan server tidak dikarang. Kebijakan menjelaskan bahwa informasi penerima dan negara pemrosesan dapat diminta melalui kontak resmi.
- Masa simpan yang tidak diketahui dijelaskan memakai kriteria tujuan dan kebutuhan data, tanpa menetapkan angka yang tidak didukung konfigurasi. Ketentuan rekaman Studio tujuh hari serta bukti moderasi tertentu sampai tenggat banding ditambah tujuh hari tetap mengikuti source yang ditinjau.

## Penyesuaian batas usia

Permintaan “15+ 18+” disusun menjadi kebijakan akun minimal 16 tahun, pengguna 16–17 tahun dengan persetujuan dan pendampingan orang tua/wali, serta host atau tamu LIVE yang mempublikasikan suara/kamera minimal 18 tahun. Penyesuaian dari 15 tahun dijelaskan kepada pengelola; aturan untuk platform berisiko tinggi tidak boleh dianggap dikecualikan hanya dengan izin orang tua.

Rujukan resmi:

- [Permenkomdigi Nomor 9 Tahun 2026](https://jdih.komdigi.go.id/produk_hukum/view/id/1007/t/peraturan+menteri+komunikasi+dan+digital+nomor+9+tahun+2026).
- [Penjelasan Komdigi tentang akun anak di bawah 16 tahun pada platform berisiko tinggi](https://portal.komdigi.go.id/kanal-publik/berita-kini/10066).
- [Buku penjelasan resmi PP TUNAS, termasuk usia 16–17 tahun dan persetujuan orang tua](https://djkpm.komdigi.go.id/assets/files/tunaspedia-buku-1.pdf).
- [UU Nomor 27 Tahun 2022 tentang Pelindungan Data Pribadi](https://jdih.komdigi.go.id/produk_hukum/view/id/832/t/undangundang+nomor+27+tahun+2022).

Batas host/tamu LIVE 18 tahun adalah pilihan kebijakan dalam teks ini, bukan pernyataan bahwa setiap undang-undang selalu mensyaratkan angka tersebut untuk semua LIVE. Penyusunan ini juga bukan penetapan resmi klasifikasi risiko Kocehind oleh regulator.

Perubahan teks tidak menambahkan verifikasi usia atau pencatatan persetujuan wali ke aplikasi. Source yang ditinjau belum memiliki mekanisme tersebut. Aturan dokumen perlu dilaksanakan melalui pengelolaan layanan dan mekanisme yang sesuai; menyetujui teks bukan bukti bahwa verifikasi sudah terjadi.

## Cara menggunakan

1. Buka berkas KEBIJAKAN_PRIVASI_KOCEHIND_2026.txt, salin seluruh isinya, lalu tempel ke isi dokumen Kebijakan Privasi pada dashboard admin.
2. Buka berkas KETENTUAN_LAYANAN_KOCEHIND_2026.txt, salin seluruh isinya, lalu tempel ke isi dokumen Ketentuan Penggunaan/Layanan pada dashboard admin.
3. Gunakan judul “Kebijakan Privasi Kocehind” dan “Ketentuan Layanan Kocehind”. Alasan pembaruan dapat ditulis: “Pembaruan identitas pengelola, kontak, usia, VPS, serta kebijakan layanan dan data Kocehind.”
4. Tinjau pratinjau dan terbitkan masing-masing melalui tombol yang tersedia. Server mencatat versi dan audit. Tidak perlu membangun ulang APK hanya untuk menerbitkan teks melalui fitur admin yang sudah ada.

Berkas catatan ini untuk pengelola, bukan untuk ditempel ke dokumen publik. Penyerahan berkas tidak menerbitkan kebijakan ke server. Komitmen penanganan hak data, promosi, penghapusan, cadangan dan insiden tetap perlu dijalankan dalam operasi layanan; teks bukan sertifikasi kepatuhan atau penerapan kontrol teknis.
