# Hotfix v6: kolom ledger lama menghalangi kredit Tripay

Backend: **2.13.0-tripay2**. Berdasarkan hotfix v5 dan ZIP v4 yang diberikan pengguna. Semua fungsi sinkronisasi Tripay v5 tetap disertakan. Android tetap 2.13.0+31; hotfix ini cukup dipasang pada VPS backend/web.

## Penyebab yang sudah ditemukan

Log VPS memperlihatkan `psycopg.errors.NotNullViolation`: kolom `coins_delta` pada `wallet_entries` tidak boleh NULL. Respons `/health` sudah 200 dengan versi v5, jadi hotfix v5 memang aktif. Kegagalan terjadi saat commit pencatatan kredit top up, setelah proses mencapai penambahan koin. Transaksi database dibatalkan; saldo tetap belum bertambah.

Migrasi v4 menambah `unit`, `delta`, `balance_after`, dan `held_after` untuk skema baru, namun tabel lama tetap memiliki kolom delta wajib yang belum diisi oleh penulis ledger baru.

## Perbaikan

Penulis ledger sekarang membaca struktur aktual `wallet_entries` satu kali per engine/proses. Penulisan memakai koneksi/transaksi yang sama dengan saldo dan invoice. Jika terdapat `coins_delta`, kolom itu diisi perubahan koin yang sebenarnya. Jika terdapat `earnings_delta` atau nama lama `income_delta`, kolom tersebut diisi perubahan pendapatan IDR. Unit yang tidak terkait mendapat delta nol. `held_delta` tetap mencatat perubahan saldo penarikan.

Kolom/tabel/constraint lama tidak dihapus atau dilonggarkan. Tidak ada perubahan pada baris riwayat lama, konfigurasi Tripay, atau saldo secara manual. Model dan migrasi v4 tetap sama. Pemeriksaan provider, penolakan nominal/metode/referensi yang berbeda, penguncian invoice, dan idempotensi pembayaran tetap berlaku.

## Instalasi

Upload `Kocehind_Hotfix_v6_Ledger_Tripay.zip` ke `/root` VPS backend/web. Akhiri LIVE yang sedang berlangsung, lalu jalankan:

```bash
sudo -i
unzip -o /root/Kocehind_Hotfix_v6_Ledger_Tripay.zip -d /root
cd /root/kocehind_v2130_vps_baru
sha256sum -c SHA256SUMS.txt && python3 UPDATE_BACKEND_WEB.py
curl -fsS --max-time 15 http://127.0.0.1:8000/health
```

Versi health harus **2.13.0-tripay2**. Updater lengkap tetap memakai alur backup, migrasi, preflight pengguna service, rollback code jika update gagal, dan publikasi web yang sudah ada. Ini paket source lengkap beserta builder, bukan APK/AAB yang sudah dibangun. Tidak diperlukan build ulang Android untuk perubahan ledger ini.

## Memulihkan transaksi yang sudah dibayar

1. Buka dompet web dan muat ulang halaman.
2. Tekan **Cek status** pada invoice yang telah dibayar, atau **Periksa pembayaran**. Tidak perlu membuat pembelian baru.
3. Backend akan memeriksa kembali receipt Tripay. Jika PAID, metode/referensi/nominal cocok, dan belum dikreditkan, saldo serta bukti kredit disimpan bersama. Contoh tagihan 5.000 koin menambah 5.000 koin satu kali, di luar penyesuaian utang refund yang memang ada.
4. Buka ulang dompet aplikasi untuk melihat saldo yang sama.

Jika health masih menunjukkan tripay1, update belum selesai. Jika ada error baru, ambil log service setelah menekan Cek status; jangan mengubah saldo, menghapus ledger, atau membayar ulang untuk mencoba memulihkannya.

## Pengujian

- **43 tes backend lulus**: 7 regresi ledger lama, 10 sinkronisasi Tripay, 10 dompet/gift/penarikan, 9 migrasi v4, dan 7 preflight/startup.
- Regresi membuat tabel dengan `coins_delta` dan delta pendapatan NOT NULL tanpa default; insert ORM lama direproduksi gagal. Penulis baru kemudian berhasil mengreditkan tagihan 5.000 koin.
- Diuji saldo awal nol serta saldo lama 735 koin, kedua nama delta pendapatan, riwayat historis yang tetap utuh, refresh/callback berulang, gift, penarikan ditolak/dibayar, refund, dan penyelesaian utang koin.
- Gangguan sengaja disisipkan setelah insert ledger sebelum commit invoice: ledger, saldo, dan status invoice seluruhnya batal, lalu retry berhasil satu kali.
- JavaScript/Flutter, model, dan migrasi v4 dipertahankan. Tes browser yang tercatat pada dokumen v5 adalah hasil rilis v5, bukan pengujian ulang v6.

Tes yang dijalankan menggunakan SQLite dan provider Tripay tiruan. Ada tes PostgreSQL opsional di `backend/tests/test_wallet_ledger_postgres_v213.py` untuk database pengujian terisolasi, tetapi belum dijalankan: lingkungan ini tidak mengizinkan pergantian user yang dibutuhkan untuk menjalankan server PostgreSQL lokal. Belum ada akses VPS/merchant untuk memasang atau menguji hotfix langsung pada transaksi pengguna.

```bash
python -m pytest -q backend/tests/test_wallet_legacy_ledger_v213.py \
  backend/tests/test_tripay_sync_v213.py backend/tests/test_wallet_v213.py \
  backend/tests/test_migration_v213_import_order.py backend/tests/test_deploy_preflight_r2.py
```
