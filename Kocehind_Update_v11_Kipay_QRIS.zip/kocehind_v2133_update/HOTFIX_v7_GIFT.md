# Hotfix v7 — gagal membuat dompet penerima gift pada database lama

Backend terbaru: **2.13.0-gift1**. Paket lengkap ini melanjutkan v6; perbaikan sinkronisasi Tripay dan penulisan ledger lama tetap disertakan. Hotfix cukup dipasang pada **VPS backend/web**. APK yang sudah dipakai tetap kompatibel.

## Penyebab dari log pengguna

Log lengkap menunjukkan empat permintaan `POST /live/rooms/.../gifts` berakhir HTTP 500 dengan `psycopg.errors.NotNullViolation`: kolom `earnings_rupiah` pada tabel `wallets` tidak boleh NULL.

Backend telah membaca dompet pengirim, lalu mencoba membuat dompet host yang belum ada. INSERT hanya mengisi kolom model sekarang, sementara tabel lama masih memiliki kolom rupiah tambahan yang wajib diisi tanpa default. Kegagalan terjadi sebelum pemotongan koin dan sebelum pencatatan gift. Error top up `coins_delta` yang juga muncul di bagian lebih awal log berasal dari rilis sebelum v6; perbaikannya tetap ada di paket ini.

## Perubahan

Pembuatan dompet baru sekarang memakai struktur tabel `wallets` aktual, dengan koneksi dan transaksi yang sama dengan pengiriman gift atau pembayaran. Seluruh saldo model sekarang dimulai dari nol. Kolom tambahan lama berupa penghitung integer wajib, termasuk `earnings_rupiah`, juga diinisialisasi nol **hanya untuk baris dompet baru**. Default, identity, computed column, dan kolom nullable yang telah tersedia tetap mengikuti skema. Kolom timestamp lama `created_at`/`updated_at` yang wajib tanpa default diberi waktu UTC saat pembuatan.

Dompet yang sudah ada tidak dibuat ulang atau direset. Nilai kolom lama yang sudah tersimpan tidak disalin, digabung, ditimpa, atau ditafsirkan ulang sebagai saldo baru. Pencatatan aktif tetap memakai kolom model v2.13 dan ledger yang sama dengan v6. Jika suatu skema memiliki data wajib lain yang tidak dapat dibuat secara aman, backend mengembalikan HTTP 503 JSON dan mencatat nama kolom untuk diperiksa; identifier atau data tersebut tidak dikarang.

Kunci pengguna, transaksi atomik, aturan saldo cukup, larangan gift ke diri sendiri, dan kunci idempotensi tetap berlaku. Kegagalan setelah penulisan ledger membatalkan dompet baru, gift, saldo pengirim, pendapatan host, dan ledger bersama-sama.

Tidak ada penghapusan atau pelonggaran constraint, perubahan skema tambahan, perubahan aset gift, atau perubahan Flutter/web/Tripay. Model dan migrasi database v4 tetap dipertahankan. Pesan aplikasi lama yang menyebut upload merupakan pesan umum saat respons bukan JSON; perbaikan ini menangani kegagalan backend yang ditemukan pada log.

## Memasang

Upload **Kocehind_Hotfix_v7_Gift_Wallet.zip** ke `/root` pada VPS backend/web, akhiri semua LIVE yang aktif, lalu:

```bash
sudo -i
unzip -o /root/Kocehind_Hotfix_v7_Gift_Wallet.zip -d /root
cd /root/kocehind_v2130_vps_baru
sha256sum -c SHA256SUMS.txt && \
python3 UPDATE_BACKEND_WEB.py && \
curl -fsS --max-time 15 http://127.0.0.1:8000/health
```

Health harus menunjukkan **2.13.0-gift1**. Updater menggunakan alur backup database/media, migrasi yang sudah ada, preflight pengguna service, rollback kode bila update gagal, dan pemasangan web yang sama dengan paket v6. Konfigurasi/key yang ada tetap digunakan. Jangan menghapus tabel dompet atau mengubah saldo manual.

Sesudah update, buat LIVE kembali dan bergabung menggunakan akun pengirim yang berbeda dari host. Buka pilihan gift, segarkan saldo, lalu kirim Mawar satu kali. Jika berhasil, saldo pengirim berkurang 1 koin dan pendapatan host bertambah menurut tarif admin saat transaksi (default Rp50 per koin). Riwayat gift mencatat satu gift. Tidak diperlukan pembelian koin baru atau build ulang APK untuk hotfix ini.

Paket tetap menyertakan source/builder Android bila ingin membangun di VPS builder yang sudah memakai key lama:

```bash
bash /root/kocehind_v2130_vps_baru/BUILD_VPS_BARU.sh
```

## Pengujian

Delapan tes regresi baru memakai tabel `wallets` dengan empat kolom rupiah integer wajib tanpa default, serta tabel `wallet_entries` lama yang mewajibkan delta terpisah. Dua variasi nama penghitung lama diuji berdasarkan struktur aktual, tanpa bergantung pada tebakan nama keempat kolom.

- INSERT ORM sebelum perbaikan direproduksi gagal pada `earnings_rupiah`.
- Seluruh sembilan gift dikirim kepada host yang belum punya dompet, dengan saldo awal pengirim 25.000 koin. Saldo, pendapatan, sembilan receipt dan delapan belas ledger diverifikasi. Pengiriman ulang kunci yang sama tidak memotong saldo dua kali.
- Top up terverifikasi membuat dompet pengguna baru pada kedua variasi skema, dan callback ulang tidak menggandakan kredit.
- Gangguan setelah kedua ledger gift ditulis membatalkan seluruh transaksi termasuk dompet host baru; retry dengan kunci yang sama berhasil sekali.
- Saldo dan nilai historis dompet yang sudah ada tidak direset. Timestamp wajib serta default server dipertahankan. Data wajib yang tidak dikenal ditolak tanpa penulisan saldo.

Hasil suite lengkap dicatat pada ringkasan verifikasi akhir. Tes memakai SQLite dan provider Tripay tiruan; belum dijalankan pada PostgreSQL atau transaksi langsung pengguna. Paket belum dipasang pada VPS pengguna dari lingkungan ini. Tes PostgreSQL opsional dari v6 tetap disertakan. Flutter/web tidak berubah, sehingga tidak dilakukan build Android atau pengujian ulang browser untuk hotfix backend ini.

```bash
python -m pytest -q backend/tests/test_wallet_legacy_accounts_v213.py \
  backend/tests/test_wallet_legacy_ledger_v213.py backend/tests/test_tripay_sync_v213.py \
  backend/tests/test_wallet_v213.py backend/tests/test_migration_v213_import_order.py \
  backend/tests/test_deploy_preflight_r2.py
```

Verifikasi akhir: **51 tes backend lulus** (8 regresi dompet lama baru, 7 regresi ledger v6, 10 sinkronisasi Tripay, 10 dompet/gift/penarikan, 9 migrasi v4, 7 preflight/startup). Skrip installer dan file Python yang diubah lolos pemeriksaan sintaks. Flutter/web, model, migrasi dan integrasi Tripay dibandingkan dengan v6 dan tidak berubah.
