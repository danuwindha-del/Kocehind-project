# Hotfix v8 — kolom Boolean frozen pada skema VPS

Backend terbaru: **2.13.0-gift2**. Paket lengkap ini melanjutkan v7 dan menyertakan seluruh perbaikan Tripay/ledger v5–v6. Perubahan cukup dipasang pada VPS backend/web. APK yang sekarang tetap kompatibel.

## Penyebab yang dipastikan dari skema

File struktur tabel dari VPS memperlihatkan tabel `wallets` dengan kolom wajib tanpa default: `user_id`, `coins`, `earnings_rupiah`, `held_rupiah`, `earned_total_rupiah`, dan `frozen`. Tiga penghitung rupiah bertipe BIGINT sudah ditangani v7. Kolom `frozen` bertipe BOOLEAN belum ditangani. Log terfilter secara eksplisit berisi `wallet_schema_unsupported_required_column column=frozen`.

Akibatnya v7 mengembalikan HTTP 503 JSON saat mencoba membuat dompet host baru. Pesan aplikasi adalah “Struktur dompet lama belum kompatibel”. Pemeriksaan berhenti sebelum pembuatan gift atau pemotongan koin.

## Perubahan yang terbatas

Saat membuat **baris dompet baru**, penulis mengisi `frozen=False` jika kolom itu bertipe Boolean, wajib diisi, dan tidak memiliki nilai default/generasi dari database. Penghitung saldo baru tetap nol. Hanya kolom bernama `frozen` yang mendapat inisialisasi Boolean tersebut; kolom Boolean wajib lain yang tidak dikenal tetap ditolak, bukan diberi nilai sembarang.

Dompet yang sudah ada tidak dibuat ulang. Nilai `frozen=True`, saldo koin/rupiah, penghitung lama/baru, dan riwayat yang sudah tersimpan tidak diubah oleh inisialisasi ini. Tidak ada perintah UPDATE massal, penghapusan data, perubahan default/constraint, atau perubahan model/migrasi v4. Penanganan kebijakan pembekuan di luar pembuatan baris baru tidak diubah oleh hotfix ini.

Transaksi gift, saldo pengirim, pendapatan host, dompet host baru, dan ledger tetap disimpan atau dibatalkan bersama. Kunci transaksi tetap mencegah pemotongan/kredit dua kali. Integrasi Tripay, aset gift, source Flutter/web, dan konfigurasi server tetap mengikuti v7.

## Instalasi

Upload **Kocehind_Hotfix_v8_Frozen_Gift.zip** ke `/root` pada VPS backend/web. Akhiri semua LIVE aktif, lalu:

```bash
sudo -i
unzip -o /root/Kocehind_Hotfix_v8_Frozen_Gift.zip -d /root
cd /root/kocehind_v2130_vps_baru
sha256sum -c SHA256SUMS.txt && \
python3 UPDATE_BACKEND_WEB.py && \
curl -fsS --max-time 15 http://127.0.0.1:8000/health
```

Health harus menunjukkan **2.13.0-gift2**. Updater lengkap tetap memakai backup database/media, migrasi yang sudah ada, preflight pengguna service, dan rollback kode jika update gagal. Tidak diperlukan pembelian koin baru atau build ulang Android.

Sesudah update, mulai LIVE kembali, bergabung dari akun lain, segarkan saldo pada pilihan gift, lalu kirim Mawar satu kali. Bila saldo cukup dan kedua akun memenuhi aturan LIVE/gift, saldo pengirim berkurang 1 koin, pendapatan host bertambah sesuai tarif admin, dan riwayat mencatat satu gift.

## Pengujian sesuai skema yang diberikan

Fixture `backend/tests/fixtures/wallet_schema_vps_v8.json` berisi struktur empat tabel (`wallets`, `wallet_entries`, `live_gifts`, `wallet_withdrawals`) yang diberikan pengguna, tanpa isi baris database atau log. Tes membangun ulang nama/tipe/nullable/default, check constraint dan foreign key tersebut pada database SQLite sementara. Unique guard idempotensi yang sudah diwajibkan migrasi v4 ikut dipasang; file inspeksi pengguna sebelumnya tidak meminta metadata unique index.

Enam skenario tambahan memeriksa:

- INSERT dengan semua nilai rupiah namun tanpa `frozen` direproduksi gagal pada constraint NOT NULL.
- Semua sembilan gift berhasil kepada host baru dengan saldo awal pengirim 25.000 koin, sembilan receipt, delapan belas ledger, jumlah saldo/pendapatan yang sesuai, dan pengiriman ulang tanpa duplikasi. Penarikan host juga diuji hingga status paid pada skema yang diberikan.
- Pembayaran terverifikasi melalui refresh dan callback sama-sama dapat membuat dompet baru dengan `frozen=False`; callback ulang tidak menggandakan kredit.
- Seluruh nilai dompet lama termasuk `frozen=True` tetap utuh ketika dompet pengguna lain dibuat.
- Gangguan setelah ledger gift ditulis membatalkan dompet host baru, gift, ledger, dan pemotongan saldo; retry kunci yang sama berhasil sekali.
- Kolom Boolean wajib lain yang tidak dikenal tetap ditolak tanpa pembuatan saldo/kredit.

Hasil suite penuh tercatat pada verifikasi akhir. Pengujian ini memakai SQLite dan provider Tripay tiruan; skema PostgreSQL direproduksi dengan batas tersebut. Belum ada pengujian langsung pada PostgreSQL/merchant/VPS pengguna atau build APK baru. Tes PostgreSQL opsional dari v6 tetap disertakan.

```bash
python -m pytest -q backend/tests/test_wallet_vps_schema_v213.py \
  backend/tests/test_wallet_legacy_accounts_v213.py backend/tests/test_wallet_legacy_ledger_v213.py \
  backend/tests/test_tripay_sync_v213.py backend/tests/test_wallet_v213.py \
  backend/tests/test_migration_v213_import_order.py backend/tests/test_deploy_preflight_r2.py
```

Verifikasi akhir: **57 tes backend lulus**: 6 tes pada empat skema tabel VPS yang diberikan, 8 regresi dompet v7, 7 regresi ledger v6, 10 sinkronisasi Tripay, 10 dompet/gift/penarikan, 9 migrasi v4, dan 7 preflight/startup. Seluruh source Flutter/web, model/migrasi, integrasi Tripay, ledger dan perhitungan gift dibandingkan dengan v7 dan tetap sama. Skrip installer dan Python yang diubah lolos pemeriksaan sintaks.
