#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
TASK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for TASK_TOOL in python3 openssl keytool jarsigner; do
  command -v "$TASK_TOOL" >/dev/null || {
    echo "Perintah $TASK_TOOL belum tersedia. Jalankan pada VPS yang sebelumnya berhasil build dengan key lama." >&2
    exit 1
  }
done
exec python3 "${TASK_DIR}/PINDAH_KEY_LAMA.py" ekspor "$@"
