#!/usr/bin/env python3
"""Simulate a sandbox receipt on the server, without putting the API key in shell history."""
import os
from pathlib import Path
import sys
from dotenv import dotenv_values


def main():
    if os.geteuid()!=0 or len(sys.argv)!=2:
        raise RuntimeError('Pemakaian di VPS backend: python SIMULASI_KIPAY_SANDBOX.py SBX-ID-DARI-RIWAYAT')
    env=dotenv_values('/etc/kocehind/backend.env')
    if env.get('KIPAY_MODE')!='sandbox':raise RuntimeError('Simulasi hanya diizinkan dalam mode sandbox.')
    for name in ('KIPAY_MODE','KIPAY_API_KEY','KIPAY_WEBHOOK_SECRET'):
        os.environ[name]=env.get(name) or ''
    sys.path.insert(0,'/opt/kocehind/backend')
    from app import kipay
    reference=sys.argv[1]
    if not kipay.valid_reference(reference) or not reference.startswith('SBX-'):
        raise RuntimeError('Gunakan ID SBX dari riwayat top up Kipay.')
    result=kipay.call('POST',reference,body={'provider':'shopeepay'},simulate=True)
    print('Simulasi dikirim. Status: '+str(result.get('status','belum diketahui')))
    print('Kembali ke web lalu Periksa pembayaran; saldo tetap melalui verifikasi backend.')


if __name__=='__main__':
    try:main()
    except Exception as exc:
        print('BELUM SELESAI: '+(str(exc) if isinstance(exc,RuntimeError) else 'Periksa mode sandbox, referensi, dan konfigurasi project.'))
        raise SystemExit(1)
