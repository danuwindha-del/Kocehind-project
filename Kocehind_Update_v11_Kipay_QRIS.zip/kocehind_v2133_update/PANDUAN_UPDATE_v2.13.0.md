> **Hotfix v8 (terbaru):** baca [HOTFIX_v8_FROZEN.md](HOTFIX_v8_FROZEN.md). Backend **2.13.0-gift2** menangani kolom Boolean wajib `frozen` pada dompet baru. 57 tes backend lulus, termasuk pengujian struktur empat tabel VPS yang diberikan. APK sekarang tetap kompatibel; dokumen rilis sebelumnya di bawah adalah riwayat.

> **Hotfix v7 (terbaru):** baca [HOTFIX_v7_GIFT.md](HOTFIX_v7_GIFT.md). Backend **2.13.0-gift1** memperbaiki pembuatan dompet penerima gift pada tabel lama yang mewajibkan `earnings_rupiah`. 51 tes backend lulus; APK tetap dapat digunakan. Dokumen rilis sebelumnya di bawah dipertahankan sebagai riwayat.

> **Hotfix v6 (terbaru):** baca [HOTFIX_v6_LEDGER.md](HOTFIX_v6_LEDGER.md). Backend **2.13.0-tripay2** mengisi kolom delta ledger lama yang sebelumnya menggagalkan kredit Tripay. 43 tes backend lulus. APK tidak perlu dibangun ulang untuk hotfix ini. Bagian rilis lama di bawah dipertahankan sebagai riwayat.

# Pembaruan hotfix v5 Tripay

Petunjuk terbaru ada pada **HOTFIX_v5_TRIPAY.md**. Setelah pembaruan ini health backend menunjukkan **2.13.0-tripay1**. Seluruh migrasi v4 di bawah tetap disertakan.

# Kocehind 2.13.0 — gift LIVE, dompet dan top up web

Android 2.13.0+31, backend 2.13.0. Paket mempertahankan source 2.12.7 dan builder yang memakai key lama. Google Play Billing **tidak dipasang**. Top up koin hanya melalui web dengan Tripay. Aplikasi tidak memiliki tombol, tautan, keterangan, atau ajakan top up ke web.

## Yang tersedia

- Username dapat diubah setiap 30 hari; nama setiap 7 hari. Jam dihitung server sejak perubahan berhasil, terpisah untuk kedua kolom. Bio/avatar tetap dapat diedit. Akun lama mendapat kesempatan perubahan pertama setelah pembaruan. Pengeditan yang gagal tidak memulai masa tunggu.
- Sembilan gift mengikuti harga pada gambar asli: Mawar 1, Hati 5, Koin Emas 10, Kado 50, Kembang Api 100, Tongkat 200, Mahkota 500, Mobil 1.000, Istana 5.000 koin. Mahkota/Mobil/Istana memakai video eksklusif asli; gambar tersedia sebagai fallback.
- Android: buka ikon gift saat menonton LIVE. Pengaturan → Koin dan pendapatan menampilkan saldo, pendapatan tersedia, dana penarikan terkunci, total pendapatan/pembayaran, aktivitas saldo dan riwayat penarikan. Dompet juga dapat dibuka dari LIVE.
- Web: Pengaturan → Koin dan pendapatan (`/wallet`) untuk membeli koin melalui Tripay. Tautan dompet/top up dari LIVE dibuka di tab baru agar koneksi LIVE tetap berlangsung. Setelah membayar, tekan Segarkan saldo pada pilihan gift.
- Penarikan hanya ke BRI, Bank Jago, DANA, ShopeePay, GO-PAY. Pengguna memeriksa nama, nomor, dan nominal sebelum mengajukan. Proses **1–2 hari kerja** merupakan antrean pembayaran manual pengelola.
- Dashboard admin → Gift dan penarikan: antrean, proses, penolakan, referensi transfer, paket koin, tarif pendapatan, rekonsiliasi pembayaran. Pengelola melakukan transfer terlebih dahulu, lalu mencatat pembayaran berhasil.
- Studio → LIVE: total gift, koin dan pendapatan; rincian gift/CSV; putar ulang, klip dan unduhan MP4 dengan efek gift. Rekaman tetap privat dan mengikuti retensi yang sudah ada, **7 hari**. Catatan transaksi keuangan tidak dihapus oleh kedaluwarsa rekaman.

## Memasang pada VPS backend/web aktif

**Catatan hotfix migrasi database:** revisi paket ini memperbaiki urutan pemuatan model dompet/gift dan mengganti nama constraint gift agar tidak berbenturan dengan relasi PostgreSQL yang sudah ada. Jika update sebelumnya berhenti dengan `DuplicateTable: relation "uq_gift_request" already exists`, gunakan paket revisi ini dan ulangi updater. **Jangan menghapus tabel, index, atau constraint secara manual.** Updater mencadangkan database/media sebelum menjalankan migrasi.


Akhiri semua LIVE sebelum pembaruan. Ekstrak paket penuh, lalu jalankan wrapper:

```bash
sudo python3 /root/kocehind_v2130_vps_baru/UPDATE_BACKEND_WEB.py
```

Atau dari source lengkap yang sudah diekstrak:

```bash
cd /root/kocehind_realtime_v2
sudo bash scripts/vps2_update_v213.sh
```

Pemasang mencadangkan database/media, memeriksa import sebagai user service, menjalankan migrasi tambahan dan memulihkan kode jika readiness gagal. TLS, konfigurasi rahasia dan key Android lama tetap mengikuti pemasang sebelumnya. Health setelah selesai harus menunjukkan `2.13.0`.

Migrasi `backend/migrate_v2_13.py` dapat diulang; tidak menghapus akun, konten atau saldo. Pengaturan default dibuat hanya jika belum ada. Jalankan updater versi baru, bukan menjalankan API baru di atas database yang belum dimigrasi.

## Mengaktifkan Tripay

Edit konfigurasi privat server:

```bash
sudoedit /etc/kocehind/backend.env
```

Tambahkan nilai merchant Anda sendiri:

```dotenv
TRIPAY_MODE=sandbox
TRIPAY_API_KEY=ISI_API_KEY_MERCHANT
TRIPAY_PRIVATE_KEY=ISI_PRIVATE_KEY_MERCHANT
TRIPAY_MERCHANT_CODE=ISI_KODE_MERCHANT
WEB_PUBLIC_URL=https://web.kocehind.web.id
```

`PUBLIC_BASE_URL` yang sudah ada harus menggunakan URL API publik, misalnya `https://api.kocehind.web.id`. Daftarkan callback merchant:

```text
https://api.kocehind.web.id/payments/tripay/callback
```

Aktifkan channel pembayaran merchant di Tripay. Gunakan kredensial sandbox selama pengujian. Ganti `TRIPAY_MODE=production` dan ketiga kredensial hanya setelah pengujian sandbox berhasil. Jangan memasukkan private key ke Flutter, JavaScript, atau berkas publik.

```bash
sudo systemctl restart kocehind-api
```

Koin hanya bertambah dari callback HMAC-SHA256 yang valid atau pemeriksaan API Tripay pada server. Redirect browser, tombol bayar dan perubahan status dari klien tidak menambah saldo. Referensi, metode dan nominal diverifikasi; transaksi/kunci permintaan dicatat untuk mencegah pemrosesan ulang.

Tagihan dengan timeout disimpan sebagai `unknown` dan menahan pembuatan tagihan lain. Admin mencari invoice di dashboard Tripay lalu memakai Verifikasi ke Tripay. Bila sudah dipastikan tidak ada pembayaran/tagihan aktif, admin dapat menutup tagihan tanpa referensi setelah minimal 5 menit. Callback sah yang terlambat masih dapat mengkreditkan pembayaran tepat satu kali.

Callback REFUND menarik kembali koin yang belum dipakai. Koin yang sudah dipakai dicatat sebagai penyesuaian utang koin dan diselesaikan oleh koin masuk berikutnya. Riwayat pendapatan host tidak otomatis dibatalkan oleh refund pembeli; admin perlu meninjau transaksi terkait sebelum membayar penarikan.

## Harga dan pendapatan awal

Default pengujian:

| Paket web | Harga sebelum biaya channel |
| --- | ---: |
| 100 koin | Rp10.000 |
| 500 koin | Rp50.000 |
| 1.000 koin | Rp100.000 |
| 5.000 koin | Rp500.000 |

Pendapatan host awal **Rp50 per koin gift**. Minimum penarikan **Rp50.000**. Semua nilai ini dapat diubah admin. Nilai pendapatan setiap gift disalin saat transaksi, sehingga perubahan tarif tidak mengubah transaksi lama. Harga gift tetap mengikuti artwork asli. Biaya channel ditampilkan pada tagihan Tripay sebelum pengguna membayar.

Koin belanja dan rupiah pendapatan adalah saldo terpisah. Koin tidak dapat ditarik langsung. Penarikan mengurangi pendapatan tersedia dan menambah saldo terkunci; penolakan mengembalikannya sekali, sedangkan pembayaran menutup saldo terkunci sekali.

## Rekaman LIVE dan gift

Perekaman memerlukan layanan LiveKit Egress/Studio yang sudah disediakan proyek. Bila belum terpasang:

```bash
sudo bash scripts/vps2_pasang_egress.sh
sudo systemctl enable --now kocehind-studio-worker
```

Pastikan `LIVE_RECORDING_ENABLED=true` dan `STUDIO_RECORDING_ROOT=/var/lib/kocehind/private-live` pada backend.env, lalu restart API dan Studio worker. Directory rekaman harus terpisah dari media publik. Pemasang update memasang font DejaVu untuk teks gift.

Setelah Egress selesai, Studio worker menggabungkan timeline gift dengan rekaman menggunakan FFmpeg. MP4 baru memuat artwork, video eksklusif, nama pengirim dan suara video gift; audio LIVE tetap ada. Perekaman memakai waktu awal capture dari Egress, bukan waktu pembukaan ruang. Gift sebelum capture dimulai tetap ada pada riwayat transaksi, tetapi tidak dapat menciptakan rekaman untuk waktu sebelum capture.

Selama proses, status `processing_gifts` belum dapat diunduh. Jika gagal setelah percobaan otomatis, Android menampilkan tombol mencoba proses ulang. Pada web, segarkan Studio untuk melihat status; endpoint pemilik untuk mencoba ulang adalah `POST /studio/live/{room_id}/retry-gifts`. Rekaman yang belum dikonfigurasi/kedaluwarsa tidak diklaim tersedia. Gift yang berdekatan dapat saling menutup sebagian efek visual; seluruh transaksi tetap tercatat pada riwayat/CSV.

## Android dan build

Pada VPS builder yang sudah mengimpor key lama:

```bash
bash /root/kocehind_v2130_vps_baru/BUILD_VPS_BARU.sh
```

Nomor build minimum 31 dan meningkat mengikuti riwayat lokal. Bila Google Play mempunyai nomor lebih tinggi, gunakan `--build-number` yang melampauinya melalui builder. Paket tidak berisi APK/AAB yang sudah dibangun. Login Google/Firebase tetap tersedia; fitur tersebut terpisah dari pembayaran dan tidak dihapus.

## Sumber integrasi dan pengujian

Kontrak pembayaran mengikuti dokumentasi resmi [TriPay Developer](https://tripay.co.id/developer): closed payment, transaction/create, transaction/detail, callback payment_status dan signature HMAC. Hasil aktual serta batas pengujian dicatat pada `PENGUJIAN_v2.13.0.md`.


## Hotfix migrasi revisi keempat (27 Oktober 2026)

- Log VPS: tabel `wallet_entries` telah ada tetapi belum memiliki `unit`, `delta`, `balance_after`, dan `held_after`.
- Menambahkan empat kolom sebagai nullable untuk menjaga detail riwayat lama tetap tidak diketahui, bukan mengarang delta/balance bernilai nol. Penulisan entri baru tetap mengisi semua kolom.
- UI web dan Flutter menampilkan keterangan untuk riwayat lama yang belum memiliki detail saldo.
- Migrasi menambahkan unique index idempotensi yang hilang hanya jika data yang ada tidak melanggar keunikan. Data duplikat tidak dihapus; migrasi berhenti dengan pesan diagnostik.
- Tes lokal SQLite tidak menggantikan pengujian langsung pada PostgreSQL produksi. Buat backup sebelum menjalankan updater.
