# Kocehind v2.12.7 — cache video dan panggung LIVE

Pembaruan lengkap untuk Android, backend dan web, dengan dasar v2.12.6 Backend Stabil R2. Aplikasi menjadi **2.12.7+30** (nomor build berikutnya tetap mengikuti riwayat lokal). Perbaikan stabilitas backend dan pemeriksaan izin pemasang R2 dipertahankan.

## Perubahan

1. **Feed berlanjut tanpa pesan kedaluwarsa.** Sesi yang masih ada dilanjutkan; cursor yang sudah hilang dipulihkan. Client mencoba satu halaman baru bila cursor dari sesi tamu/login sebelumnya ditolak, mempertahankan kartu dan posisi yang sedang ditonton.
2. **Cache video selama sesi aplikasi.** Video yang selesai diunduh digunakan kembali saat digeser kembali. Cache memakai file sementara; decoder tidak ditahan untuk semua video. Pemutaran pertama mengalir bertahap dan tidak menunggu seluruh file selesai.
3. **Tiga video berikutnya disiapkan.** Unduhan dipisahkan dari pemutar, mengabaikan kartu LIVE/foto, dan dibatasi agar video aktif tidak tertahan oleh pekerjaan latar.
4. **Preview LIVE menampilkan panggung bersama.** Host, tamu, kursi kosong, posisi dan fokus ikut ditampilkan. Preview tetap tanpa suara dan tidak mengaktifkan kamera/mikrofon penonton.
5. **Kamera memenuhi bidangnya.** Kamera solo mengisi layar; kamera peserta memakai cover tanpa ruang khusus kosong di bawah video. Rasio kamera yang berbeda dapat memotong tepi gambar.
6. **Foto profil LIVE diperbaiki.** Renderer foto yang sama dipakai pada preview dan ruang, perubahan foto disinkronkan, dan URL avatar lokal yang menyimpan token sementara diperbaiki. Foto kosong/gagal memiliki fallback sehingga bidang identitas tidak kosong.

## 1. VPS backend/web yang sudah aktif

Akhiri semua LIVE. Upload `KOCEHIND_FULL_v2.12.7_VIDEO_CACHE_LIVE.zip` ke `/root`, lalu:

```bash
unzip -o /root/KOCEHIND_FULL_v2.12.7_VIDEO_CACHE_LIVE.zip -d /root
sudo python3 /root/kocehind_v2127_vps_baru/UPDATE_BACKEND_WEB.py
```

Updater menggunakan pencadangan database/media, preflight sebagai user service, rollback kode dan pengaturan prioritas API yang sudah ada. Web juga dipasang. Migrasi menambahkan perbaikan URL avatar tanpa menghapus akun, video atau riwayat.

Periksa:

```bash
curl -fsS --max-time 10 http://127.0.0.1:8000/health
curl -fsS --max-time 10 http://127.0.0.1:8000/health/live
```

Versi backend harus `2.12.7`. Muat ulang tab web sesudah pembaruan agar seluruh modul memakai versi yang sama.

Jika menjalankan source langsung, gunakan `sudo bash scripts/vps2_update_v2127.sh`. Gunakan updater pada VPS backend yang sudah terpasang.

## 2. VPS build Android

Upload dan ekstrak ZIP yang sama pada VPS build. Jika key lama sudah diimpor:

```bash
bash /root/kocehind_v2127_vps_baru/BUILD_VPS_BARU.sh
```

**APK/AAB harus dibangun ulang** dan APK baru harus dipasang agar perubahan Android aktif. Key lama, package, konfigurasi Google/Firebase dan profil `~/.kocehind-portable` tetap dipakai. Tidak perlu membuat key atau memasukkan ulang konfigurasi.

Nomor build minimal 30, lalu dinaikkan dari riwayat lokal. Jika Play Console sudah memakai nomor lebih tinggi, gunakan `--build-number` yang melampauinya. Ambil APK/AAB dari lokasi `HASIL_TERVERIFIKASI` yang dicetak setelah build berhasil.

Untuk VPS build yang belum mengimpor key, petunjuk pemindahan satu kali ada di `MULAI_DI_SINI.txt`. Jangan mengganti keystore lama.

Publikasi APK web dengan sertifikat Google Play tetap menggunakan `PUBLIKASI_APK_PLAY.py` dan APK universal Play yang sesuai; panduan lama `PANDUAN_APK_WEB_GOOGLE_PLAY.md` tetap berlaku.

## Cara cache bekerja

Cache Android berlaku untuk proses aplikasi yang sedang terbuka. Keluar akun atau perubahan akses membersihkan cache terkait. Menutup proses aplikasi dan membuka kembali memulai cache baru; cache lama yang tertinggal karena proses dimatikan dibersihkan saat sesi baru dimulai. Android hanya mengizinkan HTTP loopback privat untuk pemutaran cache; API publik tetap memakai HTTPS.

Cache web dipisahkan per tab/sesi dan tidak menjadi unduhan offline permanen. Byte tersimpan tetap diperiksa aksesnya melalui permintaan HEAD. Tab/sesi yang sudah mati dibersihkan pada sesi berikutnya jika browser ditutup paksa sebelum sempat mengirim pembersihan.

Pemeriksaan izin, metadata dan inisialisasi decoder masih dapat memerlukan waktu singkat. Video yang belum selesai diunduh, koneksi yang lebih lambat daripada konsumsi video, atau penyimpanan sementara yang penuh tetap dapat membutuhkan loading. Ini bukan jaminan tanpa loading pada setiap perangkat/jaringan. Moderasi dan privasi tidak dimatikan untuk mempercepat pemutaran.

## Periksa pada perangkat

- Tonton satu video hingga selesai, lanjut beberapa video, lalu geser kembali. Periksa tidak ada unduhan ulang byte video yang sudah lengkap.
- Putus/tutup proses aplikasi, buka kembali, dan pastikan sesi baru tidak memakai file sesi sebelumnya.
- Tonton satu video cukup lama untuk mengunduh tiga video setelahnya; lalu geser maju.
- Buka preview LIVE host + satu tamu dan host + delapan tamu. Ubah posisi/fokus dan pastikan preview ikut berubah.
- Periksa kamera solo memenuhi layar dan foto profil tampil pada LIVE audio maupun kamera yang dimatikan.
- Periksa logout, blokir, ban, perubahan privasi dan konten yang dihapus tetap menolak akses.

Hasil lokal dan batas pengujian terdapat pada `PENGUJIAN_v2.12.7.md`. Paket ini berisi source dan alat pembaruan; deployment VPS, media SFU langsung dan build APK/AAB dengan key produksi dijalankan pada lingkungan Anda.
