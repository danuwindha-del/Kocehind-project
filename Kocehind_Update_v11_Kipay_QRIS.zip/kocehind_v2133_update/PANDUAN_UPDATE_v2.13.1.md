# Kocehind v2.13.1 — update v9

Melanjutkan paket `Kocehind_Hotfix_v8_Frozen_Gift.zip`. Backend terbaru:
**2.13.1-live**. Source Flutter: **2.13.1+32**; builder menggunakan nomor
build minimal 32 dan menaikkannya lagi bila riwayat build lama lebih tinggi.

## Perubahan

- Semua gift yang berhasil dikirim membuat satu komentar LIVE, termasuk
  nama pengirim, nama gift, ikon, dan jumlah. Gift gagal tidak membuat komentar.
  Komentar, receipt gift, ledger, dan saldo disimpan dalam transaksi yang sama.
  Retry dengan kunci transaksi sama tidak menggandakan komentar atau saldo.
- Enam gift biasa (Mawar, Hati, Koin Emas, Kado, Kembang Api, Tongkat) hanya
  muncul di komentar. Tiga gift video eksklusif (Mahkota, Mobil, Istana) juga
  tampil sebagai animasi layar. Rekaman gift mempertahankan keterangan teks
  semua gift dan hanya memakai video eksklusif sebagai efek gambar layar.
- Nama tampilan dapat diubah setiap 7 hari, username setiap 30 hari. Tanggal
  dihitung terpisah dari perubahan terakhir masing-masing field. Field yang
  masih menunggu dibuat readonly; nama yang sudah tersedia tetap dapat diedit
  meski username terkunci. Bio/foto tetap dapat disimpan selama masa tunggu.
- Host dapat menambah gambar galeri dan teks selama LIVE. Teks memiliki pilihan
  biasa atau berbackground, warna background, warna teks, dan ukuran. Gambar
  dan teks dapat diubah ukuran, digeser di dalam area siaran, dihapus, dan
  dibawa ke depan. Maksimal 12 elemen per LIVE, gambar maksimal 10 MB.
- Posisi memakai proporsi area siaran agar konsisten pada perangkat berbeda.
  Host, penonton, peserta yang bergabung kembali, dan pratinjau LIVE membaca
  state yang sama. Sinkronisasi mengikuti polling LIVE yang sudah ada; bukan
  dibakar ke track kamera. Rekaman Studio belum merekam gambar/teks tambahan.

## 1. Update backend dan web yang sudah terpasang

Akhiri LIVE aktif. Upload ZIP update ke `/root` pada VPS backend/web, lalu:

```bash
sudo -i
unzip -o /root/Kocehind_Update_v9_Live_Gift_Profil.zip -d /root
cd /root/kocehind_v2131_vps_baru
sha256sum -c SHA256SUMS.txt
python3 UPDATE_BACKEND_WEB.py
curl -fsS --max-time 15 http://127.0.0.1:8000/health
```

Lanjutkan hanya jika pemeriksaan checksum sukses. Health sesudah update harus
menunjukkan `2.13.1-live`. Skrip memakai alur backup database/media, pemeriksaan
service, migrasi dan rollback kode yang sudah ada. Migrasi menambahkan tabel
`live_overlay_states`; tidak mereset saldo, riwayat gift, atau jam perubahan
profil. Tidak ada key atau konfigurasi merchant baru di paket ini.

Untuk instalasi backend yang dikelola manual: ekstrak source, perbarui kode
backend, jalankan rantai `python migrate_v2_13.py` sesuai environment backend,
kemudian perbarui web dan restart layanan terkait. Jangan mengganti `.env`
produksi menggunakan contoh konfigurasi paket.

## 2. Build dan pasang Android terbaru

**APK lama belum memiliki editor galeri/teks dan filter gift terbaru.** Build
ulang diperlukan, kemudian pasang versi baru pada perangkat host dan penonton.
Paket ini menyertakan source dan builder, bukan APK/AAB yang sudah ditandatangani.
Gunakan identitas aplikasi dan key penandatanganan lama agar update dapat
menimpa aplikasi lama.

Jika VPS build baru sudah memakai alur key portabel paket sebelumnya, letakkan
`KOCEHIND_KEY_LAMA.enc` hasil ekspor sendiri di home VPS build, lalu:

```bash
cd /root/kocehind_v2131_vps_baru
bash BUILD_VPS_BARU.sh
```

Ikuti input builder untuk key lama dan konfigurasi yang sudah digunakan.
`PINDAH_KEY_LAMA.py`, `latest_build.py`, dan `PUBLIKASI_APK_PLAY.py` membaca
`SOURCE_LENGKAP_v2.13.1.zip` serta checksum dalam `package.json` secara otomatis.
Jangan membuat key pengganti untuk aplikasi yang sudah diterbitkan.

## 3. Cara memakai gambar dan teks LIVE

1. Host memulai LIVE, lalu membuka **Gambar & teks LIVE** (Android) atau
   **Gambar & teks** (web). Pada Android, tombol ada di bar kontrol bawah yang
   dapat digeser mendatar; bar kontrol web juga dapat digulir di layar kecil.
2. Pilih **Gambar galeri** untuk memilih dan mengunggah gambar perangkat.
3. Pilih **Teks**, isi teks, pilih versi biasa/berbackground, dan warna.
   Atur lebar, tinggi, serta ukuran teks. Simpan ke LIVE.
4. Pilih **Geser di layar**, geser elemen ke posisi yang diinginkan, lalu pilih
   **Selesai geser**. Posisi tersimpan setelah jari/pointer dilepas.
5. Jika elemen tertutup elemen lain, buka pengaturan dan pilih **Bawa ke depan**
   (Android) atau **Ke depan** (web). Ketuk elemen pada daftar untuk mengedit;
   gunakan tombol hapus untuk menghilangkannya.

Hanya host boleh mengubah elemen; moderator dan penonton hanya melihatnya.
Bila dua perangkat host mengubah state bersamaan, server menolak versi lama
agar perubahan terbaru tidak tertimpa. Muat kembali pengaturan setelah pesan
konflik. Gambar siaran dibuat sebagai salinan yang sudah dinormalisasi, tanpa
membuka akses ke URL unggahan privat asli; akses salinan berhenti ketika LIVE
berakhir, elemen dihapus, atau host diblokir dari layanan.

## 4. Uji setelah pemasangan

Gunakan dua akun/perangkat dengan aplikasi terbaru:

- Kirim Mawar satu kali: muncul satu komentar pada host dan penonton; tanpa
  popup layar. Kirim Mahkota: muncul komentar dan animasi video eksklusif.
- Host menambah gambar galeri dan dua teks (biasa/berbackground), memilih warna,
  lalu menggesernya. Penonton dan pengguna yang bergabung kembali harus melihat
  posisi dan warna yang sama. Uji edit, ukuran, bawa ke depan, dan hapus.
- Periksa profil: nama dan username memiliki tanggal tersedia masing-masing;
  nama yang sudah melewati 7 hari dapat disimpan meski username belum 30 hari.
- Periksa saldo, pendapatan, riwayat gift, serta sinkronisasi pembayaran seperti
  pada v8. Jangan mengubah jam database produksi untuk menguji masa tunggu.

Hasil pengujian lingkungan pengembangan tercatat pada `PENGUJIAN_v2.13.1.md`.
