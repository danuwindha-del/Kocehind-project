# Pengujian Kocehind v2.12.7

Tanggal: 26 Oktober 2026. Dasar source: v2.12.6 Backend Stabil R2.

## Hasil aktual

| Pemeriksaan | Hasil |
|---|---|
| Seluruh tes backend | **305 lulus, 7 dilewati** |
| Flutter analyze, Flutter 3.47.8 / Dart 3.13.7 | **Tidak ada masalah** |
| Seluruh tes Flutter | **114 lulus** |
| Regresi tambahan setelah perubahan akhir pada pemulihan/privasi | **12 lulus** pada tes pemulihan cursor, preview dan regresi feed/LIVE |
| Build bundle Flutter debug, target linux-x64 | **Berhasil**; kompilasi aplikasi dan aset, bukan APK produksi |
| Tes web non-browser, 13 berkas | **110 lulus** |
| Tes cache Dart dengan HTTP dan filesystem nyata | **Lulus**: streaming bertahap, range/suffix range, replay satu unduhan, prefetch tiga video, slot foreground, penghapusan/clear/close |
| Sintaks shell dan Python | **Lulus** |
| Guard patch LiveKit 2.6.4 yang sudah ada | **Lulus**, termasuk backup dan idempotensi |
| Lint DESIGN.md | **0 kesalahan** |

## Perintah utama

Dari direktori source:

```bash
bash scripts/periksa_source.sh
cd backend
python -m pytest -q --disable-warnings
```

Lingkungan pengujian backend memasang requirements proyek serta dependensi pengembangan `pytest`, `pytest-asyncio`, `httpx`, dan `numpy`. Pengujian memakai SQLite/media sementara; jangan arahkan tes ke database produksi.

Dari `flutter/`, setelah `flutter pub get`, jalankan patch kompatibilitas LiveKit yang memang sudah dipakai pipeline build:

```bash
python3 scripts/fix_livekit_compat.py
python3 scripts/test_livekit_compat.py
flutter analyze --no-pub
flutter test --no-pub --concurrency=1
flutter build bundle --no-pub --debug --target-platform=linux-x64
dart --disable-dart-dev tool/test_session_video_cache.dart
```

Tes DOM/worker web memakai Node 24 dan jsdom 26.1.0; 13 berkas tes non-browser dijalankan dengan `node --test --test-force-exit`. Tes baru utama adalah `websites/web/test-feed-preview-v2127.mjs`, dan tes pemulihan cursor ada pada `test-v210-session.mjs`.

## Yang diperiksa

- Cursor feed kedaluwarsa melanjutkan urutan sebelumnya; cursor yang sudah dihapus memulai halaman baru dengan pengecualian kartu yang sudah dimuat.
- Cursor identitas lain tetap ditolak server. Client memulihkan satu kali tanpa mengubah kartu aktif, serta tidak mengulang penolakan 403 atau mengulang 400 tanpa batas.
- Cache Dart mulai memberikan byte sebelum server menyelesaikan seluruh video. Replay dan seek memakai byte tersimpan; pergantian token tidak mengunduh ulang video yang sama.
- Prefetch mengabaikan video keempat dan tidak menahan koneksi video foreground. Cache dihapus ketika di-evict, di-clear, dan ditutup.
- Cache worker web memisahkan tab/sesi, memberikan range dari data yang sama, serta meminta HEAD dan menolak byte ketika izin dicabut.
- Preview memuat host, speaker dan susunan kursi tanpa membocorkan daftar penonton atau undangan. Token preview tetap tidak boleh menerbitkan audio/video.
- Renderer Flutter/DOM menampilkan host, tamu, kursi kosong, foto/fallback dan perubahan avatar. Fokus dan perpindahan susunan tidak mengganti elemen video yang masih sama.
- Permukaan solo memakai seluruh viewport; kamera memakai cover. Geometri grid/dua kursi/fokus yang sudah ada tetap lulus.
- Penyimpanan avatar menghapus token playback sementara; migrasi lama dapat dijalankan dua kali.
- Alur follow, komentar, guest, sesi, inbox, privasi, moderasi dan installer R2 mengikuti regresi proyek yang tersedia.

## Batas bukti

Tes backend yang dilewati memerlukan PostgreSQL atau lingkungan eksternal tertentu. Panggilan SFU/model yang memerlukan server produksi diisolasi pada tes terkait. Kamera fisik, suara/mikrofon nyata, kualitas jaringan seluler, dan deployment VPS pengguna belum diuji.

Percobaan menjalankan suite Chromium lokal terhalang pembatasan socket lingkungan sebelum browser membuka halaman. Karena itu **suite browser E2E tidak diklaim lulus**. Sebagai cakupan yang benar-benar dijalankan, laporan menggunakan 110 tes DOM/worker, tes Flutter, pemeriksaan geometri dan kompilasi bundle. Build APK/AAB produksi memerlukan toolchain Android dan key asli pengguna di VPS build.

Audit UI generik dijalankan dalam mode strict; hasil mentah dan perbandingan baseline tersedia di `docs/verification/ui-audit-v2127.json`. Audit tidak bersih: baseline memiliki 20 temuan statis, versi ini 24. Empat heuristik tambahan menunjuk tombol pengelolaan tamu lama setelah ekstraksi renderer; tombol tersebut tetap dihubungkan melalui handler `data-guest`. Temuan form lama dan heuristik tombol dinamis tidak disamarkan sebagai kepatuhan seluruh produk. Tidak ada hasil audit statis yang dianggap sebagai bukti kamera/SFU produksi.

Kecepatan sesungguhnya bergantung pada ukuran video, bandwidth, decoder dan ruang cache perangkat. Video yang belum selesai diunduh masih dapat menunggu jaringan. Cache tidak menjadikan konten privat tersedia di luar izin yang berlaku.
