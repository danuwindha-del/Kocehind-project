> **Hotfix v8 (terbaru):** baca [HOTFIX_v8_FROZEN.md](HOTFIX_v8_FROZEN.md). Backend **2.13.0-gift2** menangani kolom Boolean wajib `frozen` pada dompet baru. 57 tes backend lulus, termasuk pengujian struktur empat tabel VPS yang diberikan. APK sekarang tetap kompatibel; dokumen rilis sebelumnya di bawah adalah riwayat.

> **Hotfix v7 (terbaru):** baca [HOTFIX_v7_GIFT.md](HOTFIX_v7_GIFT.md). Backend **2.13.0-gift1** memperbaiki pembuatan dompet penerima gift pada tabel lama yang mewajibkan `earnings_rupiah`. 51 tes backend lulus; APK tetap dapat digunakan. Dokumen rilis sebelumnya di bawah dipertahankan sebagai riwayat.

> **Hotfix v6 (terbaru):** baca [HOTFIX_v6_LEDGER.md](HOTFIX_v6_LEDGER.md). Backend **2.13.0-tripay2** mengisi kolom delta ledger lama yang sebelumnya menggagalkan kredit Tripay. 43 tes backend lulus. APK tidak perlu dibangun ulang untuk hotfix ini. Bagian rilis lama di bawah dipertahankan sebagai riwayat.

# Pengujian Kocehind 2.13.0

Tanggal: 27 Oktober 2026 (Asia/Jakarta). Pengujian memakai source lokal, database SQLite terisolasi, mailbox uji, callback/API Tripay tiruan dan rekaman sintetis. Tidak ada uang atau pesan pengguna yang dikirim.

## Hasil fitur baru

`backend/tests/test_wallet_v213.py`: **10 lulus**. Mencakup masa tunggu nama/username dan batas 7/30 hari, edit bio tanpa mengganti identitas, signature/nominal/metode pembayaran salah, callback berulang, timeout tagihan, penolakan tagihan yang pasti, penutupan invoice oleh admin, pengembalian pembayaran dan penyesuaian koin, gift video, saldo tidak cukup, larangan gift diri sendiri, otorisasi riwayat/CSV, penarikan terkunci, penolakan/pembayaran tepat sekali, serta penolakan akses admin tanpa peran.

Pengujian rekaman menjalankan FFmpeg/FFprobe sungguhan pada video 640×360 dengan audio. Artwork dan video Mahkota dimasukkan pada waktu tertentu; frame hasil berbeda dari sumber dan stream audio/video tetap ada. Transisi Egress selesai → processing_gifts → worker → ready dan endpoint unduhan privat juga diuji.

`websites/web/test-wallet-v213-browser.mjs`: **3 lulus** di Chromium headless. Memeriksa dompet responsif pada lebar 412 px, pembuatan tagihan web, pilihan lima metode penarikan, kunci gift yang sama saat retry setelah respons tak pasti, tautan top up tab baru, dan tindakan admin sampai referensi transfer tercatat. Tampilan dompet ponsel/admin desktop ditinjau secara visual memakai data tiruan.

## Regresi dan pemeriksaan source

Suite backend terpilih: **79 lulus, 1 dilewati**. Meliputi Studio, LIVE, media LIVE, tata layar, sosial, akun 2.12, migrasi, preview 2.12.7, staging dengan umask, dan startup nyata dua worker. Setelah itu suite dompet dijalankan ulang: 10 lulus termasuk keseluruhan worker rekaman gift.

Migrasi tambahan dijalankan dua kali di database uji: berhasil, empat paket awal tetap tunggal. Source Python dikompilasi dan shell installer diperiksa dengan `bash -n`. Seluruh **51 file Dart** lolos parser sintaks tree-sitter. JavaScript yang diubah lolos `node --check`.

Hasil browser lengkap dicatat pada bagian verifikasi paket di bawah. Pengujian legal/login lama menunjukkan timeout navigasi pada Chromium uji; satu skenario yang sama juga timeout pada source 2.12.7 sebelum perubahan. Hasil ini tidak diperlakukan sebagai kelulusan autentikasi menyeluruh.

## Batas yang belum diuji

- Flutter SDK/Android SDK tidak tersedia di runtime ini. `flutter analyze`, tes widget, build, instalasi APK/AAB dan tampilan fisik Android belum dijalankan. Parser sintaks tidak menggantikan pemeriksaan tipe Flutter.
- Belum ada pembayaran Tripay sandbox/production sungguhan, kredensial merchant, callback dari internet, atau transfer bank/e-wallet. Default harga/tarif adalah konfigurasi awal pengujian.
- Belum menguji dua perangkat pada SFU/LiveKit/Egress produksi atau durasi rekaman panjang. Worker diuji memakai input media lokal dan metadata Egress tiruan.
- Penguncian baris PostgreSQL dipakai pada jalur uang, tetapi uji konkurensi lintas proses PostgreSQL belum dijalankan di lingkungan ini. SQLite tidak membuktikan perilaku `SELECT FOR UPDATE` PostgreSQL.
- Paket belum diterapkan ke VPS pengguna dan tidak menyertakan APK/AAB produksi. Pemeriksaan pemasang lokal tidak menjalankan update pada server aktif.

## Menjalankan ulang

```bash
cd kocehind_realtime_v2
python3 -m venv .venv
.venv/bin/pip install -r backend/requirements.txt pytest httpx
.venv/bin/python -m pytest -q backend/tests/test_wallet_v213.py
npm ci
CHROMIUM_EXECUTABLE=/path/to/chromium node --test --test-force-exit websites/web/test-wallet-v213-browser.mjs
```

Di lingkungan Flutter lengkap, jalankan `flutter pub get`, `flutter analyze`, tes Flutter yang relevan, lalu builder Android sebelum membagikan APK/AAB ke penguji.

## Verifikasi paket

Suite web lengkap dijalankan berurutan pada Chromium 153: **128 lulus, 2 gagal dari 130**. Keduanya merupakan tes browser lama: pemutaran WebM yang menunggu `currentTime > 1.3` dan skenario pergantian login/consent yang timeout pada batas 3 detik. Skenario WebM sempat lulus pada pengujian subset; skenario login juga menunjukkan timeout saat dijalankan pada source asli 2.12.7 dengan browser yang sama. Kedua hasil tetap dicatat sebagai gagal, bukan diabaikan. Tiga tes browser dompet/gift/admin baru lulus pada suite lengkap dan pada run mandiri.

Arsip sumber dan pembungkus memakai SHA-256 yang diperbarui. ZIP diperiksa CRC, entri path, kelengkapan aset, migrasi dan versi builder sebelum disimpan. Verifikasi ini memastikan konsistensi paket, bukan keberhasilan deploy/build produksi.


## Hotfix migrasi revisi keempat (27 Oktober 2026)

- Log VPS: tabel `wallet_entries` telah ada tetapi belum memiliki `unit`, `delta`, `balance_after`, dan `held_after`.
- Menambahkan empat kolom sebagai nullable untuk menjaga detail riwayat lama tetap tidak diketahui, bukan mengarang delta/balance bernilai nol. Penulisan entri baru tetap mengisi semua kolom.
- UI web dan Flutter menampilkan keterangan untuk riwayat lama yang belum memiliki detail saldo.
- Migrasi menambahkan unique index idempotensi yang hilang hanya jika data yang ada tidak melanggar keunikan. Data duplikat tidak dihapus; migrasi berhenti dengan pesan diagnostik.
- Tes lokal SQLite tidak menggantikan pengujian langsung pada PostgreSQL produksi. Buat backup sebelum menjalankan updater.
