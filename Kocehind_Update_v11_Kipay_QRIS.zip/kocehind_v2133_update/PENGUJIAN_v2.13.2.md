# Pengujian Kocehind 2.13.2 / update v10

## Hasil aktual di lingkungan pengembangan

- **73 tes backend lulus**, menggunakan SQLite, HTTP API nyata, serta mock layanan eksternal. Mencakup LIVE, gift, transaksi retry, total pendapatan historis, Top 3, akses host/admin, katalog publik, skema dompet lama dan sinkronisasi TriPay.
- **13 pemeriksaan web lulus**, termasuk empat pengujian Chromium nyata: homepage publik dan harga aktif pada viewport 360/1440 piksel; kegagalan katalog; preview profil sendiri/orang lain; ringkasan akhir LIVE tanpa callback panggung yang tertinggal. Tes lain memeriksa rendering, escaping, total kosong, love dan gift canvas.
- Sintaks Python dan shell pemasang diperiksa. Integritas ZIP, source payload dan manifest diverifikasi saat pengemasan.
- Tidak diterapkan ke VPS pengguna. Tidak mengirim pembayaran, push, atau email sungguhan. PostgreSQL/SFU/perangkat Android produksi belum diuji pada perubahan ini.

## Batas Flutter

Source Android disertakan, tetapi uji Flutter lengkap dan build APK/AAB produksi belum dijalankan di sini. Peninjauan otomatis menolak inisialisasi SDK Flutter ketika proses secara tak terduga mencoba mengakses alamat metadata instance 169.254.169.254. Proses tersebut tidak dicoba ulang atau dialihkan untuk melewati penolakan. Build dan uji APK perlu dilakukan di VPS build milik pengguna dengan keystore lama.

## Menjalankan pemeriksaan

Backend: pasang backend/requirements.txt, pytest dan httpx dalam virtualenv; jalankan test_live.py, test_live_summary_v2132.py, test_live_canvas_v2131.py, test_wallet_v213.py, test_wallet_legacy_accounts_v213.py, test_wallet_legacy_ledger_v213.py, test_wallet_vps_schema_v213.py dan test_tripay_sync_v213.py dari backend/tests.

Web: npm install, lalu gunakan node --test dengan test-v2132-browser.mjs, test-summary-profile-v2132.mjs, test-live-canvas-v2131.mjs, test-live-loves.mjs dan websites/main/test-legal-content.mjs. Untuk Chromium lokal, set CHROMIUM_EXECUTABLE ke executable yang tersedia. Ini tidak membutuhkan browser/CDN produksi.
